#!/usr/bin/env bash
set -Eeuo pipefail

readonly PATCHER="/usr/local/lib/wittypi5-webserver/patch_navigation.py"
find_allsky() {
    local base
    systemctl show --property=LoadState --value allsky.service 2>/dev/null | \
        grep -Fxq loaded || return 1
    for base in /home/allsky /home/*/allsky /opt/allsky; do
        [[ -f "$base/html/index.php" ]] && { printf '%s\n' "$base"; return 0; }
    done
    return 1
}

allsky_home="$(find_allsky || true)"
[[ -n "$allsky_home" ]] || { echo "Allsky-Homepage noch nicht gefunden; erneuter Versuch beim nächsten Boot." >&2; exit 1; }
if [[ -x /usr/local/sbin/witty-allsky-trixie-compat ]]; then
    /usr/local/sbin/witty-allsky-trixie-compat repair
fi
python3 "$PATCHER" --kind allsky --file "$allsky_home/html/index.php"

# A later web installation must receive the same start ordering as an Allsky
# selection made in the main installer. Use whichever clock service is present.
time_unit=""
if [[ -f /etc/systemd/system/wurb-rtc-sync.service ]]; then
    time_unit="wurb-rtc-sync.service"
elif [[ -f /etc/systemd/system/wurb-witty-hctosys.service ]]; then
    time_unit="wurb-witty-hctosys.service"
fi
if [[ -n "$time_unit" ]]; then
    mkdir -p /etc/systemd/system/allsky.service.d /etc/systemd/system/allskyperiodic.service.d
    cat > /etc/systemd/system/allsky.service.d/witty-time.conf <<EOF
[Unit]
Wants=$time_unit
After=$time_unit
EOF
    cp /etc/systemd/system/allsky.service.d/witty-time.conf \
        /etc/systemd/system/allskyperiodic.service.d/witty-time.conf
fi
if [[ -f /etc/systemd/system/wurb-hotspot-start.service ]]; then
    mkdir -p /etc/systemd/system/allsky.service.d /etc/systemd/system/allskyperiodic.service.d
    cat > /etc/systemd/system/allsky.service.d/hotspot.conf <<'EOF'
[Unit]
Wants=wurb-hotspot-start.service
After=wurb-hotspot-start.service
EOF
    cp /etc/systemd/system/allsky.service.d/hotspot.conf \
        /etc/systemd/system/allskyperiodic.service.d/hotspot.conf
fi
for project in /home/wurb/wurb_2026 /home/pi/wurb_2026 /opt/wurb_2026; do
    if [[ -f "$project/wurb_app/templates/index.html" ]]; then
        python3 "$PATCHER" --kind wurb --file "$project/wurb_app/templates/index.html"
        break
    fi
done
for project in /home/wurb/wirc_2026 /home/pi/wirc_2026 /opt/wirc_2026; do
    if [[ -f "$project/wirc_app/templates/index.html" ]]; then
        python3 "$PATCHER" --kind wirc --file "$project/wirc_app/templates/index.html"
        break
    fi
done
systemctl reload lighttpd.service 2>/dev/null || systemctl try-restart lighttpd.service 2>/dev/null || true
systemctl daemon-reload
systemctl disable wittypi5-allsky-firstboot.service >/dev/null 2>&1 || true
echo "Allsky-Navigation einmalig ergänzt: $allsky_home/html/index.php"
