#!/usr/bin/env bash
set -Eeuo pipefail

readonly PATCHER="/usr/local/lib/wittypi5-webserver/patch_navigation.py"
readonly PREFIX="[Witty-Allsky-FirstBoot]"

log() { printf '%s %s\n' "$PREFIX" "$*"; }
die() { printf '%s FEHLER: %s\n' "$PREFIX" "$*" >&2; exit 1; }

unit_loaded() {
    [[ "$(systemctl show --property=LoadState --value "$1" 2>/dev/null || true)" == loaded ]]
}

find_allsky() {
    local base
    unit_loaded allsky.service || return 1
    for base in /home/allsky /home/*/allsky /opt/allsky; do
        [[ -f "$base/html/index.php" ]] && { printf '%s\n' "$base"; return 0; }
    done
    return 1
}

patch_page() {
    local kind="$1" file="$2"
    [[ -f "$file" ]] || return 0
    python3 "$PATCHER" --kind "$kind" --file "$file"
    log "Homepage-Navigation aktualisiert: $file"
}

[[ -x "$PATCHER" || -f "$PATCHER" ]] || die "Navigations-Patcher fehlt: $PATCHER"

allsky_home=""
for attempt in $(seq 1 45); do
    allsky_home="$(find_allsky || true)"
    [[ -z "$allsky_home" ]] || break
    (( attempt == 1 || attempt % 10 == 0 )) && \
        log "Warte auf die fertig eingerichtete Allsky-Homepage (${attempt}/45) ..."
    sleep 2
done
[[ -n "$allsky_home" ]] || die "Allsky-Homepage wurde innerhalb von 90 Sekunden nicht gefunden; systemd versucht es erneut."

# Der frühe Boot kann die aktivierten Dienste durch die Before-Abhängigkeit
# noch zurückhalten. Deshalb gilt enabled ODER active als späterer Startauftrag.
declare -A restart_unit=()
managed_units=(
    allskyperiodic.timer
    allskyperiodic.service
    allsky.service
)
for unit in "${managed_units[@]}"; do
    unit_loaded "$unit" || continue
    if systemctl is-enabled --quiet "$unit" 2>/dev/null || systemctl is-active --quiet "$unit"; then
        restart_unit["$unit"]=yes
    fi
done

log "Halte ausschließlich die Allsky-Dienste für die Allsky-Aktualisierung an ..."
for unit in "${managed_units[@]}"; do
    unit_loaded "$unit" || continue
    systemctl is-active --quiet "$unit" || continue
    timeout 45s systemctl stop "$unit" || die "$unit konnte nicht angehalten werden."
done

if [[ -x /usr/local/sbin/witty-allsky-trixie-compat ]]; then
    timeout --foreground --kill-after=20s 240s \
        /usr/local/sbin/witty-allsky-trixie-compat repair
fi

patch_page allsky "$allsky_home/html/index.php"
timeout 20s php -l "$allsky_home/html/index.php" >/dev/null 2>&1 || \
    die "Die Allsky-Hauptseite enthält nach der Anpassung einen PHP-Syntaxfehler."

time_unit=""
if [[ -f /etc/systemd/system/wurb-rtc-sync.service ]]; then
    time_unit="wurb-rtc-sync.service"
elif [[ -f /etc/systemd/system/wurb-witty-hctosys.service ]]; then
    time_unit="wurb-witty-hctosys.service"
fi
if [[ -n "$time_unit" ]]; then
    mkdir -p /etc/systemd/system/allsky.service.d /etc/systemd/system/allskyperiodic.service.d
    cat > /etc/systemd/system/allsky.service.d/witty-time.conf <<EOF
[Unit]
Wants=$time_unit
After=$time_unit
EOF
    cp /etc/systemd/system/allsky.service.d/witty-time.conf \
        /etc/systemd/system/allskyperiodic.service.d/witty-time.conf
fi
if [[ -f /etc/systemd/system/wurb-hotspot-start.service ]]; then
    mkdir -p /etc/systemd/system/allsky.service.d /etc/systemd/system/allskyperiodic.service.d
    cat > /etc/systemd/system/allsky.service.d/hotspot.conf <<'EOF'
[Unit]
Wants=wurb-hotspot-start.service
After=wurb-hotspot-start.service
EOF
    cp /etc/systemd/system/allsky.service.d/hotspot.conf \
        /etc/systemd/system/allskyperiodic.service.d/hotspot.conf
fi

systemctl daemon-reload

start_if_requested() {
    local unit="$1"
    [[ "${restart_unit[$unit]:-}" == yes ]] || return 0
    systemctl reset-failed "$unit" 2>/dev/null || true
    timeout 60s systemctl start "$unit" || \
        die "$unit konnte nach der Homepage-Aktualisierung nicht gestartet werden."
    systemctl is-active --quiet "$unit" || die "$unit ist nach dem Start nicht aktiv."
    log "Dienst aktiv: $unit"
}

start_if_requested allsky.service
start_if_requested allskyperiodic.timer

wait_for_http() {
    local label="$1" url="$2" attempt response_file
    response_file="$(mktemp /var/tmp/witty-http-check.XXXXXX)"
    for attempt in $(seq 1 30); do
        if curl --noproxy '*' --location --fail --silent --show-error --max-time 5 \
                --output "$response_file" "$url" && [[ -s "$response_file" ]] && \
                ! grep -Fq '<?php' "$response_file"; then
            log "Webprüfung erfolgreich: $label ($url)"
            rm -f -- "$response_file"
            return 0
        fi
        sleep 1
    done
    rm -f -- "$response_file"
    die "$label antwortet nach der Homepage-Aktualisierung nicht unter $url."
}

wait_for_http "Allsky-Homepage" "http://127.0.0.1/"
wait_for_http "Allsky-PHP-Weboberfläche" "http://127.0.0.1/allsky/index.php"

systemctl disable wittypi5-allsky-firstboot.service >/dev/null 2>&1 || true
log "Die Allsky-Homepage-Anpassung ist abgeschlossen; der einmalige Boot-Finalisierer ist deaktiviert."
