#!/usr/bin/env bash
set -Eeuo pipefail

readonly PATCHER="/usr/local/lib/wittypi5-webserver/patch_navigation.py"
readonly PREFIX="[Witty-Allsky-FirstBoot]"

log() { printf '%s %s\n' "$PREFIX" "$*"; }

finish() {
    systemctl disable wittypi5-allsky-firstboot.service >/dev/null 2>&1 || true
}
trap finish EXIT

find_allsky() {
    local base
    for base in /home/allsky /home/*/allsky /opt/allsky; do
        [[ -f "$base/html/index.php" ]] && { printf '%s\n' "$base"; return 0; }
    done
    return 1
}

allsky_home=""
for attempt in $(seq 1 30); do
    allsky_home="$(find_allsky || true)"
    [[ -z "$allsky_home" ]] || break
    sleep 1
done
if [[ -z "$allsky_home" ]]; then
    log "Allsky-Homepage wurde nicht gefunden; der Allsky-Dienst wird dadurch nicht blockiert."
    exit 0
fi

# Nur einmalige Dateieinrichtung. Der Allsky-Dienst wird weder gestoppt noch
# gestartet, und es werden weder Bilder noch HTTP-Antworten überwacht.
if [[ -x /usr/local/sbin/witty-allsky-trixie-compat ]]; then
    if ! timeout --foreground --kill-after=20s 240s \
            /usr/local/sbin/witty-allsky-trixie-compat repair; then
        log "WARNUNG: Die optionale Webserver-Einrichtung schlug fehl; Allsky startet trotzdem."
    fi
fi

if [[ -f "$PATCHER" && -f "$allsky_home/html/index.php" ]]; then
    if python3 "$PATCHER" --kind allsky --file "$allsky_home/html/index.php"; then
        log "Homepage-Navigation aktualisiert: $allsky_home/html/index.php"
    else
        log "WARNUNG: Navigation konnte nicht ergänzt werden; Allsky startet trotzdem."
    fi
fi

# Alte Hotspot-Abhängigkeiten können den Offline-Start verzögern. Die kleine
# lokale Witty-Zeitsynchronisation bleibt dagegen ausdrücklich erhalten: Im
# Modus ohne GPS muss Allsky erst nach Witty-RTC -> Systemzeit starten.
rm -f -- /etc/systemd/system/allsky.service.d/hotspot.conf \
    /etc/systemd/system/allskyperiodic.service.d/hotspot.conf
if [[ -r /etc/witty-addon.conf ]]; then
    # shellcheck disable=SC1091
    source /etc/witty-addon.conf
fi
if [[ "${GPS_MODE:-unknown}" == none && -x /usr/local/sbin/witty-gps-manager ]]; then
    if ! timeout 30s /usr/local/sbin/witty-gps-manager refresh-time none; then
        log "WARNUNG: Die Allsky-Zeitabhängigkeit konnte nicht erneuert werden."
    fi
fi
systemctl daemon-reload >/dev/null 2>&1 || true

log "Einmalige Homepage-Nachbearbeitung beendet. Allsky bleibt vollständig unter eigener Dienststeuerung."
