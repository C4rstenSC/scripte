#!/usr/bin/env bash
set -Eeuo pipefail

# This compatibility layer is deliberately feature-based. It repairs only
# missing Trixie integration and remains harmless when Allsky gains native
# support for a newer Debian/PHP release.
readonly MODE="${1:-repair}"
readonly LOG_PREFIX="[Allsky-Trixie]"

log() { printf '%s %s\n' "$LOG_PREFIX" "$*"; }
fail() { printf '%s FEHLER: %s\n' "$LOG_PREFIX" "$*" >&2; exit 1; }

apt_plain() {
    timeout --foreground --kill-after=30s 900s env \
        DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a \
        apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 \
        -o DPkg::Lock::Timeout=120 -o Dpkg::Options::=--force-confold "$@"
}

repair_dpkg_state() {
    log "Prüfe die Debian-Paketverwaltung vor der Allsky-Installation ..."
    if ! timeout --foreground --kill-after=30s 600s env DEBIAN_FRONTEND=noninteractive \
            dpkg --force-confold --configure -a; then
        log "Repariere eine unterbrochene Paketinstallation ..."
        apt_plain --fix-broken install -y || \
            fail "Die unterbrochene Debian-Paketinstallation konnte nicht repariert werden."
        timeout --foreground --kill-after=30s 600s env DEBIAN_FRONTEND=noninteractive \
            dpkg --force-confold --configure -a || \
            fail "Debian-Pakete konnten nicht vollständig konfiguriert werden."
    fi
    if [[ -n "$(dpkg --audit 2>/dev/null)" ]]; then
        dpkg --audit >&2 || true
        fail "Die Debian-Paketverwaltung meldet weiterhin unvollständige Pakete."
    fi
    log "Debian-Paketverwaltung ist bereit."
}

os_codename() {
    local VERSION_CODENAME=""
    [[ -r /etc/os-release ]] && source /etc/os-release
    printf '%s\n' "${VERSION_CODENAME:-unknown}"
}

find_allsky() {
    local candidate
    systemctl show --property=LoadState --value allsky.service 2>/dev/null | \
        grep -Fxq loaded || return 1
    for candidate in /home/wurb/allsky /home/allsky /home/*/allsky /opt/allsky; do
        [[ -f "$candidate/allsky.sh" && -d "$candidate/html" ]] && {
            printf '%s\n' "$candidate"
            return 0
        }
    done
    return 1
}

find_allsky_source() {
    local candidate
    for candidate in /home/wurb/allsky /home/allsky /home/*/allsky /opt/allsky; do
        [[ -f "$candidate/allsky.sh" && -d "$candidate/html" ]] && {
            printf '%s\n' "$candidate"
            return 0
        }
    done
    return 1
}

install_trixie_prerequisites() {
    local camera_package=""
    repair_dpkg_state
    log "Aktualisiere die Trixie-Paketinformationen ..."
    apt_plain update || fail "Die Trixie-Paketinformationen konnten nicht aktualisiert werden."
    log "Installiere die aktuell verfügbaren Trixie-Webserver- und PHP-Pakete ..."
    apt_plain install -y lighttpd php-fpm php-cgi php-common gawk git curl ca-certificates || {
        repair_dpkg_state || true
        fail "Die Trixie-Webserver- und PHP-Pakete konnten nicht installiert werden."
    }
    repair_dpkg_state
    for required_package in php-fpm php-cgi lighttpd; do
        [[ "$(dpkg-query -W -f='${db:Status-Status}' "$required_package" 2>/dev/null || true)" == installed ]] || \
            fail "$required_package ist nicht vollständig installiert."
    done
    log "PHP-FPM-, PHP-CGI- und Lighttpd-Pakete sind vollständig konfiguriert."
    if apt-cache show python3-smbus2 >/dev/null 2>&1; then
        apt_plain install -y python3-smbus2 || \
            fail "Das für Allsky benötigte Trixie-Paket python3-smbus2 konnte nicht installiert werden."
    fi
    if ! command -v rpicam-still >/dev/null 2>&1 && ! command -v libcamera-still >/dev/null 2>&1; then
        for candidate in rpicam-apps-lite rpicam-apps libcamera-apps-lite; do
            if apt-cache show "$candidate" >/dev/null 2>&1; then
                camera_package="$candidate"
                break
            fi
        done
        if [[ -n "$camera_package" ]]; then
            apt_plain install -y "$camera_package" || \
                fail "Das Raspberry-Pi-Kamerapaket $camera_package konnte nicht installiert werden."
        else
            log "WARNUNG: Kein passendes Raspberry-Pi-Kamerawerkzeug wurde in den Paketquellen gefunden."
        fi
    fi
}

enable_php_lighttpd() {
    local php_version fpm_service fpm_config=/etc/lighttpd/conf-available/15-fastcgi-php-fpm.conf
    command -v lighttpd >/dev/null 2>&1 || fail "lighttpd ist nicht installiert."
    command -v php-cgi >/dev/null 2>&1 || fail "php-cgi ist nicht installiert."
    timeout 15s php-cgi -v >/dev/null 2>&1 || fail "php-cgi lässt sich nicht ausführen."
    php_version="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || true)"
    fpm_service="php${php_version}-fpm.service"
    log "Aktiviere FastCGI und bevorzugt PHP-FPM für Lighttpd ..."
    if command -v lighty-enable-mod >/dev/null 2>&1; then
        timeout --foreground --kill-after=5s 20s lighty-enable-mod fastcgi \
            >/dev/null 2>&1 || log "WARNUNG: FastCGI-Modulaktivierung meldete einen Fehler oder ein Zeitlimit."
    elif command -v lighttpd-enable-mod >/dev/null 2>&1; then
        timeout --foreground --kill-after=5s 20s lighttpd-enable-mod fastcgi \
            >/dev/null 2>&1 || log "WARNUNG: FastCGI-Modulaktivierung meldete einen Fehler oder ein Zeitlimit."
    fi
    # Debian Trixie liefert beide Konfigurationen im lighttpd-Paket. Die
    # explizite Prüfung verhindert einen scheinbar erfolgreichen Neustart, bei
    # dem .php-Dateien wegen eines fehlenden Links trotzdem nicht ausgeführt
    # werden.
    install -d -m 0755 /etc/lighttpd/conf-enabled
    for module_config in 10-fastcgi.conf; do
        [[ -r "/etc/lighttpd/conf-available/$module_config" ]] || \
            fail "Lighttpd-Konfiguration $module_config fehlt."
        if [[ ! -e "/etc/lighttpd/conf-enabled/$module_config" ]]; then
            ln -s "../conf-available/$module_config" "/etc/lighttpd/conf-enabled/$module_config"
            log "Fehlenden Lighttpd-Modullink ergänzt: $module_config"
        fi
    done
    if [[ -r "$fpm_config" ]] && systemctl cat "$fpm_service" >/dev/null 2>&1; then
        timeout 30s systemctl enable --now "$fpm_service" >/dev/null || \
            fail "$fpm_service konnte nicht aktiviert werden."
        if command -v lighty-disable-mod >/dev/null 2>&1; then
            timeout 20s lighty-disable-mod fastcgi-php >/dev/null 2>&1 || true
            timeout 20s lighty-enable-mod fastcgi fastcgi-php-fpm >/dev/null 2>&1 || \
                log "WARNUNG: lighty-enable-mod meldete einen Fehler; die Links werden direkt geprüft."
        elif command -v lighttpd-disable-mod >/dev/null 2>&1; then
            timeout 20s lighttpd-disable-mod fastcgi-php >/dev/null 2>&1 || true
            timeout 20s lighttpd-enable-mod fastcgi fastcgi-php-fpm >/dev/null 2>&1 || \
                log "WARNUNG: lighttpd-enable-mod meldete einen Fehler; die Links werden direkt geprüft."
        fi
        rm -f -- /etc/lighttpd/conf-enabled/15-fastcgi-php.conf
        ln -sfn ../conf-available/15-fastcgi-php-fpm.conf \
            /etc/lighttpd/conf-enabled/15-fastcgi-php-fpm.conf
        log "PHP-FPM ist aktiv; die gleichzeitig kollidierende PHP-CGI-Konfiguration wurde deaktiviert."
    else
        rm -f -- /etc/lighttpd/conf-enabled/15-fastcgi-php-fpm.conf
        [[ -r /etc/lighttpd/conf-available/15-fastcgi-php.conf ]] || \
            fail "Weder eine verwendbare PHP-FPM- noch eine PHP-CGI-Konfiguration ist vorhanden."
        ln -sfn ../conf-available/15-fastcgi-php.conf \
            /etc/lighttpd/conf-enabled/15-fastcgi-php.conf
        log "PHP-FPM ist nicht verfügbar; verwende die geprüfte PHP-CGI-Rückfallkonfiguration."
    fi
    log "Prüfe die vollständige Lighttpd-Konfiguration ..."
    lighttpd -tt -f /etc/lighttpd/lighttpd.conf >/dev/null 2>&1 || \
        fail "Die Lighttpd-Konfiguration ist nach Aktivierung von PHP ungültig."
    timeout 20s systemctl enable lighttpd.service >/dev/null 2>&1 || true
    log "Starte Lighttpd mit der aktuellen PHP-Konfiguration neu ..."
    timeout 30s systemctl restart lighttpd.service || \
        fail "Lighttpd konnte innerhalb von 30 Sekunden nicht neu gestartet werden."
    systemctl is-active --quiet lighttpd.service || fail "Lighttpd ist nach dem Neustart nicht aktiv."
    log "Lighttpd und die ausgewählte PHP-FastCGI-Laufzeit sind aktiv."
}

camera_diagnostics() {
    local camera_tool="" candidate
    log "Kameradiagnose beginnt."
    for candidate in rpicam-still libcamera-still; do
        if command -v "$candidate" >/dev/null 2>&1; then camera_tool="$candidate"; break; fi
    done
    if [[ -n "$camera_tool" ]]; then
        log "CSI-Kameras ($camera_tool --list-cameras):"
        timeout 20s runuser -u wurb -- env HOME=/home/wurb "$camera_tool" --list-cameras 2>&1 || true
    else
        log "Kein rpicam-still/libcamera-still gefunden."
    fi
    log "USB-Geräte:"
    lsusb 2>&1 || true
    log "V4L2-Geräte:"
    v4l2-ctl --list-devices 2>&1 || true
}

supported_camera_present() {
    local camera_tool="" camera_output="" candidate
    for candidate in rpicam-still libcamera-still; do
        if command -v "$candidate" >/dev/null 2>&1; then camera_tool="$candidate"; break; fi
    done
    if [[ -n "$camera_tool" ]]; then
        camera_output="$(timeout 20s runuser -u wurb -- env HOME=/home/wurb \
            "$camera_tool" --list-cameras 2>&1 || true)"
        grep -Eq '^[[:space:]]*[0-9]+[[:space:]]*:' <<<"$camera_output" && return 0
    fi
    lsusb 2>/dev/null | grep -Eiq '(^|[[:space:]])ID[[:space:]]+03c3:|ZWO|Zhen Wang'
}

camera_check() {
    camera_diagnostics
    if supported_camera_present; then
        log "Eine von Allsky unterstützte CSI- oder ZWO-Kamera wurde erkannt."
        return 0
    fi
    log "KEINE KAMERA: Bitte eine unterstützte Kamera anschließen und die Allsky-Installation erneut starten."
    return 20
}

install_rpicam_compatibility_aliases() {
    local tool legacy
    # Aktuelle Raspberry-Pi-OS-Versionen nennen die Programme rpicam-*, ältere
    # Allsky-Erkennungsroutinen suchen teilweise noch nach libcamera-*.
    # Nur fehlende Namen ergänzen; vorhandene Distributiondateien bleiben
    # unangetastet. Die Kommandozeilenoption --list-cameras ist kompatibel.
    for tool in still hello vid jpeg raw; do
        command -v "rpicam-$tool" >/dev/null 2>&1 || continue
        legacy="/usr/local/bin/libcamera-$tool"
        if ! command -v "libcamera-$tool" >/dev/null 2>&1; then
            ln -sfn "$(command -v "rpicam-$tool")" "$legacy"
            log "Trixie-Kameraalias ergänzt: libcamera-$tool -> rpicam-$tool"
        fi
    done
}

patch_php84_compatibility() {
    local allsky_home="${1:-}" file backup
    [[ -n "$allsky_home" ]] || return 0
    for file in "$allsky_home/html/functions.php" /var/www/html/allsky/functions.php; do
        [[ -f "$file" ]] || continue
        if grep -Fq 'imagecreatefrom${funcext}' "$file"; then
            backup="${file}.witty-before-php84"
            [[ -e "$backup" ]] || cp -a -- "$file" "$backup"
            sed -i 's/imagecreatefrom${funcext}/imagecreatefrom{$funcext}/g' "$file"
            log "Veraltete PHP-Zeichenketteninterpolation korrigiert: $file"
        fi
        timeout 15s php -l "$file" >/dev/null 2>&1 || \
            fail "PHP-Syntaxprüfung fehlgeschlagen: $file"
    done
}

ensure_allsky_groups() {
    local owner="$1" group
    local groups=()
    for group in video render gpio i2c; do
        getent group "$group" >/dev/null 2>&1 && groups+=("$group")
    done
    if ((${#groups[@]})); then
        usermod -aG "$(IFS=,; printf '%s' "${groups[*]}")" "$owner"
    fi
    if id www-data >/dev/null 2>&1; then
        group="$(id -gn "$owner")"
        getent group "$group" >/dev/null 2>&1 && usermod -aG "$group" www-data
    fi
}

ensure_web_paths() {
    local allsky_home="$1" web_link=/var/www/html/allsky tmp_link backup_root=""
    install -d -m 0755 /var/www/html
    if [[ -L "$web_link" ]]; then
        [[ "$(readlink -f "$web_link" 2>/dev/null || true)" == "$(readlink -f "$allsky_home/html")" ]] || \
            ln -sfn "$allsky_home/html" "$web_link"
    elif [[ ! -e "$web_link" ]]; then
        ln -s "$allsky_home/html" "$web_link"
    else
        backup_root="/var/backups/witty-allsky-paths/$(date +%Y%m%d-%H%M%S)"
        install -d -m 0700 "$backup_root"
        mv -- "$web_link" "$backup_root/allsky-webroot"
        ln -s "$allsky_home/html" "$web_link"
        log "Abweichendes Webverzeichnis gesichert: $backup_root/allsky-webroot"
    fi
    tmp_link="$allsky_home/html/tmp"
    if [[ -d "$allsky_home/tmp" ]]; then
        if [[ -e "$tmp_link" && ! -L "$tmp_link" ]]; then
            [[ -n "$backup_root" ]] || {
                backup_root="/var/backups/witty-allsky-paths/$(date +%Y%m%d-%H%M%S)"
                install -d -m 0700 "$backup_root"
            }
            mv -- "$tmp_link" "$backup_root/html-tmp"
            log "Abweichendes html/tmp-Verzeichnis gesichert: $backup_root/html-tmp"
        fi
        ln -sfn "$allsky_home/tmp" "$tmp_link"
    fi
}

ensure_live_image_compatibility() {
    local allsky_home="$1" current_dir="$1/tmp/current_images"
    local root_image="$1/image.jpg" source_target="tmp/image.jpg"
    # Ältere Allsky-Versionen veröffentlichen /current/ aus ALLSKY_HOME und
    # verwenden /current/tmp/image.jpg. Neuere Versionen veröffentlichen
    # tmp/current_images und verwenden /current/image.jpg. Beide URL-Formen
    # bleiben dadurch auf vorherigem und aktuellem Trixie funktionsfähig.
    if [[ -d "$current_dir" ]]; then
        source_target="tmp/current_images/image.jpg"
        install -d -m 0775 "$current_dir/tmp"
        if [[ ! -e "$current_dir/tmp/image.jpg" || -L "$current_dir/tmp/image.jpg" ]]; then
            ln -sfn ../image.jpg "$current_dir/tmp/image.jpg"
        fi
    fi
    if [[ ! -e "$root_image" || -L "$root_image" ]]; then
        ln -sfn "$source_target" "$root_image"
    fi

    install -d -m 0755 /etc/lighttpd/conf-available /etc/lighttpd/conf-enabled
    cat > /etc/lighttpd/conf-available/98-witty-allsky-live.conf <<'EOF'
# Witty compatibility: the current Allsky frame must never be served from a
# browser or intermediary cache. This applies to both legacy and current URLs.
$HTTP["url"] =~ "^/current/" {
    setenv.add-response-header += (
        "Cache-Control" => "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0",
        "Pragma" => "no-cache",
        "Expires" => "0"
    )
}
EOF
    ln -sfn ../conf-available/98-witty-allsky-live.conf \
        /etc/lighttpd/conf-enabled/98-witty-allsky-live.conf
    log "Livebild-Pfade und Cache-Sperre für alte und aktuelle Allsky-Versionen eingerichtet."
}

ensure_overlay() {
    local allsky_home="$1" overlay_dir target source="" marker candidate
    overlay_dir="$allsky_home/config/overlay/config"
    target="$overlay_dir/overlay.json"
    marker="$overlay_dir/.witty-trixie-overlay-v1"
    [[ -d "$overlay_dir" ]] || { log "Overlay-Verzeichnis ist noch nicht vorhanden."; return 0; }

    # Ein vorhandenes Benutzer-Overlay nach der ersten Witty-Reparatur nicht
    # erneut überschreiben. Bestehende Installationen ohne Marker erhalten
    # genau einmal die von Allsky gelieferte, kameragerechte Grundvorlage.
    [[ -e "$marker" ]] && return 0
    if supported_rpi_camera_present && [[ -s "$overlay_dir/overlay-RPi.json" ]]; then
        source="$overlay_dir/overlay-RPi.json"
    elif supported_zwo_camera_present && [[ -s "$overlay_dir/overlay-ZWO.json" ]]; then
        source="$overlay_dir/overlay-ZWO.json"
    fi
    for candidate in "$source" "$overlay_dir/overlay-RPi.json" \
                     "$overlay_dir/overlay-ZWO.json" "$overlay_dir"/overlay-*.json; do
        [[ -s "$candidate" && "$candidate" != "$target" ]] || continue
        source="$candidate"
        break
    done
    if [[ -n "$source" ]]; then
        [[ ! -s "$target" ]] || cp -a -- "$target" "${target}.witty-before-trixie-stability"
        install -m 0664 "$source" "$target"
        : > "$marker"
        log "Allsky-Overlay wurde einmalig aus $(basename "$source") stabilisiert."
    else
        log "WARNUNG: Keine passende Overlay-Vorlage gefunden; Allsky muss sie selbst erzeugen."
    fi
}

supported_rpi_camera_present() {
    local camera_tool="" camera_output="" candidate
    for candidate in rpicam-still libcamera-still; do
        if command -v "$candidate" >/dev/null 2>&1; then camera_tool="$candidate"; break; fi
    done
    [[ -n "$camera_tool" ]] || return 1
    camera_output="$(timeout 20s runuser -u wurb -- env HOME=/home/wurb \
        "$camera_tool" --list-cameras 2>&1 || true)"
    grep -Eq '^[[:space:]]*[0-9]+[[:space:]]*:' <<<"$camera_output"
}

supported_zwo_camera_present() {
    lsusb 2>/dev/null | grep -Eiq '(^|[[:space:]])ID[[:space:]]+03c3:|ZWO|Zhen Wang'
}

disable_unstable_bad_image_filter() {
    local allsky_home="$1" script="$1/scripts/removeBadImages.sh" backup
    [[ -f "$script" ]] || return 0
    if sed -n '1,8p' "$script" | grep -Eq '^[[:space:]]*exit[[:space:]]+0([[:space:]]|$)'; then
        return 0
    fi
    backup="${script}.witty-before-trixie-stability"
    [[ -e "$backup" ]] || cp -a -- "$script" "$backup"
    if head -n 1 "$script" | grep -q '^#!'; then
        sed -i '1a\# Witty/Trixie stability workaround; original saved beside this file.\nexit 0' "$script"
    else
        sed -i '1i\# Witty/Trixie stability workaround; original saved beside this file.\nexit 0' "$script"
    fi
    log "Instabilen Allsky-Filter removeBadImages.sh deaktiviert; Original wurde gesichert."
}

ensure_permissions() {
    local allsky_home="$1" owner="$2" path
    for path in "$allsky_home/html" "$allsky_home/tmp"; do
        [[ -e "$path" ]] || continue
        chown -R "$owner:www-data" "$path"
        chmod -R u+rwX,g+rwX,o+rX "$path"
        find "$path" -type d -exec chmod g+s {} +
    done
    path="$allsky_home/config"
    if [[ -d "$path" ]]; then
        chown -R "$owner:www-data" "$path"
        chmod -R u+rwX,g+rwX,o-rwx "$path"
        find "$path" -type d -exec chmod 2770 {} +
        [[ ! -f "$path/settings.json" ]] || chmod 0660 "$path/settings.json"
    fi
}

verify_php() {
    local allsky_home="${1:-}" probe_dir=/var/www/html probe token response="" url
    local attempt http_code="000" response_file=""
    # Vor der eigentlichen Allsky-Installation ist /home/wurb/allsky/html noch
    # nicht unter /allsky veröffentlicht. Deshalb wird die PHP-Laufzeit immer
    # zuerst im echten Lighttpd-Document-Root geprüft. Nach der Installation
    # darf zusätzlich der Allsky-Pfad verwendet werden, sofern der Web-Link
    # bereits auf genau dieses Verzeichnis zeigt.
    if [[ -n "$allsky_home" && -d "$allsky_home/html" && -L /var/www/html/allsky ]] && \
       [[ "$(readlink -f /var/www/html/allsky 2>/dev/null || true)" == "$(readlink -f "$allsky_home/html")" ]]; then
        probe_dir="$allsky_home/html"
    fi
    [[ -d "$probe_dir" ]] || fail "Lighttpd-Document-Root $probe_dir fehlt."
    token="WITTY_PHP_OK_$(date +%s)_$$"
    # Avoid a dot-prefixed name because some hardened Lighttpd configurations
    # deliberately deny hidden files even though PHP itself is working.
    probe="$(mktemp "$probe_dir/witty-php-check.XXXXXX.php")"
    printf '<?php echo "%s"; ?>\n' "$token" > "$probe"
    chmod 0644 "$probe"
    if [[ "$probe_dir" == /var/www/html ]]; then
        url="http://127.0.0.1/$(basename "$probe")"
    else
        url="http://127.0.0.1/allsky/$(basename "$probe")"
    fi
    response_file="$(mktemp /var/tmp/witty-php-response.XXXXXX)"
    # systemd kann den Dienst bereits als aktiv melden, während der von
    # Lighttpd gestartete PHP-FastCGI-Prozess noch hochfährt. Bis zu 30
    # Sekunden warten, statt eine einzelne Momentaufnahme als Fehler zu werten.
    for attempt in $(seq 1 30); do
        http_code="$(curl --noproxy '*' --silent --show-error --max-time 5 \
            --output "$response_file" --write-out '%{http_code}' "$url" 2>/dev/null || true)"
        [[ -n "$http_code" ]] || http_code=000
        response="$(cat "$response_file" 2>/dev/null || true)"
        [[ "$http_code" == 200 && "$response" == "$token" ]] && break
        sleep 1
    done
    rm -f -- "$probe" "$response_file"
    if [[ "$http_code" != 200 || "$response" != "$token" ]]; then
        log "DIAGNOSE: PHP-Test URL=$url HTTP=${http_code:-000}"
        log "DIAGNOSE: Aktivierte Lighttpd-Konfigurationen:"
        find /etc/lighttpd/conf-enabled -maxdepth 1 -type l -printf '%f -> %l\n' 2>/dev/null | sort >&2 || true
        systemctl status lighttpd.service --no-pager --full >&2 || true
        journalctl -u lighttpd.service -n 80 --no-pager >&2 || true
        [[ ! -r /var/log/lighttpd/error.log ]] || tail -n 80 /var/log/lighttpd/error.log >&2 || true
        fail "Lighttpd führt PHP über FastCGI nicht korrekt aus (HTTP ${http_code:-000})."
    fi
    log "PHP antwortet über Lighttpd/FastCGI korrekt."
}

verify_live_image() {
    local allsky_home="$1" source="" candidate response headers
    for candidate in "$allsky_home/tmp/current_images/image.jpg" \
                     "$allsky_home/tmp/image.jpg" "$allsky_home/image.jpg"; do
        if [[ -s "$candidate" ]]; then source="$candidate"; break; fi
    done
    if [[ -z "$source" ]]; then
        log "HINWEIS: Allsky hat noch kein Livebild erzeugt; URL- und Cache-Konfiguration sind vorbereitet."
        return 0
    fi
    response="$(mktemp /var/tmp/witty-allsky-image.XXXXXX)"
    headers="$(mktemp /var/tmp/witty-allsky-headers.XXXXXX)"
    if ! curl --noproxy '*' --fail --silent --show-error --max-time 10 \
            --dump-header "$headers" --output "$response" \
            "http://127.0.0.1/current/image.jpg?witty=$(date +%s)"; then
        rm -f -- "$response" "$headers"
        fail "Das vorhandene Allsky-Livebild ist über /current/image.jpg nicht erreichbar."
    fi
    [[ -s "$response" ]] || { rm -f -- "$response" "$headers"; fail "Die Allsky-Livebildantwort ist leer."; }
    grep -Eiq '^Cache-Control:.*(no-store|no-cache)' "$headers" || {
        rm -f -- "$response" "$headers"
        fail "Für das Allsky-Livebild fehlt die Cache-Sperre."
    }
    rm -f -- "$response" "$headers"
    log "Allsky-Livebild ist erreichbar und wird ohne Browsercache ausgeliefert."
}

install_persistent_check() {
    cat > /etc/apt/apt.conf.d/99-witty-allsky-compat <<'EOF'
DPkg::Post-Invoke { "if [ -x /usr/local/sbin/witty-allsky-trixie-compat ]; then systemctl start --no-block witty-allsky-compat.service >/dev/null 2>&1 || true; fi"; };
EOF
    systemctl daemon-reload
    systemctl enable witty-allsky-compat.service >/dev/null 2>&1 || true
}

repair_installed_allsky() {
    local allsky_home owner
    allsky_home="$(find_allsky || true)"
    [[ -n "$allsky_home" ]] || return 0
    owner="$(stat -c '%U' "$allsky_home")"
    id "$owner" >/dev/null 2>&1 || fail "Allsky-Eigentümer $owner existiert nicht."
    patch_php84_compatibility "$allsky_home"
    ensure_allsky_groups "$owner"
    ensure_web_paths "$allsky_home"
    ensure_live_image_compatibility "$allsky_home"
    ensure_overlay "$allsky_home"
    disable_unstable_bad_image_filter "$allsky_home"
    ensure_permissions "$allsky_home" "$owner"
    enable_php_lighttpd
    verify_php "$allsky_home"
    verify_live_image "$allsky_home"
    install_persistent_check
    log "Trixie-Kompatibilitätsprüfung erfolgreich: $allsky_home"
}

[[ "$EUID" -eq 0 ]] || fail "Bitte als root ausführen."
install -d -m 0755 /run/lock
exec 9>/run/lock/witty-allsky-trixie.lock
flock -w 150 9 || fail "Eine andere Allsky-/Trixie-Prüfung läuft bereits zu lange."
[[ "$MODE" =~ ^(prepare|repair|verify|camera-check|camera-present)$ ]] || fail "Ungültiger Modus: $MODE"
if [[ "$(os_codename)" != trixie ]]; then
    log "Kein Trixie-System erkannt; die Zusatzkorrektur ist nicht erforderlich."
    exit 0
fi

case "$MODE" in
    camera-present)
        install_rpicam_compatibility_aliases
        supported_camera_present
        ;;
    camera-check)
        install_rpicam_compatibility_aliases
        camera_check
        ;;
    prepare)
        install_trixie_prerequisites
        install_rpicam_compatibility_aliases
        install -d -m 0755 /var/www/html
        enable_php_lighttpd
        verify_php
        patch_php84_compatibility "$(find_allsky_source || true)"
        log "Allsky-Vorbereitung für die aktuelle Trixie-/PHP-Version ist abgeschlossen."
        ;;
    repair|verify)
        repair_installed_allsky
        ;;
esac
