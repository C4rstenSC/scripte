#!/usr/bin/env bash
set -Eeuo pipefail

# This compatibility layer is deliberately feature-based. It repairs only
# missing Trixie integration and remains harmless when Allsky gains native
# support for a newer Debian/PHP release.
readonly MODE="${1:-repair}"
readonly LOG_PREFIX="[Allsky-Trixie]"

log() { printf '%s %s\n' "$LOG_PREFIX" "$*"; }
fail() { printf '%s FEHLER: %s\n' "$LOG_PREFIX" "$*" >&2; exit 1; }

apt_plain() {
    timeout --foreground --kill-after=30s 900s env \
        DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=a \
        apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 \
        -o DPkg::Lock::Timeout=120 -o Dpkg::Options::=--force-confold "$@"
}

repair_dpkg_state() {
    log "Prüfe die Debian-Paketverwaltung vor der Allsky-Installation ..."
    if ! timeout --foreground --kill-after=30s 600s env DEBIAN_FRONTEND=noninteractive \
            dpkg --force-confold --configure -a; then
        log "Repariere eine unterbrochene Paketinstallation ..."
        apt_plain --fix-broken install -y || \
            fail "Die unterbrochene Debian-Paketinstallation konnte nicht repariert werden."
        timeout --foreground --kill-after=30s 600s env DEBIAN_FRONTEND=noninteractive \
            dpkg --force-confold --configure -a || \
            fail "Debian-Pakete konnten nicht vollständig konfiguriert werden."
    fi
    if [[ -n "$(dpkg --audit 2>/dev/null)" ]]; then
        dpkg --audit >&2 || true
        fail "Die Debian-Paketverwaltung meldet weiterhin unvollständige Pakete."
    fi
    log "Debian-Paketverwaltung ist bereit."
}

os_codename() {
    local VERSION_CODENAME=""
    [[ -r /etc/os-release ]] && source /etc/os-release
    printf '%s\n' "${VERSION_CODENAME:-unknown}"
}

find_allsky() {
    local candidate
    systemctl show --property=LoadState --value allsky.service 2>/dev/null | \
        grep -Fxq loaded || return 1
    for candidate in /home/wurb/allsky /home/allsky /home/*/allsky /opt/allsky; do
        [[ -f "$candidate/allsky.sh" && -d "$candidate/html" ]] && {
            printf '%s\n' "$candidate"
            return 0
        }
    done
    return 1
}

find_allsky_source() {
    local candidate
    for candidate in /home/wurb/allsky /home/allsky /home/*/allsky /opt/allsky; do
        [[ -f "$candidate/allsky.sh" && -d "$candidate/html" ]] && {
            printf '%s\n' "$candidate"
            return 0
        }
    done
    return 1
}

install_trixie_prerequisites() {
    local camera_package=""
    repair_dpkg_state
    log "Aktualisiere die Trixie-Paketinformationen ..."
    apt_plain update || fail "Die Trixie-Paketinformationen konnten nicht aktualisiert werden."
    log "Installiere die aktuell verfügbaren Trixie-Webserver- und PHP-Pakete ..."
    apt_plain install -y lighttpd php-cgi php-common gawk git curl ca-certificates || {
        repair_dpkg_state || true
        fail "Die Trixie-Webserver- und PHP-Pakete konnten nicht installiert werden."
    }
    repair_dpkg_state
    for required_package in php-cgi lighttpd; do
        [[ "$(dpkg-query -W -f='${db:Status-Status}' "$required_package" 2>/dev/null || true)" == installed ]] || \
            fail "$required_package ist nicht vollständig installiert."
    done
    log "PHP-CGI- und Lighttpd-Pakete sind vollständig konfiguriert."
    if ! command -v rpicam-still >/dev/null 2>&1 && ! command -v libcamera-still >/dev/null 2>&1; then
        for candidate in rpicam-apps-lite rpicam-apps libcamera-apps-lite; do
            if apt-cache show "$candidate" >/dev/null 2>&1; then
                camera_package="$candidate"
                break
            fi
        done
        if [[ -n "$camera_package" ]]; then
            apt_plain install -y "$camera_package" || \
                fail "Das Raspberry-Pi-Kamerapaket $camera_package konnte nicht installiert werden."
        else
            log "WARNUNG: Kein passendes Raspberry-Pi-Kamerawerkzeug wurde in den Paketquellen gefunden."
        fi
    fi
}

enable_php_lighttpd() {
    command -v lighttpd >/dev/null 2>&1 || fail "lighttpd ist nicht installiert."
    command -v php-cgi >/dev/null 2>&1 || fail "php-cgi ist nicht installiert."
    timeout 15s php-cgi -v >/dev/null 2>&1 || fail "php-cgi lässt sich nicht ausführen."
    log "Aktiviere FastCGI und PHP-CGI für Lighttpd ..."
    if command -v lighty-enable-mod >/dev/null 2>&1; then
        lighty-enable-mod fastcgi >/dev/null 2>&1 || true
        lighty-enable-mod fastcgi-php >/dev/null 2>&1 || true
    fi
    lighttpd -tt -f /etc/lighttpd/lighttpd.conf >/dev/null 2>&1 || \
        fail "Die Lighttpd-Konfiguration ist nach Aktivierung von PHP ungültig."
    timeout 20s systemctl enable lighttpd.service >/dev/null 2>&1 || true
    log "Starte Lighttpd mit der aktuellen PHP-Konfiguration neu ..."
    timeout 30s systemctl restart lighttpd.service || \
        fail "Lighttpd konnte innerhalb von 30 Sekunden nicht neu gestartet werden."
    systemctl is-active --quiet lighttpd.service || fail "Lighttpd ist nach dem Neustart nicht aktiv."
    log "Lighttpd und PHP-CGI sind aktiv."
}

patch_php84_compatibility() {
    local allsky_home="${1:-}" file backup
    [[ -n "$allsky_home" ]] || return 0
    for file in "$allsky_home/html/functions.php" /var/www/html/allsky/functions.php; do
        [[ -f "$file" ]] || continue
        if grep -Fq 'imagecreatefrom${funcext}' "$file"; then
            backup="${file}.witty-before-php84"
            [[ -e "$backup" ]] || cp -a -- "$file" "$backup"
            sed -i 's/imagecreatefrom${funcext}/imagecreatefrom{$funcext}/g' "$file"
            log "Veraltete PHP-Zeichenketteninterpolation korrigiert: $file"
        fi
        timeout 15s php -l "$file" >/dev/null 2>&1 || \
            fail "PHP-Syntaxprüfung fehlgeschlagen: $file"
    done
}

ensure_allsky_groups() {
    local owner="$1" group
    local groups=()
    for group in video render gpio i2c; do
        getent group "$group" >/dev/null 2>&1 && groups+=("$group")
    done
    if ((${#groups[@]})); then
        usermod -aG "$(IFS=,; printf '%s' "${groups[*]}")" "$owner"
    fi
    if id www-data >/dev/null 2>&1; then
        group="$(id -gn "$owner")"
        getent group "$group" >/dev/null 2>&1 && usermod -aG "$group" www-data
    fi
}

ensure_web_paths() {
    local allsky_home="$1" web_link=/var/www/html/allsky tmp_link
    install -d -m 0755 /var/www/html
    if [[ -L "$web_link" ]]; then
        [[ "$(readlink -f "$web_link" 2>/dev/null || true)" == "$(readlink -f "$allsky_home/html")" ]] || \
            ln -sfn "$allsky_home/html" "$web_link"
    elif [[ ! -e "$web_link" ]]; then
        ln -s "$allsky_home/html" "$web_link"
    else
        log "Vorhandenes echtes Verzeichnis $web_link bleibt unverändert."
    fi
    tmp_link="$allsky_home/html/tmp"
    if [[ -d "$allsky_home/tmp" && ! -e "$tmp_link" && ! -L "$tmp_link" ]]; then
        ln -s ../tmp "$tmp_link"
    elif [[ -L "$tmp_link" && ! -e "$tmp_link" ]]; then
        ln -sfn ../tmp "$tmp_link"
    fi
}

ensure_overlay() {
    local allsky_home="$1" overlay_dir target source=""
    overlay_dir="$allsky_home/config/overlay/config"
    target="$overlay_dir/overlay.json"
    [[ -d "$overlay_dir" ]] || { log "Overlay-Verzeichnis ist noch nicht vorhanden."; return 0; }
    [[ -s "$target" ]] && return 0
    for candidate in "$overlay_dir/overlay-RPi.json" "$overlay_dir"/overlay-*.json; do
        [[ -s "$candidate" && "$candidate" != "$target" ]] || continue
        source="$candidate"
        break
    done
    if [[ -n "$source" ]]; then
        install -m 0664 "$source" "$target"
        log "Fehlende overlay.json wurde aus $(basename "$source") erzeugt."
    else
        log "WARNUNG: Keine passende Overlay-Vorlage gefunden; Allsky muss sie selbst erzeugen."
    fi
}

ensure_permissions() {
    local allsky_home="$1" owner="$2" path
    for path in "$allsky_home/html" "$allsky_home/tmp" "$allsky_home/config/overlay"; do
        [[ -e "$path" ]] || continue
        chown -R "$owner:www-data" "$path"
        chmod -R u+rwX,g+rwX,o+rX "$path"
        find "$path" -type d -exec chmod g+s {} +
    done
}

verify_php() {
    local allsky_home="${1:-}" probe_dir=/var/www/html probe token response="" url
    [[ -n "$allsky_home" && -d "$allsky_home/html" ]] && probe_dir="$allsky_home/html"
    token="WITTY_PHP_OK_$(date +%s)_$$"
    # Avoid a dot-prefixed name because some hardened Lighttpd configurations
    # deliberately deny hidden files even though PHP itself is working.
    probe="$(mktemp "$probe_dir/witty-php-check.XXXXXX.php")"
    printf '<?php echo "%s"; ?>\n' "$token" > "$probe"
    chmod 0644 "$probe"
    for url in "http://127.0.0.1/$(basename "$probe")" "http://127.0.0.1/allsky/$(basename "$probe")"; do
        response="$(curl --fail --silent --show-error --max-time 8 "$url" 2>/dev/null || true)"
        [[ "$response" == "$token" ]] && break
    done
    rm -f -- "$probe"
    [[ "$response" == "$token" ]] || fail "Lighttpd führt PHP-CGI nicht korrekt aus."
}

install_persistent_check() {
    cat > /etc/apt/apt.conf.d/99-witty-allsky-compat <<'EOF'
DPkg::Post-Invoke { "if [ -x /usr/local/sbin/witty-allsky-trixie-compat ]; then systemctl start --no-block witty-allsky-compat.service >/dev/null 2>&1 || true; fi"; };
EOF
    systemctl daemon-reload
    systemctl enable witty-allsky-compat.service >/dev/null 2>&1 || true
}

repair_installed_allsky() {
    local allsky_home owner
    allsky_home="$(find_allsky || true)"
    [[ -n "$allsky_home" ]] || return 0
    owner="$(stat -c '%U' "$allsky_home")"
    id "$owner" >/dev/null 2>&1 || fail "Allsky-Eigentümer $owner existiert nicht."
    patch_php84_compatibility "$allsky_home"
    ensure_allsky_groups "$owner"
    ensure_web_paths "$allsky_home"
    ensure_overlay "$allsky_home"
    ensure_permissions "$allsky_home" "$owner"
    enable_php_lighttpd
    verify_php "$allsky_home"
    install_persistent_check
    log "Trixie-Kompatibilitätsprüfung erfolgreich: $allsky_home"
}

[[ "$EUID" -eq 0 ]] || fail "Bitte als root ausführen."
[[ "$MODE" =~ ^(prepare|repair|verify)$ ]] || fail "Ungültiger Modus: $MODE"
if [[ "$(os_codename)" != trixie ]]; then
    log "Kein Trixie-System erkannt; die Zusatzkorrektur ist nicht erforderlich."
    exit 0
fi

case "$MODE" in
    prepare)
        install_trixie_prerequisites
        install -d -m 0755 /var/www/html
        enable_php_lighttpd
        verify_php
        patch_php84_compatibility "$(find_allsky_source || true)"
        log "Allsky-Vorbereitung für die aktuelle Trixie-/PHP-Version ist abgeschlossen."
        ;;
    repair|verify)
        repair_installed_allsky
        ;;
esac
