#!/usr/bin/env bash
set -Eeuo pipefail

# Feature checks for the current CloudedBats installation instructions. The
# script uses Debian package names and runtime imports rather than pinning a
# Python or Raspberry Pi OS point release.
readonly MODE="${1:-verify}"
readonly PREFIX="[CloudedBats-Trixie]"

log() { printf '%s %s\n' "$PREFIX" "$*"; }
fail() { printf '%s FEHLER: %s\n' "$PREFIX" "$*" >&2; exit 1; }

os_codename() {
    local VERSION_CODENAME=""
    [[ -r /etc/os-release ]] && source /etc/os-release
    printf '%s\n' "${VERSION_CODENAME:-unknown}"
}

install_packages() {
    DEBIAN_FRONTEND=noninteractive apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 install -y "$@"
}

ensure_uvicorn_programmatic_api() {
    local python="$1" label="$2"
    local entry distribution expected specification
    local force_reinstall=no
    local -a repair_specs=()
    local -a runtime_packages=(
        'fastapi|0.115.12|fastapi==0.115.12'
        'starlette|0.46.2|starlette==0.46.2'
        'uvicorn|0.34.3|uvicorn==0.34.3'
        'websockets|15.0.1|websockets==15.0.1'
        'python-multipart|0.0.20|python-multipart==0.0.20'
    )
    if "$python" -c 'import importlib.metadata as m; import fastapi, fastapi.templating, uvicorn, websockets; from python_multipart.multipart import parse_options_header; assert m.version("fastapi") == "0.115.12"; assert m.version("starlette") == "0.46.2"; assert m.version("uvicorn") == "0.34.3"; assert m.version("websockets") == "15.0.1"; assert m.version("python-multipart") == "0.0.20"; assert hasattr(fastapi.templating, "Jinja2Templates"); assert hasattr(uvicorn, "Config"); assert hasattr(uvicorn, "Server"); from uvicorn.protocols.websockets.websockets_impl import WebSocketProtocol' \
            >/dev/null 2>&1; then
        return 0
    fi

    # Prüfe nur die Metadaten, ohne die möglicherweise noch defekten Module zu
    # importieren. So lädt ein Update ausschließlich wirklich abweichende
    # Pakete und bleibt bei kurzen PyPI-/Piwheels-Ausfällen wiederholbar.
    for entry in "${runtime_packages[@]}"; do
        IFS='|' read -r distribution expected specification <<< "$entry"
        if ! "$python" -c 'import importlib.metadata as m, sys; raise SystemExit(0 if m.version(sys.argv[1]) == sys.argv[2] else 1)' \
                "$distribution" "$expected" >/dev/null 2>&1; then
            repair_specs+=("$specification")
        fi
    done

    # Stimmen alle Versionsnummern, ist aber die API beschädigt, werden die
    # fünf kleinen Laufzeitpakete ausnahmsweise vollständig neu installiert.
    if ((${#repair_specs[@]} == 0)); then
        force_reinstall=yes
        for entry in "${runtime_packages[@]}"; do
            IFS='|' read -r distribution expected specification <<< "$entry"
            repair_specs+=("$specification")
        done
        log "$label meldet trotz passender Versionen eine beschädigte Weblaufzeit; installiere sie erneut."
    else
        log "$label: Installiere nur abweichende Pakete: ${repair_specs[*]}"
    fi

    local -a pip_options=(
        --quiet --disable-pip-version-check --progress-bar off --no-deps
        --retries 10 --timeout 45
    )
    [[ "$force_reinstall" == yes ]] && pip_options+=(--force-reinstall)

    runuser -u wurb -- env HOME=/home/wurb PIP_DEFAULT_TIMEOUT=45 \
        "$python" -m pip install "${pip_options[@]}" "${repair_specs[@]}" || \
        fail "Die kompatible Python-Weblaufzeit konnte nicht installiert werden."
    "$python" -c 'import importlib.metadata as m; import fastapi, fastapi.templating, uvicorn, websockets; from python_multipart.multipart import parse_options_header; assert m.version("fastapi") == "0.115.12"; assert m.version("starlette") == "0.46.2"; assert m.version("uvicorn") == "0.34.3"; assert m.version("websockets") == "15.0.1"; assert m.version("python-multipart") == "0.0.20"; assert hasattr(fastapi.templating, "Jinja2Templates"); assert hasattr(uvicorn, "Config"); assert hasattr(uvicorn, "Server"); from uvicorn.protocols.websockets.websockets_impl import WebSocketProtocol' || \
        fail "Die Python-Webschnittstelle ist auch nach der Reparatur nicht verwendbar."
}

prepare_wurb() {
    log "Prüfe die aktuellen WURB-Systempakete ..."
    install_packages git python3-venv python3-dev libopenblas-dev pmount \
        python3-pyaudio portaudio19-dev
}

prepare_wirc() {
    log "Prüfe die aktuellen WIRC-Kamera- und Videopakete ..."
    install_packages python3-picamera2 python3-opencv ffmpeg
}

verify_wurb() {
    local python=/home/wurb/wurb_2026/venv/bin/python3
    [[ -x "$python" ]] || fail "Die WURB-Pythonumgebung fehlt."
    ensure_uvicorn_programmatic_api "$python" WURB
    "$python" -X faulthandler -c 'import numpy, scipy, sounddevice, serial, astral, yaml, fastapi, uvicorn, websockets; assert hasattr(uvicorn, "Config"); assert hasattr(uvicorn, "Server"); from uvicorn.protocols.websockets.websockets_impl import WebSocketProtocol' || \
        fail "Eine von WURB benötigte Python-Bibliothek kann nicht geladen werden."
    [[ -f /home/wurb/wurb_2026/raspberrypi_files/wurb_2026.service ]] || \
        fail "Die aktuelle offizielle WURB-Servicevorlage fehlt."
}

verify_wirc() {
    local python=/home/wurb/wirc_2026/venv/bin/python3
    [[ -x "$python" ]] || fail "Die WIRC-Pythonumgebung fehlt."
    ensure_uvicorn_programmatic_api "$python" WIRC
    "$python" -X faulthandler -c 'import cv2; from picamera2 import Picamera2; import fastapi, fastapi.templating, uvicorn, websockets; assert hasattr(fastapi.templating, "Jinja2Templates"); assert hasattr(uvicorn, "Config"); assert hasattr(uvicorn, "Server"); from uvicorn.protocols.websockets.websockets_impl import WebSocketProtocol' || \
        fail "Eine von WIRC benötigte Kamera- oder Python-Bibliothek kann nicht geladen werden."
    [[ -f /home/wurb/wirc_2026/raspberrypi_files/wirc_2026.service ]] || \
        fail "Die aktuelle offizielle WIRC-Servicevorlage fehlt."
}

[[ "$EUID" -eq 0 ]] || fail "Bitte als root ausführen."
[[ "$MODE" =~ ^(prepare-wurb|prepare-wirc|prepare-both|verify-wurb|verify-wirc|verify-both)$ ]] || \
    fail "Ungültiger Modus: $MODE"

if [[ "$(os_codename)" != trixie ]]; then
    log "Kein Trixie-System erkannt; die Zusatzprüfung wird übersprungen."
    exit 0
fi

case "$MODE" in
    prepare-wurb) prepare_wurb ;;
    prepare-wirc) prepare_wirc ;;
    prepare-both) prepare_wurb; prepare_wirc ;;
    verify-wurb) verify_wurb ;;
    verify-wirc) verify_wirc ;;
    verify-both) verify_wurb; verify_wirc ;;
esac

log "Kompatibilitätsprüfung erfolgreich: $MODE"
