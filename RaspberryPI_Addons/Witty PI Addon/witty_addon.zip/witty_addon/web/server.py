#!/usr/bin/env python3
import json
import io
import base64
import fcntl
import math
import mimetypes
import os
import pathlib
import posixpath
import pty
import re
import select
import signal
import shutil
import sqlite3
import struct
import subprocess
import sys
import tarfile
import tempfile
import threading
import termios
import time
import uuid
import zipfile
from datetime import datetime
from zoneinfo import ZoneInfo, available_timezones
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlparse

try:
    from timezonefinder import TimezoneFinder
except ImportError:
    TimezoneFinder = None

APP_DIR = pathlib.Path(__file__).resolve().parent.parent
WEB_DIR = APP_DIR / "web"
BACKEND = APP_DIR / "backend" / "witty_backend.sh"
PORT = 8081
DOWNLOAD_DIR = APP_DIR / "downloads"
RESET_PROGRESS_FILE = pathlib.Path("/var/lib/witty-addon/reset-progress.json")
ALLSKY_BACKUP_DIR = APP_DIR / "allsky-backups"
SOFTWARE_BACKUP_DIR = APP_DIR / "software-backups"
SOFTWARE_TEMP_BACKUP_DIR = pathlib.Path("/run/witty-addon-downloads")
ALLSKY_LOCK = threading.Lock()
SOFTWARE_JOB_LOCK = threading.Lock()
SOFTWARE_JOB = {"running": False, "output": bytearray(), "output_start": 0, "output_total": 0,
                "process": None, "master_fd": None, "action": "", "component": "",
                "exit_code": None, "reboot_scheduled": False, "cancel_requested": False,
                "backup_path": "", "backup_temporary": False, "restore_backup": False}
RECORDING_KINDS = {"wurb": "wurb_recordings", "wirc": "wirc_recordings"}
RECORDING_SUFFIXES = {"wurb": {".wav"}, "wirc": {".h264", ".mp4", ".mkv"}}


def raspberry_pi_model():
    try:
        return pathlib.Path("/proc/device-tree/model").read_bytes().rstrip(b"\0").decode("utf-8", errors="replace")
    except OSError:
        try:
            config = pathlib.Path("/etc/witty-addon.conf").read_text(encoding="utf-8")
            match = re.search(r"^RPI_MODEL=([45])$", config, re.MULTILINE)
            return f"Raspberry Pi {match.group(1)}" if match else ""
        except OSError:
            return ""

try:
    TIMEZONE_FINDER = TimezoneFinder() if TimezoneFinder is not None else None
except Exception:
    TIMEZONE_FINDER = None

# Exactly one familiar place is shown for each currently valid UTC offset.
# A GPS-derived IANA zone replaces this default only for its own current offset.
CANONICAL_TIMEZONES = (
    "Pacific/Pago_Pago", "Pacific/Honolulu", "America/Anchorage",
    "America/Los_Angeles", "America/Denver", "America/Chicago",
    "America/New_York", "America/Halifax", "America/St_Johns",
    "America/Sao_Paulo", "Atlantic/South_Georgia", "Atlantic/Azores",
    "Etc/UTC", "Europe/London", "Europe/Berlin", "Europe/Athens",
    "Asia/Tehran", "Asia/Dubai", "Asia/Kabul", "Asia/Karachi",
    "Asia/Kolkata", "Asia/Kathmandu", "Asia/Dhaka", "Asia/Yangon",
    "Asia/Bangkok", "Asia/Shanghai", "Asia/Tokyo",
    "Pacific/Noumea", "Pacific/Auckland", "Pacific/Chatham",
    "Pacific/Tongatapu", "Pacific/Kiritimati",
    "Australia/Perth", "Australia/Eucla", "Australia/Darwin",
    "Australia/Broken_Hill", "Australia/Lord_Howe", "Australia/Adelaide",
    "Australia/Brisbane", "Australia/Lindeman", "Australia/Hobart",
    "Australia/Melbourne", "Australia/Sydney",
)

AUSTRALIAN_TIMEZONE_PLACES = (
    ("Perth", "Australia/Perth", -31.9523, 115.8613),
    ("Eucla", "Australia/Eucla", -31.6777, 128.8835),
    ("Darwin", "Australia/Darwin", -12.4634, 130.8456),
    ("Adelaide", "Australia/Adelaide", -34.9285, 138.6007),
    ("Broken Hill", "Australia/Broken_Hill", -31.9539, 141.4539),
    ("Brisbane", "Australia/Brisbane", -27.4698, 153.0251),
    ("Sydney", "Australia/Sydney", -33.8688, 151.2093),
    ("Canberra", "Australia/Sydney", -35.2809, 149.1300),
    ("Melbourne", "Australia/Melbourne", -37.8136, 144.9631),
    ("Hobart", "Australia/Hobart", -42.8821, 147.3272),
    ("Lord Howe", "Australia/Lord_Howe", -31.5553, 159.0821),
)


def timezone_offset_minutes(name):
    local_now = datetime.now(ZoneInfo(name))
    delta = local_now.utcoffset()
    return int(delta.total_seconds() // 60)


def timezone_from_coordinates(latitude, longitude):
    if TIMEZONE_FINDER is None:
        return ""
    try:
        latitude = float(latitude)
        longitude = float(longitude)
        if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
            return ""
        return TIMEZONE_FINDER.timezone_at(lng=longitude, lat=latitude) or ""
    except (TypeError, ValueError, OverflowError):
        return ""


def australian_timezone_place(latitude, longitude, gps_zone):
    try:
        latitude = float(latitude)
        longitude = float(longitude)
        if not (-44.5 <= latitude <= -9.0 and 112.0 <= longitude <= 160.5):
            return ""
        gps_minutes = timezone_offset_minutes(gps_zone)
    except (TypeError, ValueError, OSError):
        return ""
    candidates = []
    for name, zone, place_latitude, place_longitude in AUSTRALIAN_TIMEZONE_PLACES:
        try:
            if timezone_offset_minutes(zone) != gps_minutes:
                continue
        except (ValueError, OSError):
            continue
        latitude_scale = math.cos(math.radians((latitude + place_latitude) / 2))
        distance = (latitude - place_latitude) ** 2 + ((longitude - place_longitude) * latitude_scale) ** 2
        candidates.append((distance, name))
    return min(candidates)[1] if candidates else ""


def timezone_abbreviation(name, minutes):
    if name == "Australia/Perth":
        return "AWST"
    if name == "Australia/Eucla":
        return "ACWST"
    if name == "Australia/Darwin":
        return "ACST"
    if name in {"Australia/Adelaide", "Australia/Broken_Hill"}:
        return "ACDT" if minutes == 630 else "ACST"
    if name in {"Australia/Brisbane", "Australia/Lindeman"}:
        return "AEST"
    if name in {"Australia/Sydney", "Australia/Melbourne", "Australia/Hobart"}:
        return "AEDT" if minutes == 660 else "AEST"
    if name == "Australia/Lord_Howe":
        return "LHDT" if minutes == 660 else "LHST"
    return datetime.now(ZoneInfo(name)).tzname() or ""


def timezone_choices(current_zone, gps_zone="", gps_label=""):
    available = available_timezones()
    representatives = {}
    for name in sorted(available):
        try:
            representatives.setdefault(timezone_offset_minutes(name), name)
        except (ValueError, OSError):
            continue
    for name in CANONICAL_TIMEZONES:
        if name not in available:
            continue
        try:
            representatives[timezone_offset_minutes(name)] = name
        except (ValueError, OSError):
            continue
    if gps_zone in available:
        try:
            representatives[timezone_offset_minutes(gps_zone)] = gps_zone
        except (ValueError, OSError):
            gps_zone = ""
    zones = []
    for minutes in sorted(representatives):
        name = representatives[minutes]
        zones.append({
            "minutes": minutes,
            "timezone": name,
            "abbreviation": timezone_abbreviation(name, minutes),
            "label": gps_label if gps_label and name == gps_zone else name.rsplit("/", 1)[-1].replace("_", " "),
        })
    return zones, gps_zone


def wurb_valid_location(candidates=None):
    if candidates is None:
        candidates = [pathlib.Path("/home/wurb/wurb_settings/wurb_settings.db")]
        candidates.extend(pathlib.Path("/home").glob("*/wurb_settings/wurb_settings.db"))
    for database in dict.fromkeys(candidates):
        if not database.is_file():
            continue
        try:
            connection = sqlite3.connect(f"file:{database}?mode=ro", uri=True, timeout=0.5)
            try:
                values = dict(connection.execute(
                    "SELECT key, value FROM key_value_data WHERE identity='location'"
                ).fetchall())
            finally:
                connection.close()

            def number(key):
                try:
                    return float(values.get(key, 0.0) or 0.0)
                except (TypeError, ValueError):
                    return 0.0

            latitude = number("latitudeDd")
            longitude = number("longitudeDd")
            if latitude == 0.0 or longitude == 0.0:
                if str(values.get("geoSource", "")) == "geo-gps-or-last-found":
                    latitude = number("lastGpsLatitudeDd")
                    longitude = number("lastGpsLongitudeDd")
                if latitude == 0.0 or longitude == 0.0:
                    latitude = number("defaultLatitudeDd")
                    longitude = number("defaultLongitudeDd")
            if (latitude != 0.0 and longitude != 0.0
                    and -90 <= latitude <= 90 and -180 <= longitude <= 180):
                return latitude, longitude
        except (OSError, ValueError, sqlite3.Error):
            continue
    return None


def systemd_unit_installed(unit):
    try:
        result = subprocess.run(["systemctl", "show", "--property=LoadState", "--value", unit],
                                capture_output=True, text=True, timeout=3)
        return result.returncode == 0 and result.stdout.strip() == "loaded"
    except (OSError, subprocess.SubprocessError):
        return False


def allsky_project_path():
    if not systemd_unit_installed("allsky.service"):
        return None
    candidates = {
        pathlib.Path("/home/allsky"),
        pathlib.Path("/opt/allsky"),
        *(pathlib.Path("/home").glob("*/allsky")),
    }
    for path in candidates:
        if ((path / "allsky.sh").is_file() and (path / "html").is_dir()
                and ((path / "config/settings.json").exists() or (path / "config/config.sh").is_file())):
            return path.resolve()
    return None


def validate_allsky_backup_name(value):
    name = str(value).strip()
    if name.lower().endswith(".tar.gz"):
        name = name[:-7]
    if (not re.fullmatch(r"[A-Za-z0-9ÄÖÜäöüß][A-Za-z0-9ÄÖÜäöüß ._-]{0,79}", name)
            or name in {".", ".."}):
        raise ValueError("Invalid backup name")
    return name.rstrip(" .") + ".tar.gz"


def allsky_backup_path(name):
    safe_name = pathlib.Path(str(name)).name
    if safe_name != str(name) or not safe_name.lower().endswith(".tar.gz") or safe_name.startswith("."):
        raise ValueError("Invalid backup filename")
    path = (ALLSKY_BACKUP_DIR / safe_name).resolve()
    if path.parent != ALLSKY_BACKUP_DIR.resolve():
        raise ValueError("Invalid backup path")
    return path


def create_allsky_archive(project, destination):
    sources = [(project / "config", "allsky/config"),
               (project / "env.json", "allsky/env.json"),
               (project / "darks", "allsky/darks")]
    if not (project / "config").is_dir():
        raise FileNotFoundError("Allsky configuration directory not found")
    metadata = json.dumps({
        "format": "witty-allsky-settings-v1",
        "created_at": datetime.now().astimezone().isoformat(),
        "source": str(project),
        "includes": [archive_name for source, archive_name in sources if source.exists()],
        "excludes": ["images", "videos", "tmp"],
    }, ensure_ascii=False, indent=2).encode("utf-8")
    with tarfile.open(destination, "w:gz", dereference=False) as archive:
        manifest = tarfile.TarInfo("witty-allsky-backup.json")
        manifest.size = len(metadata)
        manifest.mode = 0o644
        manifest.mtime = int(time.time())
        archive.addfile(manifest, io.BytesIO(metadata))
        for source, archive_name in sources:
            if source.exists() or source.is_symlink():
                archive.add(source, arcname=archive_name, recursive=True)


def software_project_path(component):
    names = {"wurb": "wurb_2026", "wirc": "wirc_2026", "allsky": "allsky"}
    name = names.get(component)
    if not name:
        return None
    candidates = [pathlib.Path("/home/wurb") / name]
    candidates.extend(pathlib.Path("/home").glob(f"*/{name}"))
    return next((path.resolve() for path in candidates if path.is_dir()), None)


def create_component_backup(component, keep_local):
    project = software_project_path(component)
    if project is None:
        raise FileNotFoundError("Software is not installed")
    timestamp = datetime.now().astimezone().strftime("%Y-%m-%d--%H-%M-%S")
    filename = f"{component}_settings_{timestamp}.tar.gz"
    if keep_local:
        target_directory = ALLSKY_BACKUP_DIR if component == "allsky" else SOFTWARE_BACKUP_DIR
        target_directory.mkdir(parents=True, exist_ok=True)
        destination = target_directory / filename
    else:
        SOFTWARE_TEMP_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        destination = SOFTWARE_TEMP_BACKUP_DIR / f"{uuid.uuid4().hex}.tar.gz"
    if component == "allsky":
        create_allsky_archive(project, destination)
    else:
        settings_dir = pathlib.Path("/home/wurb") / f"{component}_settings"
        sources = []
        if settings_dir.exists():
            sources.append((settings_dir, f"{component}/settings"))
        for candidate in (project / "config", project / "settings"):
            if candidate.exists():
                sources.append((candidate, f"{component}/project-{candidate.name}"))
        for candidate in sorted(project.glob("*.yaml")) + sorted(project.glob("*.yml")) + sorted(project.glob("*.json")):
            if candidate.is_file() and candidate.stat().st_size <= 8 * 1024 * 1024:
                sources.append((candidate, f"{component}/project-files/{candidate.name}"))
        metadata = json.dumps({
            "format": "witty-software-settings-v1", "component": component,
            "created_at": datetime.now().astimezone().isoformat(), "source": str(project),
            "includes": [archive_name for _, archive_name in sources],
            "excludes": ["recordings", "venv", ".git", "logs"],
        }, ensure_ascii=False, indent=2).encode("utf-8")
        with tarfile.open(destination, "w:gz", dereference=False) as archive:
            manifest = tarfile.TarInfo("witty-software-backup.json")
            manifest.size = len(metadata); manifest.mode = 0o644; manifest.mtime = int(time.time())
            archive.addfile(manifest, io.BytesIO(metadata))
            for source, archive_name in sources:
                archive.add(source, arcname=archive_name, recursive=True)
    destination.chmod(0o640)
    return destination, filename


def restore_component_backup(component, archive_path):
    archive_path = pathlib.Path(archive_path)
    if component == "allsky":
        project = allsky_project_path()
        if project is None:
            raise FileNotFoundError("Allsky is not installed after reinstallation")
        restore_allsky_archive(project, archive_path)
        return
    project = software_project_path(component)
    if project is None:
        raise FileNotFoundError(f"{component.upper()} is not installed after reinstallation")
    prefix = f"{component}/"
    with tarfile.open(archive_path, "r:gz") as archive:
        members = archive.getmembers()
        manifest_member = next((item for item in members if item.name == "witty-software-backup.json"), None)
        if manifest_member is None:
            raise ValueError("Software backup manifest is missing")
        manifest_stream = archive.extractfile(manifest_member)
        manifest = json.loads(manifest_stream.read().decode("utf-8")) if manifest_stream else {}
        if manifest.get("format") != "witty-software-settings-v1" or manifest.get("component") != component:
            raise ValueError("Software backup does not match the selected component")
        for member in members:
            normalised = posixpath.normpath(member.name)
            if (member.name.startswith("/") or normalised.startswith("../") or normalised == ".."
                    or (normalised != "witty-software-backup.json" and not normalised.startswith(prefix))
                    or member.isdev() or member.isfifo() or member.islnk() or member.issym()):
                raise ValueError("Software backup contains an unsafe entry")
        with tempfile.TemporaryDirectory(prefix=f"{component}-restore-", dir=APP_DIR) as temporary:
            staging = pathlib.Path(temporary)
            archive.extractall(staging, filter="data")
            staged = staging / component
            replacements = []
            if (staged / "settings").is_dir():
                replacements.append((staged / "settings", pathlib.Path("/home/wurb") / f"{component}_settings"))
            for name in ("config", "settings"):
                source = staged / f"project-{name}"
                if source.is_dir():
                    replacements.append((source, project / name))
            project_files = staged / "project-files"
            if project_files.is_dir():
                replacements.extend((source, project / source.name) for source in project_files.iterdir() if source.is_file())
            unit = f"{component}_2026.service"
            was_active = service_active(unit)
            if was_active:
                subprocess.run(["systemctl", "stop", unit], check=True, timeout=60)
            try:
                for source, target in replacements:
                    if target.is_symlink() or target.is_file():
                        target.unlink()
                    elif target.is_dir():
                        shutil.rmtree(target)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(source), str(target))
                    subprocess.run(["chown", "-R", "wurb:wurb", str(target)], check=False, timeout=60)
            finally:
                if was_active:
                    subprocess.run(["systemctl", "start", unit], check=True, timeout=60)


def resolve_software_backup_reference(reference):
    reference = str(reference or "")
    if reference.startswith("local:"):
        name = pathlib.Path(reference[6:]).name
        if name != reference[6:] or not name.endswith(".tar.gz"):
            raise ValueError("Invalid local backup reference")
        for directory in (SOFTWARE_BACKUP_DIR, ALLSKY_BACKUP_DIR):
            target = directory / name
            if target.is_file() and not target.is_symlink():
                return target.resolve(), False
    elif reference.startswith("temporary:"):
        token = reference[10:]
        if re.fullmatch(r"[a-f0-9]{32}", token):
            target = SOFTWARE_TEMP_BACKUP_DIR / f"{token}.tar.gz"
            if target.is_file() and not target.is_symlink():
                return target.resolve(), True
    raise FileNotFoundError("Selected software backup is not available")


def validate_allsky_archive(path):
    allowed = ("allsky/config", "allsky/env.json", "allsky/darks")
    manifest_found = False
    settings_found = False
    members = []
    with tarfile.open(path, "r:gz") as archive:
        for member in archive:
            members.append(member)
            if len(members) > 200000:
                raise ValueError("Backup contains too many entries")
            normalised = posixpath.normpath(member.name)
            if member.name.startswith("/") or normalised.startswith("../") or normalised == "..":
                raise ValueError("Backup contains an unsafe path")
            if normalised == "witty-allsky-backup.json":
                manifest_found = True
                continue
            if not any(normalised == prefix or normalised.startswith(prefix + "/") for prefix in allowed):
                raise ValueError(f"Backup contains an unsupported path: {member.name}")
            if normalised in {"allsky/config/settings.json", "allsky/config/config.sh"}:
                settings_found = True
            if member.isdev() or member.isfifo() or member.islnk():
                raise ValueError("Backup contains an unsupported special file")
            if member.issym():
                if member.linkname.startswith("/"):
                    raise ValueError("Backup contains an unsafe symbolic link")
                link_target = posixpath.normpath(posixpath.join(posixpath.dirname(normalised), member.linkname))
                if not (link_target == "allsky/config" or link_target.startswith("allsky/config/")):
                    raise ValueError("Backup symbolic link points outside Allsky configuration")
    if not manifest_found or not settings_found:
        raise ValueError("This is not a complete Witty Allsky settings backup")
    return members


def allsky_service_states():
    units = ("allsky.service", "allskyperiodic.service", "allskyperiodic.timer")
    return {unit: service_active(unit) for unit in units}


def restore_allsky_archive(project, archive_path):
    validate_allsky_archive(archive_path)
    active_units = allsky_service_states()
    stopped = []
    rollback = ALLSKY_BACKUP_DIR / f".rollback-{datetime.now():%Y%m%d-%H%M%S}-{uuid.uuid4().hex}.tar.gz"
    create_allsky_archive(project, rollback)
    try:
        for unit, was_active in active_units.items():
            if was_active:
                subprocess.run(["systemctl", "stop", unit], check=True, timeout=60)
                stopped.append(unit)
        with tempfile.TemporaryDirectory(prefix="allsky-restore-", dir=APP_DIR) as temporary:
            staging = pathlib.Path(temporary)
            with tarfile.open(archive_path, "r:gz") as archive:
                archive.extractall(staging, numeric_owner=True, filter="data")
            staged_allsky = staging / "allsky"
            replacements = []
            for relative in ("config", "env.json", "darks"):
                source = staged_allsky / relative
                if source.exists() or source.is_symlink():
                    replacements.append((source, project / relative))
            for source, target in replacements:
                if target.is_symlink() or target.is_file():
                    target.unlink()
                elif target.is_dir():
                    shutil.rmtree(target)
                shutil.move(str(source), str(target))
        if not (project / "config").is_dir() or not (project / "config/settings.json").exists():
            raise RuntimeError("Restored Allsky settings are incomplete")
    except Exception:
        try:
            for relative in ("config", "env.json", "darks"):
                target = project / relative
                if target.is_symlink() or target.is_file():
                    target.unlink()
                elif target.is_dir():
                    shutil.rmtree(target)
            with tarfile.open(rollback, "r:gz") as archive:
                archive.extractall(project.parent, numeric_owner=True, filter="data")
        finally:
            for unit in stopped:
                subprocess.run(["systemctl", "start", unit], timeout=60, check=False)
        raise
    for unit in stopped:
        subprocess.run(["systemctl", "start", unit], timeout=60, check=True)
    subprocess.run(["systemctl", "try-reload-or-restart", "lighttpd.service"], timeout=30, check=False)
    try:
        rollback.unlink()
    except OSError:
        pass
    return stopped


def allsky_backup_listing():
    project = allsky_project_path()
    if project is None:
        raise FileNotFoundError("Allsky is not installed")
    ALLSKY_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    files = []
    for path in ALLSKY_BACKUP_DIR.iterdir():
        if path.is_file() and not path.is_symlink() and not path.name.startswith(".") and path.name.lower().endswith(".tar.gz"):
            stat = path.stat()
            files.append({"name": path.name, "size": stat.st_size, "modified": int(stat.st_mtime)})
    files.sort(key=lambda item: (item["modified"], item["name"]), reverse=True)
    return {"ok": True, "installed": True, "project": str(project), "files": files,
            "service_active": service_active("allsky.service")}


def is_recording_file(kind, path):
    return path.is_file() and not path.is_symlink() and path.suffix.lower() in RECORDING_SUFFIXES[kind]


def validate_upload_filename(kind, filename):
    filename = str(filename).strip()
    if (not filename or filename in {".", ".."} or "/" in filename or "\\" in filename
            or pathlib.Path(filename).name != filename):
        raise ValueError("Invalid filename")
    if pathlib.Path(filename).suffix.lower() not in RECORDING_SUFFIXES[kind]:
        raise ValueError("File type is not allowed for this recording page")
    return filename


def project_path(name):
    candidates = (pathlib.Path("/home/wurb") / name,
                  pathlib.Path("/home/pi") / name,
                  pathlib.Path("/opt") / name)
    if name == "wurb_2026":
        return next((path for path in candidates if (path / "wurb_main.py").is_file()
                     and (path / "wurb_app/templates/index.html").is_file()), None)
    if name == "wirc_2026":
        return next((path for path in candidates if (path / "wirc_main.py").is_file()
                     and (path / "wirc_app/templates/index.html").is_file()), None)
    return None


def project_installed(name):
    if name == "allsky":
        return allsky_project_path() is not None
    if name in {"wurb_2026", "wirc_2026"}:
        return project_path(name) is not None and systemd_unit_installed(f"{name}.service")
    return False


def component_path_present(component):
    names = {"wurb": "wurb_2026", "wirc": "wirc_2026", "allsky": "allsky"}
    name = names.get(component)
    if not name:
        return True
    candidates = {
        pathlib.Path("/home/wurb") / name,
        pathlib.Path("/home/pi") / name,
        pathlib.Path("/opt") / name,
        *(pathlib.Path("/home").glob(f"*/{name}")),
    }
    return any(path.exists() for path in candidates)


def component_fully_removed(component):
    """Require both project files and systemd units to be gone."""
    if component == "wurb":
        return (not component_path_present("wurb")
                and not systemd_unit_installed("wurb_2026.service")
                and not service_active("wurb_2026.service")
                and not pathlib.Path("/usr/local/sbin/wurb-service").exists())
    if component == "wirc":
        return (not component_path_present("wirc")
                and not systemd_unit_installed("wirc_2026.service")
                and not service_active("wirc_2026.service")
                and not pathlib.Path("/usr/local/sbin/wirc-service").exists())
    if component == "allsky":
        units = ("allsky.service", "allskyperiodic.service", "allskyperiodic.timer")
        return (not component_path_present("allsky")
                and all(not systemd_unit_installed(unit) and not service_active(unit)
                        for unit in units))
    return False


def yaml_scalar(value):
    """Decode the simple scalar values used by CloudedBats record.targets."""
    value = value.split(" #", 1)[0].strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        value = value[1:-1]
    if value.lower() in {"true", "yes"}:
        return True
    if value.lower() in {"false", "no"}:
        return False
    try:
        return float(value)
    except ValueError:
        return value


def configured_record_targets(config_path):
    """Read record.targets without adding a PyYAML dependency to the webserver."""
    if not config_path.is_file():
        return []
    targets, current = [], None
    in_record = in_targets = False
    for raw_line in config_path.read_text(encoding="utf-8", errors="replace").splitlines():
        if not raw_line.strip() or raw_line.lstrip().startswith("#"):
            continue
        indent = len(raw_line) - len(raw_line.lstrip(" "))
        stripped = raw_line.strip()
        if indent == 0:
            in_record = stripped == "record:"
            in_targets = False
            continue
        if in_record and indent == 2:
            in_targets = stripped == "targets:"
            continue
        if not in_targets:
            continue
        if indent <= 2:
            break
        if indent == 4 and stripped.startswith("-"):
            if current:
                targets.append(current)
            current = {}
            stripped = stripped[1:].strip()
            if ":" in stripped:
                key, value = stripped.split(":", 1)
                current[key.strip()] = yaml_scalar(value)
        elif current is not None and indent >= 6 and ":" in stripped:
            key, value = stripped.split(":", 1)
            current[key.strip()] = yaml_scalar(value)
    if current:
        targets.append(current)
    return targets


def target_recording_path(project, target, require_free_space=True):
    rec_dir = str(target.get("rec_dir", "")).strip()
    if not rec_dir or str(target.get("os", "Linux")) not in {"", "Linux"}:
        return None
    rec_path = pathlib.Path(rec_dir)
    media_value = str(target.get("media_path", "")).strip()
    if rec_path.is_absolute():
        base, candidate = rec_path.parent, rec_path
    elif bool(target.get("executable_path_as_base", False)):
        base, candidate = project, project / rec_path
    elif media_value:
        base = pathlib.Path(media_value)
        if not base.is_mount():
            return None
        candidate = base / rec_path
    else:
        base, candidate = project, project / rec_path
    try:
        free_limit = float(target.get("free_disk_limit", 100)) * (2 ** 20)
        if not base.exists() or (require_free_space and shutil.disk_usage(base).free < free_limit):
            return None
        candidate.mkdir(parents=True, exist_ok=True)
        return candidate.resolve()
    except (OSError, TypeError, ValueError):
        return None


def recording_target_choices(kind):
    if kind not in RECORDING_KINDS:
        raise ValueError("Unknown recording type")
    project = project_path(f"{kind}_2026")
    if project is None:
        raise FileNotFoundError(f"{kind.upper()}-2026 is not installed")
    config_path = project.parent / f"{kind}_settings" / f"{kind}_config.yaml"
    default_path = project / f"{kind}_config_default.yaml"
    targets = configured_record_targets(config_path)
    if not targets:
        targets = configured_record_targets(default_path)
    active_path = next((path for configured_target in targets
                        if (path := target_recording_path(project, configured_target, True)) is not None), None)
    choices, used_ids = [], set()
    for index, configured_target in enumerate(targets, 1):
        path = target_recording_path(project, configured_target, False)
        if path is None:
            continue
        base_id = str(configured_target.get("id", "")).strip() or f"target-{index}"
        target_id, suffix = base_id, 2
        while target_id in used_ids:
            target_id = f"{base_id}-{suffix}"; suffix += 1
        used_ids.add(target_id)
        choices.append({"id": target_id,
                        "name": str(configured_target.get("name", "")).strip() or base_id,
                        "path": path,
                        "active": active_path is not None and path == active_path})
    if not choices:
        fallback = project.parent / RECORDING_KINDS[kind]
        fallback.mkdir(parents=True, exist_ok=True)
        choices.append({"id": "local", "name": "Local", "path": fallback.resolve(), "active": True})
    elif not any(choice["active"] for choice in choices):
        choices[0]["active"] = True
    return choices


def recording_root(kind, target_id="", strict=False):
    choices = recording_target_choices(kind)
    if target_id:
        selected = next((choice for choice in choices if choice["id"] == target_id), None)
        if selected is not None:
            return selected["path"]
        if strict:
            raise ValueError("Selected recording target is not available")
    return next((choice["path"] for choice in choices if choice["active"]), choices[0]["path"])


def safe_recording_path(root, relative="", must_exist=True):
    value = str(relative or "").replace("\\", "/")
    candidate_relative = pathlib.PurePosixPath(value)
    if candidate_relative.is_absolute() or ".." in candidate_relative.parts:
        raise ValueError("Invalid path")
    candidate = (root / pathlib.Path(*candidate_relative.parts)).resolve(strict=must_exist)
    if candidate != root and root not in candidate.parents:
        raise ValueError("Path outside recording directory")
    return candidate


def deletion_sources(root, kind, relative_paths):
    if not isinstance(relative_paths, list) or not relative_paths:
        raise ValueError("No files or folders selected")
    candidates = []
    for relative in dict.fromkeys(str(value) for value in relative_paths):
        source = safe_recording_path(root, relative)
        if source == root or source.is_symlink() or not (source.is_dir() or is_recording_file(kind, source)):
            raise ValueError(f"Can not delete {source.name}")
        candidates.append(source)
    candidates.sort(key=lambda item: len(item.parts))
    selected_roots = []
    for source in candidates:
        if not any(parent in selected_roots for parent in source.parents):
            selected_roots.append(source)
    folders_with_files = sum(
        1 for source in selected_roots
        if source.is_dir() and any(item.is_file() or item.is_symlink() for item in source.rglob("*"))
    )
    return selected_roots, folders_with_files


def recording_listing(kind, target_id=""):
    choices = recording_target_choices(kind)
    selected = next((choice for choice in choices if choice["id"] == target_id), None)
    if selected is None:
        selected = next((choice for choice in choices if choice["active"]), choices[0])
    root = selected["path"]
    directories, files = [], []
    for item in root.rglob("*"):
        try:
            resolved = item.resolve(strict=True)
            if resolved != root and root not in resolved.parents:
                continue
            relative = item.relative_to(root).as_posix()
            stat = item.stat()
            parent_relative = item.parent.relative_to(root)
            parent_name = "" if parent_relative == pathlib.Path(".") else parent_relative.as_posix()
            if item.is_dir() and not item.is_symlink():
                directories.append({"path": relative, "name": item.name,
                                    "parent": parent_name})
            elif is_recording_file(kind, item):
                files.append({"path": relative, "name": item.name,
                              "parent": parent_name,
                              "size": stat.st_size, "modified": int(stat.st_mtime)})
        except (OSError, ValueError):
            continue
    directories.sort(key=lambda item: (item["parent"].lower(), item["name"].lower()))
    files.sort(key=lambda item: (-item["modified"], item["name"].lower()))
    public_targets = [{"id": choice["id"], "name": choice["name"],
                       "path": str(choice["path"]), "active": choice["active"]}
                      for choice in choices]
    return {"ok": True, "kind": kind, "root": str(root), "selected_target": selected["id"],
            "targets": public_targets, "directories": directories, "files": files,
            "updated": datetime.now().astimezone().isoformat()}


def cleanup_old_downloads():
    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    limit = time.time() - 3600
    for item in list(DOWNLOAD_DIR.glob("*.zip")) + list(DOWNLOAD_DIR.glob("*.tar.gz")):
        try:
            if item.stat().st_mtime < limit:
                item.unlink()
        except OSError:
            pass


def create_recording_zip(kind, relative_paths, folder_path="", target_id=""):
    root = recording_root(kind, target_id, strict=True)
    selected = []
    if folder_path:
        folder = safe_recording_path(root, folder_path)
        if not folder.is_dir():
            raise ValueError("Folder not found")
        selected = [item for item in folder.rglob("*") if is_recording_file(kind, item)]
        archive_label = folder.name
    else:
        if not isinstance(relative_paths, list) or not relative_paths:
            raise ValueError("No files selected")
        for relative in relative_paths:
            item = safe_recording_path(root, relative)
            if not is_recording_file(kind, item):
                raise ValueError("Only files can be selected")
            selected.append(item)
        archive_label = f"{kind}_recordings_{datetime.now().astimezone():%Y-%m-%d--%H-%M-%S}"
    cleanup_old_downloads()
    token = uuid.uuid4().hex
    archive = DOWNLOAD_DIR / f"{token}.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as output:
        used_names = set()
        for item in selected:
            if folder_path:
                member_name = item.relative_to(root).as_posix()
            else:
                # A ZIP created from individually selected files is flat. If
                # different directories contain an identical filename, retain
                # both using a stable numeric suffix instead of overwriting.
                member_name = item.name
                counter = 2
                while member_name.casefold() in used_names:
                    member_name = f"{item.stem}_{counter}{item.suffix}"
                    counter += 1
                used_names.add(member_name.casefold())
            output.write(item, member_name)
    return token, re.sub(r"[^A-Za-z0-9._-]+", "_", archive_label).strip("._") + ".zip"


def service_active(name):
    try:
        return subprocess.run(
            ["systemctl", "is-active", "--quiet", name], timeout=3
        ).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def navigation_status():
    witty_model = ""
    try:
        config = pathlib.Path("/etc/witty-addon.conf").read_text(encoding="utf-8")
        match = re.search(r"^WITTY_MODEL=([45])$", config, re.MULTILINE)
        witty_model = match.group(1) if match else ""
    except OSError:
        pass
    return {
        "wurb": project_installed("wurb_2026"),
        "wirc": project_installed("wirc_2026"),
        "allsky": project_installed("allsky"),
        "allsky_active": service_active("allsky.service"),
        "allsky_periodic_active": service_active("allskyperiodic.timer"),
        "wurb_active": service_active("wurb_2026.service"),
        "wirc_active": service_active("wirc_2026.service"),
        "witty": bool(witty_model) or pathlib.Path("/usr/local/bin/wp5").is_file()
                 or pathlib.Path("/usr/bin/wp5").is_file()
                 or pathlib.Path("/home/wurb/wittypi/utilities.sh").is_file(),
        "witty_model": witty_model,
    }


def append_software_output(chunk):
    with SOFTWARE_JOB_LOCK:
        SOFTWARE_JOB["output"].extend(chunk)
        SOFTWARE_JOB["output_total"] += len(chunk)
        if len(SOFTWARE_JOB["output"]) > 2000000:
            removed = len(SOFTWARE_JOB["output"]) - 1500000
            del SOFTWARE_JOB["output"][:removed]
            SOFTWARE_JOB["output_start"] += removed


def software_job_snapshot(cursor=None):
    with SOFTWARE_JOB_LOCK:
        output = bytes(SOFTWARE_JOB["output"][-750000:]).decode("utf-8", errors="replace")
        output = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", output)
        start = SOFTWARE_JOB["output_start"]
        total = SOFTWARE_JOB["output_total"]
        requested = start if cursor is None else max(0, int(cursor))
        reset_required = requested < start or requested > total
        if reset_required:
            requested = start
        raw = bytes(SOFTWARE_JOB["output"][requested - start:])
        return {"ok": True, "running": SOFTWARE_JOB["running"], "action": SOFTWARE_JOB["action"],
                "component": SOFTWARE_JOB["component"], "exit_code": SOFTWARE_JOB["exit_code"],
                "reboot_scheduled": SOFTWARE_JOB["reboot_scheduled"],
                "cancel_requested": SOFTWARE_JOB["cancel_requested"], "output": output,
                "terminal_base64": base64.b64encode(raw).decode("ascii"),
                "terminal_cursor": total, "terminal_reset": reset_required}


def finish_software_job(process, master_fd):
    while True:
        try:
            ready, _, _ = select.select([master_fd], [], [], 0.5)
            if ready:
                chunk = os.read(master_fd, 65536)
                if not chunk:
                    break
                append_software_output(chunk)
            elif process.poll() is not None:
                try:
                    chunk = os.read(master_fd, 65536)
                    if chunk:
                        append_software_output(chunk)
                except OSError:
                    pass
                break
        except OSError:
            break
    return_code = process.wait()
    try:
        os.close(master_fd)
    except OSError:
        pass
    with SOFTWARE_JOB_LOCK:
        completed_component = SOFTWARE_JOB["component"]
        completed_action = SOFTWARE_JOB["action"]
        backup_path = SOFTWARE_JOB.get("backup_path", "")
        backup_temporary = SOFTWARE_JOB.get("backup_temporary", False)
        restore_backup = SOFTWARE_JOB.get("restore_backup", False)
    if return_code == 0 and completed_action == "install" and restore_backup and backup_path:
        try:
            append_software_output(b"\nSettings backup is being restored ...\n")
            restore_component_backup(completed_component, backup_path)
            append_software_output(b"Settings backup was restored successfully.\n")
        except Exception as error:
            append_software_output(f"BACKUP RESTORE ERROR: {error}\n".encode("utf-8", errors="replace"))
            return_code = 1
    if (return_code == 0 and completed_action == "uninstall"
            and not component_fully_removed(completed_component)):
        append_software_output(
            b"\nERROR: Removal verification failed; files or a service are still present.\n"
        )
        return_code = 1
    if backup_temporary and backup_path:
        try:
            pathlib.Path(backup_path).unlink()
        except OSError:
            pass
    with SOFTWARE_JOB_LOCK:
        SOFTWARE_JOB["running"] = False
        SOFTWARE_JOB["exit_code"] = return_code
        SOFTWARE_JOB["master_fd"] = None
        SOFTWARE_JOB["process"] = None
        # WURB and WIRC are fully activated and started by their installers.
        # Only Allsky retains the reboot/finalisation path.
        SOFTWARE_JOB["reboot_scheduled"] = (return_code == 0
                                              and not SOFTWARE_JOB["cancel_requested"]
                                              and completed_component == "allsky"
                                              and SOFTWARE_JOB["action"] == "install")
        reboot_scheduled = SOFTWARE_JOB["reboot_scheduled"]
    if reboot_scheduled:
        timer = threading.Timer(5, lambda: subprocess.run(["systemctl", "reboot"], check=False))
        timer.daemon = True
        timer.start()


def start_software_job(action, component, backup_reference="", restore_backup=False):
    if action not in {"install", "uninstall"} or component not in {"wurb", "wirc", "allsky"}:
        raise ValueError("Invalid software operation")
    installed = project_installed({"wurb": "wurb_2026", "wirc": "wirc_2026", "allsky": "allsky"}[component])
    if action == "uninstall" and not installed:
        raise ValueError("Software is not installed")
    backup_path = ""
    backup_temporary = False
    if restore_backup:
        if action != "install" or not installed:
            raise ValueError("A backup can only be restored during reinstallation")
        backup_path, backup_temporary = resolve_software_backup_reference(backup_reference)
    script = APP_DIR / "manager" / "software_manager.sh"
    if not script.is_file():
        raise FileNotFoundError("Software manager is not installed")
    with SOFTWARE_JOB_LOCK:
        if SOFTWARE_JOB["running"]:
            raise RuntimeError("Another software operation is already running")
        master_fd, slave_fd = pty.openpty()
        fcntl.ioctl(slave_fd, termios.TIOCSWINSZ, struct.pack("HHHH", 40, 100, 0, 0))
        process = subprocess.Popen([str(script), action, component], stdin=slave_fd, stdout=slave_fd,
                                   stderr=slave_fd, close_fds=True, start_new_session=True,
                                   env={**os.environ, "TERM": "xterm-256color", "LINES": "40", "COLUMNS": "100",
                                        "DEBIAN_FRONTEND": "noninteractive", "APT_LISTCHANGES_FRONTEND": "none",
                                        "NO_COLOR": "1"})
        os.close(slave_fd)
        SOFTWARE_JOB.update({"running": True, "output": bytearray(), "output_start": 0, "output_total": 0, "process": process,
                             "master_fd": master_fd, "action": action, "component": component,
                             "exit_code": None, "reboot_scheduled": False, "cancel_requested": False,
                             "backup_path": str(backup_path), "backup_temporary": backup_temporary,
                             "restore_backup": bool(restore_backup)})
    thread = threading.Thread(target=finish_software_job, args=(process, master_fd), daemon=True)
    thread.start()
    return software_job_snapshot()


def cancel_software_job():
    with SOFTWARE_JOB_LOCK:
        process = SOFTWARE_JOB.get("process")
        if not SOFTWARE_JOB["running"] or process is None:
            raise RuntimeError("No software operation is running")
        SOFTWARE_JOB["cancel_requested"] = True
        process_id = process.pid
        cancelled_allsky_install = (SOFTWARE_JOB.get("component") == "allsky"
                                    and SOFTWARE_JOB.get("action") == "install")
    try:
        os.killpg(process_id, signal.SIGTERM)
    except ProcessLookupError:
        pass

    def disable_incomplete_allsky_finaliser():
        if cancelled_allsky_install:
            subprocess.run(["systemctl", "disable", "wittypi5-allsky-firstboot.service"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)

    disable_incomplete_allsky_finaliser()

    def force_stop():
        if process.poll() is None:
            try:
                os.killpg(process_id, signal.SIGKILL)
            except ProcessLookupError:
                pass
        disable_incomplete_allsky_finaliser()

    timer = threading.Timer(5, force_stop)
    timer.daemon = True
    timer.start()
    return software_job_snapshot()


class Handler(BaseHTTPRequestHandler):
    server_version = "wittypi5-webserver/1.0"

    def send_response_headers(self, status=200, content_type="application/json; charset=utf-8"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_OPTIONS(self):
        self.send_response_headers(204)

    def send_json(self, payload, status=200):
        encoded = json.dumps(payload).encode()
        self.send_response_headers(status)
        self.wfile.write(encoded)

    def send_download(self, target, download_name, delete_after=False):
        completed = False
        try:
            self.send_response(200)
            self.send_header("Content-Type", mimetypes.guess_type(download_name)[0] or "application/octet-stream")
            ascii_name = re.sub(r"[^A-Za-z0-9._-]+", "_", download_name)
            self.send_header("Content-Disposition", f"attachment; filename=\"{ascii_name}\"; filename*=UTF-8''{quote(download_name)}")
            self.send_header("Content-Length", str(target.stat().st_size))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with target.open("rb") as source:
                shutil.copyfileobj(source, self.wfile, length=1024 * 1024)
            completed = True
        finally:
            if delete_after and completed:
                try:
                    target.unlink()
                except OSError:
                    pass

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        if path == "/api/navigation":
            payload = navigation_status()
            try:
                local_address = self.connection.getsockname()[0]
                if local_address not in {"0.0.0.0", "::", "127.0.0.1", "::1"}:
                    payload["access_host"] = local_address
            except (AttributeError, IndexError, OSError):
                pass
            self.send_response_headers()
            self.wfile.write(json.dumps(payload).encode())
            return
        if path == "/api/software-job":
            try:
                cursor = int(query.get("cursor", ["0"])[0])
            except ValueError:
                cursor = 0
            self.send_json(software_job_snapshot(cursor))
            return
        if path == "/api/allsky-backups":
            try:
                self.send_json(allsky_backup_listing())
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 404)
            return
        if path == "/api/timezones":
            current_zone = subprocess.run(
                ["timedatectl", "show", "--property=Timezone", "--value"],
                capture_output=True, text=True, timeout=3
            ).stdout.strip() or "Etc/UTC"
            if current_zone == "Witty/FixedOffset":
                try:
                    current_zone = pathlib.Path("/var/lib/witty-addon/previous_timezone").read_text().strip() or "Etc/UTC"
                except OSError:
                    current_zone = "Etc/UTC"
            gps_zone = timezone_from_coordinates(
                query.get("lat", [None])[0], query.get("lon", [None])[0]
            ) if "lat" in query and "lon" in query else ""
            gps_label = australian_timezone_place(
                query.get("lat", [None])[0], query.get("lon", [None])[0], gps_zone
            ) if gps_zone.startswith("Australia/") else ""
            zones, gps_zone = timezone_choices(current_zone, gps_zone, gps_label)
            self.send_response_headers()
            self.wfile.write(json.dumps({"ok": True, "zones": zones,
                                         "current_timezone": current_zone,
                                         "gps_timezone": gps_zone,
                                         "coordinate_lookup_available": TIMEZONE_FINDER is not None}).encode())
            return
        if path == "/api/log-progress":
            log_dir = APP_DIR / "logs"
            candidates = [item for item in log_dir.glob("download/**/*.log") if item.is_file()]
            received = max((item.stat().st_size for item in candidates), default=0)
            self.send_response_headers()
            self.wfile.write(json.dumps({
                "ok": True,
                "active": (log_dir / ".log-download-active").is_file(),
                "received_bytes": received,
                "local_available": any(
                    item.is_file() and item.stat().st_size > 0
                    for item in (log_dir / "WittyPi5.log", log_dir / "WittyPi4.log")
                ),
                "local_size": max(
                    (item.stat().st_size for item in
                     (log_dir / "WittyPi5.log", log_dir / "WittyPi4.log")
                     if item.is_file()), default=0
                ),
            }).encode())
            return
        if path == "/api/reset-progress":
            try:
                payload = json.loads(RESET_PROGRESS_FILE.read_text(encoding="utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Invalid reset progress")
            except (OSError, ValueError, json.JSONDecodeError):
                payload = {"ok": True, "active": False, "state": "idle", "phase": "idle",
                           "current": 0, "total": 1, "percent": 0, "detail": "",
                           "started_at": 0, "updated_at": 0}
            self.send_json(payload)
            return
        if path in {"/logs/WittyPi5.log", "/logs/WittyPi4.log"}:
            target = APP_DIR / "logs" / pathlib.Path(path).name
            if not target.is_file():
                self.send_response_headers(404)
                self.wfile.write(b'{"ok":false,"error":"Log not found"}')
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Disposition", 'attachment; filename="WittyPi5.log"')
            self.send_header("Content-Length", str(target.stat().st_size))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with target.open("rb") as source:
                shutil.copyfileobj(source, self.wfile, length=64 * 1024)
            return
        if path == "/allsky-backup":
            try:
                if allsky_project_path() is None:
                    raise FileNotFoundError("Allsky is not installed")
                target = allsky_backup_path(query.get("name", [""])[0])
                if not target.is_file() or target.is_symlink():
                    raise FileNotFoundError("Backup not found")
                self.send_download(target, target.name)
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 404)
            return
        if path == "/software-backup":
            try:
                temporary = query.get("temporary", ["false"])[0] == "true"
                name = pathlib.Path(query.get("name", [""])[0]).name
                if name != query.get("name", [""])[0] or not name.endswith(".tar.gz"):
                    raise ValueError("Invalid backup filename")
                if temporary:
                    token = query.get("token", [""])[0]
                    if not re.fullmatch(r"[a-f0-9]{32}", token):
                        raise ValueError("Invalid backup token")
                    target = SOFTWARE_TEMP_BACKUP_DIR / f"{token}.tar.gz"
                else:
                    target = SOFTWARE_BACKUP_DIR / name
                    if not target.is_file():
                        target = ALLSKY_BACKUP_DIR / name
                if not target.is_file() or target.is_symlink():
                    raise FileNotFoundError("Backup not found")
                retain = query.get("retain", ["false"])[0] == "true"
                self.send_download(target, name, delete_after=temporary and not retain)
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 404)
            return
        if path == "/api/recordings":
            try:
                self.send_json(recording_listing(query.get("kind", [""])[0], query.get("target", [""])[0]))
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 400)
            return
        if path == "/recording-file":
            try:
                kind = query.get("kind", [""])[0]
                relative = query.get("path", [""])[0]
                root = recording_root(kind, query.get("target", [""])[0], strict=True)
                target = safe_recording_path(root, relative)
                if not is_recording_file(kind, target):
                    raise FileNotFoundError("Recording not found")
                self.send_download(target, target.name)
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 404)
            return
        if path == "/recording-zip":
            token = query.get("token", [""])[0]
            name = query.get("name", ["recordings.zip"])[0]
            if not re.fullmatch(r"[a-f0-9]{32}", token):
                self.send_json({"ok": False, "error": "Invalid download token"}, 400)
                return
            target = DOWNLOAD_DIR / f"{token}.zip"
            if not target.is_file():
                self.send_json({"ok": False, "error": "ZIP file not found"}, 404)
                return
            self.send_download(target, pathlib.Path(name).name, delete_after=True)
            return
        files = {
            "/": WEB_DIR / "index.html",
            "/index.html": WEB_DIR / "index.html",
            "/manual": WEB_DIR / "manual.html",
            "/manual.html": WEB_DIR / "manual.html",
            "/allsky-setup": WEB_DIR / "allsky_setup.html",
            "/allsky-setup.html": WEB_DIR / "allsky_setup.html",
            "/recordings/wurb": WEB_DIR / "recordings.html",
            "/recordings/wirc": WEB_DIR / "recordings.html",
            "/assets/bulma-v1.0.4.min.css": WEB_DIR / "assets" / "bulma-v1.0.4.min.css",
            "/assets/cloudedbats_logo.png": WEB_DIR / "assets" / "cloudedbats_logo.png",
            "/assets/xterm.js": WEB_DIR / "assets" / "xterm.js",
            "/assets/xterm.css": WEB_DIR / "assets" / "xterm.css",
        }
        target = files.get(path)
        if not target or not target.is_file():
            self.send_response_headers(404)
            self.wfile.write(b'{"ok":false,"error":"Not found"}')
            return
        mime = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response_headers(200, mime)
        self.wfile.write(target.read_bytes())

    def do_POST(self):
        request_path = urlparse(self.path).path
        if request_path == "/api/software-backup":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 2 or length > 16 * 1024:
                    raise ValueError("Invalid request size")
                request = json.loads(self.rfile.read(length))
                component = str(request.get("component", ""))
                if component not in {"wurb", "wirc", "allsky"}:
                    raise ValueError("Invalid software component")
                keep_local = request.get("keep_local") is True
                restore_after = request.get("restore_after") is True
                target, filename = create_component_backup(component, keep_local)
                if keep_local:
                    url = f"/software-backup?name={quote(filename)}"
                    backup_reference = f"local:{filename}"
                else:
                    token = target.stem.split(".", 1)[0]
                    url = f"/software-backup?temporary=true&retain={'true' if restore_after else 'false'}&token={token}&name={quote(filename)}"
                    backup_reference = f"temporary:{token}"
                self.send_json({"ok": True, "name": filename, "size": target.stat().st_size,
                                "kept_local": keep_local, "url": url,
                                "backup_reference": backup_reference})
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 400)
            return
        if request_path == "/api/software-job":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 2 or length > 16 * 1024:
                    raise ValueError("Invalid request size")
                request = json.loads(self.rfile.read(length))
                operation = str(request.get("operation", ""))
                if operation == "start":
                    action = str(request.get("action", ""))
                    component = str(request.get("component", ""))
                    if request.get("confirmation") != f"{action}:{component}":
                        raise ValueError("Software operation was not confirmed")
                    payload = start_software_job(action, component,
                                                 str(request.get("backup_reference", "")),
                                                 request.get("restore_backup") is True)
                elif operation == "input":
                    data = str(request.get("data", ""))
                    with SOFTWARE_JOB_LOCK:
                        if (not SOFTWARE_JOB["running"] or SOFTWARE_JOB["component"] != "allsky"
                                or SOFTWARE_JOB["action"] != "install" or SOFTWARE_JOB["master_fd"] is None):
                            raise RuntimeError("No interactive Allsky installation is running")
                        if len(data) > 256 or "\x00" in data:
                            raise ValueError("Invalid installer input")
                        os.write(SOFTWARE_JOB["master_fd"], data.encode("utf-8"))
                    payload = {"ok": True}
                elif operation == "resize":
                    cols = int(request.get("cols", 100))
                    rows = int(request.get("rows", 40))
                    if not 40 <= cols <= 240 or not 20 <= rows <= 80:
                        raise ValueError("Invalid terminal size")
                    with SOFTWARE_JOB_LOCK:
                        if (not SOFTWARE_JOB["running"] or SOFTWARE_JOB["component"] != "allsky"
                                or SOFTWARE_JOB["action"] != "install" or SOFTWARE_JOB["master_fd"] is None):
                            raise RuntimeError("No interactive Allsky installation is running")
                        fcntl.ioctl(SOFTWARE_JOB["master_fd"], termios.TIOCSWINSZ,
                                    struct.pack("HHHH", rows, cols, 0, 0))
                        process = SOFTWARE_JOB.get("process")
                        if process is not None:
                            try:
                                os.killpg(process.pid, signal.SIGWINCH)
                            except ProcessLookupError:
                                pass
                    payload = {"ok": True}
                elif operation == "cancel":
                    payload = cancel_software_job()
                else:
                    raise ValueError("Action not allowed")
                self.send_json(payload)
            except RuntimeError as error:
                self.send_json({"ok": False, "error": str(error)}, 409)
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 400)
            return
        if request_path == "/api/recording-upload":
            self.handle_recording_upload()
            return
        if request_path == "/api/allsky-restore-upload":
            self.handle_allsky_restore_upload()
            return
        if request_path == "/api/allsky-backups":
            self.handle_allsky_action()
            return
        if request_path not in {"/api", "/api/recordings"}:
            self.send_response_headers(404); self.wfile.write(b'{"ok":false,"error":"Not found"}'); return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 2 or length > 8 * 1024 * 1024:
                raise ValueError("Invalid request size")
            request = json.loads(self.rfile.read(length))
            if request_path == "/api/recordings":
                self.handle_recording_action(request)
                return
            action = request.get("action", "")
            allowed = {
                "status", "system_to_witty", "witty_to_system", "manual_to_witty",
                "gps_to_system", "gps_to_witty", "clear_schedule", "read_schedule", "read_named_schedule",
                "upload_schedule", "read_log", "read_local_log", "delete_log", "reboot", "shutdown", "internal_rtc_toggle",
                "log_status", "witty_reset",
                "service_start", "service_stop",
                "gps_configure", "gps_remove",
                "fixed_timezone",
                "schedule_list", "schedule_activate", "schedule_delete",
            }
            if action not in allowed:
                raise ValueError("Action not allowed")
            arguments = [str(BACKEND), action]
            if action == "manual_to_witty":
                arguments.append(str(request.get("value", "")))
            elif action == "upload_schedule":
                arguments.extend((str(request.get("filename", "")), str(request.get("content_base64", ""))))
            elif action in {"service_start", "service_stop"}:
                arguments.append(str(request.get("service", "")))
            elif action in {"gps_configure", "gps_remove"}:
                arguments.append(str(request.get("mode", "")))
            elif action == "fixed_timezone":
                arguments.extend((str(bool(request.get("enabled", False))).lower(),
                                  str(request.get("timezone", "Etc/UTC"))))
            elif action in {"schedule_activate", "schedule_delete", "read_named_schedule"}:
                arguments.append(str(request.get("filename", "")))
            timeout_seconds = 1800 if action in {"read_log", "witty_reset"} else 420
            result = subprocess.run(arguments, capture_output=True, text=True, timeout=timeout_seconds)
            try:
                payload = json.loads(result.stdout or "{}")
            except json.JSONDecodeError:
                detail = (result.stderr or result.stdout or "").strip()[-2000:]
                payload = {"ok": False, "error": detail or "Backend lieferte keine gültige JSON-Antwort"}
            if action == "status" and payload.get("ok") and payload.get("gps_mode") in {"usb", "waveshare_l76x"}:
                if payload.get("gps_latitude") in {None, ""} or payload.get("gps_longitude") in {None, ""}:
                    location = wurb_valid_location()
                    if location is not None:
                        payload["gps_latitude"] = f"{location[0]:.7f}"
                        payload["gps_longitude"] = f"{location[1]:.7f}"
                        payload["gps_position_source"] = "wurb"
            if action == "status" and payload.get("ok"):
                payload["raspberry_pi_model"] = raspberry_pi_model()
            if not payload.get("ok") and not payload.get("error"):
                detail = (result.stderr or result.stdout or "").strip()[-2000:]
                payload["error"] = detail or f"Backend wurde mit Code {result.returncode} beendet"
            status = 200 if result.returncode == 0 and payload.get("ok") else 502
        except Exception as error:
            status, payload = 400, {"ok": False, "error": str(error)}
        self.send_response_headers(status)
        self.wfile.write(json.dumps(payload).encode())

    def handle_allsky_action(self):
        if not ALLSKY_LOCK.acquire(blocking=False):
            self.send_json({"ok": False, "error": "Allsky backup operation is already running"}, 409)
            return
        temporary = None
        try:
            project = allsky_project_path()
            if project is None:
                raise FileNotFoundError("Allsky is not installed")
            length = int(self.headers.get("Content-Length", "0"))
            if length < 2 or length > 64 * 1024:
                raise ValueError("Invalid request size")
            request = json.loads(self.rfile.read(length))
            action = str(request.get("action", ""))
            ALLSKY_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            if action == "create":
                filename = validate_allsky_backup_name(request.get("name", ""))
                destination = allsky_backup_path(filename)
                if destination.exists():
                    raise FileExistsError("A backup with this name already exists")
                temporary = ALLSKY_BACKUP_DIR / f".{uuid.uuid4().hex}.tar.gz"
                create_allsky_archive(project, temporary)
                validate_allsky_archive(temporary)
                temporary.chmod(0o640)
                os.replace(temporary, destination)
                temporary = None
                payload = {"ok": True, "name": filename, "size": destination.stat().st_size,
                           "url": f"/allsky-backup?name={quote(filename)}"}
            elif action == "delete":
                destination = allsky_backup_path(str(request.get("name", "")))
                if not destination.is_file() or destination.is_symlink():
                    raise FileNotFoundError("Backup not found")
                destination.unlink()
                payload = {"ok": True}
            else:
                raise ValueError("Action not allowed")
            self.send_json(payload)
        except FileExistsError as error:
            self.send_json({"ok": False, "error": str(error)}, 409)
        except Exception as error:
            if temporary is not None:
                try:
                    temporary.unlink()
                except OSError:
                    pass
            self.send_json({"ok": False, "error": str(error)}, 400)
        finally:
            ALLSKY_LOCK.release()

    def handle_allsky_restore_upload(self):
        if not ALLSKY_LOCK.acquire(blocking=False):
            self.send_json({"ok": False, "error": "Allsky backup operation is already running"}, 409)
            return
        write_path = None
        stored_path = None
        try:
            project = allsky_project_path()
            if project is None:
                raise FileNotFoundError("Allsky is not installed")
            query = parse_qs(urlparse(self.path).query, keep_blank_values=True)
            original_name = validate_allsky_backup_name(query.get("name", [""])[0])
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 1024 ** 3:
                raise ValueError("Invalid backup upload size")
            ALLSKY_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            if shutil.disk_usage(ALLSKY_BACKUP_DIR).free < length * 3 + 64 * 1024 * 1024:
                raise OSError("Not enough free space to validate and restore this backup")
            write_path = ALLSKY_BACKUP_DIR / f".{uuid.uuid4().hex}.upload.tar.gz"
            remaining = length
            with write_path.open("xb") as output:
                while remaining:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ConnectionError("Backup upload was interrupted")
                    output.write(chunk)
                    remaining -= len(chunk)
                output.flush()
                os.fsync(output.fileno())
            validate_allsky_archive(write_path)
            stored_name = original_name
            stored_path = allsky_backup_path(stored_name)
            if stored_path.exists():
                base = original_name[:-7]
                stored_name = f"{base}-uploaded-{datetime.now():%Y%m%d-%H%M%S}.tar.gz"
                stored_path = allsky_backup_path(stored_name)
            write_path.chmod(0o640)
            os.replace(write_path, stored_path)
            write_path = None
            restarted = restore_allsky_archive(project, stored_path)
            self.send_json({"ok": True, "name": stored_name, "restarted": restarted})
        except Exception as error:
            if write_path is not None:
                try:
                    write_path.unlink()
                except OSError:
                    pass
            self.send_json({"ok": False, "error": str(error)}, 400)
        finally:
            ALLSKY_LOCK.release()

    def handle_recording_upload(self):
        destination_file = None
        write_path = None
        created = False
        try:
            query = parse_qs(urlparse(self.path).query, keep_blank_values=True)
            kind = query.get("kind", [""])[0]
            target_id = query.get("target", [""])[0]
            folder_name = query.get("folder", [""])[0]
            filename = validate_upload_filename(kind, query.get("name", [""])[0])
            overwrite = query.get("overwrite", ["false"])[0].lower() == "true"
            root = recording_root(kind, target_id, strict=True)
            folder = safe_recording_path(root, folder_name)
            if not folder.is_dir() or folder.is_symlink():
                raise ValueError("Upload folder not found")
            destination_file = safe_recording_path(
                root, (folder / filename).relative_to(root).as_posix(), must_exist=False
            )
            if destination_file.exists() and (destination_file.is_symlink() or not destination_file.is_file()):
                raise ValueError("Upload destination is not a regular file")
            if destination_file.exists() and not overwrite:
                raise FileExistsError(filename)
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 1024 ** 4:
                raise ValueError("Invalid upload size")
            reclaimable = destination_file.stat().st_size if overwrite and destination_file.exists() else 0
            if shutil.disk_usage(folder).free + reclaimable < length + 16 * 1024 * 1024:
                raise OSError("Not enough free space for upload")
            remaining = length
            write_path = folder / f".{uuid.uuid4().hex}.recording-upload"
            with write_path.open("xb") as output:
                created = True
                while remaining:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ConnectionError("Upload was interrupted")
                    output.write(chunk)
                    remaining -= len(chunk)
                output.flush()
                os.fsync(output.fileno())
            write_path.chmod(0o644)
            if destination_file.exists() and not overwrite:
                raise FileExistsError(filename)
            os.replace(write_path, destination_file)
            created = False
            self.send_json({"ok": True, "name": filename, "size": length})
        except FileExistsError:
            self.send_json({"ok": False, "error": "A file with this name already exists"}, 409)
        except Exception as error:
            if created and write_path is not None:
                try:
                    write_path.unlink()
                except OSError:
                    pass
            self.send_json({"ok": False, "error": str(error)}, 400)

    def handle_recording_action(self, request):
        try:
            kind = str(request.get("kind", ""))
            action = str(request.get("action", ""))
            target_id = str(request.get("target", ""))
            root = recording_root(kind, target_id, strict=True)
            if action == "create_folder":
                name = str(request.get("name", "")).strip()
                if not re.fullmatch(r"[A-Za-z0-9ÄÖÜäöüß][A-Za-z0-9ÄÖÜäöüß ._-]{0,79}", name) or name in {".", ".."}:
                    raise ValueError("Invalid folder name")
                parent = safe_recording_path(root, str(request.get("parent", "")))
                if not parent.is_dir() or parent.is_symlink():
                    raise ValueError("Parent folder not found")
                target = safe_recording_path(root, (parent / name).relative_to(root).as_posix(), must_exist=False)
                target.mkdir(exist_ok=False)
                payload = {"ok": True}
            elif action == "upload_check":
                folder = safe_recording_path(root, str(request.get("folder", "")))
                if not folder.is_dir() or folder.is_symlink():
                    raise ValueError("Upload folder not found")
                names = request.get("names", [])
                if not isinstance(names, list) or not names:
                    raise ValueError("No files selected")
                checked = [validate_upload_filename(kind, name) for name in names]
                conflicts = [name for name in dict.fromkeys(checked) if (folder / name).exists()]
                payload = {"ok": True, "conflicts": conflicts}
            elif action == "delete_check":
                paths = request.get("paths", [])
                sources, folders_with_files = deletion_sources(root, kind, paths)
                payload = {"ok": True, "requires_confirmation": folders_with_files > 0,
                           "folders_with_files": folders_with_files, "items": len(sources)}
            elif action == "delete":
                sources, folders_with_files = deletion_sources(root, kind, request.get("paths", []))
                if folders_with_files and request.get("confirm_recursive") is not True:
                    raise ValueError("A selected folder contains files; confirmation is required")
                for source in sources:
                    if source.is_dir():
                        shutil.rmtree(source)
                    else:
                        source.unlink()
                payload = {"ok": True}
            elif action == "move":
                paths = request.get("paths", [])
                if not isinstance(paths, list) or not paths:
                    raise ValueError("No files or folders selected")
                destination = safe_recording_path(root, request.get("destination", ""))
                if not destination.is_dir() or destination.is_symlink():
                    raise ValueError("Destination folder not found")
                candidates = []
                for relative in dict.fromkeys(str(value) for value in paths):
                    source = safe_recording_path(root, relative)
                    if source == root or source.is_symlink() or not (source.is_dir() or is_recording_file(kind, source)):
                        raise ValueError(f"Can not move {source.name}")
                    candidates.append(source)
                candidates.sort(key=lambda item: len(item.parts))
                selected_roots = []
                for source in candidates:
                    if not any(parent in selected_roots for parent in source.parents):
                        selected_roots.append(source)
                sources, targets = [], set()
                for source in selected_roots:
                    if destination == source or source in destination.parents:
                        raise ValueError(f"Can not move {source.name} into itself")
                    target = destination / source.name
                    if target.exists() or target in targets:
                        raise ValueError(f"Can not move {source.name}")
                    targets.add(target)
                    sources.append((source, target))
                for source, target in sources:
                    shutil.move(str(source), str(target))
                payload = {"ok": True}
            elif action == "create_zip":
                token, name = create_recording_zip(kind, request.get("paths", []), str(request.get("folder", "")), target_id)
                payload = {"ok": True, "url": f"/recording-zip?token={token}&name={quote(name)}"}
            else:
                raise ValueError("Action not allowed")
            self.send_json(payload)
        except Exception as error:
            self.send_json({"ok": False, "error": str(error)}, 400)

    def log_message(self, fmt, *args):
        print("wittypi5-webserver:", fmt % args, flush=True)


def automation_config_command(arguments):
    """Reuse the website's validated configuration archive implementation."""
    if len(arguments) != 3 or arguments[0] not in {
            "--automation-config-backup", "--automation-config-restore"}:
        raise ValueError("Invalid automation configuration command")
    action, component, supplied_path = arguments
    if component not in {"wurb", "wirc", "allsky"}:
        raise ValueError("Invalid software component")
    if action == "--automation-config-backup":
        output_directory = pathlib.Path(supplied_path)
        if (not output_directory.is_absolute() or output_directory.is_symlink()
                or not output_directory.is_dir()):
            raise ValueError("Invalid automation backup directory")
        output_directory = output_directory.resolve(strict=True)
        generated, filename = create_component_backup(component, True)
        destination = output_directory / filename
        if destination.exists() or destination.is_symlink():
            raise FileExistsError("The destination backup already exists")
        os.replace(generated, destination)
        destination.chmod(0o640)
        print(destination)
        return
    archive_path = pathlib.Path(supplied_path)
    if (not archive_path.is_absolute() or archive_path.is_symlink()
            or not archive_path.is_file()):
        raise ValueError("Invalid automation restore file")
    restore_component_backup(component, archive_path.resolve(strict=True))
    print(archive_path.resolve(strict=True))


if __name__ == "__main__":
    if len(sys.argv) > 1:
        try:
            automation_config_command(sys.argv[1:])
        except Exception as error:
            print(str(error), file=sys.stderr)
            raise SystemExit(1)
    else:
        ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
