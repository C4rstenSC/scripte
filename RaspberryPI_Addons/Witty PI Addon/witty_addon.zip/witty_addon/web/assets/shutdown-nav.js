(() => {
    "use strict";
    const source = document.currentScript && document.currentScript.src ? document.currentScript.src : `${location.protocol}//${location.hostname}:8081/assets/shutdown-nav.js`;
    const apiBase = new URL(source, location.href).origin;
    let statusDot = null, widget = null, labelNode = null, minutesNode = null, dateNode = null, disableButton = null, snapshot = null, refreshBusy = false, navigationState = {};

    const style = document.createElement("style");
    style.textContent = ".witty-nav-status-dot,.witty-home-status-dot{display:inline-block;width:.72rem;height:.72rem;flex:none;align-self:center;border-radius:50%;margin:0 .15rem;background:#d64545;box-shadow:0 0 .3rem rgba(214,69,69,.8)}.witty-nav-status-dot.is-connected,.witty-home-status-dot.is-connected{background:#35c46a;box-shadow:0 0 .35rem rgba(53,196,106,.85)}.witty-shutdown-widget{display:inline-flex;align-items:center;flex-wrap:wrap;gap:.42rem;margin-left:1cm;color:#ff4f5e!important;font-weight:800;font-variant-numeric:tabular-nums}.witty-shutdown-widget.is-deactivated{color:#35c46a!important}.witty-shutdown-widget button{background:#f1f1f1!important;border:1px solid #ff4f5e!important;border-radius:4px;color:#b00020!important;font-weight:800;padding:.38rem .58rem;cursor:pointer}.witty-shutdown-widget button:disabled{opacity:.5;cursor:wait}";
    document.head.appendChild(style);

    function wallClockValue(value) {
        const match = String(value || "").match(/(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})/);
        return match ? Date.UTC(+match[1], +match[2] - 1, +match[3], +match[4], +match[5], +match[6]) : null;
    }
    function mount() {
        const witty = document.querySelector(".witty-model-link,.nav-witty,.witty-home");
        if (!witty || witty.id === "wittyNavModel") return false;
        if (!statusDot) { statusDot = document.createElement("span"); statusDot.className = "witty-nav-status-dot"; statusDot.setAttribute("aria-hidden", "true"); }
        if (!widget) {
            widget = document.createElement("span"); widget.className = "witty-shutdown-widget";
            labelNode = document.createElement("span"); labelNode.textContent = "Next Shutdown: deactivated";
            minutesNode = document.createElement("span"); minutesNode.textContent = "-- min";
            const spacer = document.createElement("span"); spacer.textContent = "\u00a0\u00a0\u00a0\u00a0";
            dateNode = document.createElement("span"); dateNode.textContent = "--.--.----";
            disableButton = document.createElement("button"); disableButton.type = "button";
            disableButton.textContent = "Deactivate auto switch off"; disableButton.disabled = true;
            disableButton.addEventListener("click", disableSchedule);
            widget.append(labelNode, minutesNode, spacer, dateNode, disableButton);
        }
        if (statusDot.previousElementSibling !== witty) witty.insertAdjacentElement("afterend", statusDot);
        if (widget.previousElementSibling !== statusDot) statusDot.insertAdjacentElement("afterend", widget);
        document.querySelectorAll("a").forEach(link => {
            const text = String(link.textContent || "").trim().toLowerCase();
            let service = text.includes("wurb-2026") ? "wurb"
                : text.includes("wirc-2026") ? "wirc"
                : text === "allsky" ? "allsky"
                : text.includes("recordings") || text.includes("allsky - setup") ? "witty" : "";
            if (!service || link.classList.contains("witty-model-link")) return;
            let dot = link.nextElementSibling;
            if (!dot || !dot.classList.contains("witty-home-status-dot")) {
                dot = document.createElement("span"); dot.className = "witty-home-status-dot"; dot.setAttribute("aria-hidden", "true");
                link.insertAdjacentElement("afterend", dot);
            }
            dot.classList.toggle("is-connected", navigationState[service] === true);
        });
        updateCountdown(); return true;
    }
    function updateCountdown() {
        if (!widget) return;
        if (!snapshot) { labelNode.textContent="Next Shutdown: deactivated"; widget.classList.add("is-deactivated"); minutesNode.hidden=true; dateNode.hidden=true; disableButton.disabled = true; return; }
        labelNode.textContent="Next Shutdown:"; widget.classList.remove("is-deactivated"); minutesNode.hidden=false; dateNode.hidden=false;
        const remaining = snapshot.shutdownMs - (snapshot.wittyMs + (Date.now() - snapshot.received));
        minutesNode.textContent = `${Math.max(0, Math.ceil(remaining / 60000))} min`;
        dateNode.textContent = snapshot.date; disableButton.disabled = refreshBusy || remaining <= 0;
    }
    async function refresh(force = false) {
        if (refreshBusy) return; refreshBusy = true; updateCountdown();
        try {
            const response = await fetch(`${apiBase}/api/shutdown-status${force ? "?fresh=1" : ""}`, { cache:"no-store" });
            const data = await response.json(); if (!response.ok || !data.ok) throw new Error(data.error || response.statusText);
            statusDot && statusDot.classList.add("is-connected");
            navigationState = data.navigation && typeof data.navigation === "object" ? data.navigation : {};
            const wittyMs = wallClockValue(data.witty_time), shutdownMs = wallClockValue(data.next_shutdown);
            const dateMatch = String(data.next_shutdown || "").match(/(\d{4})-(\d{2})-(\d{2})/);
            snapshot = wittyMs !== null && shutdownMs !== null && dateMatch ? { wittyMs, shutdownMs, received:Date.now(), date:`${dateMatch[3]}.${dateMatch[2]}.${dateMatch[1]}` } : null;
        } catch (error) { snapshot = null; navigationState = {}; statusDot && statusDot.classList.remove("is-connected"); }
        finally { refreshBusy = false; mount(); updateCountdown(); }
    }
    async function disableSchedule() {
        if (refreshBusy || !snapshot) return; refreshBusy = true; updateCountdown();
        try {
            const response = await fetch(`${apiBase}/api`, { method:"POST", headers:{"Content-Type":"application/json"}, cache:"no-store", body:JSON.stringify({action:"clear_schedule"}) });
            const result = await response.json(); if (!response.ok || !result.ok) throw new Error(result.error || response.statusText);
            snapshot = null;
        } finally { refreshBusy = false; updateCountdown(); window.setTimeout(() => refresh(true), 750); }
    }
    new MutationObserver(mount).observe(document.documentElement, {childList:true,subtree:true});
    mount(); refresh(); window.setInterval(updateCountdown,1000); window.setInterval(refresh,60000);
})();
