#!/usr/bin/env bash

# ==============================================================================
# COMPLETE INTERACTIVE SET-UP FOR RASPBERRY PI 4/5
# OS: Debian Trixie (64-Bit Lite)
# Automatic installation: Wi-Fi hotspot and the selected detector software
# Interactive selection: country, GPS type, Witty Pi model, WURB, WIRC and Allsky
# ==============================================================================

# --- REPOSITORIES AND DOWNLOAD URLS ---

GIT_HUB="https://github.com"
WURB_PART="/cloudedbats/wurb_2026.git"
WURB_GIT_URL="${GIT_HUB}${WURB_PART}"


WIRC_PART="/cloudedbats/wirc_2026.git"
WIRC_GIT_URL="${GIT_HUB}${WIRC_PART}"

ALLSKY_HOME="/home/wurb/allsky"
ALLSKY_PART="/AllskyTeam/allsky.git"
ALLSKY_GIT_URL="${GIT_HUB}${ALLSKY_PART}"

WITTY_PART1="https://uugear.com"
WITTY_PART2="/repo/WittyPi5/wp5_latest.deb"
WITTYPI_DEB_URL="${WITTY_PART1}${WITTY_PART2}"

WITTY_ADDON_URL="https://raw.githubusercontent.com/C4rstenSC/scripte/main/RaspberryPI_Addons/Witty%20PI%20Addon/witty_addon.zip"

# The launcher and a future Windows controller can provide a plain KEY=VALUE
# file. Only explicitly supported keys are parsed; the file is never sourced
# as shell code while this installer is running as root.
SETUP_CONFIG_FILE=""
SETUP_NON_INTERACTIVE=false
while [ "$#" -gt 0 ]; do
    case "$1" in
        --config)
            [ "$#" -ge 2 ] || { echo "FEHLER: Hinter --config fehlt der Dateiname." >&2; exit 2; }
            SETUP_CONFIG_FILE="$2"
            shift 2
            ;;
        --non-interactive)
            SETUP_NON_INTERACTIVE=true
            shift
            ;;
        --help)
            echo "Verwendung: sudo ./installer_addon.sh [--config DATEI] [--non-interactive]"
            echo "Ohne Optionen bleibt die bisherige interaktive SSH-Installation erhalten."
            exit 0
            ;;
        *)
            echo "FEHLER: Unbekannte Option: $1" >&2
            exit 2
            ;;
    esac
done

declare -A SETUP_CONFIG=()
if [ -n "$SETUP_CONFIG_FILE" ]; then
    [ -r "$SETUP_CONFIG_FILE" ] || { echo "FEHLER: Konfigurationsdatei nicht lesbar: $SETUP_CONFIG_FILE" >&2; exit 2; }
    while IFS='=' read -r setup_key setup_value || [ -n "${setup_key:-}" ]; do
        setup_key="${setup_key//$'\r'/}"
        setup_value="${setup_value//$'\r'/}"
        [[ "$setup_key" =~ ^[[:space:]]*(#|$) ]] && continue
        setup_key="${setup_key//[[:space:]]/}"
        case "$setup_key" in
            RPI_MODEL|COUNTRY|TIMEZONE|KEYBOARD|GPS_MODE|INSTALL_WITTY|WITTY_MODEL|INSTALL_WURB|INSTALL_WIRC|INSTALL_ALLSKY|CONFIRM)
                SETUP_CONFIG["$setup_key"]="$setup_value"
                ;;
            *)
                echo "FEHLER: Nicht unterstützter Konfigurationsschlüssel: $setup_key" >&2
                exit 2
                ;;
        esac
    done < "$SETUP_CONFIG_FILE"
fi

setup_value() {
    local key="$1" environment_key="WITTY_SETUP_$1"
    if [ -n "${!environment_key:-}" ]; then
        printf '%s' "${!environment_key}"
    else
        printf '%s' "${SETUP_CONFIG[$key]:-}"
    fi
}

interactive_answer() {
    local target="$1" prompt="$2"
    if [ "$SETUP_NON_INTERACTIVE" = true ]; then
        echo "FEHLER: Für die nichtinteraktive Installation fehlt eine erforderliche Antwort: $target" >&2
        exit 2
    fi
    read -r -p "$prompt" "$target"
}

yes_no_answer() {
    case "${1,,}" in
        1|true|yes|y|ja|j) printf j ;;
        0|false|no|n|nein) printf n ;;
        '') return 1 ;;
        *) echo "FEHLER: Ungültiger Ja/Nein-Wert: $1" >&2; exit 2 ;;
    esac
}


# Check whether the script is running as root
if [ "$EUID" -ne 0 ]; then
  echo "FEHLER: Bitte starte das Skript zwingend als Root (sudo ./setup.sh)!"
  exit 1
fi

CURRENT_HOSTNAME="$(hostname -s)"
INSTALLER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CON_NAME="allsky-hotspot"
HOTSPOT_NAME="allskywifi-${CURRENT_HOSTNAME}"

update_hotspot_names() {
    if [ "${INSTALL_WURB:-false}" = true ]; then
        CON_NAME="wurb-hotspot"
        HOTSPOT_NAME="wifi4bats-${CURRENT_HOSTNAME}"
    elif [ "${INSTALL_ALLSKY:-false}" = true ]; then
        CON_NAME="allsky-hotspot"
        HOTSPOT_NAME="allskywifi-${CURRENT_HOSTNAME}"
    else
        CON_NAME="device-hotspot"
        HOTSPOT_NAME="wifi-${CURRENT_HOSTNAME}"
    fi
}



# ==============================================================================
# INTERACTIVE QUESTIONS (portable sh/bash syntax)
# ==============================================================================
[[ -t 1 ]] && clear || true
echo "===================================================================="
echo "     WURB-2026 / WIRC-2026 / ALLSKY SYSTEM-SET-UP (Pi 4B/5)"
echo "===================================================================="
echo "Aktueller Pi-Hostname erkannt: $CURRENT_HOSTNAME"
echo "Geplanter Hotspot-Name (SSID): $HOTSPOT_NAME"
echo "--------------------------------------------------------------------"

echo "Welches Raspberry-Pi-Modell wird verwendet?"
echo " 1) Raspberry Pi 5"
echo " 2) Raspberry Pi 4 / 4B"
case "$(setup_value RPI_MODEL)" in
    5) RPI_CHOICE=1 ;;
    4|4B|4b) RPI_CHOICE=2 ;;
    '') interactive_answer RPI_CHOICE "Bitte wähle eine Option [1 oder 2]: " ;;
    *) echo "FEHLER: RPI_MODEL muss 4, 4B oder 5 sein."; exit 2 ;;
esac
case "$RPI_CHOICE" in
    1) RPI_MODEL=5; RPI_VARIANT="5" ;;
    2) RPI_MODEL=4; RPI_VARIANT="4B" ;;
    *) echo "Ungültige Auswahl. Abbruch."; exit 1 ;;
esac
# Raspberry Pi 4B reports itself as "Raspberry Pi 4 Model B Rev ...". Match the
# complete model family explicitly so the "Model B" wording never causes a
# false mismatch. The shorter prefix is retained for compatible Pi 4 revisions.
DETECTED_PI_MODEL="$(tr -d '\0' </proc/device-tree/model 2>/dev/null || true)"
RPI_MODEL_MATCH=false
if [ "$RPI_MODEL" = 4 ] && [[ "$DETECTED_PI_MODEL" == "Raspberry Pi 4 Model B"* || "$DETECTED_PI_MODEL" == "Raspberry Pi 4"* ]]; then
    RPI_MODEL_MATCH=true
elif [ "$RPI_MODEL" = 5 ] && [[ "$DETECTED_PI_MODEL" == "Raspberry Pi 5 Model B"* || "$DETECTED_PI_MODEL" == "Raspberry Pi 5"* ]]; then
    RPI_MODEL_MATCH=true
elif [ -z "$DETECTED_PI_MODEL" ]; then
    echo "WARNUNG: Das Raspberry-Modell konnte nicht automatisch gelesen werden."
    RPI_MODEL_MATCH=true
fi
if [ "$RPI_MODEL_MATCH" != true ]; then
    echo "FEHLER: Ausgewählt wurde Raspberry Pi $RPI_MODEL, erkannt wurde: $DETECTED_PI_MODEL"
    echo "Die Installation wird beendet, damit keine falschen Hardware-Einstellungen gesetzt werden."
    exit 1
fi

# Question 1: deployment country
echo "In welchem Land wird der Detektor eingesetzt?"
echo " 1) Australien (AU)"
echo " 2) Deutschland (DE)"
echo " 3) Schweden (SE)"
echo " 4) Anderes Land"
case "${SETUP_COUNTRY_VALUE:-$(setup_value COUNTRY)}" in
    AU|au) COUNTRY_CHOICE=1 ;;
    DE|de) COUNTRY_CHOICE=2 ;;
    SE|se) COUNTRY_CHOICE=3 ;;
    '' ) interactive_answer COUNTRY_CHOICE "Bitte wähle eine Option [1-4]: " ;;
    *) COUNTRY_CHOICE=4 ;;
esac

# Default values
TARGET_KEYBOARD="de"

if [ "$COUNTRY_CHOICE" = "1" ]; then
    # Australia
    TARGET_COUNTRY="AU"
    TARGET_TIMEZONE="Australia/Sydney"

    echo ""
    echo "   Tastaturlayout auswählen:"
    echo "   1) Deutsch"
    echo "   2) Englisch (Australien)"
    case "$(setup_value KEYBOARD)" in
        de) KEYBOARD_CHOICE=1 ;;
        au|us|en) KEYBOARD_CHOICE=2 ;;
        '')
            if [ "$SETUP_NON_INTERACTIVE" = true ]; then KEYBOARD_CHOICE=2; else interactive_answer KEYBOARD_CHOICE "   -> Auswahl [1/2, Standard: 2]: "; fi
            ;;
        *) echo "FEHLER: Für Australien wird KEYBOARD=de oder au erwartet."; exit 2 ;;
    esac

    case "$KEYBOARD_CHOICE" in
        1)
            TARGET_KEYBOARD="de"
            ;;
        2|"")
            TARGET_KEYBOARD="au"
            ;;
        *)
            echo "   Ungültige Auswahl – verwende Englisch (Australien)."
            TARGET_KEYBOARD="au"
            ;;
    esac

elif [ "$COUNTRY_CHOICE" = "2" ]; then
    # Germany
    TARGET_COUNTRY="DE"
    TARGET_TIMEZONE="Europe/Berlin"

    echo ""
    echo "   Tastaturlayout auswählen:"
    echo "   1) Deutsch"
    echo "   2) Englisch (Australien)"
    case "$(setup_value KEYBOARD)" in
        de|'')
            if [ -z "$(setup_value KEYBOARD)" ] && [ "$SETUP_NON_INTERACTIVE" != true ]; then interactive_answer KEYBOARD_CHOICE "   -> Auswahl [1/2, Standard: 1]: "; else KEYBOARD_CHOICE=1; fi
            ;;
        au|us|en) KEYBOARD_CHOICE=2 ;;
        *) echo "FEHLER: Für Deutschland wird KEYBOARD=de oder au erwartet."; exit 2 ;;
    esac

    case "$KEYBOARD_CHOICE" in
        1|"")
            TARGET_KEYBOARD="de"
            ;;
        2)
            TARGET_KEYBOARD="au"
            ;;
        *)
            echo "   Ungültige Auswahl – verwende Deutsch."
            TARGET_KEYBOARD="de"
            ;;
    esac

elif [ "$COUNTRY_CHOICE" = "3" ]; then
    # Sweden
    TARGET_COUNTRY="SE"
    TARGET_TIMEZONE="Europe/Stockholm"

    echo ""
    TARGET_KEYBOARD="$(setup_value KEYBOARD)"
    [ -n "$TARGET_KEYBOARD" ] || interactive_answer TARGET_KEYBOARD "   -> Bitte gib das gewünschte Tastaturlayout für Schweden ein (z.B. se, de, us): "

elif [ "$COUNTRY_CHOICE" = "4" ]; then
    # Custom location
    echo ""
    CUSTOM_COUNTRY="$(setup_value COUNTRY)"
    [ -n "$CUSTOM_COUNTRY" ] || interactive_answer CUSTOM_COUNTRY "   -> Bitte gib den zweistelligen Ländercode ein (z.B. US, FR, CH): "
    TARGET_COUNTRY=$(echo "$CUSTOM_COUNTRY" | tr '[:lower:]' '[:upper:]')

    TARGET_TIMEZONE="$(setup_value TIMEZONE)"
    [ -n "$TARGET_TIMEZONE" ] || interactive_answer TARGET_TIMEZONE "   -> Bitte gib die exakte Linux-Zeitzone ein (z.B. Europe/Zurich, America/New_York): "
    TARGET_KEYBOARD="$(setup_value KEYBOARD)"
    [ -n "$TARGET_KEYBOARD" ] || interactive_answer TARGET_KEYBOARD "   -> Bitte gib das gewünschte Tastaturlayout ein (z.B. us, de, fr): "

else
    # Fall back after invalid input
    TARGET_COUNTRY="DE"
    TARGET_TIMEZONE="Europe/Berlin"
    TARGET_KEYBOARD="de"
fi


# Question 2: GPS set-up
echo "--------------------------------------------------------------------"
echo "Wie soll das GPS für WURB eingerichtet werden?"
echo " 1) Gar kein GPS-Empfang"
echo " 2) GPS über USB-Maus"
echo " 3) GPS über Waveshare L76X Platine"
case "${SETUP_GPS_VALUE:-$(setup_value GPS_MODE)}" in
    none|kein|off) GPS_CHOICE=1 ;;
    usb|usb_mouse) GPS_CHOICE=2 ;;
    waveshare|waveshare_l76x|l76x) GPS_CHOICE=3 ;;
    '') interactive_answer GPS_CHOICE "Bitte wähle eine Option [1, 2 oder 3]: " ;;
    *) echo "FEHLER: GPS_MODE muss none, usb oder waveshare_l76x sein."; exit 2 ;;
esac

# Default values
GPS_NONE=false
GPS_USB=false
GPS_WAVESHARE=false

case "$GPS_CHOICE" in
    1)
        GPS_NONE=true
        ;;
    2)
        GPS_USB=true
        ;;
    3)
        GPS_WAVESHARE=true
        ;;
    *)
        echo "Ungültige Auswahl. Es wird 'Gar kein GPS-Empfang' verwendet."
        GPS_CHOICE="1"
        GPS_NONE=true
        ;;
esac
case "$GPS_CHOICE" in
    1) GPS_MODE="none" ;;
    2) GPS_MODE="usb" ;;
    3) GPS_MODE="waveshare_l76x" ;;
esac

# Question 3: Witty Pi
echo "--------------------------------------------------------------------"
if configured_value="$(setup_value INSTALL_WITTY)" && [ -n "$configured_value" ]; then
    ANS_WITTY="$(yes_no_answer "$configured_value")"
else
    interactive_answer ANS_WITTY "3) Möchtest du Witty-Pi-Software installieren? (j/n): "
fi

if [ "$ANS_WITTY" = "j" ] || [ "$ANS_WITTY" = "J" ]; then
    INSTALL_WITTY=true
    echo "   1) Witty Pi 5"
    echo "   2) Witty Pi 4"
    case "$(setup_value WITTY_MODEL)" in
        5) WITTY_CHOICE=1 ;;
        4) WITTY_CHOICE=2 ;;
        '') interactive_answer WITTY_CHOICE "   -> Verbaute Witty-Pi-Version [1 oder 2]: " ;;
        *) echo "FEHLER: WITTY_MODEL muss 4 oder 5 sein."; exit 2 ;;
    esac
    case "$WITTY_CHOICE" in
        1) WITTY_MODEL=5 ;;
        2) WITTY_MODEL=4 ;;
        *) echo "Ungültige Witty-Auswahl. Abbruch."; exit 1 ;;
    esac
else
    INSTALL_WITTY=false
    WITTY_MODEL=0
fi


# Questions 4-6: software packages can be selected independently. Allsky is
# always installed last because its official installer may restart the Pi.
echo "--------------------------------------------------------------------"
if configured_value="$(setup_value INSTALL_WURB)" && [ -n "$configured_value" ]; then ANS_WURB="$(yes_no_answer "$configured_value")"; else interactive_answer ANS_WURB "4) Soll die WURB 2026 Software installiert werden? (j/n): "; fi
[[ "$ANS_WURB" =~ ^[jJ]$ ]] && INSTALL_WURB=true || INSTALL_WURB=false

echo "--------------------------------------------------------------------"
if configured_value="$(setup_value INSTALL_WIRC)" && [ -n "$configured_value" ]; then ANS_WIRC="$(yes_no_answer "$configured_value")"; else interactive_answer ANS_WIRC "5) Soll das WIRC-2026 Kamera-System installiert werden? (j/n): "; fi
[[ "$ANS_WIRC" =~ ^[jJ]$ ]] && INSTALL_WIRC=true || INSTALL_WIRC=false

echo "--------------------------------------------------------------------"
if configured_value="$(setup_value INSTALL_ALLSKY)" && [ -n "$configured_value" ]; then ANS_ALLSKY="$(yes_no_answer "$configured_value")"; else interactive_answer ANS_ALLSKY "6) Soll zusätzlich die Allsky Software installiert werden? (j/n): "; fi
[[ "$ANS_ALLSKY" =~ ^[jJ]$ ]] && INSTALL_ALLSKY=true || INSTALL_ALLSKY=false


# The hotspot is always installed
INSTALL_HOTSPOT=true
update_hotspot_names


echo "--------------------------------------------------------------------"
echo "Zusammenfassung der Konfiguration:"
echo " - Einsatzland:                 $TARGET_COUNTRY (Zeitzone: $TARGET_TIMEZONE)"
echo " - Tastaturlayout:              $TARGET_KEYBOARD"
echo " - Raspberry Pi:                $RPI_VARIANT (erkannt: ${DETECTED_PI_MODEL:-nicht auslesbar})"

if [ "$INSTALL_WURB" = true ]; then
    echo " - WURB 2026 installieren:      JA"
else
    echo " - WURB 2026 installieren:      NEIN"
fi

if [ "$INSTALL_ALLSKY" = true ]; then
    echo " - Allsky installieren:         JA"
else
    echo " - Allsky installieren:         NEIN"
fi

if [ "$GPS_WAVESHARE" = true ]; then
    echo " - GPS-Schnittstelle:           JA (Waveshare GPIO -> Auto-Config /dev/ttyUSB9)"
else
    echo " - GPS-Schnittstelle:           NEIN (Vorbereitet für USB-GPS-Dongles)"
fi

if [ "$INSTALL_WITTY" = true ]; then
    echo " - Witty Pi $WITTY_MODEL vorbereiten:      JA"
else
    echo " - Witty Pi 5 vorbereiten:      NEIN"
fi

if [ "$INSTALL_WIRC" = true ]; then
    echo " - WIRC Kamera installieren:    JA"
else
    echo " - WIRC Kamera installieren:    NEIN"
fi

echo " - WLAN-Hotspot konfigurieren:  JA (Automatisch -> SSID: $HOTSPOT_NAME)"
echo "--------------------------------------------------------------------"

if [ "$INSTALL_ALLSKY" = true ]; then
    echo "ACHTUNG: Für die Allsky-Erstinstallation muss mindestens eine"
    echo "         unterstützte und erkannte Kamera angeschlossen sein."
    echo "         Allsky wird nach WURB, WIRC und allen Systemphasen zuletzt installiert."
    echo "--------------------------------------------------------------------"
fi

if configured_value="$(setup_value CONFIRM)" && [ -n "$configured_value" ]; then
    ANS_START="$(yes_no_answer "$configured_value")"
elif [ "$SETUP_NON_INTERACTIVE" = true ]; then
    echo "FEHLER: Für --non-interactive muss CONFIRM=yes gesetzt sein."
    exit 2
else
    interactive_answer ANS_START "Möchtest du das Setup mit diesen Einstellungen starten? (j/n): "
fi

if [ "$ANS_START" != "j" ] && [ "$ANS_START" != "J" ]; then
    echo "Abgebrochen."
    exit 0
fi

# Names were set from the final software selection by update_hotspot_names.

# ==============================================================================
# PHASE 1: SYSTEM OPTIMISATION AND REGIONAL SETTINGS
# ==============================================================================
echo ""
echo "=== [PHASE 1] Starte Pi $RPI_MODEL System- & Ländereinstellungen ==="

# Apply the interactively selected keyboard layout
echo "[1/6] Setze Tastaturlayout ($TARGET_KEYBOARD)..."
raspi-config nonint do_configure_keyboard "$TARGET_KEYBOARD"

# Apply the selected country and time zone
echo "[2/6] Konfiguriere Regionaleinstellungen ($TARGET_COUNTRY / $TARGET_TIMEZONE)..."
raspi-config nonint do_change_timezone "$TARGET_TIMEZONE"
raspi-config nonint do_wifi_country "$TARGET_COUNTRY"

# Continue with file-system expansion and the remaining base configuration.


echo "[3/6] Expandiere das Dateisystem..."
raspi-config nonint do_expand_rootfs

echo "[4/6] Aktiviere die I2C-Hardware-Schnittstelle..."
raspi-config nonint do_i2c 0

echo "[5/6] Richte System-User 'wurb' und passwortloses Sudo ein..."
if ! id "wurb" &>/dev/null; then
    useradd -m -s /bin/bash wurb
    usermod -aG dialout,sudo,audio,video wurb
fi
echo "wurb ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/010_wurb-nopasswd
chmod 0440 /etc/sudoers.d/010_wurb-nopasswd

echo "[6/6] Prüfe modellabhängige USB-Stromversorgung..."
if [ "$RPI_MODEL" = 5 ] && [ -f /boot/firmware/config.txt ]; then
    if ! grep -q "usb_max_current_enable=1" /boot/firmware/config.txt; then
        echo "usb_max_current_enable=1" >> /boot/firmware/config.txt
    fi
fi
if [ "$RPI_MODEL" = 4 ]; then
    echo "   -> usb_max_current_enable ist eine Pi-5-Option und wird auf Pi 4 nicht gesetzt."
fi


# ==============================================================================
# PHASE 2: HARDWARE AND GPS CONFIGURATION
# ==============================================================================
echo ""
echo "=== [PHASE 2] Installiere System-Abhängigkeiten ==="
# i2c-tools is included for Witty Pi hardware diagnostics
apt update && apt install -y python3-venv python3-pip python3-dev git alsa-utils ffmpeg libasound2-dev gpsd gpsd-clients socat network-manager libopenblas-dev pmount python3-pyaudio portaudio19-dev i2c-tools

# The current upstream WURB guide explicitly targets Raspberry Pi OS Lite
# (64-bit) based on Debian Trixie. WIRC adds system picamera2, OpenCV and
# ffmpeg. Re-check those capabilities on every installation so later Trixie
# package changes fail here with a useful message rather than as a dead service.
if grep -Eq '^VERSION_CODENAME=trixie$' /etc/os-release 2>/dev/null; then
    CLOUDEDBATS_COMPAT="$INSTALLER_DIR/installer/cloudedbats_trixie_compat.sh"
    [ -f "$CLOUDEDBATS_COMPAT" ] || { echo "FEHLER: CloudedBats-Trixie-Prüfung fehlt."; exit 1; }
    if [ "$INSTALL_WURB" = true ] && [ "$INSTALL_WIRC" = true ]; then
        bash "$CLOUDEDBATS_COMPAT" prepare-both || exit 1
    elif [ "$INSTALL_WURB" = true ]; then
        bash "$CLOUDEDBATS_COMPAT" prepare-wurb || exit 1
    elif [ "$INSTALL_WIRC" = true ]; then
        bash "$CLOUDEDBATS_COMPAT" prepare-wirc || exit 1
    fi
fi

if [ "$GPS_WAVESHARE" = true ]; then
    echo "-> Konfiguriere GPS-Daemon & Virtuelle ttyUSB9-Bridge für Waveshare..."
    
    if [ -f /boot/firmware/cmdline.txt ]; then
        sed -i 's/console=ttyAMA0,[0-9]* //g' /boot/firmware/cmdline.txt
        sed -i 's/console=serial0,[0-9]* //g' /boot/firmware/cmdline.txt
    fi

    if [ -f /boot/firmware/config.txt ]; then
        UART_OVERLAY="uart0"
        [ "$RPI_MODEL" = 5 ] && UART_OVERLAY="uart0-pi5"
        if ! grep -q "dtoverlay=$UART_OVERLAY" /boot/firmware/config.txt; then
            echo "dtoverlay=$UART_OVERLAY" >> /boot/firmware/config.txt
        fi
    fi

    cat << 'EOF' > /etc/default/gpsd
START_DAEMON="true"
USBAUTO="false"
DEVICES="/dev/ttyAMA0"
GPSD_OPTIONS="-b -n -G -F /var/run/gpsd.sock"
EOF

    cat << 'EOF' > /etc/systemd/system/wurb-gps-bridge.service
[Unit]
Description=WURB GPS Virtual Serial Port Bridge
After=gpsd.service
Requires=gpsd.service

[Service]
Type=simple
ExecStart=/usr/bin/socat PTY,link=/dev/ttyWURB,raw,echo=0,group=dialout,mode=660 EXEC:"/usr/bin/gpspipe -r"
ExecStartPost=/usr/bin/ln -sf /dev/ttyWURB /dev/ttyUSB9
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

    echo "-> Lade systemd-Konfiguration neu (maximal 20 Sekunden)..."
    if ! timeout 20s systemctl daemon-reload; then
        echo "FEHLER: systemctl daemon-reload reagiert nicht."
        echo "Bitte Raspberry Pi neu starten und das Setup erneut ausführen."
        exit 1
    fi
    echo "-> Aktiviere native GPSD-Socket-Einheit für den nächsten Boot..."
    timeout 15s systemctl enable gpsd.socket 2>/dev/null || \
        echo "WARNUNG: gpsd.socket konnte momentan nicht aktiviert werden."
    timeout 15s systemctl enable wurb-gps-bridge.service 2>/dev/null || \
        echo "WARNUNG: GPS-Bridge konnte momentan nicht aktiviert werden."
    echo "-> GPSD und GPS-Bridge werden während der Installation nicht neu gestartet."
elif [ "$GPS_USB" = true ]; then
    echo "-> Konfiguriere GPSD für eine USB-GPS-Maus."
    USB_GPS_DEVICE=""
    for GPS_CANDIDATE in /dev/serial/by-id/* /dev/ttyACM* /dev/ttyUSB*; do
        [ -e "$GPS_CANDIDATE" ] || continue
        GPS_RESOLVED="$(readlink -f "$GPS_CANDIDATE" 2>/dev/null || true)"
        case "$GPS_RESOLVED" in /dev/ttyACM*|/dev/ttyUSB*) USB_GPS_DEVICE="$GPS_CANDIDATE"; break ;; esac
    done
    cat << EOF > /etc/default/gpsd
START_DAEMON="true"
USBAUTO="true"
DEVICES="$USB_GPS_DEVICE"
GPSD_OPTIONS="-n -G -F /var/run/gpsd.sock"
EOF
    cat << 'EOF' > /etc/systemd/system/wurb-gps-bridge.service
[Unit]
Description=WURB GPS Virtual Serial Port Bridge
After=gpsd.service
Requires=gpsd.service

[Service]
Type=simple
ExecStart=/usr/bin/socat PTY,link=/dev/ttyWURB,raw,echo=0,group=dialout,mode=660 EXEC:"/usr/bin/gpspipe -r"
ExecStartPost=/usr/bin/ln -sf /dev/ttyWURB /dev/ttyUSB9
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
    # Debian also provides a SysV compatibility path for gpsd.service, which can
    # block during 'systemctl enable gpsd'. Enable the native socket only; the
    # service starts automatically when required.
    if ! timeout 15s systemctl enable gpsd.socket 2>/dev/null; then
        echo "WARNUNG: gpsd.socket konnte momentan nicht aktiviert werden."
        echo "Die GPS-Einrichtung wird beim nächsten Skriptlauf erneut geprüft."
    fi
    timeout 15s systemctl enable wurb-gps-bridge.service 2>/dev/null || \
        echo "WARNUNG: GPS-Bridge konnte momentan nicht aktiviert werden."
    echo "-> GPSD-Socket und gemeinsame WURB-Bridge für den nächsten Boot vorbereitet."
else
    echo "-> Kein GPS ausgewählt: GPSD wird nicht aktiviert."
    timeout 10s systemctl disable --now gpsd.socket 2>/dev/null || true
    timeout 10s systemctl stop gpsd.service 2>/dev/null || true
fi

# ==============================================================================
# PHASE 3A: WURB SOFTWARE INSTALLATION & PETTERSSON M500 CONFIGURATION
# ==============================================================================

if [ "$INSTALL_WURB" = true ]; then

    echo ""
    echo "=== [PHASE 3] Installiere WURB-2026 Software (Venv im User 'wurb') ==="

    WURB_HOME="/home/wurb"

    # Never replace native Python packages while WURB is using them.
    timeout 15s systemctl stop wurb_2026.service 2>/dev/null || true
    timeout 5s systemctl reset-failed wurb_2026.service 2>/dev/null || true

    # Only phase 0 may remove old data. Without that choice, the existing
    # repository is updated and reused for reinstallation.
    if [ -d "$WURB_HOME/wurb_2026" ]; then
        echo "Aktualisiere vorhandenes WURB-2026-Repository..."
        sudo -u wurb git -C "$WURB_HOME/wurb_2026" pull --ff-only || \
            echo "WARNUNG: WURB-Repository konnte nicht automatisch aktualisiert werden."
    else
        echo "Klone WURB-2026 von der definierten URL..."
        if ! sudo -u wurb git clone "$WURB_GIT_URL" "$WURB_HOME/wurb_2026"; then
            echo "FEHLER: WURB-2026 konnte nicht geladen werden."
            exit 1
        fi
    fi

    # WURB normally accepts only configured serial paths or known USB IDs. Keep
    # the upstream source untouched and add the installer-owned virtual port to
    # WURB's persistent local configuration instead.
    if [ "$GPS_WAVESHARE" = true ] || [ "$GPS_USB" = true ]; then
        WURB_LOCAL_CONFIG="$WURB_HOME/wurb_settings/wurb_config.yaml"
        WURB_DEFAULT_CONFIG="$WURB_HOME/wurb_2026/wurb_config_default.yaml"
        if [ ! -f "$WURB_DEFAULT_CONFIG" ]; then
            echo "FEHLER: WURB-Standardkonfiguration wurde nicht gefunden: $WURB_DEFAULT_CONFIG"
            exit 1
        fi
        install -d -o wurb -g wurb -m 0755 "$WURB_HOME/wurb_settings"
        if [ ! -f "$WURB_LOCAL_CONFIG" ]; then
            install -o wurb -g wurb -m 0644 "$WURB_DEFAULT_CONFIG" "$WURB_LOCAL_CONFIG"
        fi
        python3 - "$WURB_LOCAL_CONFIG" << 'PY'
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
lines = path.read_text().splitlines()
result = []
inside = False
found = False
for line in lines:
    if line.strip() == "gps_device_whitelist:":
        result.extend((line, "    - /dev/ttyUSB9 # Installer-owned shared gpsd bridge."))
        inside = True
        found = True
        continue
    if inside and (not line.strip() or line.startswith("    - ") or line.startswith("    #")):
        continue
    inside = False
    result.append(line)
if not found:
    raise SystemExit("gps_device_whitelist was not found in the WURB configuration")
path.write_text("\n".join(result) + "\n")
PY
        chown wurb:wurb "$WURB_LOCAL_CONFIG"
        echo "   -> WURB erkennt die virtuelle Waveshare-Schnittstelle /dev/ttyUSB9."
    fi

    # User switch: an unquoted EOF expands WURB_GIT_URL before changing user.
    if ! sudo -u wurb -i << 'EOF'
set -e
cd /home/wurb

cd /home/wurb/wurb_2026
python3 -m venv venv
source venv/bin/activate
python -m pip install --upgrade pip

if [ -f 'requirements.txt' ]; then
    python -m pip install --no-cache-dir -r requirements.txt
fi

# Check native wheels before starting the service. A NumPy SIGBUS was the
# confirmed reason port 8080 previously failed to open.
if ! python -X faulthandler -c 'import numpy; import scipy; print("NumPy/SciPy OK")'; then
    echo "WARNUNG: NumPy/SciPy-Import fehlgeschlagen; installiere beide Pakete ohne Cache neu."
    python -m pip uninstall -y numpy scipy || true
    python -m pip install --no-cache-dir --force-reinstall numpy scipy
fi
python -X faulthandler -c 'import numpy; import scipy; print("NumPy/SciPy abschließend geprüft")'

deactivate
EOF
    then
        echo "FEHLER: WURB-Pythonumgebung oder NumPy/SciPy konnte nicht fehlerfrei eingerichtet werden."
        echo "WURB-Dienst wird nicht gestartet."
        exit 1
    fi
    if grep -Eq '^VERSION_CODENAME=trixie$' /etc/os-release 2>/dev/null; then
        bash "$INSTALLER_DIR/installer/cloudedbats_trixie_compat.sh" verify-wurb || exit 1
    fi

    # --- USB-Stick automatic mount ---
    echo "-> Konfiguriere USB-Stick automatischer MOUNT"

    cd /home/wurb/wurb_2026
    sudo cp raspberrypi_files/usb_pmount.rules /etc/udev/rules.d/
    sudo cp raspberrypi_files/usb_pmount_handler@.service /lib/systemd/system/
    sudo cp raspberrypi_files/usb_pmount_script /usr/local/bin/
    sudo chmod +x /usr/local/bin/usb_pmount_script
    echo "-> Lade USB-Regeln neu (maximal 10 Sekunden)..."
    if ! timeout 10s udevadm control --reload-rules; then
        echo "WARNUNG: udev-Regeln konnten momentan nicht neu geladen werden."
        echo "Sie werden spätestens beim nächsten Neustart eingelesen."
    fi
    # Do not run a global 'udevadm trigger': it can block on mounted USB devices
    # under Raspberry Pi OS. Rules apply on the next reconnect or reboot.


    # --- AUTOMATISCHE PETTERSSON M500 USB-KONFIGURATION ---
    echo "-> Konfiguriere USB-Berechtigungen für das Pettersson M500 Mikrofon..."

    M500_RULES="/home/wurb/wurb_2026/raspberrypi_files/pettersson_m500_batmic.rules"

    if [ -f "$M500_RULES" ]; then
        # Copy udev rules into the protected system directory
        cp "$M500_RULES" /etc/udev/rules.d/

        # Reload the rules with a timeout. A global udevadm trigger can block
        # indefinitely when combined with USB mount rules.
        if ! timeout 10s udevadm control --reload-rules; then
            echo "WARNUNG: Pettersson-Regel wird erst beim Neustart eingelesen."
        fi

        echo "   -> Pettersson-M500-Regel installiert. Mikrofon neu einstecken oder neu starten."
    else
        echo "HINWEIS: pettersson_m500_batmic.rules nicht im Repository gefunden!"
    fi


    # --- OFFIZIELLE CLOUDEDBATS-DATEIEN INSTALLIEREN ---
    WURB_SERVICE_SRC="/home/wurb/wurb_2026/raspberrypi_files/wurb_2026.service"
    WURB_ALIASES_SRC="/home/wurb/wurb_2026/raspberrypi_files/bash_aliases"

    if [ ! -f "$WURB_SERVICE_SRC" ] || [ ! -f "$WURB_ALIASES_SRC" ]; then
        echo "FEHLER: Offizielle WURB-Service- oder Alias-Datei fehlt im Repository."
        exit 1
    fi

    install -o root -g root -m 0644 "$WURB_SERVICE_SRC" \
        /etc/systemd/system/wurb_2026.service
    install -o wurb -g wurb -m 0755 "$WURB_ALIASES_SRC" \
        /home/wurb/.bash_aliases

    # gpsd owns the physical GPS port. WURB consumes only the virtual
    # NMEA stream created by the bridge, while the Witty backend remains a
    # separate gpsd client. Wants keeps WURB startable if GPS is unavailable.
    if [ "$GPS_WAVESHARE" = true ] || [ "$GPS_USB" = true ]; then
        mkdir -p /etc/systemd/system/wurb_2026.service.d
        rm -f /etc/systemd/system/wurb_2026.service.d/waveshare-gps-bridge.conf
        cat > /etc/systemd/system/wurb_2026.service.d/gps-bridge.conf << 'EOF'
[Unit]
Wants=wurb-gps-bridge.service
After=wurb-gps-bridge.service
EOF
    else
        rm -f /etc/systemd/system/wurb_2026.service.d/waveshare-gps-bridge.conf \
            /etc/systemd/system/wurb_2026.service.d/gps-bridge.conf
    fi

    # useradd normally creates a .bashrc that loads .bash_aliases. Add the
    # standard block once if it is missing.
    if ! grep -q 'bash_aliases' /home/wurb/.bashrc 2>/dev/null; then
        cat << 'EOF' >> /home/wurb/.bashrc

# Official CloudedBats commands: wurb-on/off/status and wirc-on/off/status.
if [ -f "$HOME/.bash_aliases" ]; then
    . "$HOME/.bash_aliases"
fi
EOF
        chown wurb:wurb /home/wurb/.bashrc
    fi

    if ! timeout 20s systemctl daemon-reload; then
        echo "FEHLER: systemd reagiert beim Einlesen des WURB-Dienstes nicht."
        exit 1
    fi
    # Official CloudedBats flow: enable and start as separate, time-limited
    # steps, making port 8080 available immediately after installation.
    if ! timeout 15s systemctl enable wurb_2026.service; then
        echo "FEHLER: WURB-Dienst konnte nicht aktiviert werden."
        exit 1
    fi
    timeout 5s systemctl reset-failed wurb_2026.service 2>/dev/null || true
    if ! timeout 30s systemctl start wurb_2026.service; then
        echo "WARNUNG: WURB-Dienst wurde installiert, startete aber nicht innerhalb von 30 Sekunden."
        echo "Diagnose: journalctl -u wurb_2026.service -n 50 --no-pager"
    fi
    sleep 3
    if ! systemctl is-active --quiet wurb_2026.service; then
        echo "FEHLER: WURB-Prozess ist nach dem Start wieder abgestürzt; Port 8080 ist nicht verfügbar."
        journalctl -u wurb_2026.service -n 50 --no-pager || true
        exit 1
    fi

    echo "-> Offizielle Befehle installiert: wurb-on/off/status und wirc-on/off/status"

    echo ""
    echo "=== [PHASE 3] WURB-2026 Installation abgeschlossen ==="

else

    echo ""
    echo "=== [PHASE 3] WURB-2026 Installation wird übersprungen ==="
    echo "    INSTALL_WURB=false"

fi

# ==============================================================================
# PHASE 3.5: WIRC INFRARED CAMERA INSTALLATION (conditional)
# ==============================================================================
if [ "$INSTALL_WIRC" = true ]; then
    echo ""
    echo "=== [PHASE 3.5] Installiere WIRC-2026 Infrarot-Kamera-System ==="

    WURB_HOME="/home/wurb"

    timeout 15s systemctl stop wirc_2026.service 2>/dev/null || true
    timeout 5s systemctl reset-failed wirc_2026.service 2>/dev/null || true

    # Existing files are retained unless removal was explicitly selected.
    if [ -d "$WURB_HOME/wirc_2026" ]; then
        echo "Aktualisiere vorhandenes WIRC-2026-Repository..."
        sudo -u wurb git -C "$WURB_HOME/wirc_2026" pull --ff-only || \
            echo "WARNUNG: WIRC-Repository konnte nicht automatisch aktualisiert werden."
    else
        echo "Klone WIRC-2026 von der definierten URL..."
        if ! sudo -u wurb git clone "$WIRC_GIT_URL" "$WURB_HOME/wirc_2026"; then
            echo "FEHLER: WIRC-2026 konnte nicht geladen werden."
            exit 1
        fi
    fi

    # 1. Install global camera dependencies with apt
    echo "Installiere globale Kamera- und Bildverarbeitungs-Bibliotheken..."
    apt install -y python3-picamera2 python3-opencv ffmpeg
    echo "-> Globale System-Treiber erfolgreich aufgespielt."

    # Safely prepare the WIRC URL for the here-document
    TARGET_WIRC_REPO=$(echo "$WIRC_GIT_URL" | tr -d '\r' | xargs)

    # 2. Change user, clone WIRC and build its virtual environment
    # TARGET_REPO_URL passes the GitHub address safely to the target user
    if ! sudo TARGET_REPO_URL="$TARGET_WIRC_REPO" -u wurb -i << 'EOF'
set -e
cd /home/wurb

cd /home/wurb/wirc_2026
echo "Erstelle venv mit Zugriff auf globale System-Pakete (--system-site-packages)..."
python3 -m venv --system-site-packages venv

source venv/bin/activate
python -m pip install --upgrade pip
if [ -f 'requirements.txt' ]; then
    python -m pip install --no-cache-dir -r requirements.txt
fi
python -m pip install --disable-pip-version-check --force-reinstall \
    'fastapi==0.115.12' 'starlette==0.46.2' \
    'uvicorn==0.34.3' 'websockets==15.0.1' \
    'python-multipart==0.0.20'
python -c 'import importlib.metadata as m; import fastapi, fastapi.templating, uvicorn, websockets; from python_multipart.multipart import parse_options_header; assert m.version("fastapi") == "0.115.12"; assert m.version("starlette") == "0.46.2"; assert m.version("uvicorn") == "0.34.3"; assert m.version("websockets") == "15.0.1"; assert m.version("python-multipart") == "0.0.20"; assert hasattr(fastapi.templating, "Jinja2Templates"); assert hasattr(uvicorn, "Config"); assert hasattr(uvicorn, "Server"); from uvicorn.protocols.websockets.websockets_impl import WebSocketProtocol'
deactivate
EOF
    then
        echo "FEHLER: WIRC-Pythonumgebung konnte nicht eingerichtet werden."
        exit 1
    fi
    if grep -Eq '^VERSION_CODENAME=trixie$' /etc/os-release 2>/dev/null; then
        bash "$INSTALLER_DIR/installer/cloudedbats_trixie_compat.sh" verify-wirc || exit 1
    fi

    # 3. Install the official systemd unit from the WIRC repository
    echo "Registriere offiziellen WIRC-Kamera-Hintergrunddienst..."
    WIRC_SERVICE_SRC="/home/wurb/wirc_2026/raspberrypi_files/wirc_2026.service"
    
    if [ -f "$WIRC_SERVICE_SRC" ]; then
        cp "$WIRC_SERVICE_SRC" /etc/systemd/system/
        echo "-> Originale wirc_2026.service erfolgreich in das System geladen."
    else
        echo "HINWEIS: WIRC-Service-Vorlage im Repo nicht gefunden. Erstelle stabilen Fallback..."
        cat << 'EOF' > /etc/systemd/system/wirc_2026.service
[Unit]
Description=WIRC-2026 Bat Infrared Camera Service
After=network.target

[Service]
Type=simple
User=wurb
WorkingDirectory=/home/wurb/wirc_2026
ExecStart=/home/wurb/wirc_2026/venv/bin/python3 /home/wurb/wirc_2026/wirc_main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
    fi

    # WIRC currently catches some application exceptions and can consequently
    # exit with status 0. Restart=always also recovers this clean-looking exit;
    # an explicit `systemctl stop` is still honoured by systemd.
    install -d -m 0755 /etc/systemd/system/wirc_2026.service.d
    cat > /etc/systemd/system/wirc_2026.service.d/witty-stability.conf << 'EOF'
[Unit]
StartLimitIntervalSec=180
StartLimitBurst=12

[Service]
Restart=always
RestartSec=10
EOF

    # 4. Enable and start the service
    if ! timeout 20s systemctl daemon-reload; then
        echo "FEHLER: systemd reagiert beim Einlesen des WIRC-Dienstes nicht."
        exit 1
    fi
    if ! timeout 15s systemctl enable wirc_2026.service; then
        echo "FEHLER: WIRC-Dienst konnte nicht aktiviert werden."
        exit 1
    fi
    timeout 5s systemctl reset-failed wirc_2026.service 2>/dev/null || true
    if ! timeout 30s systemctl start wirc_2026.service; then
        echo "WARNUNG: WIRC-Dienst wurde installiert, startete aber nicht innerhalb von 30 Sekunden."
    fi
    sleep 3
    if ! systemctl is-active --quiet wirc_2026.service; then
        echo "FEHLER: WIRC-Prozess ist nach dem Start wieder abgestürzt; Port 8082 ist nicht verfügbar."
        journalctl -u wirc_2026.service -n 50 --no-pager || true
        exit 1
    fi
fi

# Simple command-line control for installed services.
cat << 'EOF' > /usr/local/sbin/wurb-service
#!/usr/bin/env bash
set -u
case "${1:-status}" in
    on|enable)  exec systemctl enable --now wurb_2026.service ;;
    off|disable) exec systemctl disable --now wurb_2026.service ;;
    start|stop|restart|status) exec systemctl "$1" wurb_2026.service ;;
    *) echo "Verwendung: sudo wurb-service {on|off|start|stop|restart|status}"; exit 2 ;;
esac
EOF
chmod 755 /usr/local/sbin/wurb-service

cat << 'EOF' > /usr/local/sbin/wirc-service
#!/usr/bin/env bash
set -u
case "${1:-status}" in
    on|enable)  exec systemctl enable --now wirc_2026.service ;;
    off|disable) exec systemctl disable --now wirc_2026.service ;;
    start|stop|restart|status) exec systemctl "$1" wirc_2026.service ;;
    *) echo "Verwendung: sudo wirc-service {on|off|start|stop|restart|status}"; exit 2 ;;
esac
EOF
chmod 755 /usr/local/sbin/wirc-service

# ==============================================================================
# PHASE 4: WITTY PI 5 / GPS / RTC TIME SYNCHRONISATION
#
# User:
#   regular user = wurb
#   installation runs through sudo/root
#
# Time modes:
#
#   GPS_NONE=true
#       Witty Pi 5 RTC -> Raspberry Pi system time
#
#   GPS_USB=true
#       USB GPS -> system time -> Witty Pi 5 RTC
#
#   GPS_WAVESHARE=true
#       Waveshare L76X -> gpsd -> system time -> Witty Pi 5 RTC
#
# Exactly one GPS option must be true.
# ==============================================================================


if [ "$INSTALL_WITTY" = true ] && [ "$WITTY_MODEL" = 5 ]; then
echo ""
echo "======================================================================"
echo "=== [PHASE 4] Witty Pi 5 / GPS / RTC Zeitsynchronisation          ==="
echo "======================================================================"
echo ""

# The Allsky installer may already have started the service. Keep Allsky stopped
# during RTC configuration so it cannot record with an incorrect timestamp.
if systemctl list-unit-files --no-legend 2>/dev/null | awk '{print $1}' | grep -qx "allsky.service"; then
    echo "-> Stoppe Allsky vor der RTC-Konfiguration (maximal 30 Sekunden)..."
    timeout 30s systemctl stop allsky.service allskyperiodic.service 2>/dev/null
    STOP_RC=$?
    if [ "$STOP_RC" -ne 0 ]; then
        if [ "$STOP_RC" -eq 124 ]; then
            echo "WARNUNG: Allsky reagiert nicht auf Stop; beende verbliebene Prozesse."
            systemctl kill --kill-who=all --signal=SIGKILL \
                allsky.service allskyperiodic.service 2>/dev/null || true
            timeout 10s systemctl stop \
                allsky.service allskyperiodic.service 2>/dev/null || true
        else
            echo "WARNUNG: Allsky konnte nicht regulär gestoppt werden; Installation läuft weiter."
        fi
    fi
    echo "-> Allsky-Stoppprüfung abgeschlossen."
else
    echo "-> Kein allsky.service vorhanden; fahre mit Phase 4 fort."
fi


# ==============================================================================
# USER AND PATHS
# ==============================================================================

INSTALL_USER="wurb"
INSTALL_HOME="/home/wurb"

CONFIG_FILE="/boot/firmware/config.txt"

WITTYPI_DEB_URL="${WITTYPI_DEB_URL:-https://www.uugear.com/repo/WittyPi5/wp5_latest.deb}"
WP5_DEB="/tmp/wp5_latest.deb"


# ==============================================================================
# GPS VARIABLES
# ==============================================================================

GPS_NONE="${GPS_NONE:-false}"
GPS_USB="${GPS_USB:-false}"
GPS_WAVESHARE="${GPS_WAVESHARE:-false}"


# ==============================================================================
# CHECK ROOT PRIVILEGES
# ==============================================================================

if [ "$(id -u)" -ne 0 ]; then
    echo "FEHLER: Dieses Installationsscript benötigt Root-Rechte."
    echo ""
    echo "Bitte starten mit:"
    echo ""
    echo "    sudo bash $0"
    echo ""
    exit 1
fi


# ==============================================================================
# CHECK THE WURB USER
# ==============================================================================

if ! id "$INSTALL_USER" >/dev/null 2>&1; then
    echo "FEHLER: Benutzer '$INSTALL_USER' existiert nicht."
    exit 1
fi


if [ ! -d "$INSTALL_HOME" ]; then
    echo "FEHLER: Home-Verzeichnis '$INSTALL_HOME' existiert nicht."
    exit 1
fi


echo "Installationsbenutzer : $INSTALL_USER"
echo "Home-Verzeichnis      : $INSTALL_HOME"
echo "Installer läuft als   : $(id -un)"
echo "UID des Installers    : $(id -u)"
echo ""


# ==============================================================================
# VALIDATE THE GPS SELECTION
# ==============================================================================

GPS_COUNT=0

[ "$GPS_NONE" = true ] && GPS_COUNT=$((GPS_COUNT + 1))
[ "$GPS_USB" = true ] && GPS_COUNT=$((GPS_COUNT + 1))
[ "$GPS_WAVESHARE" = true ] && GPS_COUNT=$((GPS_COUNT + 1))


if [ "$GPS_COUNT" -ne 1 ]; then
    echo "FEHLER: Genau eine GPS-Option muss aktiviert sein."
    echo ""
    echo "Aktuelle Konfiguration:"
    echo ""
    echo "    GPS_NONE      = $GPS_NONE"
    echo "    GPS_USB       = $GPS_USB"
    echo "    GPS_WAVESHARE = $GPS_WAVESHARE"
    echo ""
    exit 1
fi


# ==============================================================================
# CHECK THE ARCHITECTURE
# ==============================================================================

echo "-> Prüfe Systemarchitektur..."

ARCH="$(dpkg --print-architecture 2>/dev/null || uname -m)"

echo "   -> Gefunden: $ARCH"


if [ "$ARCH" != "arm64" ] && [ "$ARCH" != "aarch64" ]; then
    echo ""
    echo "FEHLER: Das Witty-Pi-5-Paket benötigt ARM64."
    echo "Gefundene Architektur: $ARCH"
    echo ""
    exit 1
fi


# ==============================================================================
# REQUIRED SYSTEM PACKAGES
# ==============================================================================

echo ""
echo "-> Installiere benötigte Systempakete..."

echo "-> Prüfe den Zustand der Debian-Paketverwaltung..."
if ! timeout 600s dpkg --force-confold --configure -a; then
    echo "-> Repariere unvollständige Paketabhängigkeiten..."
    apt-get -o DPkg::Lock::Timeout=120 -o Dpkg::Options::=--force-confold \
        --fix-broken install -y
    timeout 600s dpkg --force-confold --configure -a
fi

apt-get update

apt-get install -y \
    wget \
    i2c-tools \
    jq \
    util-linux


if [ "$GPS_USB" = true ] || [ "$GPS_WAVESHARE" = true ]; then
    echo ""
    echo "-> Installiere GPS-Werkzeuge..."

    apt-get install -y \
        gpsd \
        gpsd-clients
fi


# ==============================================================================
# ENABLE I2C
# ==============================================================================

echo ""
echo "-> Aktiviere I2C..."


if command -v raspi-config >/dev/null 2>&1; then
    raspi-config nonint do_i2c 0 || true
fi


if [ -f "$CONFIG_FILE" ]; then

    if grep -qE '^[[:space:]]*dtparam=i2c_arm=off[[:space:]]*$' "$CONFIG_FILE"; then

        sed -i \
            's/^[[:space:]]*dtparam=i2c_arm=off[[:space:]]*$/dtparam=i2c_arm=on/' \
            "$CONFIG_FILE"

        echo "   -> I2C wurde aktiviert."

    elif grep -qE '^[[:space:]]*dtparam=i2c_arm=on[[:space:]]*$' "$CONFIG_FILE"; then

        echo "   -> I2C ist bereits aktiviert."

    else

        echo "" >> "$CONFIG_FILE"
        echo "# I2C für Witty Pi 5" >> "$CONFIG_FILE"
        echo "dtparam=i2c_arm=on" >> "$CONFIG_FILE"

        echo "   -> dtparam=i2c_arm=on eingetragen."
    fi

else

    echo "WARNUNG: $CONFIG_FILE wurde nicht gefunden."

fi


# ==============================================================================
# INSTALL OR UPDATE WITTY PI 5 SOFTWARE
# ==============================================================================

echo ""
echo "======================================================================"
echo "=== Witty Pi 5 Software installieren                               ==="
echo "======================================================================"
echo ""


# Remove the old temporary file
rm -f "$WP5_DEB"


echo "-> Lade Witty Pi 5 Software herunter..."
echo "   -> Quelle: $WITTYPI_DEB_URL"
echo "   -> Temporäre Datei: $WP5_DEB"
echo ""


if ! wget \
    --timeout=30 \
    --tries=3 \
    -O "$WP5_DEB" \
    "$WITTYPI_DEB_URL"
then
    echo ""
    echo "FEHLER: Witty-Pi-5-Paket konnte nicht heruntergeladen werden."

    rm -f "$WP5_DEB"

    exit 1
fi


# ------------------------------------------------------------------------------
# Validate the download
# ------------------------------------------------------------------------------

if [ ! -s "$WP5_DEB" ]; then
    echo ""
    echo "FEHLER: Die heruntergeladene WP5-Datei ist leer."

    rm -f "$WP5_DEB"

    exit 1
fi


echo "   -> Download erfolgreich."


# ------------------------------------------------------------------------------
# Validate the Debian package
# ------------------------------------------------------------------------------

echo ""
echo "-> Prüfe heruntergeladenes Debian-Paket..."


if ! dpkg-deb --info "$WP5_DEB" >/dev/null 2>&1; then
    echo "FEHLER: Die heruntergeladene Datei ist kein gültiges Debian-Paket."

    rm -f "$WP5_DEB"

    exit 1
fi


echo "   -> Debian-Paket ist gültig."


# ------------------------------------------------------------------------------
# Installation
# ------------------------------------------------------------------------------

echo ""
echo "-> Installiere / aktualisiere Witty Pi 5..."


if apt-get install -y "$WP5_DEB"; then

    echo ""
    echo "   -> Witty Pi 5 erfolgreich installiert."

else

    echo ""
    echo "FEHLER: Witty Pi 5 konnte nicht installiert werden."

    rm -f "$WP5_DEB"

    exit 1
fi


# ==============================================================================
# REMOVE THE INSTALLATION FILE
# ==============================================================================

echo ""
echo "-> Entferne Witty-Pi-Installationsdatei..."

rm -f "$WP5_DEB"


if [ -e "$WP5_DEB" ]; then
    echo "FEHLER: $WP5_DEB konnte nicht gelöscht werden."
    exit 1
else
    echo "   -> Installationsdatei vollständig gelöscht."
fi


# ==============================================================================
# LOCATE THE WP5 BINARY
# ==============================================================================

echo ""
echo "-> Suche wp5..."


WP5_BIN="$(command -v wp5 2>/dev/null || true)"


if [ -z "$WP5_BIN" ]; then
    echo "FEHLER: wp5 wurde nach der Installation nicht gefunden."
    exit 1
fi


if [ ! -x "$WP5_BIN" ]; then
    echo "FEHLER: wp5 ist nicht ausführbar:"
    echo ""
    echo "    $WP5_BIN"
    echo ""
    exit 1
fi


echo "   -> wp5 gefunden: $WP5_BIN"


# ==============================================================================
# CHECK THE WP5D SERVICE
#
# IMPORTANT:
#
# Do not restart wp5d unconditionally.
#
# Leave a service started by the Debian package running. If it is not running,
# start it with a timeout.
#
# This prevents the installer from waiting on systemctl indefinitely.
# ==============================================================================

echo ""
echo "-> Prüfe wp5d.service..."

if ! timeout 20s systemctl daemon-reload; then
    echo "FEHLER: systemd konnte die Witty-Pi-Installation nicht neu einlesen."
    exit 1
fi


if ! systemctl list-unit-files --no-legend 2>/dev/null \
    | awk '{print $1}' \
    | grep -qx "wp5d.service"
then
    echo ""
    echo "FEHLER: wp5d.service wurde nicht installiert."
    exit 1
fi


echo "   -> wp5d.service vorhanden."


# ------------------------------------------------------------------------------
# Enable the service
# ------------------------------------------------------------------------------

echo "-> Prüfe Autostart von wp5d.service..."


if systemctl is-enabled --quiet wp5d.service 2>/dev/null; then

    echo "   -> wp5d.service ist bereits für Autostart aktiviert."

else

    echo "   -> Aktiviere wp5d.service..."

    if timeout 15s systemctl enable wp5d.service; then

        echo "   -> wp5d.service wurde aktiviert."

    else

        RC=$?

        if [ "$RC" -eq 124 ]; then
            echo "FEHLER: systemctl enable wp5d.service hat länger als 15 Sekunden benötigt."
        else
            echo "FEHLER: wp5d.service konnte nicht aktiviert werden."
        fi

        exit 1
    fi
fi


# ------------------------------------------------------------------------------
# Do NOT restart an already running service
# ------------------------------------------------------------------------------

echo "-> Prüfe Status von wp5d.service..."


if systemctl is-active --quiet wp5d.service; then

    echo "   -> wp5d.service läuft bereits."
    echo "   -> Kein Neustart des Dienstes erforderlich."

else

    echo "   -> wp5d.service läuft noch nicht."
    echo "   -> Starte wp5d.service..."


    if timeout 20s systemctl start wp5d.service; then

        echo "   -> Startbefehl abgeschlossen."

    else

        RC=$?

        echo ""

        if [ "$RC" -eq 124 ]; then
            echo "FEHLER: Start von wp5d.service hat länger als 20 Sekunden benötigt."
        else
            echo "FEHLER: wp5d.service konnte nicht gestartet werden."
        fi

        echo ""
        echo "Status:"
        systemctl status wp5d.service --no-pager || true

        echo ""
        echo "Letzte Logmeldungen:"
        journalctl -u wp5d.service -n 30 --no-pager || true

        exit 1
    fi
fi


# ------------------------------------------------------------------------------
# Final validation
# ------------------------------------------------------------------------------

sleep 1


if systemctl is-active --quiet wp5d.service; then

    echo "   -> wp5d.service ist ACTIVE."

else

    echo ""
    echo "FEHLER: wp5d.service ist nach dem Start nicht ACTIVE."
    echo ""

    systemctl status wp5d.service --no-pager || true

    echo ""
    echo "Letzte Logmeldungen:"
    journalctl -u wp5d.service -n 30 --no-pager || true

    exit 1
fi


# ==============================================================================
# CHECK WITTY PI OVER I2C
#
# Witty Pi 5 uses address 0x51 by default.
#
# i2cdetect may display either
#
#     51
#
# or
#
#     UU
#
# at that address.
# ==============================================================================

echo ""
echo "-> Prüfe Witty Pi 5 auf I2C-Adresse 0x51..."


WP5_I2C_OK=false


for attempt in 1 2 3 4 5; do

    I2C_51="$(
        i2cdetect -y 1 2>/dev/null \
        | awk '$1=="50:" {print $3}'
    )"


    if [ "$I2C_51" = "51" ] || [ "$I2C_51" = "UU" ]; then
        WP5_I2C_OK=true
        break
    fi


    echo "   -> Versuch $attempt/5: 0x51 noch nicht erkannt."

    sleep 2
done


if [ "$WP5_I2C_OK" = true ]; then

    echo "   -> Witty Pi 5 auf I2C-Adresse 0x51 erkannt."
    printf 'RPI_MODEL=%s\nWITTY_MODEL=5\nGPS_MODE=%s\n' "$RPI_MODEL" "$GPS_MODE" > /etc/witty-addon.conf
    chmod 0644 /etc/witty-addon.conf

else

    echo ""
    echo "FEHLER: Witty Pi 5 wurde auf I2C-Adresse 0x51 nicht erkannt."
    echo ""
    echo "Aktuelle I2C-Belegung:"
    echo ""

    i2cdetect -y 1 || true

    echo ""
    echo "Wenn I2C erst während dieser Installation aktiviert wurde,"
    echo "ist möglicherweise zunächst ein Neustart erforderlich. Danach Installer erneut starten."
    echo ""
    exit 1

fi


# ==============================================================================
# WITTY PI TIME HELPER
#
# wp5 menu:
#
#   1 = system time -> RTC
#   2 = RTC -> system time
#  14 = Exit
# ==============================================================================

echo ""
echo "-> Erstelle Witty-Pi-Zeit-Helfer..."


cat > /usr/local/sbin/wurb-wp5-time << 'EOF'
#!/bin/bash

set -uo pipefail

WP5_BIN="$(command -v wp5 2>/dev/null || true)"
LOCK_FILE="/run/lock/witty-addon.lock"

if [ ! -x "$WP5_BIN" ]; then
    echo "FEHLER: wp5 wurde nicht gefunden."
    exit 1
fi

exec 9>"$LOCK_FILE"
if ! flock -w 150 9; then
    echo "FEHLER: Ein anderer Witty-Pi-Befehl läuft noch."
    exit 1
fi

MODE="${1:-}"

run_wp5_menu() {
    local menu="$1" service_was_active=0 rc
    systemctl is-active --quiet wp5d.service && service_was_active=1 || true
    if [ "$service_was_active" -eq 1 ]; then
        systemctl stop wp5d.service || return 1
    fi
    printf '%s\n14\n' "$menu" | timeout 20s "$WP5_BIN"
    rc=$?
    if [ "$service_was_active" -eq 1 ]; then
        systemctl start wp5d.service || true
    fi
    return "$rc"
}


case "$MODE" in


    rtc-to-system)

        echo "============================================================"
        echo "Witty Pi 5 RTC -> Linux Systemzeit"
        echo "============================================================"
        echo ""

        run_wp5_menu 2
        RC=$?


        if [ "$RC" -eq 124 ]; then
            echo "FEHLER: wp5 RTC->System Timeout."
            exit 1
        fi


        if [ "$RC" -ne 0 ]; then
            echo "FEHLER: wp5 RTC->System Synchronisation fehlgeschlagen."
            exit "$RC"
        fi


        echo ""
        echo "Aktuelle Linux-Systemzeit:"
        date --iso-8601=seconds
        ;;


    system-to-rtc)

        echo "============================================================"
        echo "Linux Systemzeit -> Witty Pi 5 RTC"
        echo "============================================================"
        echo ""

        run_wp5_menu 1
        RC=$?


        if [ "$RC" -eq 124 ]; then
            echo "FEHLER: wp5 System->RTC Timeout."
            exit 1
        fi


        if [ "$RC" -ne 0 ]; then
            echo "FEHLER: wp5 System->RTC Synchronisation fehlgeschlagen."
            exit "$RC"
        fi
        ;;


    *)

        echo "Verwendung:"
        echo ""
        echo "    $0 rtc-to-system"
        echo ""
        echo "oder"
        echo ""
        echo "    $0 system-to-rtc"

        exit 1
        ;;

esac


exit 0
EOF


chmod 755 /usr/local/sbin/wurb-wp5-time
chown root:root /usr/local/sbin/wurb-wp5-time


echo "   -> /usr/local/sbin/wurb-wp5-time erstellt."

# Write the current Linux system time specifically to the internal Pi 5 RTC.
cat > /usr/local/sbin/wurb-system-to-rpi-rtc << 'EOF'
#!/usr/bin/env bash
set -u
[ -r /etc/witty-addon.conf ] && source /etc/witty-addon.conf
[ "${RPI_MODEL:-5}" = 4 ] && exit 0

RPI_RTC=""
for RTC_SYS in /sys/class/rtc/rtc*; do
    [ -r "$RTC_SYS/name" ] || continue
    RTC_NAME="$(cat "$RTC_SYS/name")"
    case "$RTC_NAME" in
        rpi-rtc|rpi_rtc) RPI_RTC="/dev/$(basename "$RTC_SYS")"; break ;;
    esac
done

# On Raspberry Pi 5 the internal RTC is normally /dev/rtc0.
[ -n "$RPI_RTC" ] || RPI_RTC="/dev/rtc0"
if [ ! -e "$RPI_RTC" ]; then
    echo "FEHLER: Interne Raspberry-Pi-RTC wurde nicht gefunden."
    exit 1
fi
exec hwclock --systohc --utc --rtc="$RPI_RTC"
EOF
chmod 755 /usr/local/sbin/wurb-system-to-rpi-rtc
chown root:root /usr/local/sbin/wurb-system-to-rpi-rtc


# ==============================================================================
# GPS -> SYSTEM TIME -> WITTY PI RTC
# ==============================================================================

echo "-> Erstelle GPS-Zeit-Helfer..."


cat > /usr/local/sbin/wurb-gps-to-witty << 'EOF'
#!/bin/bash

set -u

WAIT_MODE="${1:-once}"
MAX_ATTEMPTS=1
[ "$WAIT_MODE" = "wait" ] && MAX_ATTEMPTS=20


echo "============================================================"
echo "GPS -> Linux Systemzeit -> Witty Pi 5 RTC"
echo "============================================================"
echo ""


if ! command -v gpspipe >/dev/null 2>&1; then
    echo "FEHLER: gpspipe wurde nicht gefunden."
    exit 1
fi


if ! command -v jq >/dev/null 2>&1; then
    echo "FEHLER: jq wurde nicht gefunden."
    exit 1
fi


echo "Prüfe GPS-Fix und GPS-Zeit..."
echo ""

GPS_TIME=""
ATTEMPT=1
while [ "$ATTEMPT" -le "$MAX_ATTEMPTS" ]; do
    GPS_TIME="$(
        timeout 30s gpspipe -w 2>/dev/null \
        | jq -r '
            select(
                .class == "TPV"
                and (.mode // 0) >= 2
                and .time != null
                and .time != ""
            )
            | .time
        ' \
        | head -n 1
    )"
    [ -n "$GPS_TIME" ] && [ "$GPS_TIME" != "null" ] && break
    echo "Noch kein gültiger GPS-Fix ($ATTEMPT/$MAX_ATTEMPTS)."
    ATTEMPT=$((ATTEMPT + 1))
    [ "$ATTEMPT" -le "$MAX_ATTEMPTS" ] && sleep 5
done


if [ -z "$GPS_TIME" ] || [ "$GPS_TIME" = "null" ]; then
    echo "WARNUNG: Kein gültiger GPS-Fix mit Zeitinformation vorhanden."
    exit 1
fi


echo "GPS-Zeit:"
echo ""
echo "    $GPS_TIME"
echo ""


echo "-> Setze Linux-Systemzeit auf GPS-Zeit..."


if ! date -u -s "$GPS_TIME"; then
    echo "FEHLER: Linux-Systemzeit konnte nicht gesetzt werden."
    exit 1
fi


echo ""
echo "Aktuelle Linux-Systemzeit:"
date --iso-8601=seconds
echo ""

echo "-> Schreibe GPS-Zeit in die interne Raspberry-Pi-RTC..."
if ! /usr/local/sbin/wurb-system-to-rpi-rtc; then
    echo "FEHLER: Raspberry-Pi-RTC konnte nicht aktualisiert werden."
    exit 1
fi


echo "-> Schreibe Systemzeit in Witty Pi 5 RTC..."


if ! /usr/local/sbin/wurb-wp5-time system-to-rtc; then
    echo "FEHLER: Witty Pi RTC konnte nicht aktualisiert werden."
    exit 1
fi


echo ""
echo "GPS -> Linux -> Raspberry-Pi-RTC + Witty-Pi-RTC erfolgreich."
echo ""


exit 0
EOF


chmod 755 /usr/local/sbin/wurb-gps-to-witty
chown root:root /usr/local/sbin/wurb-gps-to-witty


echo "   -> /usr/local/sbin/wurb-gps-to-witty erstellt."


# ==============================================================================
# CLEAN UP OLD WURB TIME SERVICES
# ==============================================================================

echo ""
echo "-> Bereinige eventuell vorhandene alte WURB-Zeitdienste..."


timeout 10s systemctl disable --now \
    wurb-witty-hctosys.service \
    2>/dev/null || true


timeout 10s systemctl disable --now \
    wurb-rtc-sync.timer \
    2>/dev/null || true


rm -f \
    /etc/systemd/system/wurb-witty-hctosys.service \
    /etc/systemd/system/wurb-rtc-sync.service \
    /etc/systemd/system/wurb-rtc-sync.timer


rm -f \
    /etc/systemd/system/allsky.service.d/witty-time.conf \
    /etc/systemd/system/allskyperiodic.service.d/witty-time.conf \
    2>/dev/null || true

# Avoid further live systemd reloads from here. Newly created time services and
# drop-ins are loaded during the required reboot.

# GPS modes and Allsky retain the internal Pi RTC. For WURB/WIRC without GPS,
# Witty is the only hardware clock and restores Linux time at every boot.
if [ -f "$CONFIG_FILE" ]; then
    sed -i '/^[[:space:]]*dtoverlay=disable-rtc[[:space:]]*$/d' "$CONFIG_FILE"
    sed -i '/^[[:space:]]*dtparam=rtc=\(on\|off\)[[:space:]]*$/d' "$CONFIG_FILE"
    if [ "$GPS_NONE" = true ] && [ "$INSTALL_ALLSKY" != true ]; then
        echo "dtparam=rtc=off" >> "$CONFIG_FILE"
        echo "dtoverlay=disable-rtc" >> "$CONFIG_FILE"
    else
        echo "dtparam=rtc=on" >> "$CONFIG_FILE"
    fi
fi


# ==============================================================================
# OPTION 1: NO GPS
#
# Witty Pi RTC -> Linux -> ALLSKY
# ==============================================================================

if [ "$GPS_NONE" = true ]; then


    echo ""
    echo "======================================================================"
    echo "=== ZEITQUELLE: WITTY PI 5 RTC                                    ==="
    echo "======================================================================"
    echo ""

    echo "-> Kein GPS ausgewählt."
    echo "-> Witty Pi 5 wird als Master-Clock verwendet."


    # --------------------------------------------------------------------------
    # Enable the internal Raspberry Pi 5 RTC
    # --------------------------------------------------------------------------

    echo ""
    if [ "$INSTALL_ALLSKY" = true ]; then
        echo "-> Allsky verwendet zusätzlich die interne Raspberry-Pi-RTC."
    else
        echo "-> Interne Raspberry-Pi-RTC ist deaktiviert; Witty bleibt alleinige Hardware-Uhr."
    fi


    if [ -f "$CONFIG_FILE" ] && [ "$INSTALL_ALLSKY" = true ]; then

        # Remove the old entry
        sed -i \
            '/^[[:space:]]*dtoverlay=disable-rtc[[:space:]]*$/d' \
            "$CONFIG_FILE"


        if grep -qE '^[[:space:]]*dtparam=rtc=off[[:space:]]*$' "$CONFIG_FILE"; then
            sed -i \
                's/^[[:space:]]*dtparam=rtc=off[[:space:]]*$/dtparam=rtc=on/' \
                "$CONFIG_FILE"
            echo "   -> Interne RTC aktiviert."

        elif grep -qE '^[[:space:]]*dtparam=rtc=on[[:space:]]*$' "$CONFIG_FILE"; then
            echo "   -> Interne RTC ist bereits aktiviert."


        else

            echo "" >> "$CONFIG_FILE"
            echo "# Interne Raspberry Pi 5 RTC aktivieren" >> "$CONFIG_FILE"
            echo "dtparam=rtc=on" >> "$CONFIG_FILE"
            echo "   -> dtparam=rtc=on eingetragen."

        fi

    elif [ ! -f "$CONFIG_FILE" ]; then

        echo "WARNUNG: $CONFIG_FILE wurde nicht gefunden."

    fi


    # --------------------------------------------------------------------------
    # fake-hwclock
    # --------------------------------------------------------------------------

    echo ""
    echo "-> Entferne fake-hwclock..."

    timeout 10s systemctl disable --now fake-hwclock.service \
        2>/dev/null || true

    apt-get remove -y fake-hwclock 2>/dev/null || true


    # --------------------------------------------------------------------------
    # Disable NTP
    # --------------------------------------------------------------------------

    echo ""
    echo "-> Deaktiviere Netzwerk-Zeitsynchronisation..."

    timedatectl set-ntp false 2>/dev/null || true

    timeout 10s systemctl disable --now \
        systemd-timesyncd.service \
        2>/dev/null || true

    timedatectl set-local-rtc 0 2>/dev/null || true


    # --------------------------------------------------------------------------
    # Boot service
    # --------------------------------------------------------------------------

    echo ""
    echo "-> Erstelle RTC->Systemzeit Boot-Service..."


    cat > /etc/systemd/system/wurb-witty-hctosys.service << 'EOF'
[Unit]
Description=Witty Pi RTC vor Detektorstart in die Systemzeit übernehmen
Requires=wp5d.service
After=wp5d.service
Before=wurb_2026.service wirc_2026.service allsky.service allskyperiodic.service

[Service]
Type=oneshot
ExecStartPre=/bin/sleep 2
ExecStart=/usr/local/sbin/wurb-wp5-time rtc-to-system
ExecStartPost=/usr/local/sbin/wurb-system-to-rpi-rtc
TimeoutStartSec=30
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

    if [ "$INSTALL_ALLSKY" != true ]; then
        sed -i '/^ExecStartPost=\/usr\/local\/sbin\/wurb-system-to-rpi-rtc$/d' \
            /etc/systemd/system/wurb-witty-hctosys.service
    fi

    echo "-> Aktiviere RTC-Dienst ohne laufenden systemd-Neuladevorgang..."
    mkdir -p /etc/systemd/system/multi-user.target.wants
    ln -sfn ../wurb-witty-hctosys.service \
        /etc/systemd/system/multi-user.target.wants/wurb-witty-hctosys.service

    # Do not start this during installation: wp5 is interactive and may block
    # before the hardware is fully initialised. The enabled service synchronises
    # at the next boot before Allsky.
    echo "-> RTC-Synchronisation ist für den nächsten Systemstart aktiviert."


    # --------------------------------------------------------------------------
    # ALLSKY dependency
    # --------------------------------------------------------------------------

    if systemctl list-unit-files --no-legend 2>/dev/null \
        | awk '{print $1}' \
        | grep -qx "allsky.service"
    then

        echo ""
        echo "-> Verknüpfe ALLSKY mit Witty-Pi-Zeitsynchronisation..."


        mkdir -p \
            /etc/systemd/system/allsky.service.d \
            /etc/systemd/system/allskyperiodic.service.d


        cat > /etc/systemd/system/allsky.service.d/witty-time.conf << 'EOF'
[Unit]
Wants=wurb-witty-hctosys.service
After=wurb-witty-hctosys.service
EOF

        cp /etc/systemd/system/allsky.service.d/witty-time.conf \
            /etc/systemd/system/allskyperiodic.service.d/witty-time.conf


        echo "   -> ALLSKY wartet auf den Synchronisationsversuch und startet auch bei RTC-Fehlern."

    else

        echo ""
        echo "WARNUNG: allsky.service wurde nicht gefunden."
        echo "Die RTC-Synchronisation läuft trotzdem beim Boot."

    fi


    echo ""
    echo "Witty Pi 5 wurde als Master-Clock eingerichtet."
    echo ""
    echo "Boot-Reihenfolge:"
    echo ""
    echo "    Witty Pi RTC"
    echo "         |"
    echo "         v"
    echo "    wp5d.service"
    echo "         |"
    echo "         v"
    echo "    Linux Systemzeit"
    echo "         |"
    echo "         v"
    echo "       ALLSKY"
    echo ""


# ==============================================================================
# OPTION 2: USB GPS
# ==============================================================================

elif [ "$GPS_USB" = true ]; then


    echo ""
    echo "======================================================================"
    echo "=== ZEITQUELLE: USB GPS                                            ==="
    echo "======================================================================"
    echo ""


    echo "-> USB-GPS ausgewählt."


    timedatectl set-ntp false 2>/dev/null || true

    timeout 10s systemctl disable --now \
        systemd-timesyncd.service \
        2>/dev/null || true

    timedatectl set-local-rtc 0 2>/dev/null || true


    echo ""
    echo "-> Aktiviere gpsd..."

    timeout 15s systemctl enable gpsd.socket 2>/dev/null || true


    # --------------------------------------------------------------------------
    # Sync-Service
    # --------------------------------------------------------------------------

    cat > /etc/systemd/system/wurb-rtc-sync.service << 'EOF'
[Unit]
Description=WURB - USB-GPS-Zeit in System- und beide Hardware-RTCs schreiben
After=gpsd.service wp5d.service
Wants=gpsd.service
Requires=wp5d.service
Before=allsky.service allskyperiodic.service

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/wurb-gps-to-witty wait
TimeoutStartSec=12min
EOF


    # --------------------------------------------------------------------------
    # Timer
    # --------------------------------------------------------------------------

    cat > /etc/systemd/system/wurb-rtc-sync.timer << 'EOF'
[Unit]
Description=WURB - USB GPS -> Witty Pi RTC Synchronisation

[Timer]
OnBootSec=1min
OnUnitActiveSec=5min
AccuracySec=1s
Unit=wurb-rtc-sync.service

[Install]
WantedBy=timers.target
EOF


    mkdir -p /etc/systemd/system/timers.target.wants
    ln -sfn ../wurb-rtc-sync.timer \
        /etc/systemd/system/timers.target.wants/wurb-rtc-sync.timer

    if systemctl list-unit-files --no-legend 2>/dev/null | awk '{print $1}' | grep -qx "allsky.service"; then
        mkdir -p /etc/systemd/system/allsky.service.d /etc/systemd/system/allskyperiodic.service.d
        cat > /etc/systemd/system/allsky.service.d/witty-time.conf << 'EOF'
[Unit]
Wants=wurb-rtc-sync.service
After=wurb-rtc-sync.service
EOF
        cp /etc/systemd/system/allsky.service.d/witty-time.conf /etc/systemd/system/allskyperiodic.service.d/witty-time.conf
        echo "   -> ALLSKY wartet beim Start auf einen gültigen USB-GPS-Fix."
    fi


    echo ""
    echo "USB-GPS-Zeitsynchronisation eingerichtet."
    echo ""
    echo "    GPS -> Linux -> Raspberry-Pi-RTC + Witty-Pi-RTC"
    echo ""
    echo "Erster Versuch : 1 Minute nach Boot"
    echo "Danach         : alle 5 Minuten"
    echo ""


# ==============================================================================
# OPTION 3: WAVESHARE L76X
# ==============================================================================

elif [ "$GPS_WAVESHARE" = true ]; then


    echo ""
    echo "======================================================================"
    echo "=== ZEITQUELLE: WAVESHARE L76X                                    ==="
    echo "======================================================================"
    echo ""


    echo "-> Waveshare L76X ausgewählt."


    timedatectl set-ntp false 2>/dev/null || true

    timeout 10s systemctl disable --now \
        systemd-timesyncd.service \
        2>/dev/null || true

    timedatectl set-local-rtc 0 2>/dev/null || true


    # --------------------------------------------------------------------------
    # GPS Bridge
    # --------------------------------------------------------------------------

    echo ""
    echo "-> Prüfe WURB GPS-Bridge..."


    if systemctl list-unit-files --no-legend 2>/dev/null \
        | awk '{print $1}' \
        | grep -qx "wurb-gps-bridge.service"
    then

        echo "   -> wurb-gps-bridge.service gefunden."

        timeout 15s systemctl enable \
            wurb-gps-bridge.service \
            2>/dev/null || true

        if ! systemctl is-active --quiet wurb-gps-bridge.service; then
            timeout 20s systemctl start \
                wurb-gps-bridge.service \
                2>/dev/null || true
        fi

    else

        echo ""
        echo "WARNUNG: wurb-gps-bridge.service wurde nicht gefunden."
        echo "GPS-Synchronisation wird trotzdem vorbereitet."
        echo ""

    fi


    # --------------------------------------------------------------------------
    # GPSD
    # --------------------------------------------------------------------------

    timeout 15s systemctl enable gpsd.socket 2>/dev/null || true


    # --------------------------------------------------------------------------
    # Sync-Service
    # --------------------------------------------------------------------------

    cat > /etc/systemd/system/wurb-rtc-sync.service << 'EOF'
[Unit]
Description=WURB - L76X-GPS-Zeit in System- und beide Hardware-RTCs schreiben
After=wurb-gps-bridge.service gpsd.service wp5d.service
Wants=wurb-gps-bridge.service gpsd.service
Requires=wp5d.service
Before=allsky.service allskyperiodic.service

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/wurb-gps-to-witty wait
TimeoutStartSec=12min
EOF


    # --------------------------------------------------------------------------
    # Timer
    # --------------------------------------------------------------------------

    cat > /etc/systemd/system/wurb-rtc-sync.timer << 'EOF'
[Unit]
Description=WURB - Waveshare GPS -> Witty Pi RTC Synchronisation

[Timer]
OnBootSec=1min
OnUnitActiveSec=5min
AccuracySec=1s
Unit=wurb-rtc-sync.service

[Install]
WantedBy=timers.target
EOF


    mkdir -p /etc/systemd/system/timers.target.wants
    ln -sfn ../wurb-rtc-sync.timer \
        /etc/systemd/system/timers.target.wants/wurb-rtc-sync.timer

    if systemctl list-unit-files --no-legend 2>/dev/null | awk '{print $1}' | grep -qx "allsky.service"; then
        mkdir -p /etc/systemd/system/allsky.service.d /etc/systemd/system/allskyperiodic.service.d
        cat > /etc/systemd/system/allsky.service.d/witty-time.conf << 'EOF'
[Unit]
Wants=wurb-rtc-sync.service
After=wurb-rtc-sync.service
EOF
        cp /etc/systemd/system/allsky.service.d/witty-time.conf /etc/systemd/system/allskyperiodic.service.d/witty-time.conf
        echo "   -> ALLSKY wartet beim Start auf einen gültigen L76X-GPS-Fix."
    fi


    echo ""
    echo "Waveshare-L76X-Zeitsynchronisation eingerichtet."
    echo ""
    echo "    L76X -> gpsd -> Linux -> Raspberry-Pi-RTC + Witty-Pi-RTC"
    echo ""
    echo "Erster Versuch : 1 Minute nach Boot"
    echo "Danach         : alle 5 Minuten"
    echo ""

fi

# Do not start Allsky during installation. At the next boot, drop-ins ensure
# time synchronisation occurs before Allsky starts.
if [ "$INSTALL_ALLSKY" = true ] && \
   systemctl list-unit-files --no-legend 2>/dev/null | awk '{print $1}' | grep -qx "allsky.service"; then
    echo "-> Allsky bleibt für den nächsten Boot aktiviert (kein Start während Setup)..."
    echo "-> Allsky startet erst nach dem Neustart und der RTC-/GPS-Synchronisation."
fi


# ==============================================================================
# COMPLETION
# ==============================================================================

echo "-> Phase-4-Units sind gespeichert; systemd lädt sie beim Neustart."


echo ""
echo "======================================================================"
echo "=== WITTY PI 5 ABSCHLUSSPRÜFUNG                                   ==="
echo "======================================================================"
echo ""


echo "Installationsbenutzer:"
echo "    $INSTALL_USER"
echo ""


echo "WP5 Binary:"
echo "    $WP5_BIN"
echo ""


echo "WP5 Installationsdatei:"

if [ -e "$WP5_DEB" ]; then
    echo "    FEHLER - Datei noch vorhanden: $WP5_DEB"
else
    echo "    GELÖSCHT"
fi

echo ""


echo "wp5d.service:"

if systemctl is-active --quiet wp5d.service; then
    echo "    ACTIVE"
else
    echo "    NICHT ACTIVE"
fi

echo ""


echo "wp5d Autostart:"

if systemctl is-enabled --quiet wp5d.service 2>/dev/null; then
    echo "    ENABLED"
else
    echo "    NICHT ENABLED"
fi

echo ""


echo "I2C / Witty Pi 5:"


I2C_FINAL="$(
    i2cdetect -y 1 2>/dev/null \
    | awk '$1=="50:" {print $3}'
)"


if [ "$I2C_FINAL" = "51" ] || [ "$I2C_FINAL" = "UU" ]; then
    echo "    Adresse 0x51 ERKANNT"
else
    echo "    Adresse 0x51 momentan NICHT erkannt"
fi


echo ""


if [ "$GPS_NONE" = true ]; then

    echo "Zeitmodus:"
    echo "    Witty-Pi-RTC -> Linux -> Raspberry-Pi-RTC -> ALLSKY"
    echo ""

    echo "RTC Boot-Service:"
    systemctl is-enabled wurb-witty-hctosys.service 2>/dev/null || true


elif [ "$GPS_USB" = true ]; then

    echo "Zeitmodus:"
    echo "    USB-GPS -> Linux -> Raspberry-Pi-RTC + Witty-Pi-RTC"
    echo ""

    echo "RTC-Sync-Timer:"
    systemctl is-enabled wurb-rtc-sync.timer 2>/dev/null || true


elif [ "$GPS_WAVESHARE" = true ]; then

    echo "Zeitmodus:"
    echo "    Waveshare L76X -> Linux -> Raspberry-Pi-RTC + Witty-Pi-RTC"
    echo ""

    echo "RTC-Sync-Timer:"
    systemctl is-enabled wurb-rtc-sync.timer 2>/dev/null || true

fi


echo ""
echo "======================================================================"
echo "=== PHASE 4 ABGESCHLOSSEN                                          ==="
echo "======================================================================"
echo ""


echo "Die Installationsdatei wurde gelöscht:"
echo ""
echo "    $WP5_DEB"
echo ""


echo "Nach Abschluss der gesamten Installation bitte neu starten:"
echo ""
echo "    sudo reboot"
echo ""


echo "Danach Witty Pi 5 prüfen:"
echo ""
echo "    systemctl status wp5d --no-pager"
echo ""
echo "    systemctl is-enabled wp5d"
echo ""
echo "    systemctl is-active wp5d"
echo ""
echo "    i2cdetect -y 1"
echo ""
echo "    wp5"
echo ""


if [ "$GPS_NONE" = true ]; then

    echo "Witty-Pi-Masterclock prüfen:"
    echo ""
    echo "    systemctl status wurb-witty-hctosys --no-pager"
    echo ""
    echo "    journalctl -u wurb-witty-hctosys -b --no-pager"
    echo ""

elif [ "$GPS_USB" = true ] || [ "$GPS_WAVESHARE" = true ]; then

    echo "GPS-Synchronisation prüfen:"
    echo ""
    echo "    systemctl status wurb-rtc-sync.timer --no-pager"
    echo ""
    echo "    systemctl list-timers --all | grep wurb-rtc"
    echo ""
    echo "    journalctl -u wurb-rtc-sync.service -b --no-pager"
    echo ""

fi


echo "======================================================================"
echo ""

else
    echo "=== [PHASE 4] Witty Pi 5 Installation wird übersprungen ==="
fi

if [ "$INSTALL_WITTY" = true ] && [ "$WITTY_MODEL" = 4 ]; then
    echo "=== [PHASE 4] Installiere Witty Pi 4 und RTC-Anbindung ==="
    # Raspberry Pi 4B is represented internally as family 4. Do not reject it
    # merely because /proc/device-tree/model includes the words "Model B".
    if [ "$RPI_MODEL" != 4 ]; then
        echo "FEHLER: UUGear gibt Witty Pi 4 offiziell nur bis Raspberry Pi 4B frei."
        echo "Für Raspberry Pi 5 bitte Witty Pi 5 auswählen."
        exit 1
    fi
    apt-get update
    apt-get install -y wget unzip i2c-tools || {
        echo "FEHLER: Witty-Pi-4-Abhängigkeiten konnten nicht installiert werden."
        exit 1
    }
    # The vendor installer installs the WiringPi version matching the OS and
    # architecture if gpio is not already available.
    raspi-config nonint do_i2c 0 || true
    WITTY4_INSTALLER="/home/wurb/installWittyPi4.sh"
    wget --timeout=30 --tries=3 -O "$WITTY4_INSTALLER" \
        https://raw.githubusercontent.com/uugear/Witty-Pi-4/main/Software/install.sh || exit 1
    chmod 0755 "$WITTY4_INSTALLER"
    # SUDO_USER is required for the owner and target path used by the vendor installer.
    if ! timeout 360s env SUDO_USER=wurb bash "$WITTY4_INSTALLER"; then
        echo "FEHLER: Offizielle Witty-Pi-4-Installation fehlgeschlagen."
        exit 1
    fi
    rm -f -- "$WITTY4_INSTALLER"
    WITTY4_HOME="/home/wurb/wittypi"
    chown -R wurb:wurb "$WITTY4_HOME"
    if ! [[ "$(i2cget -y 1 0x08 0 2>/dev/null || true)" =~ ^0x(26|37)$ ]]; then
        echo "FEHLER: Auswahl Witty Pi 4, aber an I2C 0x08 wurde keine Witty-Pi-4-Hardware erkannt."
        echo "Bitte Montage, 40-Pin-Stecker und I2C prüfen."
        exit 1
    fi
    cat > /usr/local/sbin/wurb-wp5-time <<'EOF'
#!/usr/bin/env bash
set -Eeuo pipefail
source /home/wurb/wittypi/utilities.sh
case "${1:-}" in
 rtc-to-system) rtc_to_system ;;
 system-to-rtc) system_to_rtc ;;
 *) echo "Verwendung: $0 {rtc-to-system|system-to-rtc}" >&2; exit 2 ;;
esac
EOF
    chmod 0755 /usr/local/sbin/wurb-wp5-time
    cat > /etc/systemd/system/wurb-witty-hctosys.service <<'EOF'
[Unit]
Description=Witty Pi 4 RTC in Linux-Systemzeit übernehmen
After=wittypi.service
Before=wurb_2026.service wirc_2026.service allsky.service allskyperiodic.service
[Service]
Type=oneshot
ExecStart=/usr/local/sbin/wurb-wp5-time rtc-to-system
TimeoutStartSec=20
[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload
    systemctl enable wittypi.service 2>/dev/null || true
    if [ "$GPS_NONE" = true ]; then
        systemctl enable wurb-witty-hctosys.service
    else
        cat > /usr/local/sbin/wurb-gps-to-rtc <<'EOF'
#!/usr/bin/env bash
set -Eeuo pipefail
GPS_TIME="$(timeout 4s gpspipe -w 2>/dev/null | jq -er 'select(.class=="TPV" and (.mode//0)>=2 and .time)|.time' | head -n1)"
[[ -n "$GPS_TIME" ]] || exit 0
date --set="$GPS_TIME" >/dev/null
/usr/local/sbin/wurb-wp5-time system-to-rtc
EOF
        chmod 0755 /usr/local/sbin/wurb-gps-to-rtc
        cat > /etc/systemd/system/wurb-rtc-sync.service <<'EOF'
[Unit]
Description=GPS-Zeit in System und Witty Pi 4 RTC schreiben
After=gpsd.service
[Service]
Type=oneshot
ExecStart=/usr/local/sbin/wurb-gps-to-rtc
TimeoutStartSec=20
EOF
        cat > /etc/systemd/system/wurb-rtc-sync.timer <<'EOF'
[Unit]
Description=GPS-RTC-Synchronisation
[Timer]
OnBootSec=30s
OnUnitActiveSec=5min
AccuracySec=1s
Unit=wurb-rtc-sync.service
[Install]
WantedBy=timers.target
EOF
        systemctl daemon-reload
        systemctl enable wurb-rtc-sync.timer
    fi
    printf 'RPI_MODEL=4\nWITTY_MODEL=4\nGPS_MODE=%s\n' "$GPS_MODE" > /etc/witty-addon.conf
    chmod 0644 /etc/witty-addon.conf
    echo "   -> Witty Pi 4 wurde physisch erkannt und passend eingerichtet."
fi

# ==============================================================================
# PHASE 4A: WITTY HOMEPAGE ADD-ON (before hotspot configuration)
# ==============================================================================
echo ""
echo "=== [PHASE 4A] Installiere Witty-Homepage-Add-on ==="

install_witty_homepage_addon_optional() (
WITTY_ADDON_WORK=""
cleanup_witty_addon() {
    [ -n "${WITTY_ADDON_WORK:-}" ] && [ -d "$WITTY_ADDON_WORK" ] && \
        rm -rf -- "$WITTY_ADDON_WORK"
}
trap cleanup_witty_addon EXIT

WITTY_ADDON_SOURCE="$INSTALLER_DIR"
WITTY_ADDON_BACKUP="/var/backups/witty-addon/$(date +%Y%m%d-%H%M%S)"
WITTY_ADDON_COMPONENTS=0

for REQUIRED_COMMAND in install stat timeout; do
    if ! command -v "$REQUIRED_COMMAND" >/dev/null 2>&1; then
        echo "FEHLER: Für das Witty-Add-on fehlt das Programm '$REQUIRED_COMMAND'."
        exit 1
    fi
done

echo "-> Verwende das bereits geprüfte Witty-Add-on aus dem Installationspaket..."

# Current add-on: dedicated web server on port 8081. The bundled install.sh
# copies the web application, installs and starts its systemd unit, and patches
# WURB/WIRC navigation idempotently. The older file-based path remains as a
# fallback for legacy archives.
if [ -f "$WITTY_ADDON_SOURCE/install.sh" ] && \
   [ -f "$WITTY_ADDON_SOURCE/installer/wittypi5-webserver.service" ] && \
   [ -f "$WITTY_ADDON_SOURCE/web/server.py" ]; then
    echo "-> Neue Add-on-Version mit eigenem Witty-Webserver erkannt."
    if [ -f "$WITTY_ADDON_SOURCE/VERSION" ]; then
        echo "-> Add-on-Version: $(tr -d '\r\n' < "$WITTY_ADDON_SOURCE/VERSION")"
    fi
    echo "-> Installiere Witty-Webserver und Navigation für WURB/WIRC..."

    RPI_MODEL="$RPI_MODEL" WITTY_MODEL="$WITTY_MODEL" GPS_MODE="$GPS_MODE" \
    WITTY_ADDON_EXPECT_ALLSKY="$([ "$INSTALL_ALLSKY" = true ] && printf 1 || printf 0)" \
        timeout 600s bash "$WITTY_ADDON_SOURCE/install.sh" || {
        ADDON_RC=$?
        if [ "$ADDON_RC" -eq 124 ]; then
            echo "FEHLER: Die Witty-Webserver-Installation überschritt 600 Sekunden."
        else
            echo "FEHLER: install.sh aus witty_addon.zip ist fehlgeschlagen."
        fi
        exit 1
    }

    timeout 20s systemctl daemon-reload || true
    timeout 15s systemctl enable wittypi5-webserver.service >/dev/null 2>&1 || true
    timeout 20s systemctl restart wittypi5-webserver.service || {
        echo "FEHLER: wittypi5-webserver.service konnte nicht gestartet werden."
        systemctl status wittypi5-webserver.service --no-pager --full || true
        exit 1
    }
    if [ "$INSTALL_WURB" = true ]; then
        timeout 25s systemctl restart wurb_2026.service || \
            echo "WARNUNG: WURB konnte nach dem Navigations-Patch nicht neu gestartet werden."
    fi
    if [ "$INSTALL_WIRC" = true ]; then
        timeout 25s systemctl restart wirc_2026.service || \
            echo "WARNUNG: WIRC konnte nach dem Navigations-Patch nicht neu gestartet werden."
    fi

    if ! systemctl is-active --quiet wittypi5-webserver.service; then
        echo "FEHLER: Der eigene Witty-Webserver ist nach dem Start nicht aktiv."
        journalctl -u wittypi5-webserver.service -n 60 --no-pager || true
        exit 1
    fi
    if command -v ss >/dev/null 2>&1 && \
       ! ss -lnt | awk '$4 ~ /:8081$/ {found=1} END {exit !found}'; then
        echo "FEHLER: Der Witty-Webserver läuft, aber Port 8081 ist nicht geöffnet."
        exit 1
    fi
    WITTY_HTTP_OK=false
    for attempt in 1 2 3 4 5; do
        if curl --fail --silent --show-error --max-time 5 \
                --output /dev/null http://127.0.0.1:8081/; then
            WITTY_HTTP_OK=true
            break
        fi
        sleep 1
    done
    if [ "$WITTY_HTTP_OK" != true ]; then
        echo "FEHLER: Port 8081 ist offen, liefert aber keine gültige HTTP-Antwort."
        exit 1
    fi
    if [ "$INSTALL_WURB" = true ] && \
       ! grep -q 'data-wittypi5-port="8081"' /home/wurb/wurb_2026/wurb_app/templates/index.html; then
        echo "FEHLER: Der Witty-Link wurde nicht in die WURB-Homepage eingefügt."
        exit 1
    fi
    if [ "$INSTALL_WIRC" = true ] && \
       ! grep -q 'data-wittypi5-port="8081"' /home/wurb/wirc_2026/wirc_app/templates/index.html; then
        echo "FEHLER: Der Witty-Link wurde nicht in die WIRC-Homepage eingefügt."
        exit 1
    fi

    echo "-> Witty-Webserver läuft unabhängig auf Port 8081."
    echo "-> Homepage: http://${CURRENT_HOSTNAME}:8081/"
    cleanup_witty_addon
    trap - EXIT
    return 0
fi

witty_addon_backup_and_install() {
    local SOURCE_FILE="$1"
    local TARGET_FILE="$2"
    local OWNER_REFERENCE TARGET_UID TARGET_GID RELATIVE_TARGET

    if [ ! -f "$SOURCE_FILE" ]; then
        echo "FEHLER: Add-on-Datei fehlt: $SOURCE_FILE"
        exit 1
    fi
    if [ -e "$TARGET_FILE" ]; then
        RELATIVE_TARGET="${TARGET_FILE#/}"
        mkdir -p "$WITTY_ADDON_BACKUP/$(dirname "$RELATIVE_TARGET")"
        cp -a -- "$TARGET_FILE" "$WITTY_ADDON_BACKUP/$RELATIVE_TARGET"
        OWNER_REFERENCE="$TARGET_FILE"
    else
        OWNER_REFERENCE="$(dirname "$TARGET_FILE")"
        if [ ! -d "$OWNER_REFERENCE" ]; then
            echo "FEHLER: Zielverzeichnis fehlt: $OWNER_REFERENCE"
            exit 1
        fi
    fi
    TARGET_UID="$(stat -c '%u' "$OWNER_REFERENCE")"
    TARGET_GID="$(stat -c '%g' "$OWNER_REFERENCE")"
    install -D -m 0644 -o "$TARGET_UID" -g "$TARGET_GID" \
        "$SOURCE_FILE" "$TARGET_FILE"
}

# The official Witty Pi 5 package normally creates no project directory under
# /home. Older add-on files searched there exclusively and hid the Witty button
# even when wp5 was installed.
witty_addon_fix_wp5_detection() {
    local API_FILE="$1"

    if grep -q '"witty": exists_below_home(' "$API_FILE"; then
        sed -i '/^[[:space:]]*"witty": exists_below_home(/,/^[[:space:]]*),[[:space:]]*$/c\
        "witty": any(path.is_file() for path in (\
            pathlib.Path("/usr/local/bin/wp5"),\
            pathlib.Path("/usr/bin/wp5"),\
            pathlib.Path("/usr/local/sbin/wp5"),\
        )) or exists_below_home(\
            "wittypi", "wittypi5", "witty-pi-5-software", "wp5"\
        ),' "$API_FILE"
    fi

    if ! grep -q 'pathlib.Path("/usr/local/bin/wp5")' "$API_FILE"; then
        echo "FEHLER: Die Witty-Erkennung konnte in $API_FILE nicht angepasst werden."
        exit 1
    fi
}

witty_addon_restart_service() {
    local SERVICE_NAME="$1"
    systemctl reset-failed "$SERVICE_NAME" 2>/dev/null || true
    if ! timeout 25s systemctl restart "$SERVICE_NAME"; then
        echo "WARNUNG: $SERVICE_NAME konnte nach dem Add-on nicht sofort neu gestartet werden."
        echo "          Diagnose: journalctl -u $SERVICE_NAME -b --no-pager -n 80"
        return 0
    fi
    sleep 2
    if ! systemctl is-active --quiet "$SERVICE_NAME"; then
        echo "WARNUNG: $SERVICE_NAME ist nach dem Neustart nicht aktiv."
        echo "          Diagnose: journalctl -u $SERVICE_NAME -b --no-pager -n 80"
    fi
}

if [ "$INSTALL_WURB" = true ]; then
    WURB_ADDON_HOME="/home/wurb/wurb_2026"
    if [ ! -d "$WURB_ADDON_HOME/wurb_api" ] || [ ! -d "$WURB_ADDON_HOME/wurb_app" ]; then
        echo "FEHLER: WURB wurde ausgewählt, aber die fertige Installation fehlt unter $WURB_ADDON_HOME."
        exit 1
    fi
    echo "-> Ersetze und ergänze die WURB-Homepage-Dateien..."
    witty_addon_backup_and_install "$WITTY_ADDON_SOURCE/wurb_2026/wurb_api/main.py" \
        "$WURB_ADDON_HOME/wurb_api/main.py"
    witty_addon_fix_wp5_detection "$WURB_ADDON_HOME/wurb_api/main.py"
    witty_addon_backup_and_install "$WITTY_ADDON_SOURCE/wurb_2026/wurb_app/templates/index.html" \
        "$WURB_ADDON_HOME/wurb_app/templates/index.html"
    witty_addon_backup_and_install "$WITTY_ADDON_SOURCE/wurb_2026/wurb_app/static/witty.html" \
        "$WURB_ADDON_HOME/wurb_app/static/witty.html"
    WITTY_ADDON_COMPONENTS=$((WITTY_ADDON_COMPONENTS + 1))
fi

if [ "$INSTALL_WIRC" = true ]; then
    WIRC_ADDON_HOME="/home/wurb/wirc_2026"
    if [ ! -d "$WIRC_ADDON_HOME/wirc_api" ] || [ ! -d "$WIRC_ADDON_HOME/wirc_app" ]; then
        echo "FEHLER: WIRC wurde ausgewählt, aber die fertige Installation fehlt unter $WIRC_ADDON_HOME."
        exit 1
    fi
    echo "-> Ersetze und ergänze die WIRC-Homepage-Dateien..."
    witty_addon_backup_and_install "$WITTY_ADDON_SOURCE/wirc_2026/wirc_api/api_main.py" \
        "$WIRC_ADDON_HOME/wirc_api/api_main.py"
    witty_addon_fix_wp5_detection "$WIRC_ADDON_HOME/wirc_api/api_main.py"
    witty_addon_backup_and_install "$WITTY_ADDON_SOURCE/wirc_2026/wirc_app/templates/index.html" \
        "$WIRC_ADDON_HOME/wirc_app/templates/index.html"
    witty_addon_backup_and_install "$WITTY_ADDON_SOURCE/wirc_2026/wirc_app/static/witty.html" \
        "$WIRC_ADDON_HOME/wirc_app/static/witty.html"
    WITTY_ADDON_COMPONENTS=$((WITTY_ADDON_COMPONENTS + 1))
fi

if [ "$INSTALL_ALLSKY" = true ]; then
    if [ ! -d "$ALLSKY_HOME/html" ] || [ ! -f "$ALLSKY_HOME/variables.sh" ]; then
        echo "FEHLER: Allsky wurde ausgewählt, aber die fertige Installation fehlt unter $ALLSKY_HOME."
        exit 1
    fi
    echo "-> Ersetze und ergänze die Allsky-Homepage-Dateien..."
    witty_addon_backup_and_install "$WITTY_ADDON_SOURCE/allsky/html/index.php" \
        "$ALLSKY_HOME/html/index.php"
    witty_addon_backup_and_install "$WITTY_ADDON_SOURCE/allsky/html/witty.html" \
        "$ALLSKY_HOME/html/witty.html"
    witty_addon_backup_and_install "$WITTY_ADDON_SOURCE/allsky/html/witty-services.php" \
        "$ALLSKY_HOME/html/witty-services.php"
    witty_addon_backup_and_install "$WITTY_ADDON_SOURCE/allsky/html/witty-api.php" \
        "$ALLSKY_HOME/html/witty-api.php"
    WITTY_ADDON_COMPONENTS=$((WITTY_ADDON_COMPONENTS + 1))
fi

if [ "$WITTY_ADDON_COMPONENTS" -gt 0 ]; then
    echo "-> Installiere den abgesicherten Witty-Hintergrundadapter..."
    install -D -m 0755 "$WITTY_ADDON_SOURCE/witty/witty_backend.sh" \
        /usr/local/lib/witty-addon/witty_backend.sh
    install -D -m 0440 "$WITTY_ADDON_SOURCE/witty/witty-addon-sudoers" \
        /etc/sudoers.d/witty-addon
    if command -v visudo >/dev/null 2>&1 && \
            ! visudo -cf /etc/sudoers.d/witty-addon >/dev/null; then
        echo "FEHLER: Die sudoers-Regel des Witty-Add-ons ist ungültig."
        exit 1
    fi

    [ "$INSTALL_WURB" = true ] && witty_addon_restart_service wurb_2026.service
    [ "$INSTALL_WIRC" = true ] && witty_addon_restart_service wirc_2026.service
    if [ "$INSTALL_ALLSKY" = true ]; then
        timeout 15s systemctl reload lighttpd.service 2>/dev/null || \
            timeout 20s systemctl restart lighttpd.service 2>/dev/null || \
            echo "WARNUNG: Der Allsky-Webserver konnte nicht neu geladen werden."
    fi
    echo "-> Witty-Add-on für $WITTY_ADDON_COMPONENTS Komponente(n) installiert."
    [ -d "$WITTY_ADDON_BACKUP" ] && \
        echo "-> Sicherung ersetzter Originaldateien: $WITTY_ADDON_BACKUP"
else
    echo "-> Keine WURB-, WIRC- oder Allsky-Installation ausgewählt; Add-on wird übersprungen."
fi

cleanup_witty_addon
trap - EXIT
)

if ! install_witty_homepage_addon_optional; then
    echo "WARNUNG: Das optionale Witty-Homepage-Add-on konnte nicht installiert werden."
    echo "          Die Hauptinstallation wird trotzdem fortgesetzt."
fi

# ==============================================================================
# PHASE 5: WI-FI HOTSPOT CONFIGURATION
# ==============================================================================
echo ""
echo "=== [PHASE 5] Konfiguriere Wi-Fi Hotspot via NetworkManager ==="

# Derive names again from the final software selection immediately before
# creation, preventing a stale value such as wifi4bats-* entering the Allsky path.
update_hotspot_names
if [ "$INSTALL_ALLSKY" = true ]; then
    CON_NAME="allsky-hotspot"
    HOTSPOT_NAME="allskywifi-${CURRENT_HOSTNAME}"
fi

echo "-> Erstelle Access Point mit Profilname '$CON_NAME' und SSID '$HOTSPOT_NAME'..."

if ! command -v nmcli >/dev/null 2>&1; then
    echo "FEHLER: NetworkManager/nmcli ist nicht installiert."
    exit 1
fi
if ! timeout 8s nmcli --wait 5 -t -f DEVICE,TYPE device status | grep -q '^wlan0:wifi$'; then
    echo "FEHLER: WLAN-Schnittstelle wlan0 wurde nicht gefunden."
    exit 1
fi
# Remove old access-point and hotspot profiles. Retain normal Wi-Fi client
# connections so internet access is not removed.
while IFS= read -r OLD_UUID; do
    [ -n "$OLD_UUID" ] || continue
    OLD_MODE="$(timeout 5s nmcli --wait 2 -g 802-11-wireless.mode connection show "$OLD_UUID" 2>/dev/null || true)"
    if [ "$OLD_MODE" = "ap" ]; then
        OLD_NAME="$(timeout 5s nmcli --wait 2 -g connection.id connection show "$OLD_UUID" 2>/dev/null || true)"
        echo "   -> Entferne altes Hotspot-Profil: ${OLD_NAME:-$OLD_UUID}"
        if ! timeout 5s nmcli --wait 0 connection delete uuid "$OLD_UUID" >/dev/null 2>&1; then
            echo "WARNUNG: Profil ${OLD_NAME:-$OLD_UUID} konnte nicht regulär gelöscht werden."
        fi
    fi
done < <(timeout 8s nmcli --wait 5 -t -f UUID,TYPE connection show | awk -F: '$2 == "802-11-wireless" {print $1}')

nmcli_hotspot() {
    if ! timeout 15s nmcli --wait 10 "$@"; then
        echo "FEHLER: NetworkManager-Befehl fehlgeschlagen oder hat zu lange benötigt: nmcli $*"
        exit 1
    fi
}

nmcli_hotspot radio wifi on
nmcli_hotspot con add con-name "$CON_NAME" ifname wlan0 type wifi ssid "$HOTSPOT_NAME"
nmcli_hotspot con modify "$CON_NAME" wifi-sec.key-mgmt wpa-psk
nmcli_hotspot con modify "$CON_NAME" wifi-sec.psk chiroptera
nmcli_hotspot con modify "$CON_NAME" wifi-sec.proto rsn
nmcli_hotspot con modify "$CON_NAME" wifi-sec.pairwise ccmp
nmcli_hotspot con modify "$CON_NAME" wifi-sec.group ccmp
nmcli_hotspot con modify "$CON_NAME" 802-11-wireless.mode ap 802-11-wireless.band bg ipv4.method shared
nmcli_hotspot con modify "$CON_NAME" connection.autoconnect yes connection.autoconnect-priority 100 connection.autoconnect-retries 0 ipv6.method disabled

CONFIGURED_SSID="$(timeout 5s nmcli --wait 2 -g 802-11-wireless.ssid connection show "$CON_NAME" 2>/dev/null || true)"
if [ "$CONFIGURED_SSID" != "$HOTSPOT_NAME" ]; then
    echo "FEHLER: Hotspot-SSID wurde nicht korrekt gespeichert."
    echo "Erwartet: $HOTSPOT_NAME"
    echo "Gefunden: $CONFIGURED_SSID"
    exit 1
fi

# Autoconnect is unreliable when NetworkManager selects a known client profile
# first at boot. This service explicitly requests the new access point and
# retries while wlan0 is not yet ready.
cat > /etc/systemd/system/wurb-hotspot-start.service << EOF
[Unit]
Description=WURB/Allsky - WLAN-Hotspot beim Boot aktivieren
Wants=NetworkManager.service
After=NetworkManager.service
Before=allsky.service allskyperiodic.service

[Service]
Type=oneshot
ExecStart=/bin/bash -c 'for attempt in 1 2 3 4 5; do /usr/bin/nmcli --wait 15 connection up "$CON_NAME" && exit 0; sleep 3; done; exit 1'
TimeoutStartSec=100
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

mkdir -p /etc/systemd/system/multi-user.target.wants
ln -sfn ../wurb-hotspot-start.service \
    /etc/systemd/system/multi-user.target.wants/wurb-hotspot-start.service

if [ "$INSTALL_ALLSKY" = true ]; then
    mkdir -p /etc/systemd/system/allsky.service.d /etc/systemd/system/allskyperiodic.service.d
    cat > /etc/systemd/system/allsky.service.d/hotspot.conf << 'EOF'
[Unit]
Wants=wurb-hotspot-start.service
After=wurb-hotspot-start.service
EOF
    cp /etc/systemd/system/allsky.service.d/hotspot.conf \
        /etc/systemd/system/allskyperiodic.service.d/hotspot.conf
fi

echo "-> Hotspot '$CONFIGURED_SSID' erfolgreich registriert und für den Boot-Start aktiviert."

# ==============================================================================
# SET-UP COMPLETE AND DIAGNOSTICS
# ==============================================================================
echo ""
echo "===================================================================="
echo " CONFIGURATION BEENDET – PRÜFE DIENST-STATUS..."
echo "===================================================================="
sleep 3

if [ "$INSTALL_WURB" = true ] && systemctl is-active --quiet wurb_2026.service; then
    echo " STATUS: GLÜCKWUNSCH! Der WURB-Webserver läuft jetzt erfolgreich!"
	
    echo " Du erreichst das WURB - Interface unter $CURRENT_HOSTNAME:8080"
if [ "$INSTALL_WIRC" = true ]; then
	echo " Du erreichst das WIRC - Interface unter $CURRENT_HOSTNAME:8082"
	else echo ""
fi
elif [ "$INSTALL_WURB" = true ]; then
    echo " ACHTUNG: WURB ist installiert, aber Port 8080 ist noch nicht aktiv."
    echo " Diagnose: journalctl -u wurb_2026.service -n 50 --no-pager"
fi

if [ "$INSTALL_WIRC" = true ] && ! systemctl is-active --quiet wirc_2026.service; then
    echo "ACHTUNG: WIRC läuft nicht. Diagnose:"
    journalctl -u wirc_2026.service -n 15 --no-pager || true
fi

echo ""
echo "===================================================================="
echo " -> Hostname des Pi:     $CURRENT_HOSTNAME"
echo " -> Einsatzland:         $TARGET_COUNTRY (Tastaturlayout: $TARGET_KEYBOARD)"
echo " -> WLAN-Hotspot aktiv:  $HOTSPOT_NAME (Passwort: chiroptera)"
echo "--------------------------------------------------------------------"
if [ "$INSTALL_ALLSKY" = true ]; then
    echo "Als letzter Schritt folgt jetzt der offizielle Allsky-Installer."
    echo "Allsky darf den Raspberry Pi danach automatisch neu starten."
else
    echo "Der Raspberry Pi wird nach der erfolgreichen Abschlussprüfung automatisch neu gestartet."
fi
echo "Dienste abschalten: sudo wurb-service off / sudo wirc-service off"
echo "===================================================================="

# ==============================================================================
# FINAL PHASE: ALLSKY
# The official Allsky installer may reboot the Raspberry Pi itself, so no
# required installation work may follow its invocation.
# ==============================================================================
if [ "$INSTALL_ALLSKY" = true ]; then
    echo ""
    echo "===================================================================="
    echo "=== [LETZTE PHASE] Installiere Allsky Software                    ==="
    echo "===================================================================="
    echo "Alle übrigen Installationsphasen sind bereits abgeschlossen."
    echo "Ein automatischer Neustart durch Allsky ist ab jetzt unkritisch."

    echo "-> Installiere benötigte Basispakete für Allsky..."
    apt-get update
    apt-get install -y \
        git curl wget ca-certificates build-essential make gcc g++ pkg-config \
        cmake gawk dialog jq bc rsync unzip zip usbutils v4l-utils \
        python3 python3-pip python3-venv python3-dev network-manager
    apt-get install -y jc 2>/dev/null || true

    echo "-> Lade beziehungsweise aktualisiere Allsky..."
    if [ -d "$ALLSKY_HOME/.git" ]; then
        if ! sudo -u wurb git -C "$ALLSKY_HOME" pull --ff-only; then
            echo "WARNUNG: Das vorhandene Allsky-Repository konnte nicht aktualisiert werden."
            echo "          Die vorhandene Version wird für die Installation verwendet."
        fi
    else
        if [ -e "$ALLSKY_HOME" ]; then
            echo "FEHLER: $ALLSKY_HOME existiert, ist aber kein Git-Repository."
            echo "Bitte den Ordner prüfen oder manuell sichern/entfernen und erneut starten."
            exit 1
        fi
        if ! sudo -u wurb git clone --depth 1 "$ALLSKY_GIT_URL" "$ALLSKY_HOME"; then
            echo "FEHLER: Das Allsky-Repository konnte nicht geladen werden."
            exit 1
        fi
    fi
    chown -R wurb:wurb "$ALLSKY_HOME"

    # Erst nach dem Download prüfen: So werden sowohl die aktuelle
    # Trixie-/PHP-Laufzeit als auch der tatsächlich geladene Allsky-PHP-Code
    # noch vor dem offiziellen Allsky-Installer validiert.
    if grep -Eq '^VERSION_CODENAME=trixie$' /etc/os-release 2>/dev/null; then
        echo "-> Prüfe die Allsky-Kompatibilität mit Debian Trixie und PHP..."
        if [ -x /usr/local/sbin/witty-allsky-trixie-compat ]; then
            timeout --foreground --kill-after=30s 1200s \
                /usr/local/sbin/witty-allsky-trixie-compat prepare || {
                echo "FEHLER: Die dynamische Trixie-/PHP-Vorbereitung ist fehlgeschlagen oder hat das Zeitlimit überschritten."
                exit 1
            }
        else
            echo "FEHLER: Die benötigte Allsky-/Trixie-Kompatibilitätsschicht fehlt."
            exit 1
        fi
    fi

    # This preparation must precede install.sh because Allsky may reboot
    # immediately at the end of its own installation.
    echo "-> Konfiguriere automatisches Mounten von USB-Sticks..."
    USB_PMOUNT_TEMP="$(mktemp -d /var/tmp/allsky-usb-pmount.XXXXXX)"
    if ! git clone --depth 1 "$WURB_GIT_URL" "$USB_PMOUNT_TEMP/repository"; then
        echo "FEHLER: Die USB-Mount-Dateien konnten nicht geladen werden."
        rm -rf -- "$USB_PMOUNT_TEMP"
        exit 1
    fi
    USB_PMOUNT_SOURCE="$USB_PMOUNT_TEMP/repository/raspberrypi_files"
    if [ ! -f "$USB_PMOUNT_SOURCE/usb_pmount.rules" ] || \
       [ ! -f "$USB_PMOUNT_SOURCE/usb_pmount_handler@.service" ] || \
       [ ! -f "$USB_PMOUNT_SOURCE/usb_pmount_script" ]; then
        echo "FEHLER: Benötigte USB-Mount-Dateien wurden nicht gefunden."
        rm -rf -- "$USB_PMOUNT_TEMP"
        exit 1
    fi
    install -m 0644 "$USB_PMOUNT_SOURCE/usb_pmount.rules" \
        /etc/udev/rules.d/usb_pmount.rules
    install -m 0644 "$USB_PMOUNT_SOURCE/usb_pmount_handler@.service" \
        /lib/systemd/system/usb_pmount_handler@.service
    install -m 0755 "$USB_PMOUNT_SOURCE/usb_pmount_script" \
        /usr/local/bin/usb_pmount_script
    rm -rf -- "$USB_PMOUNT_TEMP"
    timeout 20s systemctl daemon-reload || true
    timeout 10s udevadm control --reload-rules || \
        echo "WARNUNG: Die USB-Regeln werden beim nächsten Neustart eingelesen."

    echo ""
    echo "-> Starte jetzt als allerletzten Schritt den offiziellen Allsky-Installer."
    echo "-> Eine unterstützte Kamera muss für die Erstinstallation angeschlossen sein."
    echo "-> Ein von Allsky ausgelöster automatischer Neustart ist jetzt beabsichtigt."
    echo ""

    if ! sudo -u wurb -H bash -lc 'cd /home/wurb/allsky && ./install.sh'; then
        echo ""
        echo "FEHLER: Der offizielle Allsky-Installer wurde nicht erfolgreich beendet."
        echo "Bei der Erstinstallation muss eine unterstützte Kamera erkannt werden."
        exit 1
    fi

    # This section is reached only when Allsky does not trigger a reboot.
    if [ -x /usr/local/sbin/witty-allsky-trixie-compat ]; then
        timeout 180s /usr/local/sbin/witty-allsky-trixie-compat repair || {
            echo "FEHLER: Die Allsky-Nachprüfung für Trixie ist fehlgeschlagen."
            exit 1
        }
    fi
    timeout 20s systemctl daemon-reload || true
    if systemctl list-unit-files --no-legend 2>/dev/null \
        | awk '{print $1}' | grep -qx 'allsky.service'; then
        echo "=== Allsky wurde erfolgreich installiert. ==="
    else
        echo "FEHLER: Allsky install.sh endete, aber allsky.service wurde nicht angelegt."
        exit 1
    fi
fi

echo ""
echo "===================================================================="
echo " Installation vollständig erfolgreich – Raspberry Pi startet neu."
echo "===================================================================="
sync
systemctl reboot
