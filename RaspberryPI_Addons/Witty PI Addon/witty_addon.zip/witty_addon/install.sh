#!/usr/bin/env bash
set -Eeuo pipefail

log() { printf '[wittypi5-webserver] %s\n' "$*"; }
die() { printf '[wittypi5-webserver] FEHLER: %s\n' "$*" >&2; exit 1; }
[[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Bitte mit sudo starten: sudo bash $0"

source_dir="$(cd "$(dirname "$0")" && pwd)"
for command_name in python3 install systemctl find stat timeout curl flock cmp runuser getent apt-get seq tail; do
    command -v "$command_name" >/dev/null 2>&1 || die "Das Programm '$command_name' fehlt."
done

if [[ -d /home/wurb ]]; then
    app_dir="/home/wurb/wittypi5-webserver"
elif [[ -n "${SUDO_USER:-}" && "${SUDO_USER}" != root ]]; then
    user_home="$(getent passwd "$SUDO_USER" | cut -d: -f6)"
    app_dir="$user_home/wittypi5-webserver"
else
    app_dir="/home/wittypi5-webserver"
fi

backup_dir="/var/backups/wittypi5-webserver/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$backup_dir" "$app_dir/web/assets" "$app_dir/backend" "$app_dir/logs"
mkdir -p "$app_dir/manager" "$app_dir/launchers" "$app_dir/automation"
[[ -d "$app_dir" ]] && cp -a "$app_dir/." "$backup_dir/webserver" 2>/dev/null || true

# Use an isolated Python environment for the offline GPS-coordinate-to-time-zone
# database. Existing installations are reused, so later updates stay quick.
web_python=/usr/bin/python3
web_venv="/var/lib/witty-addon/web-venv"
if [[ ! -x "$web_venv/bin/python3" ]] || \
        ! "$web_venv/bin/python3" -c 'import timezonefinder' >/dev/null 2>&1; then
    if ! python3 -m venv "$web_venv" >/dev/null 2>&1; then
        log "python3-venv is missing; installing it for GPS time-zone detection ..."
        timeout 180s apt-get update || die "The package lists could not be updated."
        timeout 180s apt-get install -y python3-venv || die "python3-venv could not be installed."
        python3 -m venv "$web_venv" || die "The web-server Python environment could not be created."
    fi
    log "Installing the offline GPS time-zone database ..."
    timeout 420s "$web_venv/bin/python3" -m pip install --disable-pip-version-check --no-cache-dir \
        'timezonefinder==9.0.0' || die "The offline GPS time-zone database could not be installed."
fi
"$web_venv/bin/python3" -c 'from timezonefinder import TimezoneFinder; TimezoneFinder()' \
    >/dev/null 2>&1 || die "The offline GPS time-zone database is not usable."
web_python="$web_venv/bin/python3"

# Remove the obsolete backend location used by early add-on releases. Keeping
# it allowed an old API implementation to survive beside the current website.
rm -f -- /usr/local/lib/witty-addon/witty_backend.sh

install -m 0755 "$source_dir/web/server.py" "$app_dir/web/server.py"
install -m 0644 "$source_dir/web/index.html" "$app_dir/web/index.html"
install -m 0644 "$source_dir/web/recordings.html" "$app_dir/web/recordings.html"
install -m 0644 "$source_dir/web/manual.html" "$app_dir/web/manual.html"
install -m 0644 "$source_dir/web/allsky_setup.html" "$app_dir/web/allsky_setup.html"
install -m 0644 "$source_dir/web/assets/bulma-v1.0.4.min.css" "$app_dir/web/assets/bulma-v1.0.4.min.css"
install -m 0644 "$source_dir/web/assets/cloudedbats_logo.png" "$app_dir/web/assets/cloudedbats_logo.png"
install -m 0644 "$source_dir/web/assets/xterm.js" "$app_dir/web/assets/xterm.js"
install -m 0644 "$source_dir/web/assets/xterm.css" "$app_dir/web/assets/xterm.css"
install -m 0644 "$source_dir/web/assets/xterm-LICENSE.txt" "$app_dir/web/assets/xterm-LICENSE.txt"
install -m 0755 "$source_dir/backend/witty_backend.sh" "$app_dir/backend/witty5_backend.sh"
install -m 0755 "$source_dir/backend/witty4_backend.sh" "$app_dir/backend/witty4_backend.sh"
install -m 0755 "$source_dir/backend/witty_backend_dispatch.sh" "$app_dir/backend/witty_backend.sh"
install -m 0755 "$source_dir/manager/software_manager.sh" "$app_dir/manager/software_manager.sh"
install -m 0755 "$source_dir/manager/wurb-service" "$app_dir/manager/wurb-service"
install -m 0755 "$source_dir/manager/wirc-service" "$app_dir/manager/wirc-service"
install -m 0644 "$source_dir/manager/wirc_2026.service" "$app_dir/manager/wirc_2026.service"
install -m 0644 "$source_dir/VERSION" "$app_dir/VERSION"
for launcher in update.sh installer.sh; do
    install -m 0755 "$source_dir/launchers/$launcher" "$app_dir/launchers/$launcher"
done

# Direkte Witty-Installationen ohne äußeren Launcher halten ebenfalls die
# update.sh des aufrufenden SSH-Benutzers aktuell.
launcher_user="${SUDO_USER:-}"
if [[ -z "$launcher_user" || "$launcher_user" == root ]]; then
    launcher_user="$(stat -c '%U' "$source_dir" 2>/dev/null || true)"
fi
if [[ -n "$launcher_user" && "$launcher_user" != root ]] && id "$launcher_user" >/dev/null 2>&1; then
    launcher_home="$(getent passwd "$launcher_user" | cut -d: -f6)"
    launcher_group="$(id -gn "$launcher_user")"
    if [[ -n "$launcher_home" && -d "$launcher_home" ]]; then
        install -o "$launcher_user" -g "$launcher_group" -m 0755 \
            "$source_dir/launchers/update.sh" "$launcher_home/update.sh"
        log "Update-Starter aktualisiert: $launcher_home/update.sh"
    fi
fi
for obsolete_launcher in installer_papa.sh update_papa.sh; do
    rm -f -- "$app_dir/launchers/$obsolete_launcher"
done
install -m 0644 "$source_dir/automation/installer.conf.example" "$app_dir/automation/installer.conf.example"
install -m 0644 "$source_dir/automation/WINDOWS_CONTROL_PROTOCOL.txt" "$app_dir/automation/WINDOWS_CONTROL_PROTOCOL.txt"
install -m 0755 "$source_dir/automation/windows_control.sh" "$app_dir/automation/windows_control.sh"
install -o root -g root -m 0755 "$source_dir/automation/windows_control.sh" /usr/local/sbin/witty-windows-control
if [[ -e /usr/local/sbin/wurb-service ]] || \
   systemctl show --property=LoadState --value wurb_2026.service 2>/dev/null | grep -Fxq loaded; then
    install -o root -g root -m 0755 "$source_dir/manager/wurb-service" /usr/local/sbin/wurb-service
fi
if [[ -e /usr/local/sbin/wirc-service ]] || \
   systemctl show --property=LoadState --value wirc_2026.service 2>/dev/null | grep -Fxq loaded; then
    install -o root -g root -m 0755 "$source_dir/manager/wirc-service" /usr/local/sbin/wirc-service
fi
cmp -s "$source_dir/backend/witty_backend.sh" "$app_dir/backend/witty5_backend.sh" || \
    die "Das Witty-Pi-5-Backend wurde nicht vollständig ersetzt."
if grep -Fq 'Die interne Pi-5-RTC kann nicht sicher zur Laufzeit deaktiviert werden' \
        "$app_dir/backend/witty5_backend.sh"; then
    die "Im installierten Backend wurde noch die veraltete RTC-Sperre gefunden."
fi
if [[ -f "$source_dir/backend/wurb-wp5-time" ]] && command -v wp5 >/dev/null 2>&1; then
    install -o root -g root -m 0755 "$source_dir/backend/wurb-wp5-time" /usr/local/sbin/wurb-wp5-time
fi
install -o root -g root -m 0755 "$source_dir/backend/witty-gps-manager" /usr/local/sbin/witty-gps-manager
install -o root -g root -m 0755 "$source_dir/backend/witty-time-sync" /usr/local/sbin/witty-time-sync

if id wurb >/dev/null 2>&1 && getent group i2c >/dev/null 2>&1; then
    usermod -aG i2c wurb
    printf '%s\n' 'f /run/lock/wittypi5_app.lock 0660 root i2c -' \
        > /etc/tmpfiles.d/wittypi5-app-lock.conf
    systemd-tmpfiles --create /etc/tmpfiles.d/wittypi5-app-lock.conf
    chown root:i2c /var/lock/wittypi5_app.lock
    chmod 0660 /var/lock/wittypi5_app.lock
    log "wp5-Sperrdatei ist für die i2c-Gruppe freigegeben."
fi

# Der Hauptinstaller übergibt die gewählte Platine. Bei Einzel-Updates bleibt
# eine vorhandene Auswahl erhalten; andernfalls entscheidet der Dispatcher
# ausschließlich anhand tatsächlich ansprechbarer Hardware.
if [[ "${WITTY_MODEL:-}" =~ ^[45]$ ]]; then
    configured_timezone="${TIMEZONE:-$(sed -nE 's/^TIMEZONE=([^[:space:]]+)$/\1/p' /etc/witty-addon.conf 2>/dev/null | head -n 1)}"
    [[ -n "$configured_timezone" ]] || configured_timezone="$(timedatectl show --property=Timezone --value 2>/dev/null || printf 'Etc/UTC')"
    [[ "$configured_timezone" != Witty/FixedOffset ]] || \
        configured_timezone="$(tr -d '\r\n' </var/lib/witty-addon/previous_timezone 2>/dev/null || printf 'Etc/UTC')"
    [[ -n "$configured_timezone" ]] || configured_timezone=Etc/UTC
    printf 'RPI_MODEL=%s\nWITTY_MODEL=%s\nGPS_MODE=%s\nTIMEZONE=%s\n' \
        "${RPI_MODEL:-}" "$WITTY_MODEL" "${GPS_MODE:-unknown}" "$configured_timezone" > /etc/witty-addon.conf
    chmod 0644 /etc/witty-addon.conf
fi
install -D -m 0755 "$source_dir/installer/finalize_allsky.sh" /usr/local/lib/wittypi5-webserver/finalize_allsky.sh
install -D -m 0755 "$source_dir/installer/patch_navigation.py" /usr/local/lib/wittypi5-webserver/patch_navigation.py
install -m 0644 "$source_dir/installer/wittypi5-allsky-firstboot.service" /etc/systemd/system/wittypi5-allsky-firstboot.service
install -m 0755 "$source_dir/installer/allsky_trixie_compat.sh" /usr/local/sbin/witty-allsky-trixie-compat
systemctl disable --now witty-allsky-compat.service >/dev/null 2>&1 || true
rm -f -- /etc/systemd/system/witty-allsky-compat.service \
    /etc/apt/apt.conf.d/99-witty-allsky-compat
install -m 0755 "$source_dir/installer/cloudedbats_trixie_compat.sh" /usr/local/sbin/witty-cloudedbats-trixie-compat

patch_file() {
    local kind="$1" file="$2"
    [[ -f "$file" ]] || return 0
    mkdir -p "$backup_dir/$(dirname "${file#/}")"
    cp -a "$file" "$backup_dir/${file#/}"
    python3 "$source_dir/installer/patch_navigation.py" --kind "$kind" --file "$file"
    log "Navigation ergaenzt: $file"
}

find_project() {
    local name="$1" candidate
    if [[ "$name" == allsky ]]; then
        # A cloned or aborted source tree is not an installed Allsky system.
        # Require the service unit as well before patching pages or invoking
        # the Trixie web-server compatibility layer.
        systemctl show --property=LoadState --value allsky.service 2>/dev/null | \
            grep -Fxq loaded || return 1
        for candidate in /home/allsky /home/*/allsky /opt/allsky; do
            [[ -f "$candidate/allsky.sh" && -d "$candidate/html" ]] && { printf '%s\n' "$candidate"; return; }
        done
        return 1
    fi
    for candidate in "/home/wurb/$name" "/home/pi/$name" "/opt/$name"; do
        [[ -d "$candidate" ]] && { printf '%s\n' "$candidate"; return; }
    done
    find /home -mindepth 2 -maxdepth 3 -type d -name "$name" -print -quit 2>/dev/null
}

wurb_home="$(find_project wurb_2026 || true)"
wirc_home="$(find_project wirc_2026 || true)"

check_wurb_python() {
    [[ -n "$wurb_home" && -x "$wurb_home/venv/bin/python3" ]] || return 1
    "$wurb_home/venv/bin/python3" -X faulthandler -c \
        'import importlib.metadata as m; import fastapi, uvicorn, websockets, numpy, scipy, sounddevice, serial, astral, yaml; assert m.version("uvicorn") == "0.34.3"; assert m.version("websockets") == "15.0.1"; assert hasattr(uvicorn, "Config"); assert hasattr(uvicorn, "Server"); from uvicorn.protocols.websockets.websockets_impl import WebSocketProtocol' \
        >/dev/null 2>&1
}

repair_wurb_runtime() {
    local wurb_owner wurb_owner_home
    [[ -n "$wurb_home" ]] || return 0
    if ! check_wurb_python; then
        log "Repairing the existing WURB Python and audio environment ..."
        timeout 180s apt-get update || die "The package lists for WURB could not be updated."
        timeout 300s apt-get install -y python3-venv python3-pip python3-dev alsa-utils ffmpeg \
            libasound2-dev libopenblas-dev python3-pyaudio portaudio19-dev usbutils pmount || \
            die "The WURB audio packages could not be installed."
        wurb_owner="$(stat -c '%U' "$wurb_home")"
        wurb_owner_home="$(getent passwd "$wurb_owner" | cut -d: -f6)"
        runuser -u "$wurb_owner" -- env HOME="$wurb_owner_home" WURB_HOME="$wurb_home" bash -c '
            set -e
            cd "$WURB_HOME"
            python3 -m venv --upgrade venv
            . venv/bin/activate
            python -m pip install --upgrade pip
            python -m pip install --no-cache-dir -r requirements.txt
            python -m pip install --quiet --disable-pip-version-check --force-reinstall uvicorn==0.34.3 websockets==15.0.1
        ' || die "The WURB Python environment could not be repaired."
        check_wurb_python || die "WURB still cannot import its Python/audio libraries after repair."
    fi
    if ! systemctl cat wurb_2026.service >/dev/null 2>&1; then
        [[ -f "$wurb_home/raspberrypi_files/wurb_2026.service" ]] || \
            die "The WURB systemd service file is missing."
        install -m 0644 "$wurb_home/raspberrypi_files/wurb_2026.service" \
            /etc/systemd/system/wurb_2026.service
        systemctl enable wurb_2026.service || die "The WURB service could not be enabled."
    fi
    install -d -m 0755 /etc/systemd/system/wurb_2026.service.d
    cat > /etc/systemd/system/wurb_2026.service.d/witty-stability.conf <<'EOF'
[Unit]
StartLimitIntervalSec=180
StartLimitBurst=12

[Service]
Restart=always
RestartSec=10
EOF
}

wait_for_stable_wurb() {
    local attempt consecutive=0 inactive_seconds=0 port_wait_seconds=0 port_seen=0 state=""
    [[ -n "$wurb_home" ]] || return 0
    for attempt in $(seq 1 75); do
        state="$(systemctl is-active wurb_2026.service 2>/dev/null || true)"
        if [[ "$state" == active ]] && \
                timeout 1s bash -c '</dev/tcp/127.0.0.1/8080' >/dev/null 2>&1; then
            consecutive=$((consecutive + 1))
            inactive_seconds=0
            port_wait_seconds=0
            port_seen=1
            (( consecutive >= 20 )) && return 0
        else
            consecutive=0
            if [[ "$state" != active ]]; then
                inactive_seconds=$((inactive_seconds + 1))
                (( inactive_seconds < 5 )) || break
            else
                inactive_seconds=0
                if (( port_seen == 0 )); then
                    port_wait_seconds=$((port_wait_seconds + 1))
                    (( port_wait_seconds < 20 )) || break
                fi
            fi
        fi
        sleep 1
    done
    systemctl status wurb_2026.service --no-pager --full || true
    journalctl -u wurb_2026.service -n 80 --no-pager || true
    return 1
}

check_wirc_python() {
    [[ -n "$wirc_home" && -x "$wirc_home/venv/bin/python3" ]] || return 1
    "$wirc_home/venv/bin/python3" -c \
        'import importlib.metadata as m; import cv2, picamera2, libcamera, fastapi, fastapi.templating, uvicorn, websockets, jinja2, PIL, yaml; from python_multipart.multipart import parse_options_header; assert m.version("fastapi") == "0.115.12"; assert m.version("starlette") == "0.46.2"; assert m.version("uvicorn") == "0.34.3"; assert m.version("websockets") == "15.0.1"; assert m.version("python-multipart") == "0.0.20"; assert hasattr(fastapi.templating, "Jinja2Templates"); assert hasattr(uvicorn, "Config"); assert hasattr(uvicorn, "Server"); from uvicorn.protocols.websockets.websockets_impl import WebSocketProtocol' \
        >/dev/null 2>&1
}

repair_wirc_runtime() {
    local wirc_owner wirc_owner_home
    [[ -n "$wirc_home" ]] || return 0
    if ! check_wirc_python; then
        log "Repairing the existing WIRC Python and camera environment ..."
        timeout 180s apt-get update || die "The package lists for WIRC could not be updated."
        timeout 300s apt-get install -y python3-venv python3-pip python3-dev \
            python3-picamera2 python3-opencv ffmpeg usbutils pmount || \
            die "The WIRC camera packages could not be installed."
        wirc_owner="$(stat -c '%U' "$wirc_home")"
        wirc_owner_home="$(getent passwd "$wirc_owner" | cut -d: -f6)"
        runuser -u "$wirc_owner" -- env HOME="$wirc_owner_home" WIRC_HOME="$wirc_home" bash -c '
            set -e
            cd "$WIRC_HOME"
            python3 -m venv --upgrade --system-site-packages venv
            . venv/bin/activate
            python -m pip install --upgrade pip
            python -m pip install --no-cache-dir -r requirements.txt
            python -m pip install --quiet --disable-pip-version-check --force-reinstall fastapi==0.115.12 starlette==0.46.2 uvicorn==0.34.3 websockets==15.0.1 python-multipart==0.0.20
        ' || die "The WIRC Python environment could not be repaired."
        check_wirc_python || die "WIRC still cannot import its Python/camera libraries after repair."
    fi
    if ! systemctl cat wirc_2026.service >/dev/null 2>&1; then
        [[ -f "$wirc_home/raspberrypi_files/wirc_2026.service" ]] || \
            die "The WIRC systemd service file is missing."
        install -m 0644 "$wirc_home/raspberrypi_files/wirc_2026.service" \
            /etc/systemd/system/wirc_2026.service
        systemctl enable wirc_2026.service || die "The WIRC service could not be enabled."
    fi
    install -d -m 0755 /etc/systemd/system/wirc_2026.service.d
    cat > /etc/systemd/system/wirc_2026.service.d/witty-stability.conf <<'EOF'
[Unit]
StartLimitIntervalSec=180
StartLimitBurst=12

[Service]
Restart=always
RestartSec=10
EOF
}

wait_for_stable_wirc() {
    local attempt consecutive=0 inactive_seconds=0 port_wait_seconds=0 port_seen=0 state=""
    [[ -n "$wirc_home" ]] || return 0
    for attempt in $(seq 1 90); do
        state="$(systemctl is-active wirc_2026.service 2>/dev/null || true)"
        if [[ "$state" == active ]] && \
                timeout 1s bash -c '</dev/tcp/127.0.0.1/8082' >/dev/null 2>&1; then
            consecutive=$((consecutive + 1))
            inactive_seconds=0
            port_wait_seconds=0
            port_seen=1
            (( consecutive >= 35 )) && return 0
        else
            consecutive=0
            if [[ "$state" != active ]]; then
                inactive_seconds=$((inactive_seconds + 1))
                (( inactive_seconds < 5 )) || break
            else
                inactive_seconds=0
                if (( port_seen == 0 )); then
                    port_wait_seconds=$((port_wait_seconds + 1))
                    (( port_wait_seconds < 20 )) || break
                fi
            fi
        fi
        sleep 1
    done
    systemctl status wirc_2026.service --no-pager --full || true
    journalctl -u wirc_2026.service -n 80 --no-pager || true
    for log_file in /home/wurb/wirc_logging/wirc_info_log.txt /home/wurb/wirc_logging/wirc_debug_log.txt; do
        [[ ! -f "$log_file" ]] || { printf '%s\n' "--- $log_file ---"; tail -n 80 "$log_file" || true; }
    done
    return 1
}

repair_wurb_runtime
repair_wirc_runtime

# Keep the physical GPS port owned by gpsd. WURB receives the replicated
# NMEA stream through /dev/ttyUSB9, while this add-on remains another gpsd
# client. Apply the same correction during updates of existing installations.
configured_gps_mode="${GPS_MODE:-unknown}"
if [[ -r /etc/witty-addon.conf ]]; then
    # shellcheck disable=SC1091
    source /etc/witty-addon.conf
    configured_gps_mode="${GPS_MODE:-$configured_gps_mode}"
fi
# Older add-on releases did not always persist the GPS selection.  Only fill
# an unknown value automatically; an explicit "none" selection stays intact.
if [[ "$configured_gps_mode" == "unknown" ]]; then
    if [[ -r /etc/default/gpsd ]] && \
       grep -Eq '^[[:space:]]*DEVICES="/dev/(ttyAMA0|serial0)"' /etc/default/gpsd; then
        configured_gps_mode="waveshare_l76x"
    else
        for gps_candidate in /dev/ttyACM* /dev/ttyUSB*; do
            [[ -e "$gps_candidate" && "$gps_candidate" != "/dev/ttyUSB9" ]] || continue
            configured_gps_mode="usb"
            break
        done
    fi
fi
# Die Add-on-Installation richtet absichtlich keinen automatischen RTC-/GPS-
# Zeitdienst ein. Zeitaktionen bleiben manuelle Funktionen der Homepage. Das
# verhindert Blockaden und unbeabsichtigte Eingriffe in den Bootvorgang.
log "Keine automatischen RTC-/GPS-Bootdienste eingerichtet."
timedatectl set-ntp false >/dev/null 2>&1 || true
timeout 15s systemctl disable --now systemd-timesyncd.service >/dev/null 2>&1 || true
[[ "$(timedatectl show --property=NTP --value 2>/dev/null || true)" != yes ]] || \
    die "Die automatische Netzwerk-Zeitsynchronisation konnte nicht deaktiviert werden."
log "Automatische Netzwerk-Zeitsynchronisation ist dauerhaft deaktiviert."
if [[ "$configured_gps_mode" =~ ^(usb|waveshare_l76x)$ ]]; then
    for bridge_command in socat gpspipe; do
        command -v "$bridge_command" >/dev/null 2>&1 || die "Das Programm '$bridge_command' für die GPS-Bridge fehlt."
    done
    cat > /etc/systemd/system/wurb-gps-bridge.service << 'EOF'
[Unit]
Description=WURB GPS Virtual Serial Port Bridge
After=gpsd.service
Requires=gpsd.service

[Service]
Type=simple
ExecStart=/usr/bin/socat PTY,link=/dev/ttyWURB,raw,echo=0,group=dialout,mode=660 EXEC:"/usr/bin/gpspipe -r"
ExecStartPost=/usr/bin/ln -sf /dev/ttyWURB /dev/ttyUSB9
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
    mkdir -p /etc/systemd/system/multi-user.target.wants
    ln -sfn ../wurb-gps-bridge.service /etc/systemd/system/multi-user.target.wants/wurb-gps-bridge.service
fi
if [[ "$configured_gps_mode" =~ ^(usb|waveshare_l76x)$ && -n "$wurb_home" ]]; then
    wurb_owner="$(stat -c '%U' "$wurb_home")"
    wurb_group="$(stat -c '%G' "$wurb_home")"
    wurb_parent="$(dirname "$wurb_home")"
    wurb_local_config="$wurb_parent/wurb_settings/wurb_config.yaml"
    if [[ ! -f "$wurb_local_config" && -f "$wurb_home/wurb_config_default.yaml" ]]; then
        install -d -o "$wurb_owner" -g "$wurb_group" -m 0755 "$(dirname "$wurb_local_config")"
        install -o "$wurb_owner" -g "$wurb_group" -m 0644 "$wurb_home/wurb_config_default.yaml" "$wurb_local_config"
    fi
    if [[ -f "$wurb_local_config" ]]; then
        python3 - "$wurb_local_config" << 'PY'
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
lines = path.read_text().splitlines()
result = []
inside = False
found = False
for line in lines:
    if line.strip() == "gps_device_whitelist:":
        result.extend((line, "    - /dev/ttyUSB9 # Installer-owned shared gpsd bridge."))
        inside = True
        found = True
        continue
    if inside and (not line.strip() or line.startswith("    - ") or line.startswith("    #")):
        continue
    inside = False
    result.append(line)
if not found:
    raise SystemExit("gps_device_whitelist was not found in the WURB configuration")
path.write_text("\n".join(result) + "\n")
PY
        chown "$wurb_owner:$wurb_group" "$wurb_local_config"
    fi
    wurb_settings_db="$wurb_parent/wurb_settings/wurb_settings.db"
    if [[ -f "$wurb_settings_db" ]]; then
        python3 - "$wurb_settings_db" << 'PY'
import sqlite3
import sys

database = sys.argv[1]
connection = sqlite3.connect(database, timeout=15)
try:
    cursor = connection.cursor()

    def value(identity, key):
        row = cursor.execute(
            "SELECT value FROM key_value_data WHERE identity=? AND key=?",
            (identity, key),
        ).fetchone()
        return row[0] if row else ""

    latitude = float(value("location", "defaultLatitudeDd") or 0)
    longitude = float(value("location", "defaultLongitudeDd") or 0)
    source = value("location", "geoSource")
    if source in {"", "geo-default"} and latitude == 0.0 and longitude == 0.0:
        for identity in ("location", "startupLocation", "userLocation"):
            cursor.execute(
                "INSERT OR REPLACE INTO key_value_data(identity,key,value) VALUES(?,?,?)",
                (identity, "geoSource", "geo-gps-or-last-found"),
            )
        for identity in ("settings", "startupSettings", "userSettings"):
            cursor.execute(
                "INSERT OR REPLACE INTO key_value_data(identity,key,value) VALUES(?,?,?)",
                (identity, "lastGpsAtStartup", "keep"),
            )
        connection.commit()
finally:
    connection.close()
PY
        chown "$wurb_owner:$wurb_group" "$wurb_settings_db"
    fi
    mkdir -p /etc/systemd/system/wurb_2026.service.d
    rm -f /etc/systemd/system/wurb_2026.service.d/waveshare-gps-bridge.conf
    cat > /etc/systemd/system/wurb_2026.service.d/gps-bridge.conf << 'EOF'
[Unit]
Wants=wurb-gps-bridge.service
After=wurb-gps-bridge.service
EOF
fi
[[ -n "$wurb_home" ]] && patch_file wurb "$wurb_home/wurb_app/templates/index.html"
[[ -n "$wirc_home" ]] && patch_file wirc "$wirc_home/wirc_app/templates/index.html"

allsky_home="$(find_project allsky || true)"
if [[ -n "$allsky_home" && -f "$allsky_home/html/index.php" ]]; then
    patch_file allsky "$allsky_home/html/index.php"
fi

sed -e "s|__APP_DIR__|$app_dir|g" -e "s|__PYTHON__|$web_python|g" \
    "$source_dir/installer/wittypi5-webserver.service" \
    > /etc/systemd/system/wittypi5-webserver.service
chmod 0644 /etc/systemd/system/wittypi5-webserver.service
timeout 20s systemctl daemon-reload || die "systemd konnte nicht neu geladen werden."
if [[ "$configured_gps_mode" =~ ^(usb|waveshare_l76x)$ && -n "$wurb_home" ]]; then
    timeout 20s systemctl enable wurb-gps-bridge.service >/dev/null || \
        die "Die WURB-GPS-Bridge konnte nicht aktiviert werden."
    timeout 25s systemctl restart wurb-gps-bridge.service || \
        die "Die WURB-GPS-Bridge konnte nicht gestartet werden."
    bridge_ready=false
    for attempt in 1 2 3 4 5; do
        if [[ -e /dev/ttyWURB && -e /dev/ttyUSB9 ]]; then
            bridge_ready=true
            break
        fi
        sleep 1
    done
    [[ "$bridge_ready" == true ]] || \
        die "Die GPS-Bridge läuft, aber /dev/ttyUSB9 wurde nicht angelegt."
    grep -Fq -- '- /dev/ttyUSB9' "$wurb_local_config" || \
        die "WURB wurde nicht auf die virtuelle GPS-Schnittstelle /dev/ttyUSB9 umgestellt."
fi
if [[ -n "$allsky_home" && -f "$allsky_home/html/index.php" ]]; then
    systemctl disable wittypi5-allsky-firstboot.service >/dev/null 2>&1 || true
elif [[ "${WITTY_ADDON_EXPECT_ALLSKY:-0}" == 1 ]]; then
    timeout 15s systemctl enable wittypi5-allsky-firstboot.service || \
        die "Die einmalige Allsky-Nachbearbeitung konnte nicht aktiviert werden."
    log "Allsky-Navigation wird beim ersten Neustart automatisch ergänzt."
fi
timeout 15s systemctl enable wittypi5-webserver.service || \
    die "wittypi5-webserver.service konnte nicht für den Autostart aktiviert werden."
# enable --now startet einen bereits aktiven Dienst nicht neu. Nach einem Update
# würde sonst der alte Python-Prozess mit dem vorherigen server.py-Code weiterlaufen.
timeout 25s systemctl restart wittypi5-webserver.service || \
    die "wittypi5-webserver.service konnte nicht neu gestartet werden."
if [[ -n "$wurb_home" ]] && systemctl is-active --quiet wurb_2026.service; then
    timeout 25s systemctl reset-failed wurb_2026.service 2>/dev/null || true
    timeout 25s systemctl restart wurb_2026.service || \
        die "wurb_2026.service could not be restarted after the add-on update."
    wait_for_stable_wurb || \
        die "WURB did not remain stable on port 8080 after the add-on update. See the diagnostics above."
fi
if [[ -n "$wirc_home" ]] && systemctl is-active --quiet wirc_2026.service; then
    timeout 25s systemctl reset-failed wirc_2026.service 2>/dev/null || true
    timeout 25s systemctl restart wirc_2026.service || \
        die "wirc_2026.service could not be restarted after the add-on update."
    wait_for_stable_wirc || \
        die "WIRC did not remain stable on port 8082 after the add-on update. See the diagnostics above."
fi
if [[ -n "$allsky_home" ]]; then
    timeout 180s /usr/local/sbin/witty-allsky-trixie-compat repair || \
        log "WARNUNG: Optionale Allsky-Webserver-Einrichtung fehlgeschlagen; der Allsky-Dienst bleibt unangetastet."
    timeout 20s systemctl reload lighttpd.service 2>/dev/null || true
fi

sleep 2
systemctl is-active --quiet wittypi5-webserver.service || \
    die "wittypi5-webserver.service ist nach der Installation nicht aktiv."
if [[ "$configured_gps_mode" =~ ^(usb|waveshare_l76x)$ && -n "$wurb_home" ]]; then
    systemctl is-active --quiet wurb-gps-bridge.service || \
        die "Die WURB-GPS-Bridge ist nach der Installation nicht aktiv."
    [[ "$(readlink -f /dev/ttyUSB9 2>/dev/null || true)" == /dev/pts/* ]] || \
        die "/dev/ttyUSB9 verweist nicht auf die virtuelle GPS-Bridge."
fi

http_ok=false
for attempt in 1 2 3 4 5; do
    if curl --fail --silent --show-error --max-time 5 \
            --output /dev/null http://127.0.0.1:8081/; then
        http_ok=true
        break
    fi
    sleep 1
done
$http_ok || die "Der Witty-Webserver liefert auf Port 8081 keine gültige HTTP-Antwort."

log "Installiert in $app_dir"
log "Witty-Homepage: http://$(hostname):8081/"
log "Sicherung: $backup_dir"
