Witty Pi 5 eigener Webserver
============================

Paketversion: 2026-09-16.155

- Version 2026-09-16.155 wartet nach Dienstneustarts auf die echte
  Betriebsbereitschaft von Port 8081 und PHP-CGI, stellt die Trixie-
  FastCGI-Modullinks sicher und erlaubt dem Windows-Launcher die Verwendung
  eines bereits übertragenen Pakets

Ergebnis:
- Version 2026-09-16.154 begrenzt beide Lighttpd-Modulaktivierungen und verhindert flackernde oder vorzeitig entsperrte Softwarebuttons während laufender Installationen
- Version 2026-09-16.153 bestätigt die PTY-Tastatursteuerung des blauen Allsky-Dialogs und wiederholt die Allsky-/Witty-Nachbearbeitung nach einem frühen Neustart automatisch im selben Boot
- Version 2026-09-16.152 prüft und repariert Allsky auf Trixie vor Homepage-, Windows- und Hauptinstallation, zeigt jeden PHP-/Lighttpd-Schritt an und verhindert einen synchron blockierenden APT-Nachlauf
- update_addon.sh vergleicht zuerst die installierte Add-on-Version und beendet gleiche Versionen ohne Paket- oder Dienstprüfung
- Updates vergleichen einzelne Add-on-Dateien; install.sh und requirements.txt bleiben Erst- und Neuinstallationen vorbehalten
- der Witty-Webserver wird nur neu gestartet, wenn seine laufende Python- oder systemd-Datei tatsächlich geändert wurde
- Version 2026-09-15.151 vereinheitlicht Installation und Update auf selbstladende GitHub-Starter; die frueheren Papa-Starter entfallen
- Version 2026-09-15.150 bestätigt Deinstallationen erst nach unabhängiger Datei-, Dienst- und Prozessprüfung und aktualisiert neue Softwareterminals ohne alte Polling-Verzögerung
- WURB- und WIRC-Stabilitaetspruefung laeuft parallel und zeigt alle fuenf Sekunden den Fortschritt
- WIRC prueft FastAPI-Templates, Uvicorn, Websockets und Multipart und repariert die getestete Weblaufzeit auf 0.115.12/0.46.2/0.34.3/15.0.1/0.0.20
- Beim WIRC-Update werden nur abweichende Python-Pakete geladen; kurze PyPI-/Piwheels-Ausfaelle werden mit zehn Versuchen und 45 Sekunden Zeitlimit je Versuch abgefangen
- Strg+C beendet auch parallel laufende Dienstpruefungen und liefert Exit-Code 130
- zusaetzliche stabile SSH-Schnittstelle automation/windows_control.sh fuer Raspi-Scripte.exe
- Nach einem erfolgreichen Update bleibt in jedem Add-on-Sicherungsbereich automatisch nur die neueste datierte Sicherung erhalten
- alle GitHub-Starter laden aus RaspberryPI_Addons/Witty PI Addon im Branch main
- ein liegengebliebener oder abgebrochener Allsky-Quellordner gilt ohne geladene allsky.service nicht mehr als Installation
- Allsky-Navigation, Lighttpd/PHP-Pruefung und Overlay-Reparatur laufen nur bei tatsaechlich installiertem Allsky
- ZIP enthaelt installer_addon.sh, update_addon.sh sowie nur noch die allgemeinen Starter installer.sh und update.sh
- installer.sh und update.sh laden das aktuelle ZIP immer aus dem GitHub-Branch main; installer_papa.sh und update_papa.sh sind entfernt
- installer_addon.sh akzeptiert weiterhin SSH-Eingaben und optional eine sichere KEY=VALUE-Konfiguration fuer eine spaetere Windows-Oberflaeche
- stabile WITTY-CONTROL-Ereigniszeilen und Prozess-Exitcodes fuer eine spaetere C#/SSH-Steuerung
- aktuelle Trixie-Pakete und Python-Importe fuer WURB und WIRC werden vor dem Dienststart funktionsbasiert geprueft
- dynamische Allsky-/Trixie-Vorbereitung für PHP-CGI, Lighttpd und verfügbare Raspberry-Pi-Kamerapakete
- dauerhafte Allsky-Nachprüfung nach Debian-Paketupdates und bei jedem Systemstart
- Webpfad, Gerätezugriffsgruppen, Overlay-Vorlage und PHP-Ausführung werden geprüft statt blind überschrieben
- installierte Software bietet Neuinstallation; der jeweilige Dienst wird vorher kontrolliert beendet
- nach WURB-/WIRC-Installation wird der Dienst für den Homepage-Patch angehalten und danach stabil neu gestartet
- bei fehlender Software bleiben Start, Stopp und Deinstallation ausgeblendet
- optionale Einstellungssicherung vor Neuinstallation oder Deinstallation, lokal oder als Download
- GPS-Konfiguration unterhalb der internen Pi-5-RTC; Pi-4-Systeme blenden die nicht vorhandene interne RTC aus
- GPS-Koordinaten werden bei gueltigem Positionsfix direkt unter der GPS-Zeit angezeigt
- unabhaengiger systemd-Dienst wittypi5-webserver.service
- Port 8081
- Installation in /home/wurb/wittypi5-webserver, wenn /home/wurb vorhanden ist
- WURB und WIRC bleiben Uvicorn-Dienste auf Port 8080 bzw. 8082
- Stoppen von WURB oder WIRC beendet den Witty-Webserver nicht
- vorhandene Homepage-Dateien werden gesichert und nur in-place ergaenzt
- keine kompletten WURB-, WIRC- oder Allsky-Dateien sind im ZIP enthalten
- WURB- und WIRC-Aufnahmeverwaltung auf Port 8081, nur bei vorhandener Installation
- sichere Einzel- und ZIP-Downloads, Ordneranlage, Verschieben und Loeschen von Aufnahmen
- temporaere ZIP-Dateien werden nach erfolgreicher HTTP-Uebertragung geloescht
- Zielordner hierarchisch und ohne wiederholte Pfadnamen dargestellt
- Recordings-Schaltflaechen direkt neben WURB/WIRC; Witty Pi 5 rechts abgesetzt
- ZIPs aus ausgewaehlten Dateien ohne Ordnerstruktur und mit Download-Zeitstempel
- Aufnahmeziel aus record.targets der aktiven WURB/WIRC-Konfiguration ermittelt
- tatsaechlicher lokaler, USB- oder Festplatten-Speicherort auf der Webseite angezeigt
- WURB-Dateifilter: WAV; WIRC-Dateifilter: H264, MP4 und MKV
- zweisprachiger Leerhinweis in geoeffneten Ordnern ohne passende Aufnahmen
- Unterordner in beliebiger Tiefe erstellbar; Dateien und ganze Ordner verschiebbar
- Dienst-stoppen-Schaltflaechen und zugehoerige Handler aus WURB/WIRC entfernt
- Recording-Ziel wird bei jedem Backend-Aufruf erneut aus record.targets bestimmt
- Auswahl aller verfuegbaren konfigurierten Recording-Speicher auf WURB/WIRC-Seiten
- aktive Aufnahmequelle markiert; alle Datei- und Ordneraktionen an die Auswahl gebunden
- Witty-Pi-5-Navigation auf allen Seiten sichtbar und ca. 2 cm vom vorherigen Navigationsziel abgesetzt
- Allsky bei vorhandener Installation auf allen Seiten unmittelbar links vor Witty Pi 5
- Witty-Kopfbereich einschliesslich Navigation, Dienststatus und Seitentitel bleibt beim Scrollen sichtbar
- Witty-Reset zeigt Arbeitsschritt, prozentualen Fortschritt und sekundengenaue Laufzeit
- Wiederherstellung laedt zuerst alle WPI-Dateien hoch und liest die Firmware-Dateiliste erst danach gemeinsam ein
- aktiver Zeitmodus steht direkt neben der Bezeichnung; Umschaltflaechen sind rechtsbuendig angeordnet
- deutsch- und australisch-englische Anleitung in kurze Erklaerungen und Schritt-fuer-Schritt-Ablaeufe gegliedert
- Leerhinweis nur im tiefsten leeren Ordner, nicht zusaetzlich in dessen Elternordnern
- gemeinsame Sprachauswahl fuer Witty, WURB Recordings und WIRC Recordings inklusive Live-Tab-Synchronisierung
- Auswahl loeschen fuer Dateien und Ordner; Inhaltspruefung und zweisprachige Rueckfrage vor rekursivem Loeschen
- gestreamter Mehrfach-Upload mit Zielordnerwahl und Fortschritt; WAV fuer WURB, H264/MP4/MKV fuer WIRC
- Konfliktpruefung vor Upload: vorhandene/mehrfach gewaehlte Namen wahlweise ueberschreiben oder gezielt ueberspringen
- nach erfolgreichem Upload zuerst Dateistruktur aktualisieren und danach Upload-Fenster automatisch schliessen
- Erfolgsmeldung nach Upload zwei Sekunden sichtbar, bevor sich das Fenster schliesst
- Verschieben-Schaltflaeche links vor der Zielordner-Auswahl angeordnet
- Allsky-Erkennung fuer /home/allsky, Benutzer-Home-Verzeichnisse und /opt korrigiert
- neue zweisprachige Seite "Allsky - Setup" fuer validierte Einstellungs-Sicherungen
- Allsky-Wiederherstellung mit Rueckrollkopie und kontrolliertem Dienst-Neustart
- jeder erneute Witty-Logabruf ersetzt die lokale Kopie durch einen frischen Firmware-Snapshot
- wiederholte Schedule-Dateiverwaltungsmeldungen werden nur im Logfenster zusammengefasst; der Download bleibt vollstaendig
- Allsky-Statusampel und manuelle Start-/Stoppsteuerung auf Witty- und Allsky-Setup-Seite
- farbige Zeitmodus-Anzeige direkt hinter der aktuellen Witty-RTC-Zeit im Skripteditor
- Skriptnamensfeld direkt unter Editor und Schaltzeitenvorschau vor den Dateiaktionen
- Beispielknopf links neben dem Knopf zum Leeren des Editorfensters angeordnet
- vollstaendige Anzeige grosser Witty-Logs ohne die alte 512-KiB-Grenze
- Anzeige der bekannten Loggroesse; Witty Pi 5 liefert vor dem Download keine Dateigroesse
- abgesicherter Witty-Reset mit Skript-Backup, Wiederherstellung und erneuter Aktivierung
- Zeitplanpruefung akzeptiert bis einschliesslich 4096 Ereignisse
- zweisprachige vollstaendige Bedienungsanleitung fuer Witty sowie WURB-/WIRC-Recordings
- Anleitung-Button rechts unterhalb der Ueberschrift auf allen drei Bedienseiten
- sichtbarer 5-mm-Abstand zwischen den beiden Zeitmodus-Schaltflaechen
- Dienstampeln: grau bei nicht installiert, rot bei installiert/gestoppt und gruen bei laufendem Dienst
- eingeschraenkte Web-Installation und Deinstallation fuer WURB-2026, WIRC-2026 und Allsky mit Neustart
- Allsky-Kamerawarnung vor der Bestaetigung und interaktive Ausgabe des offiziellen Installers
- Installationslinks verwenden die beim Seitenaufruf erreichte IP-Adresse und funktionieren dadurch auch am Hotspot
- vollstaendige Allsky-Erkennung verlangt Projektstruktur und geladene allsky.service
- WURB-, WIRC- und Allsky-Status stehen untereinander; Installationsknopf heisst Software installieren
- GPS-Koordinaten werden offline einer exakten IANA-Zeitzone zugeordnet; je UTC-Offset erscheint nur ein Referenzort
- ohne installierte GPS-Option wird ausdruecklich "Zeitzonenermittlung nicht moeglich" angezeigt
- australische GPS-Orte und Sonderoffsets werden einzeln als Perth, Eucla, Darwin, Adelaide, Broken Hill, Brisbane, Sydney, Canberra, Melbourne, Hobart oder Lord Howe bezeichnet
- fehlende GPS-Koordinaten werden alle zehn Sekunden erneut abgefragt; der letzte vollständige Fix wird 15 Minuten einschließlich Position zwischengespeichert
- falls gpsd noch keinen Fix an die Witty-Seite geliefert hat, wird dieselbe gueltige Position aus wurb_settings.db verwendet, mit der WURB seine Sonnenzeiten berechnet
- GPS-Zeit wird wieder unabhaengig vom Positionsfix angezeigt; der Python-Webserver liest WURBs gueltige Position zusaetzlich direkt als zweiten Fallback
- der offizielle Allsky-Dialog ist auf der Webseite als echtes Terminal mit Pfeil-, Tabulator-, Leer-, Enter- und Esc-Tasten bedienbar
- laufende Web-Installationen koennen abgebrochen werden; eine unvollstaendige Allsky-Installation loest danach keine Erststart-Nachbearbeitung aus
- Allsky ueber die Webseite installiert vorab dieselben USB-Mount-Regeln und denselben einmaligen Homepage-Finalisierer wie installer.sh
- Neustart-Erkennung prueft alle 1,5 Sekunden und laedt die Seite sofort nach Rueckkehr des Webservers statt nach einer festen Minute
- WURB- und WIRC-Webinstallation startet die fertigen Dienste direkt und verlangt keinen Raspberry-Neustart mehr; Allsky behaelt seinen erforderlichen Erststartpfad
- WIRC-Webinstallation prueft Python-/Kamerabibliotheken sowie Port 8082 und meldet Erfolg erst nach 35 Sekunden stabilem Betrieb; Fehler enthalten systemd- und WIRC-Diagnosen
- Dienstmeldungen verwenden verstaendliche Texte wie "WIRC-Dienst wurde gestartet" oder "WURB-Dienst wurde beendet" statt interner sudo-Befehle
- Meldungszeilen werden 30 Sekunden nach der letzten unveraenderten Meldung automatisch ausgeblendet; laufende Statusaktualisierungen starten die Frist neu
- vorhandene WURB-/WIRC-Umgebungen werden beim Add-on-Update auf fehlende Python-, Audio- und Kamerabibliotheken geprueft und bei Bedarf repariert
- Startpruefungen verlangen stabile Antworten auf Port 8080 beziehungsweise 8082; Allsky prueft Capture-Dienst und Webserver, Deinstallationen kontrollieren beendete Dienste und Timer
- nur die Allsky-Installation darf noch einen Neustart ausloesen; auch die Allsky-Deinstallation wird ohne Neustart abgeschlossen
- WURB-, WIRC- und Allsky-Steuerungen stehen je Software in drei Zeilen; Dienst- und Softwareaktionen sind nach Name und Status eingerueckt

Installation aus dem entpackten ZIP:
    sudo bash witty_addon/install.sh

Direktinstallation ueber die einzelne GitHub-Datei:
    sudo bash install_wittypi5_webserver.sh

Aufruf:
    http://RASPBERRY-IP:8081/
    http://RASPBERRY-IP:8081/recordings/wurb
    http://RASPBERRY-IP:8081/recordings/wirc

Kontrolle:
    systemctl status wittypi5-webserver.service
    journalctl -u wittypi5-webserver.service -n 100 --no-pager
