#!/usr/bin/env bash
set -Eeuo pipefail

# Local update launcher. The complete update implementation is versioned inside
# witty_addon.zip so this small entry point also suits later SSH automation.
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly ARCHIVE="$SCRIPT_DIR/witty_addon.zip"

log() { printf '[Witty-Launcher] %s\n' "$*"; }
die() { printf '[Witty-Launcher] FEHLER: %s\n' "$*" >&2; exit 1; }
[[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Bitte mit sudo starten: sudo ./update.sh"

if ! command -v unzip >/dev/null 2>&1; then
    apt-get update
    DEBIAN_FRONTEND=noninteractive apt-get install -y unzip
fi

[[ -f "$ARCHIVE" ]] || die "witty_addon.zip muss im selben Verzeichnis wie update.sh liegen."
unzip -tq "$ARCHIVE" >/dev/null || die "witty_addon.zip ist beschädigt."
if unzip -Z1 "$ARCHIVE" | grep -Eq '(^/|(^|/)\.\.(/|$))'; then die "Unsichere Dateipfade im ZIP-Archiv."; fi
package_version="$(unzip -p "$ARCHIVE" witty_addon/VERSION 2>/dev/null | tr -d '\r\n')"
[[ -n "$package_version" ]] || die "VERSION fehlt in witty_addon.zip."
log "Geprüfte ZIP-Paketversion: $package_version"

# Keep the local installer ready for direct use and for a later Windows client.
[[ ! -f "$SCRIPT_DIR/installer.sh" ]] || chmod 0755 "$SCRIPT_DIR/installer.sh"

temp_base="${TMPDIR:-/var/tmp}"
[[ -d "$temp_base" ]] || temp_base=/tmp
work_dir="$(mktemp -d "$temp_base/witty-update-launcher.XXXXXX")"
cleanup() { rm -rf -- "$work_dir"; }
trap cleanup EXIT
unzip -q "$ARCHIVE" -d "$work_dir"
runner="$work_dir/witty_addon/update_addon.sh"
[[ -f "$runner" ]] || die "update_addon.sh fehlt in witty_addon.zip."
chmod 0755 "$runner"
log "Starte update_addon.sh aus der lokalen ZIP-Datei."
printf '[WITTY-CONTROL] event=update_started source=local\n'
runner_rc=0
bash "$runner" "$@" || runner_rc=$?
if (( runner_rc != 0 )); then
    result=error
    (( runner_rc == 130 )) && result=cancelled
    printf '[WITTY-CONTROL] event=update_finished result=%s exit_code=%s\n' "$result" "$runner_rc"
    exit "$runner_rc"
fi
printf '[WITTY-CONTROL] event=update_finished result=success\n'
