#!/usr/bin/env bash
set -Eeuo pipefail

# GitHub installation launcher for a fresh Raspberry Pi OS. It bootstraps only
# download/extraction tools; installer_addon.sh owns all hardware decisions.
readonly ADDON_URL="https://raw.githubusercontent.com/C4rstenSC/scripte/main/RaspberryPI_Addons/Witty%20PI%20Addon/witty_addon.zip"
log() { printf '[Witty-Launcher] %s\n' "$*"; }
die() { printf '[Witty-Launcher] FEHLER: %s\n' "$*" >&2; exit 1; }
[[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Bitte mit sudo starten: sudo ./installer_papa.sh"

missing=false
for command_name in curl unzip; do command -v "$command_name" >/dev/null 2>&1 || missing=true; done
if [[ "$missing" == true ]]; then
    apt-get update
    DEBIAN_FRONTEND=noninteractive apt-get install -y curl unzip ca-certificates
fi

temp_base="${TMPDIR:-/var/tmp}"
[[ -d "$temp_base" ]] || temp_base=/tmp
work_dir="$(mktemp -d "$temp_base/witty-install-github.XXXXXX")"
cleanup() { rm -rf -- "$work_dir"; }
trap cleanup EXIT
archive="$work_dir/witty_addon.zip"
log "Lade die aktuelle witty_addon.zip von GitHub ..."
curl --fail --location --show-error --silent --connect-timeout 15 --max-time 180 \
    --retry 3 --retry-delay 2 --output "$archive" "${ADDON_URL}?download=$(date +%s)" || \
    die "GitHub-Download fehlgeschlagen."
unzip -tq "$archive" >/dev/null || die "Das GitHub-ZIP ist beschädigt."
if unzip -Z1 "$archive" | grep -Eq '(^/|(^|/)\.\.(/|$))'; then die "Unsichere Dateipfade im ZIP-Archiv."; fi
unzip -q "$archive" -d "$work_dir/extracted"
runner="$work_dir/extracted/witty_addon/installer_addon.sh"
[[ -f "$runner" ]] || die "installer_addon.sh fehlt im GitHub-ZIP."
chmod 0755 "$runner"
printf '[WITTY-CONTROL] event=install_started source=github\n'
bash "$runner" "$@"
printf '[WITTY-CONTROL] event=install_finished result=success\n'
