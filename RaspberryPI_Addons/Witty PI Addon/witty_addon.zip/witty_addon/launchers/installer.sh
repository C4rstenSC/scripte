#!/usr/bin/env bash
set -Eeuo pipefail

# Local installation launcher. The full interactive installer and its matching
# add-on payload are kept together inside witty_addon.zip.
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly ARCHIVE="$SCRIPT_DIR/witty_addon.zip"
log() { printf '[Witty-Launcher] %s\n' "$*"; }
die() { printf '[Witty-Launcher] FEHLER: %s\n' "$*" >&2; exit 1; }
[[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Bitte mit sudo starten: sudo ./installer.sh"

if ! command -v unzip >/dev/null 2>&1 || ! command -v curl >/dev/null 2>&1 || ! command -v wget >/dev/null 2>&1; then
    apt-get update
    DEBIAN_FRONTEND=noninteractive apt-get install -y curl wget unzip ca-certificates
fi
[[ -f "$ARCHIVE" ]] || die "witty_addon.zip muss im selben Verzeichnis wie installer.sh liegen."
unzip -tq "$ARCHIVE" >/dev/null || die "witty_addon.zip ist beschädigt."
if unzip -Z1 "$ARCHIVE" | grep -Eq '(^/|(^|/)\.\.(/|$))'; then die "Unsichere Dateipfade im ZIP-Archiv."; fi
[[ ! -f "$SCRIPT_DIR/update.sh" ]] || chmod 0755 "$SCRIPT_DIR/update.sh"

temp_base="${TMPDIR:-/var/tmp}"
[[ -d "$temp_base" ]] || temp_base=/tmp
work_dir="$(mktemp -d "$temp_base/witty-install-launcher.XXXXXX")"
cleanup() { rm -rf -- "$work_dir"; }
trap cleanup EXIT
unzip -q "$ARCHIVE" -d "$work_dir"
runner="$work_dir/witty_addon/installer_addon.sh"
[[ -f "$runner" ]] || die "installer_addon.sh fehlt in witty_addon.zip."
chmod 0755 "$runner"
log "Starte installer_addon.sh aus der lokalen ZIP-Datei."
printf '[WITTY-CONTROL] event=install_started source=local\n'
bash "$runner" "$@"
printf '[WITTY-CONTROL] event=install_finished result=success\n'
