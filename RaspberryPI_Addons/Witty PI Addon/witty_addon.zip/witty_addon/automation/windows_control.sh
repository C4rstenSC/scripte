#!/usr/bin/env bash
set -uo pipefail

# Stable SSH control protocol for Raspi-Scripte.exe. Human-readable output from
# existing managers is sent to stderr; stdout is reserved for protocol blocks.
readonly PROTOCOL_VERSION="1"
readonly EXIT_SUCCESS=0
readonly EXIT_GENERAL=1
readonly EXIT_INVALID=2
readonly EXIT_NOT_INSTALLED=3
readonly EXIT_SERVICE=4
readonly EXIT_SOFTWARE=5
readonly EXIT_BACKUP=6
readonly EXIT_UPDATE=7
readonly EXIT_INTERACTIVE=8

readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

find_app_root() {
    local candidate=""
    if [[ -f "$SCRIPT_DIR/../VERSION" && -d "$SCRIPT_DIR/../web" ]]; then
        (cd "$SCRIPT_DIR/.." && pwd)
        return 0
    fi
    for candidate in /home/wurb/wittypi5-webserver /home/*/wittypi5-webserver /opt/wittypi5-webserver; do
        [[ -f "$candidate/VERSION" && -d "$candidate/automation" ]] || continue
        printf '%s\n' "$candidate"
        return 0
    done
    return 1
}

APP_ROOT="$(find_app_root 2>/dev/null || true)"
readonly APP_ROOT

clean_value() {
    local value="${1:-}"
    value="${value//$'\r'/ }"
    value="${value//$'\n'/ }"
    value="${value//\\/\\\\}"
    printf '%s' "${value:0:1500}"
}

addon_version() {
    local candidate=""
    for candidate in "$APP_ROOT/VERSION" "$SCRIPT_DIR/../VERSION"; do
        [[ -n "$candidate" && -r "$candidate" ]] || continue
        tr -d '\r\n' <"$candidate"
        return 0
    done
    printf 'unknown'
}

witty_software_version() {
    local binary package version
    binary="$(command -v wp5 2>/dev/null || true)"
    [[ -n "$binary" ]] || { printf 'unknown'; return; }
    package="$(dpkg-query -S "$binary" 2>/dev/null | head -n1 | cut -d: -f1 || true)"
    if [[ -n "$package" ]]; then
        version="$(dpkg-query -W -f='${Version}' "$package" 2>/dev/null || true)"
        [[ -n "$version" ]] && { printf '%s' "$version"; return; }
    fi
    printf 'unknown'
}

config_value() {
    local key="$1"
    [[ -r /etc/witty-addon.conf ]] || return 1
    sed -nE "s/^${key}=([^[:space:]]+)$/\\1/p" /etc/witty-addon.conf | head -n 1
}

unit_load_state() {
    local unit="$1" state=""
    command -v systemctl >/dev/null 2>&1 || { printf 'unknown'; return; }
    state="$(timeout 4s systemctl show --property=LoadState --value "$unit" 2>/dev/null || true)"
    case "$state" in
        loaded) printf 'loaded' ;;
        masked) printf 'masked' ;;
        not-found) printf 'not-installed' ;;
        *) printf 'unknown' ;;
    esac
}

service_state() {
    local unit="$1" load state
    load="$(unit_load_state "$unit")"
    if [[ "$load" == masked ]]; then
        printf 'inactive'
        return
    fi
    [[ "$load" == loaded ]] || {
        [[ "$load" == not-installed ]] && printf 'not-installed' || printf 'unknown'
        return
    }
    state="$(timeout 4s systemctl is-active "$unit" 2>/dev/null || true)"
    case "$state" in
        active) printf 'active' ;;
        inactive) printf 'inactive' ;;
        failed) printf 'failed' ;;
        *) printf 'unknown' ;;
    esac
}

project_present() {
    local software="$1" candidate=""
    case "$software" in
        wurb)
            for candidate in /home/wurb/wurb_2026 /home/pi/wurb_2026 /opt/wurb_2026; do
                [[ -f "$candidate/wurb_main.py" && -f "$candidate/wurb_app/templates/index.html" ]] && return 0
            done
            ;;
        wirc)
            for candidate in /home/wurb/wirc_2026 /home/pi/wirc_2026 /opt/wirc_2026; do
                [[ -f "$candidate/wirc_main.py" && -f "$candidate/wirc_app/templates/index.html" ]] && return 0
            done
            ;;
        allsky)
            for candidate in /home/wurb/allsky /home/allsky /home/*/allsky /opt/allsky; do
                [[ -f "$candidate/allsky.sh" && -d "$candidate/html" && -d "$candidate/config" ]] && return 0
            done
            ;;
    esac
    return 1
}

software_unit() {
    case "$1" in
        wurb) printf 'wurb_2026.service' ;;
        wirc) printf 'wirc_2026.service' ;;
        allsky) printf 'allsky.service' ;;
    esac
}

installed_state() {
    local software="$1" unit load has_project=no
    unit="$(software_unit "$software")"
    load="$(unit_load_state "$unit")"
    project_present "$software" && has_project=yes
    if [[ "$load" =~ ^(loaded|masked)$ && "$has_project" == yes ]]; then
        printf 'yes'
    elif [[ "$load" =~ ^(not-installed|masked)$ && "$has_project" == no ]]; then
        printf 'no'
    else
        printf 'unknown'
    fi
}

witty_installed_state() {
    local load has_files=no
    load="$(unit_load_state wittypi5-webserver.service)"
    [[ -n "$APP_ROOT" && -x "$APP_ROOT/backend/witty_backend.sh" ]] && has_files=yes
    if [[ "$load" =~ ^(loaded|masked)$ && "$has_files" == yes ]]; then
        printf 'yes'
    elif [[ "$load" =~ ^(not-installed|masked)$ && "$has_files" == no ]]; then
        printf 'no'
    else
        printf 'unknown'
    fi
}

os_release_value() {
    local key="$1" value=""
    [[ -r /etc/os-release ]] || { printf 'unknown'; return; }
    value="$(sed -nE "s/^${key}=(.*)$/\\1/p" /etc/os-release | head -n 1)"
    value="${value#\"}"; value="${value%\"}"
    value="${value#\'}"; value="${value%\'}"
    [[ -n "$value" ]] && clean_value "$value" || printf 'unknown'
}

require_root() {
    if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
        control_error "${1:-unknown}" "${2:-}" "root-required" \
            "Run this command with sudo." "$EXIT_GENERAL"
    fi
}

validate_software() {
    case "${1:-}" in wurb|wirc|allsky) return 0 ;; esac
    control_error "${2:-unknown}" "${1:-}" "invalid-software" \
        "SOFTWARE must be wurb, wirc or allsky." "$EXIT_INVALID"
}

control_error() {
    local action="$1" software="$2" code="$3" message="$4" exit_code="$5"
    printf '[WITTY-CONTROL]\n'
    printf 'ACTION=%s\n' "$(clean_value "$action")"
    [[ -z "$software" ]] || printf 'SOFTWARE=%s\n' "$(clean_value "$software")"
    printf 'RESULT=error\n'
    printf 'ERROR_CODE=%s\n' "$(clean_value "$code")"
    printf 'MESSAGE=%s\n' "$(clean_value "$message")"
    printf '[/WITTY-CONTROL]\n'
    exit "$exit_code"
}

command_message() {
    local data="${1:-}"
    python3 -c 'import json,sys
try:
 data=json.load(sys.stdin); print(data.get("error") or data.get("message") or "")
except Exception:
 print("")' <<<"$data" 2>/dev/null || true
}

show_version() {
    printf '[WITTY-VERSION]\n'
    printf 'PROTOCOL_VERSION=%s\n' "$PROTOCOL_VERSION"
    printf 'ADDON_VERSION=%s\n' "$(clean_value "$(addon_version)")"
    printf '[/WITTY-VERSION]\n'
}

show_status() {
    local rpi_model="unknown" rpi_number="unknown" witty_installed witty_model="unknown"
    local witty_version="unknown" witty_software="unknown" witty_output="" parsed="" backend=""
    local wurb_installed wirc_installed allsky_installed
    if [[ -r /proc/device-tree/model ]]; then
        rpi_model="$(tr -d '\0\r\n' </proc/device-tree/model 2>/dev/null || true)"
        [[ -n "$rpi_model" ]] || rpi_model="unknown"
    fi
    if [[ "$rpi_model" =~ Raspberry[[:space:]]Pi[[:space:]]([45]) ]]; then
        rpi_number="${BASH_REMATCH[1]}"
    else
        rpi_number="$(config_value RPI_MODEL 2>/dev/null || true)"
        [[ "$rpi_number" =~ ^[45]$ ]] || rpi_number="unknown"
    fi
    witty_installed="$(witty_installed_state)"
    witty_software="$(witty_software_version)"
    witty_model="$(config_value WITTY_MODEL 2>/dev/null || true)"
    [[ "$witty_model" =~ ^[45]$ ]] || witty_model="unknown"
    backend="$APP_ROOT/backend/witty_backend.sh"
    if [[ "$witty_installed" == yes && -x "$backend" ]]; then
        witty_output="$(timeout 20s "$backend" status 2>/dev/null || true)"
        parsed="$(python3 -c 'import json,re,sys
try:
 data=json.load(sys.stdin)
 model=str(data.get("model", "")); match=re.search(r"([45])", model)
 print(match.group(1) if match else "unknown")
 print(str(data.get("firmware") or "unknown"))
except Exception:
 print("unknown"); print("unknown")' <<<"$witty_output" 2>/dev/null || printf 'unknown\nunknown\n')"
        mapfile -t witty_fields <<<"$parsed"
        [[ "$witty_model" != unknown ]] || witty_model="${witty_fields[0]:-unknown}"
        witty_version="${witty_fields[1]:-unknown}"
    fi
    wurb_installed="$(installed_state wurb)"
    wirc_installed="$(installed_state wirc)"
    allsky_installed="$(installed_state allsky)"
    # Die alte Windows-Oberfläche kennt nur installiert/nicht installiert.
    # Bei einer unvollständigen Allsky-Deinstallation muss der Entfernen-Knopf
    # sichtbar bleiben, damit übrig gebliebene Dienste oder Dateien bereinigt
    # werden können.
    [[ "$allsky_installed" != unknown ]] || allsky_installed=yes
    printf '[WITTY-STATUS]\n'
    printf 'PROTOCOL_VERSION=%s\n' "$PROTOCOL_VERSION"
    printf 'ADDON_VERSION=%s\n' "$(clean_value "$(addon_version)")"
    printf 'RPI_MODEL=%s\n' "$(clean_value "$rpi_model")"
    printf 'RPI_MODEL_NUMBER=%s\n' "$rpi_number"
    printf 'OS=%s\n' "$(os_release_value NAME)"
    printf 'OS_VERSION=%s\n' "$(os_release_value VERSION_ID)"
    printf 'HOSTNAME=%s\n' "$(clean_value "$(hostname 2>/dev/null || printf unknown)")"
    printf 'WITTY_INSTALLED=%s\n' "$witty_installed"
    printf 'WITTY_MODEL=%s\n' "$witty_model"
    printf 'WITTY_VERSION=%s\n' "$(clean_value "$witty_version")"
    printf 'WITTY_SOFTWARE_VERSION=%s\n' "$(clean_value "$witty_software")"
    printf 'WURB_INSTALLED=%s\n' "$wurb_installed"
    printf 'WURB_SERVICE=%s\n' "$([[ "$wurb_installed" == no ]] && printf not-installed || service_state wurb_2026.service)"
    printf 'WIRC_INSTALLED=%s\n' "$wirc_installed"
    printf 'WIRC_SERVICE=%s\n' "$([[ "$wirc_installed" == no ]] && printf not-installed || service_state wirc_2026.service)"
    printf 'ALLSKY_INSTALLED=%s\n' "$allsky_installed"
    printf 'ALLSKY_SERVICE=%s\n' "$([[ "$allsky_installed" == no ]] && printf not-installed || service_state allsky.service)"
    printf '[/WITTY-STATUS]\n'
}

control_witty_software_update() {
    local api_url="https://api.github.com/repos/uugear/Witty-Pi-5-Software/releases/latest"
    local work_dir metadata tag asset_url deb package_name package_version installed_version
    local wp5d_active=no wp5d_enabled=no rc=0
    require_root witty-software-update ""
    [[ "$(config_value WITTY_MODEL 2>/dev/null || true)" == 5 || -x "$(command -v wp5 2>/dev/null || true)" ]] || \
        control_error witty-software-update "" unsupported-hardware \
            "The manufacturer update is available only for Witty Pi 5." "$EXIT_UPDATE"
    for command in curl jq dpkg-deb apt-get; do
        command -v "$command" >/dev/null 2>&1 || control_error witty-software-update "" missing-command \
            "Required command is missing: $command" "$EXIT_UPDATE"
    done

    work_dir="$(mktemp -d /var/tmp/witty-wp5-update.XXXXXX)" || \
        control_error witty-software-update "" temporary-directory-failed \
            "The temporary update directory could not be created." "$EXIT_UPDATE"
    trap 'rm -rf -- "$work_dir"' EXIT
    metadata="$work_dir/release.json"; deb="$work_dir/wp5.deb"
    printf '[WITTY-CONTROL]\nACTION=witty-software-update\nSTATE=started\nPTY_REQUIRED=yes\n[/WITTY-CONTROL]\n'
    printf '%s\n' "[Witty-Pi-5] Lese die aktuelle Herstellerversion von GitHub ..." >&2
    curl --fail --location --silent --show-error --retry 3 --connect-timeout 20 \
        -H 'Accept: application/vnd.github+json' -H 'User-Agent: witty-addon' \
        "$api_url" -o "$metadata" || control_error witty-software-update "" github-release-failed \
            "The latest UUGear release could not be read from GitHub." "$EXIT_UPDATE"
    tag="$(jq -r '.tag_name // empty' "$metadata" | sed -E 's/^[vV]//')"
    asset_url="$(jq -r '[.assets[] | select((.name|ascii_downcase|endswith(".deb")))] as $all | (($all | map(select(.name|ascii_downcase|test("arm64|aarch64")))) + $all)[0].browser_download_url // empty' "$metadata")"
    [[ -n "$tag" && -n "$asset_url" ]] || control_error witty-software-update "" github-asset-missing \
        "The current UUGear release does not contain a Debian package for Witty Pi 5." "$EXIT_UPDATE"
    printf '%s\n' "[Witty-Pi-5] GitHub-Version: $tag" >&2
    installed_version="$(witty_software_version)"
    if [[ "$installed_version" != unknown ]] && dpkg --compare-versions "$installed_version" ge "$tag"; then
        printf '%s\n' "[Witty-Pi-5] Installierte Herstellersoftware $installed_version ist bereits aktuell." >&2
        trap - EXIT; rm -rf -- "$work_dir"
        printf '[WITTY-CONTROL]\nACTION=witty-software-update\nSTATE=finished\nRESULT=success\nVERSION=%s\nCHANGED=no\n[/WITTY-CONTROL]\n' "$(clean_value "$installed_version")"
        return 0
    fi
    printf '%s\n' "[Witty-Pi-5] Lade das signalisierte Debian-Paket aus dem offiziellen UUGear-GitHub-Release ..." >&2
    curl --fail --location --silent --show-error --retry 3 --connect-timeout 20 \
        "$asset_url" -o "$deb" || control_error witty-software-update "" github-download-failed \
            "The official Witty Pi 5 Debian package could not be downloaded." "$EXIT_UPDATE"
    dpkg-deb --info "$deb" >/dev/null 2>&1 || control_error witty-software-update "" invalid-debian-package \
        "The downloaded release asset is not a valid Debian package." "$EXIT_UPDATE"
    package_name="$(dpkg-deb -f "$deb" Package 2>/dev/null || true)"
    package_version="$(dpkg-deb -f "$deb" Version 2>/dev/null || true)"
    [[ ( "${package_name,,}" == *wp5* || "${package_name,,}" == *witty*pi*5* ) && -n "$package_version" ]] || \
        control_error witty-software-update "" unexpected-debian-package \
            "The downloaded package is not the expected wp5 manufacturer software." "$EXIT_UPDATE"
    systemctl is-active --quiet wp5d.service && wp5d_active=yes || true
    systemctl is-enabled --quiet wp5d.service && wp5d_enabled=yes || true
    systemctl stop wp5d.service >/dev/null 2>&1 || true
    printf '%s\n' "[Witty-Pi-5] Installiere Herstellerpaket $package_name $package_version ..." >&2
    DEBIAN_FRONTEND=noninteractive apt-get -o DPkg::Lock::Timeout=120 install -y "$deb" >&2 || rc=$?
    if [[ "$wp5d_enabled" == yes ]]; then systemctl enable wp5d.service >/dev/null 2>&1 || true; else systemctl disable wp5d.service >/dev/null 2>&1 || true; fi
    if [[ "$wp5d_active" == yes ]]; then systemctl start wp5d.service >/dev/null 2>&1 || rc=1; else systemctl stop wp5d.service >/dev/null 2>&1 || true; fi
    (( rc == 0 )) || control_error witty-software-update "" manufacturer-install-failed \
        "The official Witty Pi 5 package could not be installed or its previous service state could not be restored." "$EXIT_UPDATE"
    if id wurb >/dev/null 2>&1 && getent group i2c >/dev/null 2>&1; then
        usermod -aG i2c wurb
        printf '%s\n' 'f /run/lock/wittypi5_app.lock 0660 root i2c -' > /etc/tmpfiles.d/wittypi5-app-lock.conf
        systemd-tmpfiles --create /etc/tmpfiles.d/wittypi5-app-lock.conf >/dev/null 2>&1 || true
    fi
    [[ ! -x /usr/local/sbin/witty-disable-auto-time ]] || \
        /usr/local/sbin/witty-disable-auto-time >/dev/null
    installed_version="$(witty_software_version)"
    trap - EXIT; rm -rf -- "$work_dir"
    printf '%s\n' "[Witty-Pi-5] Herstellerupdate auf $installed_version abgeschlossen." >&2
    printf '[WITTY-CONTROL]\nACTION=witty-software-update\nSTATE=finished\nRESULT=success\nVERSION=%s\nCHANGED=yes\n[/WITTY-CONTROL]\n' "$(clean_value "$installed_version")"
}

control_service() {
    local action="$1" software="$2" installed backend_action service_arg output rc state message
    validate_software "$software" "$action"
    require_root "$action" "$software"
    installed="$(installed_state "$software")"
    [[ "$installed" == yes ]] || control_error "$action" "$software" "software-not-installed" \
        "The selected software is not installed completely." "$EXIT_NOT_INSTALLED"
    backend="$APP_ROOT/backend/witty_backend.sh"
    [[ -x "$backend" ]] || control_error "$action" "$software" "backend-not-installed" \
        "The installed Witty backend was not found." "$EXIT_SERVICE"
    [[ "$action" == service-start ]] && backend_action=service_start || backend_action=service_stop
    case "$software" in
        wurb) service_arg=wurb_2026 ;;
        wirc) service_arg=wirc_2026 ;;
        allsky) service_arg=allsky ;;
    esac
    output="$(timeout 150s "$backend" "$backend_action" "$service_arg" 2>&1)"; rc=$?
    state="$(service_state "$(software_unit "$software")")"
    if (( rc != 0 )); then
        message="$(command_message "$output")"; [[ -n "$message" ]] || message="$output"
        control_error "$action" "$software" "service-command-failed" "$message" "$EXIT_SERVICE"
    fi
    printf '[WITTY-CONTROL]\nACTION=%s\nSOFTWARE=%s\nRESULT=success\nSERVICE_STATUS=%s\n[/WITTY-CONTROL]\n' \
        "$action" "$software" "$state"
}

software_manager_path() {
    local candidate=""
    for candidate in "$APP_ROOT/manager/software_manager.sh" "$SCRIPT_DIR/../manager/software_manager.sh"; do
        [[ -x "$candidate" ]] && { printf '%s\n' "$candidate"; return 0; }
    done
    return 1
}

control_software() {
    local action="$1" software="$2" installed manager manager_action rc
    validate_software "$software" "$action"
    require_root "$action" "$software"
    installed="$(installed_state "$software")"
    if [[ "$action" == reinstall && "$installed" != yes ]]; then
        control_error "$action" "$software" "software-not-installed" \
            "Reinstallation requires an existing complete installation." "$EXIT_NOT_INSTALLED"
    fi
    if [[ "$action" == uninstall && "$installed" == no ]]; then
        control_error "$action" "$software" "software-not-installed" \
            "The selected software is not installed completely." "$EXIT_NOT_INSTALLED"
    fi
    if [[ "$software" == allsky && "$action" != uninstall && ( ! -t 0 || ! -t 1 ) ]]; then
        printf '[WITTY-CONTROL]\nACTION=%s\nSOFTWARE=allsky\nRESULT=interactive-required\nPTY_REQUIRED=yes\n[/WITTY-CONTROL]\n' "$action"
        exit "$EXIT_INTERACTIVE"
    fi
    manager="$(software_manager_path || true)"
    [[ -n "$manager" ]] || control_error "$action" "$software" "manager-not-installed" \
        "software_manager.sh was not found." "$EXIT_SOFTWARE"
    manager_action=install; [[ "$action" == uninstall ]] && manager_action=uninstall
    printf '[WITTY-CONTROL]\nACTION=%s\nSOFTWARE=%s\nSTATE=started\n' "$action" "$software"
    [[ "$software" != allsky || "$action" == uninstall ]] || printf 'PTY_REQUIRED=yes\n'
    printf '[/WITTY-CONTROL]\n'
    if [[ "$software" == allsky && "$action" != uninstall ]]; then
        "$manager" "$manager_action" "$software"; rc=$?
    else
        "$manager" "$manager_action" "$software" >&2; rc=$?
    fi
    if (( rc != 0 )); then
        if [[ "$software" == allsky && "$rc" -eq 20 ]]; then
            control_error "$action" "$software" "camera-not-detected" \
                "No supported Allsky camera was detected. Connect a camera and start the installation again." "$EXIT_SOFTWARE"
        fi
        control_error "$action" "$software" "software-operation-failed" \
            "The software manager returned exit code $rc. See stderr for details." "$EXIT_SOFTWARE"
    fi
    printf '[WITTY-CONTROL]\nACTION=%s\nSOFTWARE=%s\nSTATE=finished\nRESULT=success\n[/WITTY-CONTROL]\n' \
        "$action" "$software"
}

client_identity() {
    local user="${SUDO_USER:-}"
    if [[ -z "$user" || "$user" == root ]] || ! getent passwd "$user" >/dev/null 2>&1; then
        if getent passwd wurb >/dev/null 2>&1; then user=wurb; else user=root; fi
    fi
    printf '%s\n' "$user"
}

backup_root_for_client() {
    local user home
    user="$(client_identity)"
    home="$(getent passwd "$user" | cut -d: -f6)"
    [[ "$home" == /* && "$home" != / ]] || return 1
    printf '%s/witty-backups\n' "${home%/}"
}

archive_helper() {
    local candidate=""
    for candidate in "$APP_ROOT/web/server.py" "$SCRIPT_DIR/../web/server.py"; do
        [[ -f "$candidate" ]] && { printf '%s\n' "$candidate"; return 0; }
    done
    return 1
}

control_backup() {
    local software="$1" installed helper root user group output rc file
    validate_software "$software" config-backup
    require_root config-backup "$software"
    installed="$(installed_state "$software")"
    [[ "$installed" == yes ]] || control_error config-backup "$software" "software-not-installed" \
        "The selected software is not installed completely." "$EXIT_NOT_INSTALLED"
    helper="$(archive_helper || true)"; root="$(backup_root_for_client || true)"
    [[ -n "$helper" && -n "$root" ]] || control_error config-backup "$software" "backup-helper-unavailable" \
        "The backup helper or client home directory is unavailable." "$EXIT_BACKUP"
    user="$(client_identity)"; group="$(id -gn "$user")"
    install -d -o "$user" -g "$group" -m 0750 "$root" || \
        control_error config-backup "$software" "backup-directory-failed" "The backup directory could not be created." "$EXIT_BACKUP"
    output="$(python3 "$helper" --automation-config-backup "$software" "$root" 2>&1)"; rc=$?
    (( rc == 0 )) || control_error config-backup "$software" "backup-failed" "$output" "$EXIT_BACKUP"
    file="$(tail -n 1 <<<"$output")"
    [[ -f "$file" && "$file" == "$root"/* && ! -L "$file" ]] || \
        control_error config-backup "$software" "backup-result-invalid" "The backup helper returned an invalid file." "$EXIT_BACKUP"
    chown "$user:$group" "$file"; chmod 0640 "$file"
    printf '[WITTY-CONTROL]\nACTION=config-backup\nSOFTWARE=%s\nRESULT=success\nFILE=%s\n[/WITTY-CONTROL]\n' \
        "$software" "$(clean_value "$file")"
}

control_upload_path() {
    local software="$1" root user group
    validate_software "$software" config-upload-path
    require_root config-upload-path "$software"
    root="$(backup_root_for_client || true)"
    [[ -n "$root" ]] || control_error config-upload-path "$software" "backup-directory-unavailable" \
        "The client upload directory is unavailable." "$EXIT_BACKUP"
    user="$(client_identity)"; group="$(id -gn "$user")"
    install -d -o "$user" -g "$group" -m 0750 "$root" || \
        control_error config-upload-path "$software" "backup-directory-failed" \
            "The upload directory could not be created." "$EXIT_BACKUP"
    printf '[WITTY-CONTROL]\nACTION=config-upload-path\nSOFTWARE=%s\nRESULT=success\nDIR=%s\n[/WITTY-CONTROL]\n' \
        "$software" "$(clean_value "$root")"
}

control_delete_backup() {
    local software="$1" supplied="${2:-}" root resolved root_resolved
    validate_software "$software" config-delete
    require_root config-delete "$software"
    root="$(backup_root_for_client || true)"
    [[ -n "$root" && "$supplied" == /* && ! -L "$supplied" && -f "$supplied" ]] || \
        control_error config-delete "$software" "invalid-backup-path" "The backup path is invalid." "$EXIT_BACKUP"
    resolved="$(realpath -e -- "$supplied" 2>/dev/null || true)"
    root_resolved="$(realpath -e -- "$root" 2>/dev/null || true)"
    [[ -n "$resolved" && -n "$root_resolved" && "$resolved" == "$root_resolved"/* ]] || \
        control_error config-delete "$software" "backup-outside-upload-directory" \
            "The backup is outside the client backup directory." "$EXIT_BACKUP"
    rm -f -- "$resolved"
    printf '[WITTY-CONTROL]\nACTION=config-delete\nSOFTWARE=%s\nRESULT=success\n[/WITTY-CONTROL]\n' "$software"
}

control_restore() {
    local software="$1" supplied="${2:-}" installed helper root resolved root_resolved output rc
    validate_software "$software" config-restore
    require_root config-restore "$software"
    [[ -n "$supplied" ]] || control_error config-restore "$software" "backup-file-required" \
        "A backup file path is required." "$EXIT_INVALID"
    installed="$(installed_state "$software")"
    [[ "$installed" == yes ]] || control_error config-restore "$software" "software-not-installed" \
        "The selected software is not installed completely." "$EXIT_NOT_INSTALLED"
    root="$(backup_root_for_client || true)"; helper="$(archive_helper || true)"
    [[ -n "$root" && -n "$helper" ]] || control_error config-restore "$software" "restore-helper-unavailable" \
        "The restore helper or client home directory is unavailable." "$EXIT_BACKUP"
    [[ "$supplied" == /* && ! -L "$supplied" && -f "$supplied" ]] || \
        control_error config-restore "$software" "invalid-backup-path" "The backup must be a regular absolute file." "$EXIT_BACKUP"
    resolved="$(realpath -e -- "$supplied" 2>/dev/null || true)"
    root_resolved="$(realpath -e -- "$root" 2>/dev/null || true)"
    [[ -n "$resolved" && -n "$root_resolved" && "$resolved" == "$root_resolved"/* ]] || \
        control_error config-restore "$software" "backup-outside-upload-directory" \
            "The backup must be inside the SSH user's witty-backups directory." "$EXIT_BACKUP"
    [[ "$(basename "$resolved")" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{0,159}\.tar\.gz$ ]] || \
        control_error config-restore "$software" "invalid-backup-filename" "The backup filename is not allowed." "$EXIT_BACKUP"
    output="$(python3 "$helper" --automation-config-restore "$software" "$resolved" 2>&1)"; rc=$?
    (( rc == 0 )) || control_error config-restore "$software" "restore-failed" "$output" "$EXIT_BACKUP"
    rm -f -- "$resolved"
    printf '[WITTY-CONTROL]\nACTION=config-restore\nSOFTWARE=%s\nRESULT=success\nFILE=%s\n[/WITTY-CONTROL]\n' \
        "$software" "$(clean_value "$resolved")"
}

find_update_launcher() {
    local user home candidate=""
    user="$(client_identity)"; home="$(getent passwd "$user" | cut -d: -f6)"
    for candidate in "$home/update.sh" /home/wurb/update.sh; do
        [[ -f "$candidate" ]] && { printf '%s\n' "$candidate"; return 0; }
    done
    return 1
}

control_update() {
    local launcher rc
    require_root update ""
    launcher="$(find_update_launcher || true)"
    [[ -n "$launcher" ]] || control_error update "" "update-launcher-not-found" \
        "Place the general update.sh in the SSH user's home directory." "$EXIT_UPDATE"
    printf '[WITTY-CONTROL]\nACTION=update\nSTATE=started\n[/WITTY-CONTROL]\n'
    bash "$launcher" >&2; rc=$?
    if (( rc != 0 )); then
        control_error update "" "update-failed" \
            "The update launcher returned exit code $rc. See stderr for details." "$EXIT_UPDATE"
    fi
    printf '[WITTY-CONTROL]\nACTION=update\nSTATE=finished\nRESULT=success\n[/WITTY-CONTROL]\n'
}

valid_timezone() {
    local zone="$1"
    [[ -n "$zone" && "$zone" != Witty/FixedOffset ]] || return 1
    timedatectl list-timezones 2>/dev/null | grep -Fxq "$zone"
}

persist_installer_timezone() {
    local zone="$1" temporary
    temporary="$(mktemp /var/tmp/witty-addon-conf.XXXXXX)"
    if [[ -r /etc/witty-addon.conf ]]; then
        grep -v '^TIMEZONE=' /etc/witty-addon.conf >"$temporary" || true
    fi
    printf 'TIMEZONE=%s\n' "$zone" >>"$temporary"
    install -o root -g root -m 0644 "$temporary" /etc/witty-addon.conf
    rm -f -- "$temporary"
}

run_installed_compatibility_check() {
    local software="$1" unit="$2" label="$3" helper="$4" mode="$5" limit="$6"
    local was_active=false rc=0
    [[ "$(installed_state "$software")" == yes ]] || {
        printf '%s ist nicht installiert; keine Kompatibilitätsänderung.\n' "$label" >&2
        return 0
    }
    [[ -x "$helper" ]] || {
        printf 'FEHLER: Die geprüfte %s-Kompatibilitätsroutine fehlt: %s\n' "$label" "$helper" >&2
        return 1
    }
    systemctl is-active --quiet "$unit" && was_active=true
    if $was_active; then
        printf '%s wird nur für seine eigene Kompatibilitätsprüfung angehalten ...\n' "$label" >&2
        timeout 45s systemctl stop "$unit" >&2 || return 1
    fi
    timeout --foreground --kill-after=30s "$limit" "$helper" "$mode" >&2 || rc=$?
    if $was_active; then
        systemctl reset-failed "$unit" >/dev/null 2>&1 || true
        timeout 45s systemctl start "$unit" >&2 || rc=1
    fi
    (( rc == 0 )) || return "$rc"
    printf '%s-Kompatibilitätsprüfung erfolgreich; andere Anwendungsdienste blieben unberührt.\n' "$label" >&2
}

post_linux_compatibility() {
    printf 'Prüfe installierte Anwendungen mit den versionierten Witty-Routinen ...\n' >&2
    run_installed_compatibility_check wurb wurb_2026.service WURB \
        /usr/local/sbin/witty-cloudedbats-trixie-compat verify-wurb 700 || return 1
    run_installed_compatibility_check wirc wirc_2026.service WIRC \
        /usr/local/sbin/witty-cloudedbats-trixie-compat verify-wirc 700 || return 1
    run_installed_compatibility_check allsky allsky.service Allsky \
        /usr/local/sbin/witty-allsky-trixie-compat repair 360 || return 1
}

control_linux_update() {
    local saved_timezone="" current_timezone="" rc=0 timezone_rc=0 gps_mode=""
    require_root linux-update ""
    if [[ ! -t 0 || ! -t 1 ]]; then
        printf '[WITTY-CONTROL]\nACTION=linux-update\nRESULT=interactive-required\nPTY_REQUIRED=yes\n[/WITTY-CONTROL]\n'
        exit "$EXIT_INTERACTIVE"
    fi
    command -v apt-get >/dev/null 2>&1 || control_error linux-update "" apt-missing \
        "apt-get was not found." "$EXIT_UPDATE"
    command -v timedatectl >/dev/null 2>&1 || control_error linux-update "" timedatectl-missing \
        "timedatectl was not found." "$EXIT_UPDATE"

    saved_timezone="$(config_value TIMEZONE 2>/dev/null || true)"
    if ! valid_timezone "$saved_timezone"; then
        current_timezone="$(timedatectl show --property=Timezone --value 2>/dev/null || true)"
        if [[ "$current_timezone" == Witty/FixedOffset ]]; then
            current_timezone="$(tr -d '\r\n' </var/lib/witty-addon/previous_timezone 2>/dev/null || true)"
        fi
        valid_timezone "$current_timezone" && saved_timezone="$current_timezone" || saved_timezone=Etc/UTC
    fi
    persist_installer_timezone "$saved_timezone"
    trap 'timedatectl set-timezone "$saved_timezone" >/dev/null 2>&1 || true' EXIT

    printf '[WITTY-CONTROL]\nACTION=linux-update\nSTATE=started\nPTY_REQUIRED=yes\nTIMEZONE=%s\n[/WITTY-CONTROL]\n' \
        "$(clean_value "$saved_timezone")"
    printf 'Linux-Paketupdate startet ohne Debconf-Menüs. Gespeicherte Zeitzone: %s\n' "$saved_timezone" >&2
    export DEBIAN_FRONTEND=noninteractive
    export APT_LISTCHANGES_FRONTEND=none
    export NEEDRESTART_MODE=a
    dpkg --force-confold --configure -a >&2 || rc=$?
    if (( rc == 0 )); then
        apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 -o DPkg::Lock::Timeout=120 update >&2 || rc=$?
    fi
    if (( rc == 0 )); then
        apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 -o DPkg::Lock::Timeout=120 \
            -o Dpkg::Options::=--force-confold -y full-upgrade >&2 || rc=$?
    fi

    printf 'Stelle die während der Witty-Installation gespeicherte Zeitzone wieder her: %s\n' "$saved_timezone" >&2
    timedatectl set-timezone "$saved_timezone" >&2 || timezone_rc=$?
    if (( timezone_rc != 0 )); then
        control_error linux-update "" timezone-restore-failed \
            "The saved Witty installation timezone could not be restored." "$EXIT_UPDATE"
    fi
    if (( rc != 0 )); then
        control_error linux-update "" linux-update-failed \
            "The Linux package update failed with exit code $rc. The saved timezone was restored." "$EXIT_UPDATE"
    fi
    if ! post_linux_compatibility; then
        control_error linux-update "" post-update-compatibility-failed \
            "A compatibility check for an installed application failed. Its service state was restored where possible." "$EXIT_UPDATE"
    fi
    gps_mode="$(config_value GPS_MODE 2>/dev/null || true)"
    if [[ "$gps_mode" =~ ^(usb|waveshare_l76x)$ && -x /usr/local/sbin/witty-time-sync ]]; then
        timeout 20s /usr/local/sbin/witty-time-sync schedule-dst >/dev/null 2>&1 || true
    fi
    trap - EXIT
    printf '[WITTY-CONTROL]\nACTION=linux-update\nSTATE=finished\nRESULT=success\nTIMEZONE=%s\n[/WITTY-CONTROL]\n' \
        "$(clean_value "$saved_timezone")"
}

usage() {
    cat >&2 <<'EOF'
Usage: sudo windows_control.sh COMMAND [SOFTWARE] [BACKUP_FILE]
Commands: status, version, service-start, service-stop, install, reinstall,
          uninstall, update, witty-software-update, linux-update,
          config-backup, config-upload-path, config-delete, config-restore
Software: wurb, wirc, allsky
EOF
}

action="${1:-}"
case "$action" in
    status) [[ "$#" -eq 1 ]] || control_error status "" invalid-parameter "status takes no parameter." "$EXIT_INVALID"; show_status ;;
    version) [[ "$#" -eq 1 ]] || control_error version "" invalid-parameter "version takes no parameter." "$EXIT_INVALID"; show_version ;;
    service-start|service-stop)
        [[ "$#" -eq 2 ]] || control_error "$action" "${2:-}" invalid-parameter "$action requires exactly one SOFTWARE parameter." "$EXIT_INVALID"
        control_service "$action" "$2"
        ;;
    install|reinstall|uninstall)
        [[ "$#" -eq 2 ]] || control_error "$action" "${2:-}" invalid-parameter "$action requires exactly one SOFTWARE parameter." "$EXIT_INVALID"
        control_software "$action" "$2"
        ;;
    update) [[ "$#" -eq 1 ]] || control_error update "" invalid-parameter "update takes no parameter." "$EXIT_INVALID"; control_update ;;
    witty-software-update) [[ "$#" -eq 1 ]] || control_error witty-software-update "" invalid-parameter "witty-software-update takes no parameter." "$EXIT_INVALID"; control_witty_software_update ;;
    linux-update) [[ "$#" -eq 1 ]] || control_error linux-update "" invalid-parameter "linux-update takes no parameter." "$EXIT_INVALID"; control_linux_update ;;
    config-backup)
        [[ "$#" -eq 2 ]] || control_error config-backup "${2:-}" invalid-parameter "config-backup requires exactly one SOFTWARE parameter." "$EXIT_INVALID"
        control_backup "$2"
        ;;
    config-upload-path)
        [[ "$#" -eq 2 ]] || control_error config-upload-path "${2:-}" invalid-parameter "config-upload-path requires exactly one SOFTWARE parameter." "$EXIT_INVALID"
        control_upload_path "$2"
        ;;
    config-delete)
        [[ "$#" -eq 3 ]] || control_error config-delete "${2:-}" invalid-parameter "config-delete requires SOFTWARE and BACKUP_FILE." "$EXIT_INVALID"
        control_delete_backup "$2" "$3"
        ;;
    config-restore)
        [[ "$#" -eq 3 ]] || control_error config-restore "${2:-}" invalid-parameter "config-restore requires SOFTWARE and BACKUP_FILE." "$EXIT_INVALID"
        control_restore "$2" "$3"
        ;;
    *) usage; control_error "${action:-unknown}" "" invalid-command "The command is not supported." "$EXIT_INVALID" ;;
esac

exit "$EXIT_SUCCESS"
