#!/usr/bin/env bash
set -Eeuo pipefail
[[ "${EUID:-$(id -u)}" -eq 0 ]] || { echo "Bitte mit sudo starten." >&2; exit 1; }
work_dir="$(mktemp -d /var/tmp/wittypi5-webserver-install.XXXXXX)"
trap 'rm -rf -- "$work_dir"' EXIT
archive="${1:-${WITTY_ADDON_LOCAL_ZIP:-}}"
if [[ -z "$archive" ]]; then
    caller="${SUDO_USER:-$(id -un)}"
    caller_home="$(getent passwd "$caller" 2>/dev/null | cut -d: -f6)"
    archive="${caller_home:-/home/$caller}/witty_addon.zip"
fi
[[ -f "$archive" && -r "$archive" ]] || {
    echo "Keine vorbereitete witty_addon.zip gefunden. Bitte zuerst Raspi-Scripte 0.6 verwenden." >&2
    exit 2
}
unzip -tq "$archive" >/dev/null
unzip -q "$archive" -d "$work_dir/files"
bash "$work_dir/files/witty_addon/install.sh"
