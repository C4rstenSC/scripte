#!/usr/bin/env bash
set -Eeuo pipefail
readonly URL="https://raw.githubusercontent.com/C4rstenSC/scripte/main/RaspberryPI_Addons/Witty%20PI%20Addon/witty_addon.zip"
[[ "${EUID:-$(id -u)}" -eq 0 ]] || { echo "Bitte mit sudo starten." >&2; exit 1; }
work_dir="$(mktemp -d /var/tmp/wittypi5-webserver-install.XXXXXX)"
trap 'rm -rf -- "$work_dir"' EXIT
curl -fsSL --retry 3 -o "$work_dir/witty_addon.zip" "$URL"
unzip -tq "$work_dir/witty_addon.zip" >/dev/null
unzip -q "$work_dir/witty_addon.zip" -d "$work_dir/files"
bash "$work_dir/files/witty_addon/install.sh"
