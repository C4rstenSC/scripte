#!/usr/bin/env bash
set -Eeuo pipefail

# Privilegierter Befehlsadapter fuer die Witty-Pi-5-Webseite.
# Jeder wp5-Aufruf wird serialisiert; ein aktiver wp5d wird kurz angehalten und
# danach wieder gestartet. Dadurch entsteht keine zweite parallele wp5-Instanz.

readonly LOCK_FILE="/run/lock/witty-addon.lock"
readonly STATE_DIR="/var/lib/witty-addon"
readonly SELF_PATH="$(readlink -f "$0")"
readonly APP_DIR="$(dirname "$(dirname "$SELF_PATH")")"
readonly LOG_DIR="$APP_DIR/logs"
readonly LOG_PROGRESS_FILE="$LOG_DIR/.log-download-active"
readonly RESET_PROGRESS_FILE="$STATE_DIR/reset-progress.json"
readonly OFFSET_FILE="$STATE_DIR/fixed_offset_minutes"
readonly PREVIOUS_TZ_FILE="$STATE_DIR/previous_timezone"
readonly GPS_TIME_CACHE_FILE="$STATE_DIR/last_gps_time"
readonly GPS_FIX_CACHE_FILE="$STATE_DIR/last_gps_fix"
readonly WP5_BIN="${WP5_BIN:-/usr/local/bin/wp5}"
mkdir -p "$STATE_DIR" "$LOG_DIR"
exec 9>"$LOCK_FILE"
flock -w 150 9 || { printf '{"ok":false,"error":"Witty ist beschaeftigt"}\n'; exit 1; }

RESET_ACTIVE=false

json_escape() {
    local value="${1-}"
    value=${value//\\/\\\\}; value=${value//\"/\\\"}
    value=${value//$'\n'/\\n}; value=${value//$'\r'/\\r}; value=${value//$'\t'/\\t}
    printf '%s' "$value"
}

reset_progress() {
    local state="$1" phase="$2" current="${3:-0}" total="${4:-1}" detail="${5:-}" started_at="${6:-$(date +%s)}"
    local percent=0 temporary="${RESET_PROGRESS_FILE}.tmp.$$"
    (( total > 0 )) && percent=$((current * 100 / total))
    (( percent > 100 )) && percent=100
    printf '{"ok":true,"active":%s,"state":"%s","phase":"%s","current":%s,"total":%s,"percent":%s,"detail":"%s","started_at":%s,"updated_at":%s}\n' \
        "$([[ "$state" == running ]] && printf true || printf false)" \
        "$(json_escape "$state")" "$(json_escape "$phase")" "$current" "$total" "$percent" \
        "$(json_escape "$detail")" "$started_at" "$(date +%s)" >"$temporary"
    chmod 0644 "$temporary"
    mv -f "$temporary" "$RESET_PROGRESS_FILE"
}

fail() {
    if $RESET_ACTIVE; then
        reset_progress failed failed 0 1 "$1" "${RESET_STARTED_AT:-$(date +%s)}" || true
    fi
    printf '{"ok":false,"error":"%s"}\n' "$(json_escape "$1")"
    exit 1
}
success() { printf '{"ok":true,"message":"%s"}\n' "$(json_escape "${1:-OK}")"; }

wait_for_wirc_service() {
    local attempt consecutive=0
    for attempt in $(seq 1 90); do
        if systemctl is-active --quiet wirc_2026.service && \
                timeout 1s bash -c '</dev/tcp/127.0.0.1/8082' >/dev/null 2>&1; then
            consecutive=$((consecutive + 1))
            (( consecutive >= 35 )) && return 0
        else
            consecutive=0
        fi
        sleep 1
    done
    return 1
}

wait_for_wurb_service() {
    local attempt consecutive=0
    for attempt in $(seq 1 75); do
        if systemctl is-active --quiet wurb_2026.service && \
                timeout 1s bash -c '</dev/tcp/127.0.0.1/8080' >/dev/null 2>&1; then
            consecutive=$((consecutive + 1))
            (( consecutive >= 20 )) && return 0
        else
            consecutive=0
        fi
        sleep 1
    done
    return 1
}

wirc_failure_details() {
    local details
    details="$(journalctl -u wirc_2026.service -n 35 --no-pager --output=cat 2>&1 || true)"
    printf '%s' "${details:-WIRC hat keine Diagnosemeldung geliefert}"
}

find_wp5() {
    local candidate
    for candidate in "$WP5_BIN" /usr/bin/wp5 /usr/local/sbin/wp5 /home/*/Witty-Pi-5-Software/wp5 /home/*/witty-pi-5-software/wp5; do
        [[ -x "$candidate" ]] && { printf '%s\n' "$candidate"; return; }
    done
    return 1
}

run_wp5() {
    local input="$1" max_seconds="${2:-45}" working_dir="${3:-$STATE_DIR}" output service_was_active=0 wp5
    wp5="$(find_wp5)" || fail "wp5 wurde nicht gefunden"
    systemctl is-active --quiet wp5d.service && service_was_active=1 || true
    if (( service_was_active )); then
        systemctl stop wp5d.service || fail "wp5d konnte nicht angehalten werden"
    fi
    output="$(cd "$working_dir" && timeout "${max_seconds}s" "$wp5" <<<"$input" 2>&1)" || {
        local rc=$?
        (( service_was_active )) && systemctl start wp5d.service || true
        fail "wp5-Aufruf fehlgeschlagen (Code $rc): $output"
    }
    (( service_was_active )) && systemctl start wp5d.service || true
    printf '%s\n' "$output"
}

probe_wp5() {
    local input="$1" output service_was_active=0 wp5
    wp5="$(find_wp5)" || fail "wp5 wurde nicht gefunden"
    systemctl is-active --quiet wp5d.service && service_was_active=1 || true
    (( service_was_active )) && systemctl stop wp5d.service || true
    set +e
    output="$(cd "$STATE_DIR" && timeout 12s "$wp5" <<<"$input" 2>&1)"
    set -e
    (( service_was_active )) && systemctl start wp5d.service || true
    printf '%s\n' "$output"
}

remote_file_index() {
    local menu_option="$1" filename="$2" allow_unique_prefix="${3:-false}" output escaped prefix_match
    # Leere Eingabe bricht die Dateiauswahl ab, 5 verlaesst das Untermenue und
    # 14 beendet wp5. Ohne diese Eingaben wartet wp5 rekursiv bis zum Timeout.
    output="$(probe_wp5 $'6\n'"$menu_option"$'\n\n5\n14')"
    escaped="$(printf '%s' "$filename" | sed 's/[][\\.^$*+?{}|()]/\\&/g')"
    # Unterstützt u.a. "[1] name", "1) name", "1 - name" sowie
    # nachgestellte Kennzeichnungen wie "(in use)" oder "(active)".
    if sed -nE "s/^[[:space:]]*[([]?([0-9]+)[])]?[[:space:].:-]+$escaped([[:space:]]+.*)?[[:space:]]*$/\\1/Ip" \
            <<<"$output" | tail -n1 | grep -E '^[0-9]+$'; then
        return 0
    fi
    [[ "$allow_unique_prefix" == true ]] || return 0

    # Einige Firmwarestaende kuerzen lange Namen bei der Dateiauflistung.
    # Nur eine einzige, ausreichend lange Praefix-Uebereinstimmung akzeptieren,
    # damit niemals eine nur aehnlich benannte Datei geloescht wird.
    prefix_match="$(sed -nE 's/^[[:space:]]*[([]?([0-9]+)[])]?[[:space:].:-]+([^[:space:]]+\.wpi)([[:space:]]+.*)?[[:space:]]*$/\1\t\2/Ip' \
        <<<"$output" | awk -F '\t' -v target="${filename,,}" '
            {
                name=tolower($2)
                if (length(name) >= 16 && (index(target,name)==1 || index(name,target)==1)) {
                    count++; found=$1
                }
            }
            END { if (count == 1) print found }
        ')"
    if [[ "$prefix_match" =~ ^[0-9]+$ ]]; then
        printf '%s\n' "$prefix_match"
    fi
    # "Nicht gefunden" ist ein gueltiges Suchergebnis. Der Aufrufer
    # entscheidet anschliessend, ob eine lokale Kopie verwendet werden kann.
    return 0
}

local_file_index() {
    local filename="$1"
    find "$STATE_DIR" -maxdepth 1 -type f \
        \( -iname '*.wpi' -o -iname '*.act' -o -iname '*.skd' \) -printf '%f\n' 2>/dev/null \
        | sort -f | awk -v target="$filename" '$0 == target { print NR; exit }'
}

remote_schedule_files() {
    local output
    # Aktivierung blendet das aktive Skript aus; Download zeigt alle Dateien.
    output="$(probe_wp5 $'6\n2\n\n5\n14')"
    output+=$'\n'"$(probe_wp5 $'6\n3\n\n5\n14')"
    # In der Weboberflaeche nur vom Benutzer verwaltbare WPI-Quelldateien
    # anzeigen. Interne Eintraege wie "schedule" sowie ACT/SKD-Ausgaben
    # gehoeren nicht in diese Liste.
    sed -nE 's/^[[:space:]]*[([]?[0-9]+[])]?[[:space:].:-]+([^[:space:]]+\.wpi)([[:space:]]+.*)?[[:space:]]*$/\1/Ip' \
        <<<"$output" | awk 'tolower($0) != "schedule.wpi"' | sort -fu
}

schedule_list_json() {
    local active file separator=""
    if schedule_is_in_use; then
        active="$(tracked_schedule_name)"
    else
        active=""
        rm -f -- "$STATE_DIR/active_schedule_name"
    fi
    printf '{"ok":true,"active":"%s","files":[' "$(json_escape "$active")"
    while IFS= read -r file; do
        [[ -n "$file" ]] || continue
        printf '%s"%s"' "$separator" "$(json_escape "$file")"
        separator=,
    done < <({ remote_schedule_files; find "$STATE_DIR" -maxdepth 1 -type f \
        -iname '*.wpi' ! -iname 'schedule.wpi' -printf '%f\n' 2>/dev/null; } | sort -fu)
    printf ']}\n'
}

schedule_is_in_use() {
    local output
    output="$(probe_wp5 $'14')"
    grep -qiE 'Manage schedule scripts.*\(in use\)|schedule scripts.*in use' <<<"$output"
}

expand_next_event() {
    local raw="$1" day clock candidate
    [[ "$raw" =~ ^([0-9]{1,2})[[:space:]]+([0-9]{2}:[0-9]{2}:[0-9]{2})$ ]] || { printf '%s\n' "$raw"; return; }
    day="${BASH_REMATCH[1]}"; clock="${BASH_REMATCH[2]}"
    candidate="$(date -d "$(date +%Y-%m)-$day $clock" --iso-8601=seconds 2>/dev/null || true)"
    if [[ -n "$candidate" ]] && (( $(date -d "$candidate" +%s) <= $(date +%s) )); then
        candidate="$(date -d "$(date -d 'next month' +%Y-%m)-$day $clock" --iso-8601=seconds 2>/dev/null || true)"
    fi
    printf '%s\n' "${candidate:-$raw}"
}

tracked_schedule_name() {
    local tracked
    tracked="$(cat "$STATE_DIR/active_schedule_name" 2>/dev/null || true)"
    printf '%s\n' "${tracked:-schedule.wpi}"
}

make_firmware_safe_schedule_copy() {
    local source_name="$1" base prefix digest safe_name
    base="${source_name%.[Ww][Pp][Ii]}"
    base="$(printf '%s' "$base" | sed 's/[^A-Za-z0-9._-]/_/g; s/^[^A-Za-z0-9]*//')"
    prefix="${base:0:20}"
    [[ -n "$prefix" ]] || prefix="witty-script"
    digest="$(sha256sum "$STATE_DIR/$source_name" | cut -c1-6)"
    safe_name="${prefix}-${digest}.wpi"
    install -m 0644 "$STATE_DIR/$source_name" "$STATE_DIR/$safe_name"
    printf '%s\n' "$safe_name"
}

upload_local_schedule() {
    local filename="$1" local_index upload_output attempt detail
    local_index="$(local_file_index "$filename")"
    [[ "$local_index" =~ ^[0-9]+$ ]] || fail "Die lokale Datei $filename wurde nicht gefunden"
    for attempt in 1 2 3; do
        upload_output="$(run_wp5 $'6\n1\n'"$local_index"$'\n5\n14')"
        if grep -Fqi "Uploaded $filename to Witty Pi." <<<"$upload_output"; then
            sleep 2
            return 0
        fi
        (( attempt < 3 )) && sleep 3
    done
    detail="$(grep -iE 'upload failed|invalid packet|file too large|device is busy|I/O error|failed to send' \
        <<<"$upload_output" | tail -n1 | sed 's/^[[:space:]]*//' || true)"
    fail "Witty hat den Upload nach drei Versuchen nicht bestaetigt. Firmwaremeldung: ${detail:-keine Detailmeldung}. Datei: $filename ($(wc -c <"$STATE_DIR/$filename") Byte)"
}

ACTIVATION_OUTPUT=""
activate_remote_schedule() {
    local filename="$1" attempt index
    ACTIVATION_OUTPUT=""
    for attempt in 1 2 3; do
        index="$(remote_file_index 2 "$filename")"
        # Ein bereits aktives Skript wird von der Aktivierungsliste verborgen.
        [[ "$index" =~ ^[0-9]+$ ]] || return 2
        ACTIVATION_OUTPUT="$(run_wp5 $'6\n2\n'"$index"$'\n5\n14')"
        if ! grep -qiE 'activation failed|failed|not found|invalid|requires firmware|timed out|I/O error' \
                <<<"$ACTIVATION_OUTPUT" \
                && grep -qiE 'Waiting for script processing.*done|Scheduled (startup|shutdown)' \
                <<<"$ACTIVATION_OUTPUT"; then
            return 0
        fi
        (( attempt < 3 )) && sleep 3
    done
    return 1
}

gps_fix() {
    local allow_cache="${1:-false}" value timestamp now cached cached_fix cached_latitude cached_longitude live_latitude live_longitude temporary
    command -v gpspipe >/dev/null 2>&1 || return 1
    command -v jq >/dev/null 2>&1 || return 1
    # Sofort den ersten gültigen TPV-Fix verwenden. Die frühere Variante wartete
    # noch auf insgesamt zwölf gpsd-Meldungen und setzte dadurch eine alte Zeit.
    value="$(set +o pipefail; timeout 4s gpspipe -w 2>/dev/null | jq -sr \
        '[.[] | select(.class=="TPV" and .time)] as $all
         | if ($all | length) == 0 then empty
           else ([$all[] | select((.mode // 0) >= 2 and .lat != null and .lon != null)] | last) as $position
           | ($all | last) as $latest
           | "\($latest.time)|\($position.lat // "")|\($position.lon // "")"
           end')"
    timestamp="${value%%|*}"
    if [[ -n "$timestamp" ]] && date -d "$timestamp" +%s >/dev/null 2>&1; then
        date +%s >"$GPS_TIME_CACHE_FILE"
        IFS='|' read -r _ live_latitude live_longitude <<<"$value"
        if [[ "$live_latitude" =~ ^-?[0-9]+([.][0-9]+)?$ && "$live_longitude" =~ ^-?[0-9]+([.][0-9]+)?$ ]]; then
            temporary="${GPS_FIX_CACHE_FILE}.tmp.$$"
            printf '%s\n' "$value" >"$temporary"
            chmod 0644 "$temporary"
            mv -f "$temporary" "$GPS_FIX_CACHE_FILE"
        fi
        printf '%s\n' "$value"
        return 0
    fi
    [[ "$allow_cache" == true ]] || return 1
    cached="$(cat "$GPS_TIME_CACHE_FILE" 2>/dev/null || true)"; now="$(date +%s)"
    if [[ "$cached" =~ ^[0-9]+$ ]] && (( now >= cached && now - cached <= 900 )); then
        cached_fix="$(cat "$GPS_FIX_CACHE_FILE" 2>/dev/null || true)"
        IFS='|' read -r _ cached_latitude cached_longitude <<<"$cached_fix"
        if [[ "$cached_latitude" =~ ^-?[0-9]+([.][0-9]+)?$ && "$cached_longitude" =~ ^-?[0-9]+([.][0-9]+)?$ ]]; then
            printf '%s|%s|%s\n' "$(date -u --iso-8601=seconds)" "$cached_latitude" "$cached_longitude"
        else
            printf '%s||\n' "$(date -u --iso-8601=seconds)"
        fi
        return 0
    fi
    return 1
}

gps_time() {
    local value timestamp latitude longitude
    value="$(gps_fix "${1:-false}")" || return 1
    IFS='|' read -r timestamp latitude longitude <<<"$value"
    # Für automatische Uhrkorrekturen reicht eine bloße gpsd-Zeitmeldung nicht.
    # Erst ein echter 2D/3D-Fix mit plausibler Position darf System und RTCs
    # verändern; so löst ein Startwert keinen falschen Abschalttermin aus.
    [[ "$latitude" =~ ^-?[0-9]+([.][0-9]+)?$ && "$longitude" =~ ^-?[0-9]+([.][0-9]+)?$ ]] || return 1
    printf '%s\n' "$timestamp"
}

wurb_coordinates() {
    local database
    command -v python3 >/dev/null 2>&1 || return 1
    for database in /home/wurb/wurb_settings/wurb_settings.db /home/*/wurb_settings/wurb_settings.db; do
        [[ -r "$database" ]] || continue
        python3 - "$database" <<'PY' 2>/dev/null && return 0
import sqlite3
import sys

path = sys.argv[1]
connection = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=0.5)
try:
    values = dict(connection.execute(
        "SELECT key, value FROM key_value_data WHERE identity='location'"
    ).fetchall())
finally:
    connection.close()

def number(key):
    try:
        return float(values.get(key, 0.0) or 0.0)
    except (TypeError, ValueError):
        return 0.0

latitude = number("latitudeDd")
longitude = number("longitudeDd")
source = str(values.get("geoSource", ""))
if latitude == 0.0 or longitude == 0.0:
    if source == "geo-gps-or-last-found":
        latitude = number("lastGpsLatitudeDd")
        longitude = number("lastGpsLongitudeDd")
    if latitude == 0.0 or longitude == 0.0:
        latitude = number("defaultLatitudeDd")
        longitude = number("defaultLongitudeDd")
if latitude == 0.0 or longitude == 0.0 or not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
    raise SystemExit(1)
print(f"{latitude:.7f}|{longitude:.7f}")
PY
    done
    return 1
}

detect_gps_mode() {
    local device
    # The bridge is shared by USB and GPIO receivers and therefore cannot
    # identify a Waveshare board. Waveshare is reported only when the main
    # installer persisted GPS_MODE=waveshare_l76x or configured gpsd for its
    # UART device. The USB installer writes DEVICES="" instead.
    if [[ -r /etc/default/gpsd ]] && \
       grep -Eq '^[[:space:]]*DEVICES="/dev/(ttyAMA0|serial0)"' /etc/default/gpsd; then
        printf 'waveshare_l76x\n'
        return
    fi
    for device in /dev/ttyACM* /dev/ttyUSB*; do
        [[ -e "$device" ]] || continue
        [[ "$device" == /dev/ttyUSB9 ]] && continue
        printf 'usb\n'
        return
    done
    printf 'unknown\n'
}

sync_internal_rtc() {
    local rtc_device
    rtc_device="$(internal_rtc_device || true)"
    if [[ -n "$rtc_device" ]] && command -v hwclock >/dev/null 2>&1; then
        timeout 8s hwclock --systohc --rtc "$rtc_device" >/dev/null 2>&1 || \
            fail "Systemzeit gesetzt, aber Raspberry-Pi-RTC konnte nicht geschrieben werden"
    fi
}

disable_automatic_time_sync() {
    timedatectl set-ntp false >/dev/null 2>&1 || \
        timeout 15s systemctl disable --now systemd-timesyncd.service >/dev/null 2>&1 || true
    [[ "$(timedatectl show --property=NTP --value 2>/dev/null || true)" != yes ]] || \
        fail "Automatische Netzwerk-Zeitsynchronisation konnte nicht deaktiviert werden"
}

pi_boot_config() {
    local candidate
    for candidate in /boot/firmware/config.txt /boot/config.txt; do
        [[ -f "$candidate" ]] && { printf '%s\n' "$candidate"; return 0; }
    done
    return 1
}

internal_rtc_boot_enabled() {
    local config_file
    config_file="$(pi_boot_config)" || return 1
    grep -Eq '^[[:space:]]*(dtoverlay=disable-rtc|dtparam=rtc=off)[[:space:]]*$' "$config_file" && return 1
    return 0
}

internal_rtc_boot_disabled() {
    local config_file
    config_file="$(pi_boot_config)" || return 1
    grep -Eq '^[[:space:]]*(dtoverlay=disable-rtc|dtparam=rtc=off)[[:space:]]*$' "$config_file"
}

set_internal_rtc_boot() {
    local enabled="$1" config_file
    config_file="$(pi_boot_config)" || fail "Raspberry-Pi-Bootkonfiguration wurde nicht gefunden"
    sed -i -E '/^[[:space:]]*(dtoverlay=disable-rtc|dtparam=rtc=(on|off))[[:space:]]*$/d' "$config_file"
    if [[ "$enabled" == true ]]; then
        printf 'dtparam=rtc=on\n' >>"$config_file"
    else
        printf 'dtparam=rtc=off\ndtoverlay=disable-rtc\n' >>"$config_file"
    fi
}

internal_rtc_device() {
    local rtc_path rtc_name device
    if [[ -r /etc/witty-addon.conf ]]; then
        # shellcheck disable=SC1091
        source /etc/witty-addon.conf
        [[ "${RPI_MODEL:-5}" == 4 ]] && return 1
    fi
    internal_rtc_boot_enabled || return 1
    # Raspberry Pi 5 meldet seine interne RTC normalerweise als rtc-rp5c01;
    # die Nummer kann je nach weiteren RTC-Treibern rtc0 oder rtc1 sein.
    for rtc_path in /sys/class/rtc/rtc*; do
        [[ -d "$rtc_path" ]] || continue
        rtc_name="$(cat "$rtc_path/name" 2>/dev/null || true)"
        if [[ "$rtc_name" =~ (rp5c01|raspberry|rpi) ]]; then
            device="/dev/$(basename "$rtc_path")"
            [[ -e "$device" ]] && { printf '%s\n' "$device"; return 0; }
        fi
    done
    # Kompatibilitaets-Fallback fuer Kernel, die keinen eindeutigen Namen
    # bereitstellen. Es wird bewusst nicht nur rtc0 angenommen.
    for device in /dev/rtc0 /dev/rtc1 /dev/rtc2; do
        [[ -e "$device" ]] && { printf '%s\n' "$device"; return 0; }
    done
    return 1
}

normalise_display_time() {
    local value="$1" mode="${2:-local}" now_epoch value_epoch difference
    [[ -n "$value" ]] || return 0
    now_epoch="$(date +%s)"
    value_epoch="$(date -d "$value" +%s 2>/dev/null || true)"
    if [[ "$value_epoch" =~ ^[0-9]+$ ]]; then
        difference=$((now_epoch - value_epoch)); (( difference < 0 )) && difference=$((-difference))
        # RTCs zeigen nur ganze Sekunden. Werte innerhalb einer Sekunde gehören
        # zum selben Messzeitpunkt und werden auf den Antwortzeitpunkt gebracht.
        if (( difference <= 5 )); then
            [[ "$mode" == utc ]] && date -u --iso-8601=seconds || date --iso-8601=seconds
            return
        fi
    fi
    printf '%s\n' "$value"
}

timezone_name() {
    timedatectl show --property=Timezone --value 2>/dev/null || printf 'Europe/Berlin\n'
}

apply_fixed_timezone() {
    local enabled="$1" selected_zone="$2" current offset_text offset sign absolute hours minutes zone_source
    [[ "$enabled" == true || "$enabled" == false ]] || fail "Ungueltiger Umschaltwert"
    command -v timedatectl >/dev/null 2>&1 || fail "timedatectl wurde nicht gefunden"
    timedatectl list-timezones | grep -Fxq "$selected_zone" || fail "Ungueltige Zeitzone: $selected_zone"
    if [[ "$enabled" == true ]]; then
        command -v zic >/dev/null 2>&1 || fail "zic aus dem Paket tzdata wurde nicht gefunden"
        current="$(timezone_name)"
        printf '%s\n' "$selected_zone" >"$PREVIOUS_TZ_FILE"
        offset_text="$(TZ="$selected_zone" date +%z)"
        hours=$((10#${offset_text:1:2})); minutes=$((10#${offset_text:3:2}))
        offset=$((hours * 60 + minutes))
        if [[ "${offset_text:0:1}" == "-" ]]; then offset=$((-offset)); fi
        sign="+"
        if (( offset < 0 )); then sign="-"; fi
        absolute=$(( offset < 0 ? -offset : offset )); hours=$((absolute / 60)); minutes=$((absolute % 60))
        zone_source="$STATE_DIR/fixed-offset.zone"
        printf 'Zone Witty/FixedOffset %s%02d:%02d - WIT\n' "$sign" "$hours" "$minutes" >"$zone_source"
        zic -d /usr/share/zoneinfo "$zone_source" || fail "Feste Zeitzone konnte nicht erstellt werden"
        timedatectl set-timezone Witty/FixedOffset || fail "Feste Zeitzone konnte nicht aktiviert werden"
        printf '%s\n' "$offset" >"$OFFSET_FILE"
    else
        timedatectl set-timezone "$selected_zone" || fail "Zeitzone $selected_zone konnte nicht aktiviert werden"
        printf '%s\n' "$selected_zone" >"$PREVIOUS_TZ_FILE"
        offset_text="$(date +%z)"; hours=$((10#${offset_text:1:2})); minutes=$((10#${offset_text:3:2}))
        offset=$((hours * 60 + minutes))
        if [[ "${offset_text:0:1}" == "-" ]]; then offset=$((-offset)); fi
        printf '%s\n' "$offset" >"$OFFSET_FILE"
    fi
    run_wp5 $'1\n14' >/dev/null
    if [[ -x /usr/local/sbin/witty-time-sync ]]; then
        timeout 20s /usr/local/sbin/witty-time-sync schedule-dst >/dev/null 2>&1 || true
    fi
}

status_action() {
    local output rtc_time model firmware voltage temperature startup shutdown active gps gps_latitude gps_longitude internal fixed_offset fixed_timezone selected_timezone gps_mode="unknown"
    if [[ -r /etc/witty-addon.conf ]]; then
        # shellcheck disable=SC1091
        source /etc/witty-addon.conf
        gps_mode="${GPS_MODE:-unknown}"
    fi
    # GPS und Witty laufen parallel. Zuvor begann die bis zu vier Sekunden
    # dauernde GPS-Abfrage erst nach dem vollständigen wp5-Aufruf.
    exec 8< <(gps_fix true || true)
    output="$(run_wp5 $'14')"
    model="$(sed -n 's/^  Model: //p' <<<"$output" | head -n1)"
    firmware="$(sed -nE 's/.*(Firmware|FW)([[:space:]]+Version)?[^0-9]*([0-9]+([.][0-9]+)+).*/\3/Ip' <<<"$output" | head -n1)"
    rtc_time="$(sed -n 's/^  RTC Time: *//p' <<<"$output" | head -n1)"
    voltage="$(sed -nE 's/.*V-(IN|USB): ([0-9.]+V).*/\2/p' <<<"$output" | head -n1)"
    temperature="$(sed -nE 's/^  Temperature: ([^ ]+).*/\1/p' <<<"$output" | head -n1)"
    startup="$(sed -nE 's/.*Schedule next startup *\[([^]]+)\].*/\1/p' <<<"$output" | head -n1)"
    shutdown="$(sed -nE 's/.*Schedule next shutdown *\[([^]]+)\].*/\1/p' <<<"$output" | head -n1)"
    startup="$(expand_next_event "$startup")"
    shutdown="$(expand_next_event "$shutdown")"
    if grep -qi 'schedule scripts.*in use' <<<"$output"; then
        active="$(tracked_schedule_name)"
    else
        active=""
        startup=""
        shutdown=""
    fi
    IFS='|' read -r gps gps_latitude gps_longitude <&8 || { gps=""; gps_latitude=""; gps_longitude=""; }
    exec 8<&-
    if [[ "$gps_mode" != none && "$gps_mode" != usb && "$gps_mode" != waveshare_l76x ]]; then
        gps_mode="$(detect_gps_mode)"
        # A valid gpsd fix without the installer-specific Waveshare bridge is a
        # USB receiver, even when its serial node is hidden by gpsd permissions.
        [[ "$gps_mode" == unknown && -n "$gps" ]] && gps_mode="usb"
    fi
    if [[ "$gps_mode" != none && ( -z "$gps_latitude" || -z "$gps_longitude" ) ]]; then
        IFS='|' read -r gps_latitude gps_longitude <<<"$(wurb_coordinates || true)"
    fi
    rtc_time="$(normalise_display_time "$rtc_time")"
    gps="$(normalise_display_time "$gps" utc)"
    [[ -n "$(internal_rtc_device || true)" ]] && internal=true || internal=false
    internal_disabled=false; internal_rtc_boot_disabled && internal_disabled=true
    fixed_offset="$(cat "$OFFSET_FILE" 2>/dev/null || printf '60')"
    [[ "$(timezone_name)" == Witty/FixedOffset ]] && fixed_timezone=true || fixed_timezone=false
    selected_timezone="$(timezone_name)"
    [[ "$selected_timezone" == Witty/FixedOffset ]] && selected_timezone="$(cat "$PREVIOUS_TZ_FILE" 2>/dev/null || printf 'Etc/UTC')"
    gps_runtime_active=false
    if [[ "$gps_mode" =~ ^(usb|waveshare_l76x)$ ]] && systemctl is-active --quiet gpsd.service && systemctl is-active --quiet wurb-gps-bridge.service; then
        gps_runtime_active=true
    elif [[ "$gps_mode" == none ]] && ! systemctl is-active --quiet gpsd.service && ! systemctl is-active --quiet wurb-gps-bridge.service; then
        gps_runtime_active=true
    fi
    printf '{"ok":true,"connected":true,"model":"%s","firmware":"%s","system_time":"%s","witty_time":"%s","gps_mode":"%s","gps_runtime_active":%s,"gps_valid":%s,"gps_time":"%s","gps_latitude":"%s","gps_longitude":"%s","internal_rtc":%s,"internal_rtc_disabled":%s,"fixed_offset_minutes":%s,"fixed_timezone":%s,"timezone":"%s","voltage":"%s","temperature":"%s","active_script":"%s","next_startup":"%s","next_shutdown":"%s"}\n' \
        "$(json_escape "$model")" "$(json_escape "$firmware")" "$(date --iso-8601=seconds)" "$(json_escape "$rtc_time")" \
        "$(json_escape "$gps_mode")" "$gps_runtime_active" "$([[ -n "$gps" ]] && printf true || printf false)" "$(json_escape "$gps")" \
        "$(json_escape "$gps_latitude")" "$(json_escape "$gps_longitude")" "$internal" "$internal_disabled" \
        "$fixed_offset" "$fixed_timezone" "$(json_escape "$selected_timezone")" \
        "$(json_escape "$voltage")" "$(json_escape "$temperature")" "$(json_escape "$active")" \
        "$(json_escape "$startup")" "$(json_escape "$shutdown")"
}

write_uploaded_schedule() {
    local filename="$1" encoded="$2" target bytes lines
    local begin_text end_text begin_epoch end_epoch period=0 events=1 current duration token number factor state_line
    local -a durations=()
    [[ "$filename" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{0,26}\.wpi$ ]] || fail "Ungueltiger Dateiname: maximal 27 Zeichen vor .wpi (31 Zeichen insgesamt)"
    [[ "${filename,,}" != "schedule.wpi" ]] || fail "Der reservierte Dateiname schedule.wpi ist nicht erlaubt"
    target="$STATE_DIR/$filename"
    printf '%s' "$encoded" | base64 -d >"$target" 2>/dev/null || fail "Ungueltige Skriptdaten"
    bytes="$(wc -c <"$target")"
    (( bytes > 0 && bytes <= 4000 )) || fail "Das Skript muss 1 bis 4000 Byte enthalten"
    lines="$(grep -Eic '^[[:space:]]*(ON|OFF)[[:space:]]+' "$target" || true)"
    (( lines <= 128 )) || fail "Mehr als 128 ON/OFF-Zeilen"
    while IFS= read -r state_line; do
        (( $(printf '%s' "$state_line" | wc -c) < 128 )) || fail "Eine Skriptzeile ist mindestens 128 Byte lang"
    done <"$target"
    grep -Eq '^BEGIN[[:space:]]+[0-9]{4}-[0-9]{2}-[0-9]{2}[[:space:]]+[0-9]{2}:[0-9]{2}:[0-9]{2}' "$target" || fail "BEGIN fehlt oder ist ungueltig"
    grep -Eq '^END[[:space:]]+[0-9]{4}-[0-9]{2}-[0-9]{2}[[:space:]]+[0-9]{2}:[0-9]{2}:[0-9]{2}' "$target" || fail "END fehlt oder ist ungueltig"
    ! grep -q '[<|>]' "$target" || fail "Die Zeichen <, | und > sind nicht erlaubt"
    begin_text="$(sed -nE 's/^BEGIN[[:space:]]+([0-9-]+[[:space:]]+[0-9:]+).*/\1/p' "$target" | head -n1)"
    end_text="$(sed -nE 's/^END[[:space:]]+([0-9-]+[[:space:]]+[0-9:]+).*/\1/p' "$target" | head -n1)"
    begin_epoch="$(date -d "$begin_text" +%s 2>/dev/null)" || fail "BEGIN ist ungueltig"
    end_epoch="$(date -d "$end_text" +%s 2>/dev/null)" || fail "END ist ungueltig"
    (( end_epoch > begin_epoch )) || fail "END muss nach BEGIN liegen"
    while IFS= read -r state_line; do
        state_line="${state_line%$'\r'}"
        duration=0
        for token in ${state_line#* }; do
            [[ "$token" =~ ^([DHMS])([0-9]+)$ ]] || fail "Ungueltige ON/OFF-Dauer: $token"
            number="${BASH_REMATCH[2]}"
            case "${BASH_REMATCH[1]}" in D) factor=86400;; H) factor=3600;; M) factor=60;; S) factor=1;; esac
            duration=$((duration + number * factor))
        done
        durations+=("$duration"); period=$((period + duration))
    done < <(sed -nE 's/^[[:space:]]*(ON|OFF)[[:space:]]+([^#]+).*/\1 \2/p' "$target")
    (( period > 0 )) || fail "Die Periodendauer muss groesser als 0 sein"
    current="$begin_epoch"
    while (( current < end_epoch && events <= 4096 )); do
        for duration in "${durations[@]}"; do
            current=$((current + duration)); ((events += 1))
            (( current >= end_epoch || events > 4096 )) && break
        done
    done
    (( events <= 4096 )) || fail "Das Skript erzeugt mehr als 4096 Ereignisse"
}

emit_local_log() {
    local log_size log_view_bytes log_partial
    [[ -s "$LOG_DIR/WittyPi5.log" ]] || fail "Auf dem Raspberry ist keine gespeicherte LOG-Datei vorhanden"
    log_size="$(wc -c <"$LOG_DIR/WittyPi5.log")"
    # Return the complete snapshot. The former 512-KiB cap made a healthy
    # one-megabyte firmware log appear incomplete in the browser.
    log_view_bytes="$log_size"
    [[ -f "$LOG_DIR/.WittyPi5.partial" ]] && log_partial=true || log_partial=false
    printf '{"ok":true,"filename":"WittyPi5.log","size":%s,"view_size":%s,"truncated":%s,"partial":%s,"content_base64":"%s"}\n' \
        "$log_size" "$log_view_bytes" \
        "$([[ "$log_size" -gt "$log_view_bytes" ]] && printf true || printf false)" \
        "$log_partial" "$(tail -c "$log_view_bytes" "$LOG_DIR/WittyPi5.log" | base64 -w0)"
}

log_status_json() {
    local local_size=0 local_available=false
    if [[ -s "$LOG_DIR/WittyPi5.log" ]]; then
        local_size="$(wc -c <"$LOG_DIR/WittyPi5.log")"
        local_available=true
    fi
    # Firmware 1.6 exposes the log filename but no stat/size command. Its
    # exact size only becomes known while wp5 downloads the file.
    printf '{"ok":true,"firmware_size_known":false,"firmware_size":null,"local_available":%s,"local_size":%s}\n' \
        "$local_available" "$local_size"
}

download_schedule_to_directory() {
    local filename="$1" destination="$2" index output target
    index="$(remote_file_index 3 "$filename" true)"
    [[ "$index" =~ ^[0-9]+$ ]] || fail "Sicherung abgebrochen: $filename wird vom Witty nicht zum Download aufgelistet"
    target="$destination/$filename"
    rm -f -- "$target"
    if ! output="$(run_wp5 $'6\n3\n'"$index"$'\n5\n14' 120 "$destination")"; then
        fail "Sicherung abgebrochen: Download von $filename ist fehlgeschlagen: $output"
    fi
    [[ -s "$target" ]] || fail "Sicherung abgebrochen: $filename wurde nicht vollständig heruntergeladen: $(grep -iE 'failed|error|not found|invalid' <<<"$output" | tail -n1 | sed 's/^[[:space:]]*//' || printf 'keine Detailmeldung')"
    chmod 0644 "$target"
}

witty_reset_with_schedule_restore() {
    local backup_dir active_name="" was_active=false filename format_output activation_rc restored_filename found
    local total_steps current_step=0
    local -a schedule_files=() restored_files=()
    RESET_ACTIVE=true
    RESET_STARTED_AT="$(date +%s)"
    reset_progress running inventory 0 1 "" "$RESET_STARTED_AT"
    backup_dir="$STATE_DIR/reset-backups/$(date +%Y%m%d-%H%M%S)"
    mkdir -p "$backup_dir"

    if schedule_is_in_use; then
        was_active=true
        active_name="$(tracked_schedule_name)"
    fi
    mapfile -t schedule_files < <(remote_schedule_files)
    total_steps=$((2 * ${#schedule_files[@]} + 4))
    current_step=1
    reset_progress running backup "$current_step" "$total_steps" "" "$RESET_STARTED_AT"
    for filename in "${schedule_files[@]}"; do
        [[ -n "$filename" ]] || continue
        reset_progress running backup "$current_step" "$total_steps" "$filename" "$RESET_STARTED_AT"
        download_schedule_to_directory "$filename" "$backup_dir"
        ((current_step += 1))
        reset_progress running backup "$current_step" "$total_steps" "$filename" "$RESET_STARTED_AT"
    done

    # Menu 13/2 is the official "Format Witty Pi disk" operation. Unlike
    # menu 12 it removes the growing firmware log as well as stored scripts.
    reset_progress running reset "$current_step" "$total_steps" "" "$RESET_STARTED_AT"
    if ! format_output="$(run_wp5 $'13\n2\ny\n9\n14' 90 "$backup_dir")"; then
        fail "Witty-Reset ist fehlgeschlagen. Die Skriptsicherung liegt in $backup_dir: $format_output"
    fi
    grep -Fqi 'Witty Pi disk is formatted!' <<<"$format_output" || \
        fail "Witty-Datenträger wurde nicht als formatiert bestätigt. Die Skriptsicherung liegt in $backup_dir"
    ((current_step += 1))
    reset_progress running restore "$current_step" "$total_steps" "" "$RESET_STARTED_AT"

    rm -f -- "$LOG_DIR/WittyPi5.log" "$LOG_DIR/.WittyPi5.partial" "$LOG_PROGRESS_FILE"
    for filename in "${schedule_files[@]}"; do
        [[ -s "$backup_dir/$filename" ]] || \
            fail "Wiederherstellung angehalten: Sicherung $backup_dir/$filename fehlt"
        reset_progress running restore "$current_step" "$total_steps" "$filename" "$RESET_STARTED_AT"
        install -m 0644 "$backup_dir/$filename" "$STATE_DIR/$filename"
        upload_local_schedule "$filename"
        ((current_step += 1))
        reset_progress running restore "$current_step" "$total_steps" "$filename" "$RESET_STARTED_AT"
    done

    # Erst nachdem alle Dateien übertragen wurden, die Firmware-Dateiliste
    # einmal gesammelt lesen. Dadurch entfällt ein langsames "List Files"
    # zwischen jedem einzelnen Upload.
    reset_progress running verify "$current_step" "$total_steps" "" "$RESET_STARTED_AT"
    mapfile -t restored_files < <(remote_schedule_files)
    for filename in "${schedule_files[@]}"; do
        found=false
        for restored_filename in "${restored_files[@]}"; do
            if [[ "$restored_filename" == "$filename" ]]; then found=true; break; fi
        done
        $found || fail "Wiederherstellung unvollständig: $filename wurde nach dem gemeinsamen Abschlussabgleich nicht auf dem Witty gefunden. Sicherung: $backup_dir"
    done
    ((current_step += 1))
    reset_progress running reactivate "$current_step" "$total_steps" "$active_name" "$RESET_STARTED_AT"
    if $was_active && [[ -n "$active_name" ]]; then
        activation_rc=0
        activate_remote_schedule "$active_name" || activation_rc=$?
        (( activation_rc == 0 )) || \
            fail "Alle Skripte wurden wiederhergestellt, aber $active_name konnte nicht erneut aktiviert werden. Sicherung: $backup_dir"
        printf '%s\n' "$active_name" >"$STATE_DIR/active_schedule_name"
    else
        rm -f -- "$STATE_DIR/active_schedule_name"
    fi
    current_step="$total_steps"
    reset_progress complete complete "$current_step" "$total_steps" "" "$RESET_STARTED_AT"
    RESET_ACTIVE=false
    printf '{"ok":true,"message":"%s","backup_dir":"%s","restored":%s,"reactivated":%s}\n' \
        "$(json_escape "Witty wurde zurückgesetzt; ${#schedule_files[@]} Skripte wurden gesichert und wiederhergestellt")" \
        "$(json_escape "$backup_dir")" "${#schedule_files[@]}" "$was_active"
}

action="${1:-status}"
case "$action" in
    status) status_action ;;
    system_to_witty) run_wp5 $'1\n14' >/dev/null; success "Systemzeit wurde in die Witty-RTC geschrieben" ;;
    witty_to_system) run_wp5 $'2\n14' >/dev/null; sync_internal_rtc; success "Witty-RTC wurde als Systemzeit uebernommen" ;;
    manual_to_system)
        [[ "${2:-}" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}(:[0-9]{2})?$ ]] || fail "Ungueltige Zeit"
        disable_automatic_time_sync
        date --set="${2/T/ }" >/dev/null
        success "Systemzeit wurde manuell gesetzt"
        ;;
    manual_to_witty)
        [[ "${2:-}" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}(:[0-9]{2})?$ ]] || fail "Ungueltige Zeit"
        disable_automatic_time_sync
        date --set="${2/T/ }" >/dev/null
        run_wp5 $'1\n14' >/dev/null
        success "Zeit wurde gesetzt und in die Witty-RTC geschrieben"
        ;;
    gps_to_system)
        value="$(gps_time || true)"; [[ -n "$value" ]] || fail "Keine gueltige GPS-Zeit"
        disable_automatic_time_sync
        date --set="$value" >/dev/null
        sync_internal_rtc
        success "GPS-Zeit wurde als Systemzeit und Raspberry-Pi-RTC uebernommen"
        ;;
    gps_to_witty)
        value="$(gps_time || true)"; [[ -n "$value" ]] || fail "Keine gueltige GPS-Zeit"
        disable_automatic_time_sync
        date --set="$value" >/dev/null
        # Write Witty immediately after setting Linux time. The internal RTC
        # follows afterwards so its hwclock I/O cannot delay the Witty value.
        run_wp5 $'1\n14' >/dev/null
        sync_internal_rtc
        success "GPS-Zeit wurde in System-, Raspberry-Pi- und Witty-RTC geschrieben"
        ;;
    fixed_timezone)
        apply_fixed_timezone "${2:-}" "${3:-}"
        success "Zeitzoneneinstellung wurde übernommen und die Witty-RTC synchronisiert"
        ;;
    gps_configure|gps_remove)
        gps_choice="${2:-}"
        [[ "$gps_choice" =~ ^(none|usb|waveshare_l76x)$ ]] || fail "Ungueltige GPS-Option"
        manager_action=configure; [[ "$action" == gps_remove ]] && manager_action=remove
        manager_output="$(timeout 360s /usr/local/sbin/witty-gps-manager "$manager_action" "$gps_choice" 2>&1)" || fail "$manager_output"
        if [[ "$action" == gps_configure && "$gps_choice" == none ]]; then
            run_wp5 $'2\n14' >/dev/null
        fi
        gps_reboot=false; grep -Fq 'REBOOT_REQUIRED=1' <<<"$manager_output" && gps_reboot=true
        printf '{"ok":true,"message":"%s","reboot_required":%s}\n' \
            "$(json_escape "$([[ "$action" == gps_configure ]] && printf 'GPS-Konfiguration wurde übernommen' || printf 'GPS-Konfiguration wurde deinstalliert')")" "$gps_reboot"
        ;;
    clear_schedule)
        clear_output="$(run_wp5 $'12\n1\n12\n2\n12\n3\n14')"
        if grep -qiE 'Failed to clear|Failed to stop|admin status|no response' <<<"$clear_output"; then
            fail "Zeitplan konnte nicht vollständig deaktiviert werden: $(grep -iE 'Failed to clear|Failed to stop|admin status|no response' <<<"$clear_output" | tail -n1 | sed 's/^[[:space:]]*//')"
        fi
        grep -Fq 'Scheduled startup time is cleared!' <<<"$clear_output" || fail "Der nächste Starttermin wurde nicht bestätigt gelöscht"
        grep -Fq 'Scheduled shutdown time is cleared!' <<<"$clear_output" || fail "Der nächste Abschalttermin wurde nicht bestätigt gelöscht"
        grep -Fq 'Schedule script is not being used now!' <<<"$clear_output" || fail "Die Skript-Deaktivierung wurde von Witty nicht bestätigt"
        rm -f -- "$STATE_DIR/active_schedule_name"
        success "Zeitplan, nächster Start und nächstes Herunterfahren wurden deaktiviert"
        ;;
    schedule_list) schedule_list_json ;;
    schedule_activate)
        filename="${2:-}"
        original_filename="$filename"
        shortened=false
        [[ "$filename" =~ ^[A-Za-z0-9._-]{1,64}$ ]] || fail "Ungueltiger Skriptname"
        index="$(remote_file_index 2 "$filename")"
        if [[ ! "$index" =~ ^[0-9]+$ && -f "$STATE_DIR/$filename" ]]; then
            if (( ${#filename} > 31 )); then
                filename="$(make_firmware_safe_schedule_copy "$filename")"
                shortened=true
                index="$(remote_file_index 2 "$filename")"
            fi
        fi
        if [[ ! "$index" =~ ^[0-9]+$ && -f "$STATE_DIR/$filename" ]]; then
            upload_local_schedule "$filename"
        fi
        activation_rc=0
        activate_remote_schedule "$filename" || activation_rc=$?
        if (( activation_rc != 0 )); then
            (( activation_rc == 2 )) && fail "Skript $filename wird nicht als aktivierbar aufgelistet"
            fail "Witty konnte $filename auch nach drei Versuchen nicht aktivieren. Letzte Firmwaremeldung: $(grep -iE 'activation failed|I/O error|invalid|not found' <<<"$ACTIVATION_OUTPUT" | tail -n1 | sed 's/^[[:space:]]*//' || printf 'keine Detailmeldung')"
        fi
        printf '%s\n' "$filename" >"$STATE_DIR/active_schedule_name"
        if $shortened; then
            rm -f -- "$STATE_DIR/$original_filename"
            success "Der problematische lange Dateiname wurde automatisch durch $filename ersetzt und dieses Skript wurde aktiviert"
        else
            success "Skript $filename wurde aktiviert"
        fi
        ;;
    schedule_delete)
        filename="${2:-}"
        [[ "$filename" =~ ^[A-Za-z0-9._-]{1,64}$ ]] || fail "Ungueltiger Skriptname"
        if schedule_is_in_use && [[ "$filename" == "$(tracked_schedule_name)" ]]; then
            fail "Das aktive Skript muss vor dem Loeschen deaktiviert oder gewechselt werden"
        fi
        index="$(remote_file_index 4 "$filename" true)"
        if [[ ! "$index" =~ ^[0-9]+$ ]]; then
            # Fehlgeschlagene Firmware-Uploads hinterlassen absichtlich eine
            # lokale Kopie fuer einen neuen Versuch. Solche Eintraege wurden
            # bisher in der Webseite angezeigt, konnten aber nicht geloescht
            # werden, weil sie noch gar nicht auf dem Witty-Datentraeger lagen.
            if [[ -f "$STATE_DIR/$filename" ]]; then
                rm -f -- "$STATE_DIR/$filename"
                success "Lokale Kopie $filename wurde geloescht; auf dem Witty war diese Datei nicht vorhanden"
                exit 0
            fi
            fail "Skript $filename wird weder auf dem Witty noch lokal gefunden"
        fi
        delete_output="$(run_wp5 $'6\n4\n'"$index"$'\ny\n5\n14')"
        if grep -qiE 'failed|not found|invalid|requires firmware|timed out|cannot delete' <<<"$delete_output"; then
            fail "Skript konnte nicht geloescht werden: $delete_output"
        fi
        rm -f -- "$STATE_DIR/$filename"
        success "Skript $filename wurde geloescht"
        ;;
    read_schedule)
        filename="$(tracked_schedule_name)"
        if [[ -f "$STATE_DIR/$filename" ]]; then
            printf '{"ok":true,"filename":"%s","content_base64":"%s"}\n' \
                "$(json_escape "$filename")" "$(base64 -w0 "$STATE_DIR/$filename")"
            exit 0
        fi
        remote_name="$filename"
        index="$(remote_file_index 3 "$remote_name")"
        if [[ ! "$index" =~ ^[0-9]+$ ]]; then
            remote_name="schedule"
            index="$(remote_file_index 3 "$remote_name")"
        fi
        [[ "$index" =~ ^[0-9]+$ ]] || fail "Zeitplan ist aktiv, aber die Firmware listet die interne Quelldatei weder als schedule.wpi noch als schedule zum Download auf"
        rm -f -- "$STATE_DIR/$filename" "$STATE_DIR/schedule" "$STATE_DIR/schedule.wpi"
        run_wp5 $'6\n3\n'"$index"$'\n5\n14' >/dev/null
        downloaded_file=""
        for candidate in "$STATE_DIR/$filename" "$STATE_DIR/$remote_name" "$STATE_DIR/schedule" "$STATE_DIR/schedule.wpi"; do
            [[ -f "$candidate" ]] && { downloaded_file="$candidate"; break; }
        done
        [[ -n "$downloaded_file" ]] || fail "Aktuelles Skript konnte nicht gelesen werden"
        printf '{"ok":true,"filename":"%s","content_base64":"%s"}\n' \
            "$(json_escape "$filename")" "$(base64 -w0 "$downloaded_file")"
        ;;
    read_named_schedule)
        filename="${2:-}"
        [[ "$filename" =~ ^[A-Za-z0-9._-]{1,64}$ ]] || fail "Ungueltiger Skriptname"
        index="$(remote_file_index 3 "$filename" true)"
        if [[ "$index" =~ ^[0-9]+$ ]]; then
            rm -f -- "$STATE_DIR/$filename"
            download_output="$(run_wp5 $'6\n3\n'"$index"$'\n5\n14')"
            [[ -f "$STATE_DIR/$filename" ]] || \
                fail "Skript $filename wurde vom Witty nicht bereitgestellt: $(grep -iE 'failed|error|not found|invalid' <<<"$download_output" | tail -n1 | sed 's/^[[:space:]]*//' || printf 'keine Detailmeldung')"
        fi
        [[ -f "$STATE_DIR/$filename" ]] || fail "Skript $filename wurde weder auf dem Witty noch lokal gefunden"
        printf '{"ok":true,"filename":"%s","content_base64":"%s"}\n' \
            "$(json_escape "$filename")" "$(base64 -w0 "$STATE_DIR/$filename")"
        ;;
    read_log)
        download_dir="$LOG_DIR/download"
        log_partial=false
        mkdir -p "$download_dir"
        # Every press requests a fresh firmware snapshot. Files left in the
        # transfer directory by an earlier download must never be selected.
        find "$download_dir" -maxdepth 3 -type f -iname '*.log' -delete
        : >"$LOG_PROGRESS_FILE"
        trap 'rm -f -- "$LOG_PROGRESS_FILE"' EXIT
        log_settings="$(probe_wp5 $'11\n14\n14')"
        log_was_enabled=false
        if grep -qiE 'Log to file on Witty Pi.*\[Yes\]' <<<"$log_settings"; then
            log_was_enabled=true
        fi
        if $log_was_enabled; then
            pause_output="$(run_wp5 $'11\n12\n0\n14' 15 "$download_dir")"
            grep -Fqi 'Do not write log file on Witty Pi!' <<<"$pause_output" || \
                fail "Die laufende Firmware-Protokollierung konnte für den Download nicht pausiert werden"
        fi
        save_rc=0; download_rc=0; restore_rc=0; save_output=""; log_output=""; restore_output=""
        set +e
        save_output="$(run_wp5 $'13\n6\n9\n14' 20 "$download_dir")"; save_rc=$?
        if (( save_rc == 0 )); then
            log_output="$(run_wp5 $'13\n7\n9\n14' 1200 "$download_dir")"; download_rc=$?
        fi
        if $log_was_enabled; then
            restore_output="$(run_wp5 $'11\n12\n1\n14' 15 "$download_dir")"; restore_rc=$?
        fi
        set -e
        downloaded_log="$(find "$download_dir" -maxdepth 3 -type f -iname '*.log' -size +0c -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -n1 | cut -d' ' -f2- || true)"
        (( restore_rc == 0 )) || fail "Die Firmware-Protokollierung konnte nach dem Download nicht wieder aktiviert werden"
        (( save_rc == 0 )) || fail "Firmware-Log konnte nicht als Snapshot gespeichert werden: $save_output"
        if (( download_rc != 0 )); then
            [[ -n "$downloaded_log" && -s "$downloaded_log" ]] || fail "Firmware-Log konnte nicht heruntergeladen werden: $log_output"
            log_partial=true
        fi
        [[ -n "$downloaded_log" && -s "$downloaded_log" ]] || \
            fail "Die Firmware hat keine lesbare LOG-Datei bereitgestellt: $(grep -iE 'failed|error|not found|timed out' <<<"$log_output" | tail -n1 | sed 's/^[[:space:]]*//' || printf 'keine Detailmeldung')"
        fresh_log="$LOG_DIR/.WittyPi5.log.new.$$"
        install -m 0644 "$downloaded_log" "$fresh_log"
        mv -f -- "$fresh_log" "$LOG_DIR/WittyPi5.log"
        if $log_partial; then touch "$LOG_DIR/.WittyPi5.partial"; else rm -f -- "$LOG_DIR/.WittyPi5.partial"; fi
        rm -f -- "$LOG_PROGRESS_FILE"
        trap - EXIT
        emit_local_log
        ;;
    read_local_log) emit_local_log ;;
    log_status) log_status_json ;;
    witty_reset) witty_reset_with_schedule_restore ;;
    delete_log)
        find "$LOG_DIR" -maxdepth 2 -type f -iname '*.log' -delete
        rm -f -- "$LOG_DIR/.WittyPi5.partial" "$LOG_PROGRESS_FILE"
        success "Alle lokalen LOG-Dateien wurden aus dem Witty-Webserver-Verzeichnis geloescht"
        ;;
    upload_schedule)
        filename="${2:-}"
        write_uploaded_schedule "$filename" "${3:-}"
        replaced_active=false
        if schedule_is_in_use && [[ "$filename" == "$(tracked_schedule_name)" ]]; then
            clear_output="$(run_wp5 $'12\n1\n12\n2\n12\n3\n14')"
            grep -Fq 'Scheduled startup time is cleared!' <<<"$clear_output" || fail "Das aktive Skript konnte vor dem Ersetzen nicht abgeschaltet werden"
            grep -Fq 'Scheduled shutdown time is cleared!' <<<"$clear_output" || fail "Das aktive Skript konnte vor dem Ersetzen nicht abgeschaltet werden"
            grep -Fq 'Schedule script is not being used now!' <<<"$clear_output" || fail "Die Skript-Deaktivierung wurde von Witty nicht bestätigt"
            rm -f -- "$STATE_DIR/active_schedule_name"
            replaced_active=true
        fi
        upload_local_schedule "$filename"
        # Die Download-Liste zeigt auch das aktive Skript; die Aktivierungsliste
        # blendet es aus. Fuer die reine Upload-Bestaetigung daher Option 3 nutzen.
        index="$(remote_file_index 3 "$filename")"
        if [[ ! "$index" =~ ^[0-9]+$ ]]; then
            available="$(remote_schedule_files | paste -sd ', ' -)"
            fail "Das hochgeladene Skript $filename wurde nicht in der Witty-Liste gefunden. Gefunden: ${available:-keine Dateien}"
        fi
        if $replaced_active; then
            upload_message="Das bisher aktive Skript $filename wurde abgeschaltet und ersetzt. Alle Skripte sind deaktiviert; die neue Version kann manuell aktiviert werden"
        else
            upload_message="Skript $filename wurde auf Witty kopiert. Die Aktivierung erfolgt manuell über die Skriptliste"
        fi
        printf '{"ok":true,"message":"%s","filename":"%s","deactivated":%s}\n' \
            "$(json_escape "$upload_message")" \
            "$(json_escape "$filename")" "$replaced_active"
        ;;
    service_start|service_stop)
        service="${2:-}"
        if [[ "$service" == allsky ]]; then
            systemctl cat allsky.service >/dev/null 2>&1 || fail "Allsky-Dienst wurde nicht gefunden"
            if [[ "$action" == service_start ]]; then
                timeout 30s systemctl start allsky.service || fail "allsky.service konnte nicht gestartet werden"
                if systemctl cat allskyperiodic.timer >/dev/null 2>&1; then
                    timeout 30s systemctl start allskyperiodic.timer || fail "allskyperiodic.timer konnte nicht gestartet werden"
                fi
                sleep 5
                systemctl is-active --quiet allsky.service || \
                    fail "Allsky wurde gestartet, aber allsky.service hat sich wieder beendet: $(journalctl -u allsky.service -n 35 --no-pager --output=cat 2>&1 || true)"
                timeout 8s curl --fail --silent --show-error --output /dev/null http://127.0.0.1/ || \
                    fail "Allsky läuft, aber der Webserver auf Port 80 antwortet nicht"
                success "Allsky-Dienste wurden gestartet"
            else
                if systemctl cat allskyperiodic.timer >/dev/null 2>&1; then
                    timeout 30s systemctl stop allskyperiodic.timer || fail "allskyperiodic.timer konnte nicht gestoppt werden"
                fi
                if systemctl is-active --quiet allskyperiodic.service; then
                    timeout 30s systemctl stop allskyperiodic.service || fail "allskyperiodic.service konnte nicht gestoppt werden"
                fi
                timeout 30s systemctl stop allsky.service || fail "allsky.service konnte nicht gestoppt werden"
                if systemctl is-active --quiet allsky.service || systemctl is-active --quiet allskyperiodic.service || systemctl is-active --quiet allskyperiodic.timer; then
                    fail "Mindestens ein Allsky-Dienst läuft weiterhin"
                fi
                success "Allsky-Dienste wurden gestoppt"
            fi
            exit 0
        fi
        case "$service:$action" in
            wurb_2026:service_start) service_state="on"; service_label="WURB"; service_result="gestartet"; service_command="$(command -v wurb-service || true)" ;;
            wurb_2026:service_stop) service_state="off"; service_label="WURB"; service_result="beendet"; service_command="$(command -v wurb-service || true)" ;;
            wirc_2026:service_start) service_state="on"; service_label="WIRC"; service_result="gestartet"; service_command="$(command -v wirc-service || true)" ;;
            wirc_2026:service_stop) service_state="off"; service_label="WIRC"; service_result="beendet"; service_command="$(command -v wirc-service || true)" ;;
            *) fail "Dienst nicht erlaubt" ;;
        esac
        [[ -n "$service_command" ]] || fail "Der Befehl fuer den Dienst wurde nicht gefunden"
        [[ "$service_state" != on ]] || systemctl reset-failed "$service.service" 2>/dev/null || true
        timeout 30s "$service_command" "$service_state" || fail "$service_command $service_state ist fehlgeschlagen"
        if [[ "$service" == wirc_2026 && "$service_state" == on ]] && ! wait_for_wirc_service; then
            fail "WIRC wurde gestartet, blieb aber nicht stabil oder Port 8082 antwortet nicht: $(wirc_failure_details)"
        fi
        if [[ "$service" == wurb_2026 && "$service_state" == on ]] && ! wait_for_wurb_service; then
            fail "WURB wurde gestartet, blieb aber nicht stabil oder Port 8080 antwortet nicht: $(journalctl -u wurb_2026.service -n 35 --no-pager --output=cat 2>&1 || true)"
        fi
        if [[ "$service_state" == off ]] && systemctl is-active --quiet "$service.service"; then
            fail "$service_label-Dienst läuft nach dem Beenden weiterhin"
        fi
        success "$service_label-Dienst wurde $service_result"
        ;;
    reboot) success "Raspberry Pi wird neu gestartet"; (sleep 2; systemctl reboot) >/dev/null 2>&1 & ;;
    shutdown) success "Raspberry Pi wird heruntergefahren"; (sleep 2; systemctl poweroff) >/dev/null 2>&1 & ;;
    internal_rtc_toggle)
        if internal_rtc_boot_enabled; then
            set_internal_rtc_boot false
            printf '{"ok":true,"message":"%s","reboot_required":true}\n' \
                "$(json_escape "Interne Raspberry-Pi-5-RTC wurde deaktiviert; ein Neustart ist erforderlich")"
        else
            set_internal_rtc_boot true
            printf '{"ok":true,"message":"%s","reboot_required":true}\n' \
                "$(json_escape "Interne Raspberry-Pi-5-RTC wurde aktiviert; ein Neustart ist erforderlich")"
        fi
        ;;
    *) fail "Unbekannte Aktion" ;;
esac
