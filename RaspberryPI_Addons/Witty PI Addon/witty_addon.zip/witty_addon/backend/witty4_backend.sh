#!/usr/bin/env bash
set -Eeuo pipefail
readonly HOME4="${WITTY4_HOME:-/home/wurb/wittypi}"
readonly STATE_DIR="/var/lib/witty-addon"
readonly APP_DIR="$(dirname "$(dirname "$(readlink -f "$0")")")"
readonly LOG_DIR="$APP_DIR/logs"
readonly PREVIOUS_TZ_FILE="$STATE_DIR/previous_timezone"
readonly OFFSET_FILE="$STATE_DIR/fixed_offset_minutes"
readonly RESET_PROGRESS_FILE="$STATE_DIR/reset-progress.json"
mkdir -p "$STATE_DIR" "$LOG_DIR"
exec 9>/run/lock/witty-addon.lock
flock -w 30 9 || { echo '{"ok":false,"error":"Witty ist beschäftigt"}'; exit 1; }

RESET_ACTIVE=false
esc(){ local s="${1-}"; s=${s//\\/\\\\}; s=${s//\"/\\\"}; s=${s//$'\n'/\\n}; printf %s "$s"; }
reset_progress(){
 local state="$1" phase="$2" current="${3:-0}" total="${4:-1}" detail="${5:-}" started_at="${6:-$(date +%s)}" percent=0 temporary="${RESET_PROGRESS_FILE}.tmp.$$"
 (( total > 0 )) && percent=$((current * 100 / total)); (( percent > 100 )) && percent=100
 printf '{"ok":true,"active":%s,"state":"%s","phase":"%s","current":%s,"total":%s,"percent":%s,"detail":"%s","started_at":%s,"updated_at":%s}\n' \
  "$([[ "$state" == running ]] && echo true || echo false)" "$(esc "$state")" "$(esc "$phase")" "$current" "$total" "$percent" "$(esc "$detail")" "$started_at" "$(date +%s)" >"$temporary"
 chmod 0644 "$temporary"; mv -f "$temporary" "$RESET_PROGRESS_FILE"
}
fail(){ if $RESET_ACTIVE; then reset_progress failed failed 0 1 "$1" "${RESET_STARTED_AT:-$(date +%s)}" || true; fi; printf '{"ok":false,"error":"%s"}\n' "$(esc "$1")"; exit 1; }
ok(){ printf '{"ok":true,"message":"%s"}\n' "$(esc "${1:-OK}")"; }
wait_for_wirc_service(){
 local attempt consecutive=0
 for attempt in $(seq 1 90); do
  if systemctl is-active --quiet wirc_2026.service && timeout 1s bash -c '</dev/tcp/127.0.0.1/8082' >/dev/null 2>&1; then
   consecutive=$((consecutive + 1)); (( consecutive >= 35 )) && return 0
  else
   consecutive=0
  fi
  sleep 1
 done
 return 1
}
wait_for_wurb_service(){
 local attempt consecutive=0
 for attempt in $(seq 1 75); do
  if systemctl is-active --quiet wurb_2026.service && timeout 1s bash -c '</dev/tcp/127.0.0.1/8080' >/dev/null 2>&1; then
   consecutive=$((consecutive + 1)); (( consecutive >= 20 )) && return 0
  else
   consecutive=0
  fi
  sleep 1
 done
 return 1
}
wirc_failure_details(){
 local details
 details="$(journalctl -u wirc_2026.service -n 35 --no-pager --output=cat 2>&1 || true)"
 printf '%s' "${details:-WIRC hat keine Diagnosemeldung geliefert}"
}
[[ -r "$HOME4/utilities.sh" ]] || fail "Witty-Pi-4-Software fehlt in $HOME4"
# shellcheck disable=SC1090
source "$HOME4/utilities.sh"
firmware_id="$(i2c_read 1 0x08 0 2>/dev/null || true)"
[[ "$firmware_id" =~ ^0x(26|37)$ ]] || fail "Witty Pi 4 wurde an I2C-Adresse 0x08 nicht erkannt"

validate_name(){ [[ "$1" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{0,58}\.wpi$ ]] || fail "Ungültiger Skriptname"; }
emit_file(){ printf '{"ok":true,"filename":"%s","content_base64":"%s"}\n' "$(esc "$1")" "$(base64 -w0 "$2")"; }
detect_gps_mode(){
  local device
  # The common WURB bridge is used for both GPS variants. Only the persisted
  # installer UART configuration is allowed to identify a Waveshare L76X.
  if [[ -r /etc/default/gpsd ]] && grep -Eq '^[[:space:]]*DEVICES="/dev/(ttyAMA0|serial0)"' /etc/default/gpsd; then echo waveshare_l76x; return; fi
  for device in /dev/ttyACM* /dev/ttyUSB*; do [[ -e "$device" ]] || continue; [[ "$device" == /dev/ttyUSB9 ]] && continue; echo usb; return; done
  echo unknown
}
gps_fix(){
  local value timestamp live_latitude live_longitude
  command -v gpspipe >/dev/null 2>&1 || return 1
  command -v jq >/dev/null 2>&1 || return 1
  value="$(set +o pipefail; timeout 5s gpspipe -w 2>/dev/null | jq -sr \
    '[.[] | select(.class=="TPV" and .time and (.mode // 0) >= 2 and .lat != null and .lon != null)] as $fixes
     | if ($fixes | length) < 2 or $fixes[-1].time == $fixes[-2].time then empty
       else ($fixes | last) | "\(.time)|\(.lat)|\(.lon)"
       end')"
  timestamp="${value%%|*}"
  if [[ -n "$timestamp" ]] && date -d "$timestamp" +%s >/dev/null 2>&1; then
    IFS='|' read -r _ live_latitude live_longitude <<<"$value"
    printf '%s\n' "$value"; return 0
  fi
  return 1
}
wurb_coordinates(){
  local database
  command -v python3 >/dev/null 2>&1 || return 1
  for database in /home/wurb/wurb_settings/wurb_settings.db /home/*/wurb_settings/wurb_settings.db; do
    [[ -r "$database" ]] || continue
    python3 - "$database" <<'PY' 2>/dev/null && return 0
import sqlite3
import sys
connection = sqlite3.connect(f"file:{sys.argv[1]}?mode=ro", uri=True, timeout=0.5)
try:
    values = dict(connection.execute("SELECT key, value FROM key_value_data WHERE identity='location'").fetchall())
finally:
    connection.close()
def number(key):
    try:
        return float(values.get(key, 0.0) or 0.0)
    except (TypeError, ValueError):
        return 0.0
latitude, longitude = number("latitudeDd"), number("longitudeDd")
if latitude == 0.0 or longitude == 0.0:
    if str(values.get("geoSource", "")) == "geo-gps-or-last-found":
        latitude, longitude = number("lastGpsLatitudeDd"), number("lastGpsLongitudeDd")
    if latitude == 0.0 or longitude == 0.0:
        latitude, longitude = number("defaultLatitudeDd"), number("defaultLongitudeDd")
if latitude == 0.0 or longitude == 0.0 or not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
    raise SystemExit(1)
print(f"{latitude:.7f}|{longitude:.7f}")
PY
  done
  return 1
}
timezone_name(){ timedatectl show --property=Timezone --value 2>/dev/null || printf 'Etc/UTC\n'; }
apply_fixed_timezone(){
  local enabled="$1" selected_zone="$2" offset_text offset sign absolute hours minutes zone_source
  [[ "$enabled" == true || "$enabled" == false ]] || fail "Ungueltiger Umschaltwert"
  timedatectl list-timezones | grep -Fxq "$selected_zone" || fail "Ungueltige Zeitzone: $selected_zone"
  if [[ "$enabled" == true ]]; then
    command -v zic >/dev/null 2>&1 || fail "zic aus dem Paket tzdata wurde nicht gefunden"
    printf '%s\n' "$selected_zone" >"$PREVIOUS_TZ_FILE"
    offset_text="$(TZ="$selected_zone" date +%z)"
    hours=$((10#${offset_text:1:2})); minutes=$((10#${offset_text:3:2})); offset=$((hours * 60 + minutes))
    [[ "${offset_text:0:1}" == "-" ]] && offset=$((-offset))
    sign="+"; (( offset < 0 )) && sign="-"
    absolute=$(( offset < 0 ? -offset : offset )); hours=$((absolute / 60)); minutes=$((absolute % 60))
    zone_source="$STATE_DIR/fixed-offset.zone"
    printf 'Zone Witty/FixedOffset %s%02d:%02d - WIT\n' "$sign" "$hours" "$minutes" >"$zone_source"
    zic -d /usr/share/zoneinfo "$zone_source" || fail "Feste Zeitzone konnte nicht erstellt werden"
    timedatectl set-timezone Witty/FixedOffset || fail "Feste Zeitzone konnte nicht aktiviert werden"
  else
    timedatectl set-timezone "$selected_zone" || fail "Zeitzone konnte nicht aktiviert werden"
    printf '%s\n' "$selected_zone" >"$PREVIOUS_TZ_FILE"
    offset_text="$(date +%z)"; hours=$((10#${offset_text:1:2})); minutes=$((10#${offset_text:3:2})); offset=$((hours * 60 + minutes))
    [[ "${offset_text:0:1}" == "-" ]] && offset=$((-offset))
  fi
  printf '%s\n' "$offset" >"$OFFSET_FILE"
  system_to_rtc >/dev/null
  if [[ -x /usr/local/sbin/witty-time-sync ]]; then
    timeout 20s /usr/local/sbin/witty-time-sync schedule-dst >/dev/null 2>&1 || true
  fi
}
action="${1:-status}"
case "$action" in
 status)
  gps_mode="unknown"; [[ -r /etc/witty-addon.conf ]] && source /etc/witty-addon.conf; gps_mode="${GPS_MODE:-unknown}"
  if [[ "$gps_mode" != none && "$gps_mode" != usb && "$gps_mode" != waveshare_l76x ]]; then gps_mode="$(detect_gps_mode)"; fi
  gps=""; gps_latitude=""; gps_longitude=""
  if [[ "$gps_mode" == waveshare_l76x || ( "$gps_mode" == usb && "$(detect_gps_mode)" == usb ) ]]; then
    IFS='|' read -r gps gps_latitude gps_longitude <<<"$(gps_fix || true)"
  fi
  fw="$(i2c_read 1 0x08 12 2>/dev/null || true)"; fw=$((fw))
  rtc="$(get_rtc_time 2>/dev/null || true)"; temp="$(get_temperature 2>/dev/null || true)"
  start="$(get_startup_time 2>/dev/null || true)"; stop="$(get_shutdown_time 2>/dev/null || true)"
  active=""; [[ -s "$HOME4/schedule.wpi" ]] && active="schedule.wpi"
  selected_timezone="$(timezone_name)"; fixed_timezone=false
  if [[ "$selected_timezone" == Witty/FixedOffset ]]; then fixed_timezone=true; selected_timezone="$(cat "$PREVIOUS_TZ_FILE" 2>/dev/null || echo Etc/UTC)"; fi
  fixed_offset="$(cat "$OFFSET_FILE" 2>/dev/null || echo 0)"
  gps_runtime_active=false
  if [[ "$gps_mode" == usb ]] && [[ "$(detect_gps_mode)" == usb ]] && systemctl is-active --quiet gpsd.service && systemctl is-active --quiet wurb-gps-bridge.service; then gps_runtime_active=true
  elif [[ "$gps_mode" == waveshare_l76x ]] && [[ -e /dev/serial0 || -e /dev/ttyAMA0 ]] && systemctl is-active --quiet gpsd.service && systemctl is-active --quiet wurb-gps-bridge.service; then gps_runtime_active=true
  elif [[ "$gps_mode" == none ]] && ! systemctl is-active --quiet gpsd.service && ! systemctl is-active --quiet wurb-gps-bridge.service; then gps_runtime_active=true; fi
  printf '{"ok":true,"connected":true,"model":"Witty Pi 4","firmware":"%s","system_time":"%s","witty_time":"%s","gps_mode":"%s","gps_runtime_active":%s,"gps_valid":%s,"gps_time":"%s","gps_latitude":"%s","gps_longitude":"%s","internal_rtc":false,"internal_rtc_disabled":false,"fixed_offset_minutes":%s,"fixed_timezone":%s,"timezone":"%s","voltage":"","temperature":"%s","active_script":"%s","next_startup":"%s","next_shutdown":"%s"}\n' "$fw" "$(date --iso-8601=seconds)" "$(esc "$rtc")" "$(esc "$gps_mode")" "$gps_runtime_active" "$([[ -n "$gps" ]] && echo true || echo false)" "$(esc "$gps")" "$(esc "$gps_latitude")" "$(esc "$gps_longitude")" "$fixed_offset" "$fixed_timezone" "$(esc "$selected_timezone")" "$(esc "$temp")" "$active" "$(esc "$start")" "$(esc "$stop")" ;;
 system_to_witty) system_to_rtc >/dev/null; ok "Systemzeit wurde in die Witty-Pi-4-RTC geschrieben" ;;
 witty_to_system) rtc_to_system >/dev/null; ok "Witty-Pi-4-RTC wurde als Systemzeit übernommen" ;;
 manual_to_system)
  [[ "${2:-}" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}(:[0-9]{2})?$ ]] || fail "Ungueltige Zeit"
  if [[ -x /usr/local/sbin/witty-disable-auto-time ]]; then
   /usr/local/sbin/witty-disable-auto-time >/dev/null || fail "Automatische Zeitsynchronisation konnte nicht deaktiviert werden"
  else
   timedatectl set-ntp false >/dev/null 2>&1 || true
  fi
  date --set="${2/T/ }" >/dev/null
  manual_gps_mode="unknown"; [[ -r /etc/witty-addon.conf ]] && source /etc/witty-addon.conf; manual_gps_mode="${GPS_MODE:-unknown}"
  if [[ "$manual_gps_mode" == none ]]; then system_to_rtc >/dev/null; ok "Systemzeit wurde gesetzt und fuer den naechsten Start in der Witty-RTC gespeichert"; exit 0; fi
  ok "Systemzeit wurde manuell gesetzt"
  ;;
 manual_to_witty) [[ ! -x /usr/local/sbin/witty-disable-auto-time ]] || /usr/local/sbin/witty-disable-auto-time >/dev/null; date --set="${2/T/ }" >/dev/null; system_to_rtc >/dev/null; ok "Zeit wurde gesetzt" ;;
 gps_to_system) v="$(timeout 3s gpspipe -w 2>/dev/null | jq -er 'select(.class=="TPV" and (.mode//0)>=2 and .time)|.time' | head -1)"; date --set="$v" >/dev/null; ok "GPS-Zeit übernommen" ;;
 gps_to_witty) v="$(timeout 3s gpspipe -w 2>/dev/null | jq -er 'select(.class=="TPV" and (.mode//0)>=2 and .time)|.time' | head -1)"; date --set="$v" >/dev/null; system_to_rtc >/dev/null; ok "GPS-Zeit in System und Witty-RTC geschrieben" ;;
 gps_configure|gps_remove) choice="${2:-}"; [[ "$choice" =~ ^(none|usb|waveshare_l76x)$ ]] || fail "Ungueltige GPS-Option"; manager=configure; [[ "$action" == gps_remove ]] && manager=remove; output="$(timeout 360s /usr/local/sbin/witty-gps-manager "$manager" "$choice" 2>&1)" || fail "$output"; if [[ "$action" == gps_configure && "$choice" == none ]]; then rtc_to_system >/dev/null; fi; reboot=false; grep -Fq 'REBOOT_REQUIRED=1' <<<"$output" && reboot=true; printf '{"ok":true,"message":"GPS-Konfiguration wurde aktualisiert","reboot_required":%s}\n' "$reboot" ;;
 schedule_list)
  printf '{"ok":true,"active":"%s","files":[' "$([[ -s "$HOME4/schedule.wpi" ]] && echo schedule.wpi)"; sep=""
  for f in "$HOME4"/schedules/*.wpi; do [[ -f "$f" ]] || continue; printf '%s"%s"' "$sep" "$(esc "$(basename "$f")")"; sep=,; done; echo ']}' ;;
 upload_schedule)
  name="${2:-}"; validate_name "$name"; printf %s "${3:-}" | base64 -d >"$HOME4/schedules/$name" || fail "Ungültige Skriptdaten"; chmod 644 "$HOME4/schedules/$name"; ok "Skript wurde auf den Raspberry kopiert und kann manuell aktiviert werden" ;;
 schedule_activate)
  name="${2:-}"; validate_name "$name"; [[ -f "$HOME4/schedules/$name" ]] || fail "Skript nicht gefunden"; install -m 644 "$HOME4/schedules/$name" "$HOME4/schedule.wpi"; timeout 30s "$HOME4/runScript.sh" 0 revise >/dev/null 2>&1 || fail "Skript konnte nicht aktiviert werden"; printf %s "$name" >"$STATE_DIR/active_schedule_name"; ok "Skript wurde aktiviert" ;;
 clear_schedule) rm -f "$HOME4/schedule.wpi"; clear_startup_time; clear_shutdown_time; rm -f "$STATE_DIR/active_schedule_name"; ok "Zeitplan deaktiviert" ;;
 schedule_delete) name="${2:-}"; validate_name "$name"; rm -f -- "$HOME4/schedules/$name"; ok "Skript gelöscht" ;;
 read_named_schedule) name="${2:-}"; validate_name "$name"; [[ -f "$HOME4/schedules/$name" ]] || fail "Skript nicht gefunden"; emit_file "$name" "$HOME4/schedules/$name" ;;
 read_schedule) [[ -s "$HOME4/schedule.wpi" ]] || fail "Kein aktives Skript"; emit_file "$(cat "$STATE_DIR/active_schedule_name" 2>/dev/null || echo schedule.wpi)" "$HOME4/schedule.wpi" ;;
 read_log)
  { cat "$HOME4/wittyPi.log" "$HOME4/schedule.log" 2>/dev/null || true; } >"$LOG_DIR/WittyPi4.log"
  [[ -s "$LOG_DIR/WittyPi4.log" ]] || fail "Keine Witty-Pi-4-Protokolldatei vorhanden"
  printf '{"ok":true,"filename":"WittyPi4.log","size":%s,"view_size":%s,"truncated":false,"partial":false,"content_base64":"%s"}\n' "$(wc -c <"$LOG_DIR/WittyPi4.log")" "$(wc -c <"$LOG_DIR/WittyPi4.log")" "$(base64 -w0 "$LOG_DIR/WittyPi4.log")" ;;
 read_local_log)
  [[ -s "$LOG_DIR/WittyPi4.log" ]] || fail "Auf dem Raspberry ist keine gespeicherte Witty-Pi-4-Protokolldatei vorhanden"
  printf '{"ok":true,"filename":"WittyPi4.log","size":%s,"view_size":%s,"truncated":false,"partial":false,"content_base64":"%s"}\n' "$(wc -c <"$LOG_DIR/WittyPi4.log")" "$(wc -c <"$LOG_DIR/WittyPi4.log")" "$(base64 -w0 "$LOG_DIR/WittyPi4.log")" ;;
 log_status)
  log_size=0
  for log_file in "$HOME4/wittyPi.log" "$HOME4/schedule.log"; do
   [[ -f "$log_file" ]] && log_size=$((log_size + $(wc -c <"$log_file")))
  done
  local_size=0; [[ -s "$LOG_DIR/WittyPi4.log" ]] && local_size="$(wc -c <"$LOG_DIR/WittyPi4.log")"
  printf '{"ok":true,"firmware_size_known":true,"firmware_size":%s,"local_available":%s,"local_size":%s}\n' \
   "$log_size" "$([[ "$local_size" -gt 0 ]] && echo true || echo false)" "$local_size" ;;
 witty_reset)
  RESET_ACTIVE=true; RESET_STARTED_AT="$(date +%s)"; reset_progress running backup 0 10 "" "$RESET_STARTED_AT"
  backup_dir="$STATE_DIR/reset-backups/$(date +%Y%m%d-%H%M%S)"; mkdir -p "$backup_dir/schedules"
  cp -a "$HOME4/schedules/." "$backup_dir/schedules/" 2>/dev/null || true
  [[ -s "$HOME4/schedule.wpi" ]] && install -m 0644 "$HOME4/schedule.wpi" "$backup_dir/schedule.wpi"
  active_name="$(cat "$STATE_DIR/active_schedule_name" 2>/dev/null || true)"
  reset_progress running reset 2 10 "" "$RESET_STARTED_AT"
  clear_startup_time || fail "Witty-Pi-4-Startzeit konnte nicht gelöscht werden; Sicherung: $backup_dir"
  reset_progress running reset 3 10 "Startzeit" "$RESET_STARTED_AT"
  clear_shutdown_time || fail "Witty-Pi-4-Abschaltzeit konnte nicht gelöscht werden; Sicherung: $backup_dir"
  reset_progress running reset 4 10 "Abschaltzeit" "$RESET_STARTED_AT"
  clear_low_voltage_threshold || fail "Witty-Pi-4-Unterspannungsgrenze konnte nicht zurückgesetzt werden; Sicherung: $backup_dir"
  reset_progress running reset 5 10 "Unterspannungsgrenze" "$RESET_STARTED_AT"
  clear_recovery_voltage_threshold || fail "Witty-Pi-4-Wiederherstellungsgrenze konnte nicht zurückgesetzt werden; Sicherung: $backup_dir"
  reset_progress running reset 6 10 "Wiederherstellungsgrenze" "$RESET_STARTED_AT"
  clear_over_temperature_action || fail "Witty-Pi-4-Übertemperaturaktion konnte nicht zurückgesetzt werden; Sicherung: $backup_dir"
  reset_progress running reset 7 10 "Übertemperaturaktion" "$RESET_STARTED_AT"
  clear_below_temperature_action || fail "Witty-Pi-4-Untertemperaturaktion konnte nicht zurückgesetzt werden; Sicherung: $backup_dir"
  reset_progress running restore 8 10 "" "$RESET_STARTED_AT"
  rm -f -- "$HOME4/schedule.wpi" "$HOME4/wittyPi.log" "$HOME4/schedule.log" "$LOG_DIR/WittyPi4.log"
  if [[ -n "$active_name" && -s "$backup_dir/schedules/$active_name" ]]; then
   install -m 0644 "$backup_dir/schedules/$active_name" "$HOME4/schedule.wpi"
   timeout 30s "$HOME4/runScript.sh" 0 revise >/dev/null 2>&1 || fail "Skripte sind gesichert, aber $active_name konnte nicht wieder aktiviert werden; Sicherung: $backup_dir"
   printf '%s' "$active_name" >"$STATE_DIR/active_schedule_name"
  else
   rm -f -- "$STATE_DIR/active_schedule_name"
  fi
  reset_progress complete complete 10 10 "" "$RESET_STARTED_AT"; RESET_ACTIVE=false
  script_count="$(find "$backup_dir/schedules" -maxdepth 1 -type f -iname '*.wpi' | wc -l)"
  printf '{"ok":true,"message":"%s","backup_dir":"%s","restored":%s,"reactivated":%s}\n' \
   "$(esc "Witty Pi 4 wurde zurückgesetzt; $script_count Skripte wurden gesichert")" "$(esc "$backup_dir")" "$script_count" "$([[ -n "$active_name" ]] && echo true || echo false)" ;;
 delete_log) rm -f "$LOG_DIR"/*.log; ok "Lokale Logs gelöscht" ;;
 fixed_timezone) apply_fixed_timezone "${2:-false}" "${3:-Etc/UTC}"; ok "Zeitzone übernommen" ;;
 reboot) ok "Raspberry Pi wird neu gestartet"; (sleep 2; systemctl reboot) >/dev/null 2>&1 & ;;
 shutdown) ok "Raspberry Pi wird heruntergefahren"; (sleep 2; systemctl poweroff) >/dev/null 2>&1 & ;;
 service_start|service_stop)
  svc="${2:-}"
  if [[ "$svc" == allsky ]]; then
   systemctl cat allsky.service >/dev/null 2>&1 || fail "Allsky-Dienst wurde nicht gefunden"
   if [[ "$action" == service_start ]]; then
    timeout 30s systemctl start allsky.service || fail "allsky.service konnte nicht gestartet werden"
    if systemctl cat allskyperiodic.timer >/dev/null 2>&1; then timeout 30s systemctl start allskyperiodic.timer || fail "allskyperiodic.timer konnte nicht gestartet werden"; fi
    sleep 5
    systemctl is-active --quiet allsky.service || fail "Allsky wurde gestartet, aber allsky.service hat sich wieder beendet: $(journalctl -u allsky.service -n 35 --no-pager --output=cat 2>&1 || true)"
    timeout 8s curl --fail --silent --show-error --output /dev/null http://127.0.0.1/ || fail "Allsky läuft, aber der Webserver auf Port 80 antwortet nicht"
    ok "Allsky-Dienste wurden gestartet"
   else
    if systemctl cat allskyperiodic.timer >/dev/null 2>&1; then timeout 30s systemctl stop allskyperiodic.timer || fail "allskyperiodic.timer konnte nicht gestoppt werden"; fi
    if systemctl is-active --quiet allskyperiodic.service; then timeout 30s systemctl stop allskyperiodic.service || fail "allskyperiodic.service konnte nicht gestoppt werden"; fi
    timeout 30s systemctl stop allsky.service || fail "allsky.service konnte nicht gestoppt werden"
    if systemctl is-active --quiet allsky.service || systemctl is-active --quiet allskyperiodic.service || systemctl is-active --quiet allskyperiodic.timer; then fail "Mindestens ein Allsky-Dienst läuft weiterhin"; fi
    ok "Allsky-Dienste wurden gestoppt"
   fi
  else
   [[ "$svc" =~ ^(wurb_2026|wirc_2026)$ ]] || fail "Dienst nicht erlaubt"
   label=WURB; [[ "$svc" == wirc_2026 ]] && label=WIRC
   if [[ "$action" == service_start ]]; then
    systemctl reset-failed "$svc.service" 2>/dev/null || true
   fi
   systemctl "${action#service_}" "$svc.service" || fail "Dienstbefehl fehlgeschlagen"
   if [[ "$svc" == wirc_2026 && "$action" == service_start ]] && ! wait_for_wirc_service; then
    fail "WIRC wurde gestartet, blieb aber nicht stabil oder Port 8082 antwortet nicht: $(wirc_failure_details)"
   fi
   if [[ "$svc" == wurb_2026 && "$action" == service_start ]] && ! wait_for_wurb_service; then
    fail "WURB wurde gestartet, blieb aber nicht stabil oder Port 8080 antwortet nicht: $(journalctl -u wurb_2026.service -n 35 --no-pager --output=cat 2>&1 || true)"
   fi
   if [[ "$action" == service_stop ]] && systemctl is-active --quiet "$svc.service"; then fail "$label-Dienst läuft nach dem Beenden weiterhin"; fi
   result=beendet; [[ "$action" == service_start ]] && result=gestartet
   ok "$label-Dienst wurde $result"
  fi ;;
 internal_rtc_toggle) fail "Raspberry Pi 4 besitzt keine interne RTC" ;;
 *) fail "Aktion wird von Witty Pi 4 nicht unterstützt" ;;
esac
