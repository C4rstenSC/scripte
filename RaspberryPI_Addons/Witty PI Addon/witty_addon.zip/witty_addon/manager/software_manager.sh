#!/usr/bin/env bash
set -Eeuo pipefail

# This component manager is intentionally limited to WURB, WIRC and Allsky.
# It is launched by the local Witty web service and never provides a shell.
readonly ACTION="${1:-}"
readonly COMPONENT="${2:-}"
readonly APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
readonly WURB_REPO="https://github.com/cloudedbats/wurb_2026.git"
readonly WIRC_REPO="https://github.com/cloudedbats/wirc_2026.git"
readonly ALLSKY_REPO="https://github.com/AllskyTeam/allsky.git"
readonly PATCHER="/usr/local/lib/wittypi5-webserver/patch_navigation.py"

[[ "$EUID" -eq 0 ]] || { echo "FEHLER: Softwareverwaltung benötigt Root-Rechte."; exit 1; }
[[ "$ACTION" =~ ^(install|uninstall)$ ]] || { echo "FEHLER: Ungültige Aktion."; exit 2; }
[[ "$COMPONENT" =~ ^(wurb|wirc|allsky)$ ]] || { echo "FEHLER: Ungültige Software."; exit 2; }
export DEBIAN_FRONTEND=noninteractive

# Web-launched package operations run in a pseudo-terminal. Disable APT's
# carriage-return progress animation so the browser receives compact lines.
apt_plain() {
    command apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 \
        -o DPkg::Lock::Timeout=120 -o Dpkg::Options::=--force-confold "$@"
}

repair_interrupted_dpkg() {
    echo "Prüfe den Zustand der Debian-Paketverwaltung ..."
    if timeout 600s dpkg --force-confold --configure -a; then
        echo "Debian-Paketverwaltung ist bereit."
        return 0
    fi
    echo "Unvollständige Paketabhängigkeiten werden automatisch repariert ..."
    apt_plain --fix-broken install -y || {
        echo "FEHLER: Unterbrochene Debian-Paketinstallation konnte nicht repariert werden."
        return 1
    }
    timeout 600s dpkg --force-confold --configure -a || {
        echo "FEHLER: Debian-Pakete konnten nicht vollständig konfiguriert werden."
        return 1
    }
    echo "Debian-Paketverwaltung wurde erfolgreich repariert."
}

ensure_user() {
    if ! id wurb >/dev/null 2>&1; then
        useradd --create-home --shell /bin/bash wurb
    fi
    usermod -aG dialout,sudo,audio,video wurb
}

run_as_wurb() {
    runuser -u wurb -- env HOME=/home/wurb "$@"
}

unmount_project_tree() {
    local project="$1" mount_target=""
    [[ -d "$project" && ! -L "$project" ]] || return 0
    timeout 30s sync >/dev/null 2>&1 || true
    while IFS= read -r -d '' mount_target; do
        echo "Hänge belegten Pfad vor der Sicherung aus: $mount_target"
        if ! timeout 20s umount -- "$mount_target"; then
            echo "Reguläres Aushängen war nicht möglich; trenne den alten Mount verzögert: $mount_target"
            timeout 20s umount --lazy -- "$mount_target" || {
                echo "FEHLER: Belegter Mount konnte nicht getrennt werden: $mount_target"
                return 1
            }
        fi
    done < <(python3 - "$project" <<'PY'
import os
import re
import sys

root = os.path.realpath(sys.argv[1])
targets = []
with open('/proc/self/mountinfo', encoding='utf-8') as handle:
    for line in handle:
        fields = line.split(' - ', 1)[0].split()
        if len(fields) < 5:
            continue
        target = re.sub(r'\\([0-7]{3})', lambda m: chr(int(m.group(1), 8)), fields[4])
        try:
            inside = os.path.commonpath((root, os.path.realpath(target))) == root
        except ValueError:
            inside = False
        if inside:
            targets.append(target)
for target in sorted(set(targets), key=lambda value: (value.count('/'), len(value)), reverse=True):
    sys.stdout.buffer.write(os.fsencode(target) + b'\0')
PY
    )
}

remove_allsky_project() {
    local project="$1" resolved=""
    [[ -e "$project" || -L "$project" ]] || return 0
    case "$project" in
        /home/wurb/allsky|/home/allsky|/home/*/allsky|/opt/allsky) ;;
        *) echo "FEHLER: Unsicherer Allsky-Löschpfad wurde abgelehnt: $project"; return 1 ;;
    esac
    if [[ -L "$project" ]]; then
        rm -f -- "$project"
    else
        resolved="$(readlink -f -- "$project" 2>/dev/null || true)"
        [[ "$resolved" == "$project" ]] || {
            echo "FEHLER: Allsky-Pfad verweist unerwartet auf ein anderes Ziel: $project"
            return 1
        }
        unmount_project_tree "$project" || return 1
        rm -rf --one-file-system -- "$project" || {
            echo "FEHLER: Allsky-Projektordner konnte nicht vollständig entfernt werden: $project"
            return 1
        }
    fi
    [[ ! -e "$project" && ! -L "$project" ]] || {
        echo "FEHLER: Allsky-Projektpfad ist nach dem Löschen weiterhin vorhanden: $project"
        return 1
    }
    echo "Alter Allsky-Projektordner wurde vollständig entfernt: $project"
}

remove_witty_allsky_backups() {
    local root=""
    for root in /var/backups/witty-addon-uninstall /var/backups/witty-addon-stale; do
        [[ -d "$root" ]] || continue
        find "$root" -mindepth 1 -maxdepth 1 -type d -name '*-allsky' \
            -exec rm -rf --one-file-system -- {} + || \
            echo "WARNUNG: Nicht alle alten Allsky-Sicherungen unter $root konnten entfernt werden."
    done
    [[ ! -d /var/backups/witty-allsky-paths ]] || \
        rm -rf --one-file-system -- /var/backups/witty-allsky-paths || \
        echo "WARNUNG: /var/backups/witty-allsky-paths konnte nicht vollständig entfernt werden."
    return 0
}

update_or_clone() {
    local url="$1" destination="$2" default_branch="" remote_revision="" local_revision=""
    if [[ -d "$destination/.git" ]]; then
        echo "Lade den aktuellen Softwarestand von GitHub: $url"
        run_as_wurb git -C "$destination" remote set-url origin "$url"
        if ! run_as_wurb git -C "$destination" diff --quiet || ! run_as_wurb git -C "$destination" diff --cached --quiet; then
            echo "Lokale, versionierte Änderungen werden vor der Neuinstallation als Git-Sicherung abgelegt ..."
            run_as_wurb git -C "$destination" stash push -m "witty-addon-before-reinstall-$(date +%Y%m%d-%H%M%S)"
        fi
        run_as_wurb git -C "$destination" fetch --prune origin
        default_branch="$(run_as_wurb git -C "$destination" remote show origin | sed -n 's/.*HEAD branch: //p' | head -n 1)"
        [[ -n "$default_branch" ]] || default_branch=main
        run_as_wurb git -C "$destination" merge --ff-only "origin/$default_branch"
        remote_revision="$(run_as_wurb git -C "$destination" rev-parse "origin/$default_branch")"
        local_revision="$(run_as_wurb git -C "$destination" rev-parse HEAD)"
        if [[ "$local_revision" != "$remote_revision" ]]; then
            echo "FEHLER: Die lokale Revision weicht nach dem Update noch vom GitHub-Stand ab."
            echo "Lokal:  ${local_revision:0:8}"
            echo "GitHub: ${remote_revision:0:8}"
            exit 1
        fi
    elif [[ -e "$destination" ]]; then
        echo "FEHLER: $destination existiert, ist aber kein Git-Repository."
        exit 1
    else
        echo "Lade die aktuelle Software vollständig von GitHub: $url"
        run_as_wurb git clone --depth 1 "$url" "$destination"
    fi
    local_revision="$(run_as_wurb git -C "$destination" rev-parse HEAD)"
    echo "Installierter GitHub-Stand: ${local_revision:0:8} ($(run_as_wurb git -C "$destination" log -1 --format=%cs))"
}

patch_pages() {
    local component="${1:-}"
    [[ -x "$PATCHER" || -f "$PATCHER" ]] || return 0
    [[ "$component" == wurb && -f /home/wurb/wurb_2026/wurb_app/templates/index.html ]] && \
        python3 "$PATCHER" --kind wurb --file /home/wurb/wurb_2026/wurb_app/templates/index.html || true
    [[ "$component" == wirc && -f /home/wurb/wirc_2026/wirc_app/templates/index.html ]] && \
        python3 "$PATCHER" --kind wirc --file /home/wurb/wirc_2026/wirc_app/templates/index.html || true
    [[ "$component" == allsky && -f /home/wurb/allsky/html/index.php ]] && \
        python3 "$PATCHER" --kind allsky --file /home/wurb/allsky/html/index.php || true
}

install_service_commands() {
    install -d -m 0755 /usr/local/sbin
    install -m 0755 "$APP_DIR/manager/wurb-service" /usr/local/sbin/wurb-service
    install -m 0755 "$APP_DIR/manager/wirc-service" /usr/local/sbin/wirc-service
}

wirc_port_ready() {
    timeout 1s bash -c '</dev/tcp/127.0.0.1/8082' >/dev/null 2>&1
}

wurb_port_ready() {
    timeout 1s bash -c '</dev/tcp/127.0.0.1/8080' >/dev/null 2>&1
}

wait_for_stable_wurb() {
    local attempt consecutive=0 inactive_seconds=0 port_wait_seconds=0 port_seen=0 state=""
    echo "Prüfe WURB-Dienst und Port 8080 acht Sekunden lang auf Stabilität ..."
    for attempt in $(seq 1 45); do
        state="$(systemctl is-active wurb_2026.service 2>/dev/null || true)"
        if [[ "$state" == active ]] && wurb_port_ready; then
            consecutive=$((consecutive + 1))
            inactive_seconds=0
            port_wait_seconds=0
            port_seen=1
            if (( consecutive >= 8 )); then
                echo "WURB läuft stabil und Port 8080 antwortet."
                return 0
            fi
            if (( attempt == 1 || attempt % 5 == 0 )); then
                echo "WURB-Prüfung: ${consecutive}/8 stabile Sekunden."
            fi
        else
            consecutive=0
            if [[ "$state" != active ]]; then
                inactive_seconds=$((inactive_seconds + 1))
                (( inactive_seconds < 5 )) || break
            else
                inactive_seconds=0
                if (( port_seen == 0 )); then
                    port_wait_seconds=$((port_wait_seconds + 1))
                    (( port_wait_seconds < 20 )) || break
                fi
            fi
        fi
        sleep 1
    done
    echo "FEHLER: WURB oder Port 8080 blieb nach der Installation nicht stabil."
    systemctl status wurb_2026.service --no-pager --full || true
    journalctl -u wurb_2026.service -n 80 --no-pager || true
    return 1
}

wait_for_stable_wirc() {
    local attempt consecutive=0 inactive_seconds=0 port_wait_seconds=0 port_seen=0 state=""
    echo "Prüfe kurz, ob WIRC-Dienst und Port 8082 erreichbar sind ..."
    for attempt in $(seq 1 25); do
        state="$(systemctl is-active wirc_2026.service 2>/dev/null || true)"
        if [[ "$state" == active ]] && wirc_port_ready; then
            consecutive=$((consecutive + 1))
            inactive_seconds=0
            port_wait_seconds=0
            port_seen=1
            if (( consecutive >= 3 )); then
                echo "WIRC läuft und Port 8082 antwortet."
                return 0
            fi
        else
            consecutive=0
            if [[ "$state" != active ]]; then
                inactive_seconds=$((inactive_seconds + 1))
                (( inactive_seconds < 5 )) || break
            else
                inactive_seconds=0
                if (( port_seen == 0 )); then
                    port_wait_seconds=$((port_wait_seconds + 1))
                    (( port_wait_seconds < 15 )) || break
                fi
            fi
        fi
        sleep 1
    done
    echo "FEHLER: WIRC oder Port 8082 blieb nach der Installation nicht stabil."
    systemctl status wirc_2026.service --no-pager --full || true
    journalctl -u wirc_2026.service -n 80 --no-pager || true
    for log_file in /home/wurb/wirc_logging/wirc_info_log.txt /home/wurb/wirc_logging/wirc_debug_log.txt; do
        if [[ -f "$log_file" ]]; then
            echo "--- $log_file ---"
            tail -n 80 "$log_file" || true
        fi
    done
    return 1
}

stop_unit_before_reinstall() {
    local unit="$1" label="$2"
    systemctl cat "$unit" >/dev/null 2>&1 || return 0
    if systemctl is-active --quiet "$unit"; then
        echo "$label wird für die Neuinstallation beendet ..."
        timeout 45s systemctl stop "$unit" || {
            echo "FEHLER: $label konnte vor der Neuinstallation nicht beendet werden."
            systemctl status "$unit" --no-pager --full || true
            exit 1
        }
    fi
}

ALLSKY_GUARD_ACTIVE=false
ALLSKY_GUARD_PACKAGES=""
ALLSKY_GUARD_REVISION=""
ALLSKY_GUARD_SERVICE=""

capture_allsky_guard() {
    local project=/home/wurb/allsky
    if [[ ! -d "$project" ]] && ! systemctl cat allsky.service >/dev/null 2>&1; then
        return 0
    fi
    ALLSKY_GUARD_ACTIVE=true
    ALLSKY_GUARD_PACKAGES="$(dpkg-query -W -f='${binary:Package}=${Version}\n' \
        'lighttpd*' 'php*' 2>/dev/null | sort || true)"
    ALLSKY_GUARD_REVISION="$(git -C "$project" rev-parse HEAD 2>/dev/null || true)"
    ALLSKY_GUARD_SERVICE="$(systemctl is-active allsky.service 2>/dev/null || true)"
    echo "Allsky-Schutz aktiv: WURB/WIRC verändert weder Allsky-Projekt noch Webserver-/PHP-Pakete."
}

verify_allsky_guard() {
    local project=/home/wurb/allsky packages revision service
    $ALLSKY_GUARD_ACTIVE || return 0
    packages="$(dpkg-query -W -f='${binary:Package}=${Version}\n' \
        'lighttpd*' 'php*' 2>/dev/null | sort || true)"
    revision="$(git -C "$project" rev-parse HEAD 2>/dev/null || true)"
    service="$(systemctl is-active allsky.service 2>/dev/null || true)"
    [[ "$packages" == "$ALLSKY_GUARD_PACKAGES" ]] || {
        echo "FEHLER: Allsky-Webserver-/PHP-Pakete wurden während der Fremdinstallation verändert."
        return 1
    }
    [[ "$revision" == "$ALLSKY_GUARD_REVISION" ]] || {
        echo "FEHLER: Das Allsky-Projekt wurde während der Fremdinstallation verändert."
        return 1
    }
    if [[ "$ALLSKY_GUARD_SERVICE" == active && "$service" != active ]]; then
        echo "FEHLER: Der zuvor aktive Allsky-Dienst ist während der Fremdinstallation ausgefallen."
        return 1
    fi
    echo "Allsky-Schutzprüfung erfolgreich: Installation, Pakete und laufender Dienst blieben unberührt."
}

install_wurb() {
    echo "=== WURB-2026 wird installiert ==="
    capture_allsky_guard
    stop_unit_before_reinstall wurb_2026.service "WURB-Dienst"
    ensure_user
    apt_plain update
    if [[ -x /usr/local/sbin/witty-cloudedbats-trixie-compat ]] && \
       grep -Eq '^VERSION_CODENAME=trixie$' /etc/os-release 2>/dev/null; then
        /usr/local/sbin/witty-cloudedbats-trixie-compat prepare-wurb
    fi
    apt_plain install --no-upgrade -y python3-venv python3-pip python3-dev git alsa-utils ffmpeg \
        libasound2-dev libopenblas-dev pmount python3-pyaudio portaudio19-dev usbutils
    update_or_clone "$WURB_REPO" /home/wurb/wurb_2026
    chown -R wurb:wurb /home/wurb/wurb_2026
    run_as_wurb bash -lc 'set -e; cd /home/wurb/wurb_2026; python3 -m venv venv; . venv/bin/activate; python -m pip install --quiet --upgrade pip; if [[ -f requirements.txt ]]; then python -m pip install --quiet --no-cache-dir -r requirements.txt; fi; python -X faulthandler -c "import numpy; import scipy; print(\"NumPy/SciPy OK\")"'
    if [[ -x /usr/local/sbin/witty-cloudedbats-trixie-compat ]]; then
        /usr/local/sbin/witty-cloudedbats-trixie-compat verify-wurb
    fi
    for pair in \
        "usb_pmount.rules:/etc/udev/rules.d/usb_pmount.rules:0644" \
        "usb_pmount_handler@.service:/lib/systemd/system/usb_pmount_handler@.service:0644" \
        "usb_pmount_script:/usr/local/bin/usb_pmount_script:0755" \
        "pettersson_m500_batmic.rules:/etc/udev/rules.d/pettersson_m500_batmic.rules:0644"; do
        IFS=: read -r source target mode <<<"$pair"
        [[ -f "/home/wurb/wurb_2026/raspberrypi_files/$source" ]] && \
            install -m "$mode" "/home/wurb/wurb_2026/raspberrypi_files/$source" "$target"
    done
    service_source=/home/wurb/wurb_2026/raspberrypi_files/wurb_2026.service
    [[ -f "$service_source" ]] || { echo "FEHLER: WURB-Servicevorlage fehlt."; exit 1; }
    install -m 0644 "$service_source" /etc/systemd/system/wurb_2026.service
    install -d -m 0755 /etc/systemd/system/wurb_2026.service.d
    cat > /etc/systemd/system/wurb_2026.service.d/witty-stability.conf <<'EOF'
[Unit]
StartLimitIntervalSec=180
StartLimitBurst=12

[Service]
Restart=always
RestartSec=10
EOF
    install_service_commands
    if [[ -r /etc/witty-addon.conf ]]; then
        # shellcheck disable=SC1091
        source /etc/witty-addon.conf
    fi
    if [[ "${GPS_MODE:-none}" =~ ^(usb|waveshare_l76x)$ && -x /usr/local/sbin/witty-gps-manager ]]; then
        /usr/local/sbin/witty-gps-manager configure "$GPS_MODE"
    fi
    udevadm control --reload-rules || true
    echo "WURB-Dienst wird für die Homepage-Aktualisierung angehalten ..."
    timeout 45s systemctl stop wurb_2026.service 2>/dev/null || true
    echo "Spiele die Witty-Navigation erneut in die WURB-Homepage ein ..."
    patch_pages wurb
    systemctl daemon-reload
    systemctl enable wurb_2026.service
    systemctl reset-failed wurb_2026.service || true
    systemctl start wurb_2026.service
    wait_for_stable_wurb || exit 1
    verify_allsky_guard || exit 1
    echo "=== WURB-2026 wurde erfolgreich installiert ==="
}

install_wirc() {
    echo "=== WIRC-2026 wird installiert ==="
    capture_allsky_guard
    stop_unit_before_reinstall wirc_2026.service "WIRC-Dienst"
    ensure_user
    apt_plain update
    if [[ -x /usr/local/sbin/witty-cloudedbats-trixie-compat ]] && \
       grep -Eq '^VERSION_CODENAME=trixie$' /etc/os-release 2>/dev/null; then
        /usr/local/sbin/witty-cloudedbats-trixie-compat prepare-wirc
    fi
    apt_plain install --no-upgrade -y python3-venv python3-pip python3-dev git python3-picamera2 \
        python3-opencv ffmpeg usbutils pmount
    update_or_clone "$WIRC_REPO" /home/wurb/wirc_2026
    chown -R wurb:wurb /home/wurb/wirc_2026
    run_as_wurb bash -lc 'set -e; cd /home/wurb/wirc_2026; python3 -m venv --system-site-packages venv; . venv/bin/activate; python -m pip install --quiet --upgrade pip; if [[ -f requirements.txt ]]; then python -m pip install --quiet --no-cache-dir -r requirements.txt; fi'
    run_as_wurb /home/wurb/wirc_2026/venv/bin/python3 -c \
        'import cv2, picamera2, libcamera, fastapi, uvicorn, jinja2, PIL, yaml; print("WIRC Python-/Kamerabibliotheken: OK")'
    if [[ -x /usr/local/sbin/witty-cloudedbats-trixie-compat ]]; then
        /usr/local/sbin/witty-cloudedbats-trixie-compat verify-wirc
    fi
    run_as_wurb /home/wurb/wirc_2026/venv/bin/python3 -c \
        'import importlib.metadata as m; import fastapi, fastapi.templating, uvicorn, websockets; from python_multipart.multipart import parse_options_header; assert m.version("fastapi") == "0.115.12"; assert m.version("starlette") == "0.46.2"; assert m.version("uvicorn") == "0.34.3"; assert m.version("websockets") == "15.0.1"; assert m.version("python-multipart") == "0.0.20"; assert hasattr(fastapi.templating, "Jinja2Templates"); assert hasattr(uvicorn, "Config"); assert hasattr(uvicorn, "Server"); from uvicorn.protocols.websockets.websockets_impl import WebSocketProtocol; print("WIRC Python-Webschnittstelle: OK")'
    service_source=/home/wurb/wirc_2026/raspberrypi_files/wirc_2026.service
    if [[ -f "$service_source" ]]; then
        install -m 0644 "$service_source" /etc/systemd/system/wirc_2026.service
    else
        install -m 0644 "$APP_DIR/manager/wirc_2026.service" /etc/systemd/system/wirc_2026.service
    fi
    install -d -m 0755 /etc/systemd/system/wirc_2026.service.d
    cat > /etc/systemd/system/wirc_2026.service.d/witty-stability.conf <<'EOF'
[Unit]
StartLimitIntervalSec=180
StartLimitBurst=12

[Service]
Restart=always
RestartSec=10
EOF
    install_service_commands
    echo "WIRC-Dienst wird für die Homepage-Aktualisierung angehalten ..."
    timeout 45s systemctl stop wirc_2026.service 2>/dev/null || true
    echo "Spiele die Witty-Navigation erneut in die WIRC-Homepage ein ..."
    patch_pages wirc
    systemctl daemon-reload
    systemctl enable wirc_2026.service
    systemctl reset-failed wirc_2026.service || true
    systemctl start wirc_2026.service
    wait_for_stable_wirc || exit 1
    verify_allsky_guard || exit 1
    echo "=== WIRC-2026 wurde erfolgreich installiert ==="
}

prepare_allsky_usb_mount() {
    local source_dir="" temp_dir=""
    # Abgebrochene frühere Installationsversuche dürfen weder Speicherplatz
    # belegen noch einen erneuten Versuch beeinflussen. Es werden ausschließlich
    # die von dieser Funktion erzeugten, eindeutig benannten Verzeichnisse
    # direkt unter /var/tmp entfernt.
    find /var/tmp -mindepth 1 -maxdepth 1 -type d -name 'allsky-usb-pmount.*' \
        -exec rm -rf --one-file-system -- {} + 2>/dev/null || true
    if [[ -f /home/wurb/wurb_2026/raspberrypi_files/usb_pmount.rules ]] && \
       [[ -f /home/wurb/wurb_2026/raspberrypi_files/usb_pmount_handler@.service ]] && \
       [[ -f /home/wurb/wurb_2026/raspberrypi_files/usb_pmount_script ]]; then
        source_dir=/home/wurb/wurb_2026/raspberrypi_files
    else
        temp_dir="$(mktemp -d /var/tmp/allsky-usb-pmount.XXXXXX)"
        # mktemp erzeugt das Verzeichnis root:root mit Modus 0700. Ein Clone
        # als Benutzer wurb kann darin kein repository-Verzeichnis anlegen.
        # Die Dateien werden nur kurzfristig als Root gelesen und anschließend
        # vollständig entfernt, daher erfolgt dieser temporäre Clone als Root.
        if ! git clone --depth 1 "$WURB_REPO" "$temp_dir/repository"; then
            rm -rf -- "$temp_dir"
            echo "FEHLER: Die USB-Mount-Dateien für Allsky konnten nicht geladen werden."
            exit 1
        fi
        source_dir="$temp_dir/repository/raspberrypi_files"
    fi
    for required_file in usb_pmount.rules usb_pmount_handler@.service usb_pmount_script; do
        [[ -f "$source_dir/$required_file" ]] || {
            [[ -z "$temp_dir" ]] || rm -rf -- "$temp_dir"
            echo "FEHLER: Die Allsky-USB-Vorbereitung ist unvollständig: $required_file fehlt."
            exit 1
        }
    done
    install -m 0644 "$source_dir/usb_pmount.rules" /etc/udev/rules.d/usb_pmount.rules
    install -m 0644 "$source_dir/usb_pmount_handler@.service" /lib/systemd/system/usb_pmount_handler@.service
    install -m 0755 "$source_dir/usb_pmount_script" /usr/local/bin/usb_pmount_script
    [[ -z "$temp_dir" ]] || rm -rf -- "$temp_dir"
    systemctl daemon-reload
    udevadm control --reload-rules || true
}

allsky_camera_diagnostics() {
    local camera_tool=""
    echo "=== Allsky-Kameraprüfung ==="
    for candidate in rpicam-still libcamera-still; do
        if command -v "$candidate" >/dev/null 2>&1; then
            camera_tool="$candidate"
            break
        fi
    done
    if [[ -n "$camera_tool" ]]; then
        echo "Raspberry-Pi-/CSI-Kameras ($camera_tool --list-cameras):"
        run_as_wurb timeout 20s "$camera_tool" --list-cameras 2>&1 || true
    else
        echo "Kein rpicam-still/libcamera-still im Suchpfad gefunden."
    fi
    echo "USB-Geräte:"
    lsusb 2>&1 || true
    echo "V4L2-Geräte:"
    v4l2-ctl --list-devices 2>&1 || true
    echo "Vorhandene Video-/Media-Geräteknoten:"
    find /dev -maxdepth 1 \( -name 'video*' -o -name 'media*' \) -printf '%f\n' 2>/dev/null | sort || true
    echo "=== Ende der Kameraprüfung ==="
}

allsky_supported_camera_present() {
    local camera_tool="" camera_output=""
    for candidate in rpicam-still libcamera-still; do
        if command -v "$candidate" >/dev/null 2>&1; then
            camera_tool="$candidate"
            break
        fi
    done
    if [[ -n "$camera_tool" ]]; then
        camera_output="$(run_as_wurb timeout 20s "$camera_tool" --list-cameras 2>&1 || true)"
        # rpicam/libcamera listet erkannte CSI-Kameras als "0 : SENSOR [...]".
        if grep -Eq '^[[:space:]]*[0-9]+[[:space:]]*:' <<<"$camera_output"; then
            return 0
        fi
    fi
    # ZWO/ASI verwendet die USB-Herstellerkennung 03c3. Diese Kameras tauchen
    # nicht zwingend als /dev/video* auf, werden aber vom Allsky-ASI-Treiber
    # direkt angesprochen.
    lsusb 2>/dev/null | grep -Eiq '(^|[[:space:]])ID[[:space:]]+03c3:|ZWO|Zhen Wang' && return 0
    return 1
}

print_allsky_no_camera_final() {
    printf '\033[1;31m\n'
    printf '%s\n' "ALLSKY-INSTALLATION BEENDET: Es wurde keine von Allsky unterstützte Kamera erkannt."
    printf '%s\n' "Es wurde noch kein Allsky-Dienst eingerichtet und kein Neustart vorgemerkt."
    printf '%s\n' "USB-/ZWO-Kamera: Kamera einstecken, kurz warten und 'Allsky installieren' erneut anklicken."
    printf '%s\n' "CSI-Flachbandkamera: Raspberry Pi herunterfahren, stromlos anschließen, neu starten"
    printf '%s\n' "und anschließend 'Allsky installieren' erneut anklicken."
    printf '\033[0m\n'
}

install_allsky() {
    echo "=== Allsky wird installiert ==="
    echo "ACHTUNG: Für die Erstinstallation muss mindestens eine unterstützte Kamera angeschlossen sein."
    echo "=== Allsky-Deinstallationsbereinigung vor der Installation ==="
    echo "Prüfe und entferne alte Dienste, Mounts, Weblinks und Allsky-Ordner ..."
    uninstall_component
    if component_path_exists allsky || unit_loaded allsky.service || \
       unit_loaded allskyperiodic.service || unit_loaded allskyperiodic.timer; then
        echo "FEHLER: Die Allsky-Vorbereinigung hat noch Installationsreste gefunden."
        exit 1
    fi
    echo "Allsky-Vorbereinigung erfolgreich: Es sind keine alten Installationsreste mehr vorhanden."
    ensure_user
    apt_plain update
    apt_plain install -y git curl wget ca-certificates build-essential make gcc g++ pkg-config cmake \
        gawk dialog jq bc rsync unzip zip usbutils v4l-utils python3 python3-pip python3-venv \
        python3-dev network-manager pmount
    apt_plain install -y jc || true
    update_or_clone "$ALLSKY_REPO" /home/wurb/allsky
    chown -R wurb:wurb /home/wurb/allsky
    # Nach dem Download ausführen, damit neben PHP/Lighttpd auch der soeben
    # geladene Allsky-PHP-Code vor dem offiziellen Installer geprüft wird.
    if [[ -x /usr/local/sbin/witty-allsky-trixie-compat ]]; then
        timeout --foreground --kill-after=30s 1200s \
            /usr/local/sbin/witty-allsky-trixie-compat prepare || {
            echo "FEHLER: Die Allsky-/Trixie-Vorbereitung ist fehlgeschlagen oder hat das Zeitlimit überschritten."
            exit 1
        }
    elif grep -Eq '^VERSION_CODENAME=trixie$' /etc/os-release 2>/dev/null; then
        echo "FEHLER: Die benötigte Allsky-/Trixie-Kompatibilitätsschicht fehlt."
        exit 1
    fi
    prepare_allsky_usb_mount
    # The official installer may restart the Pi before this manager returns.
    # Prepare the one-shot navigation and dependency finaliser first.
    [[ -x /usr/local/lib/wittypi5-webserver/finalize_allsky.sh ]] || {
        echo "FEHLER: Der Allsky-Erststart-Finalisierer fehlt."; exit 1;
    }
    [[ -f /etc/systemd/system/wittypi5-allsky-firstboot.service ]] || {
        echo "FEHLER: Der Allsky-Erststart-Service fehlt."; exit 1;
    }
    systemctl daemon-reload
    allsky_camera_diagnostics
    if allsky_supported_camera_present; then
        echo "Unterstützte Kamera erkannt. Die interaktive Allsky-Installation kann beginnen."
    else
        echo "HINWEIS: Aktuell wurde keine unterstützte Kamera erkannt."
        echo "Der offizielle Allsky-Installer wird trotzdem geöffnet und entscheidet abschließend."
    fi
    systemctl enable wittypi5-allsky-firstboot.service
    echo "Der offizielle Allsky-Installer startet jetzt. Das blaue Fenster mit Pfeiltasten, Tabulator, Leertaste und Enter bedienen."
    allsky_installer_rc=0
    run_as_wurb bash -lc 'cd /home/wurb/allsky && bash ./install.sh' || allsky_installer_rc=$?
    if (( allsky_installer_rc != 0 )); then
        systemctl disable wittypi5-allsky-firstboot.service >/dev/null 2>&1 || true
        echo "FEHLER: Der offizielle Allsky-Installer wurde mit Exit-Code $allsky_installer_rc beendet."
        allsky_camera_diagnostics
        if ! allsky_supported_camera_present; then
            print_allsky_no_camera_final
            exit 20
        fi
        exit "$allsky_installer_rc"
    fi
    systemctl daemon-reload
    systemctl show --property=LoadState --value allsky.service | grep -Fxq loaded || {
        echo "FEHLER: Allsky wurde beendet, aber allsky.service fehlt."; exit 1;
    }
    systemctl enable allsky.service >/dev/null 2>&1 || true
    if ! systemctl is-active --quiet allsky.service; then
        echo "Allsky-Dienst wird nach der Installation gestartet ..."
        systemctl reset-failed allsky.service 2>/dev/null || true
        timeout 60s systemctl start allsky.service || true
    fi
    systemctl is-active --quiet allsky.service || {
        echo "FEHLER: Allsky wurde installiert, aber allsky.service läuft nicht."
        systemctl status allsky.service --no-pager --full || true
        journalctl -u allsky.service -n 80 --no-pager || true
        exit 1
    }
    timeout 8s curl --fail --silent --show-error --output /dev/null http://127.0.0.1/ || {
        echo "FEHLER: Der Allsky-Webserver antwortet nach der Installation nicht."
        systemctl status lighttpd.service --no-pager --full || true
        journalctl -u lighttpd.service -n 80 --no-pager || true
        exit 1
    }
    # Beim folgenden Neustart nur Allsky finalisieren. WURB und WIRC werden von
    # einer Allsky-Installation weder gestoppt noch an ihren Homepages geändert.
    systemctl enable wittypi5-allsky-firstboot.service
    systemctl enable allsky.service >/dev/null 2>&1 || true
    if command -v systemd-run >/dev/null 2>&1; then
        reboot_unit="witty-allsky-reboot-$(date +%s)"
        systemd-run --unit="$reboot_unit" --on-active=10s /usr/bin/systemctl reboot >/dev/null || true
        echo "Allsky wurde erfolgreich installiert. Der Raspberry Pi startet in etwa 10 Sekunden neu."
        echo "Beim Neustart wird nur die Witty-Navigation ergänzt; Allsky wird nicht überwacht oder angehalten."
    else
        echo "Allsky wurde erfolgreich installiert. Bitte den Raspberry Pi jetzt neu starten."
    fi
    echo "=== Allsky wurde erfolgreich installiert ==="
}

archive_project() {
    local project="$1" name="$2" backup_root="$3"
    if [[ -e "$project" || -L "$project" ]]; then
        unmount_project_tree "$project" || return 1
        mkdir -p "$backup_root"
        mv -- "$project" "$backup_root/$name"
        echo "Projekt wurde zur Wiederherstellung gesichert: $backup_root/$name"
    fi
}

find_component_project() {
    local candidate=""
    case "$1" in
        wurb)
            for candidate in /home/wurb/wurb_2026 /home/pi/wurb_2026 /opt/wurb_2026; do
                [[ -f "$candidate/wurb_main.py" ]] && { printf '%s\n' "$candidate"; return 0; }
            done
            ;;
        wirc)
            for candidate in /home/wurb/wirc_2026 /home/pi/wirc_2026 /opt/wirc_2026; do
                [[ -f "$candidate/wirc_main.py" ]] && { printf '%s\n' "$candidate"; return 0; }
            done
            ;;
        allsky)
            for candidate in /home/allsky /home/*/allsky /opt/allsky; do
                [[ -f "$candidate/allsky.sh" && -d "$candidate/html" ]] && { printf '%s\n' "$candidate"; return 0; }
            done
            ;;
    esac
    return 1
}

component_path_exists() {
    local candidate=""
    case "$1" in
        wurb) for candidate in /home/wurb/wurb_2026 /home/pi/wurb_2026 /opt/wurb_2026; do [[ ! -e "$candidate" ]] || return 0; done ;;
        wirc) for candidate in /home/wurb/wirc_2026 /home/pi/wirc_2026 /opt/wirc_2026; do [[ ! -e "$candidate" ]] || return 0; done ;;
        allsky) for candidate in /home/allsky /home/*/allsky /opt/allsky; do [[ ! -e "$candidate" ]] || return 0; done ;;
    esac
    return 1
}

remove_unit_file() {
    local unit="$1" fragment
    fragment="$(systemctl show --property=FragmentPath --value "$unit" 2>/dev/null || true)"
    case "$fragment" in
        /etc/systemd/system/*|/usr/lib/systemd/system/*|/lib/systemd/system/*)
            [[ ! -f "$fragment" ]] || rm -f -- "$fragment"
            ;;
    esac
}

unit_loaded() {
    [[ "$(systemctl show --property=LoadState --value "$1" 2>/dev/null || true)" == loaded ]]
}

disable_loaded_unit() {
    local unit="$1"
    unit_loaded "$unit" || return 0
    systemctl disable --now "$unit" || true
}

uninstall_component() {
    local backup_root="/var/backups/witty-addon-uninstall/$(date +%Y%m%d-%H%M%S)-$COMPONENT"
    local project=""
    project="$(find_component_project "$COMPONENT" || true)"
    if [[ "$COMPONENT" == allsky && -z "$project" ]]; then
        for candidate in /home/wurb/allsky /home/allsky /home/*/allsky /opt/allsky; do
            if [[ -e "$candidate" || -L "$candidate" ]]; then
                project="$candidate"
                break
            fi
        done
    fi
    echo "=== $COMPONENT wird deinstalliert ==="
    case "$COMPONENT" in
        wurb)
            disable_loaded_unit wurb_2026.service
            remove_unit_file wurb_2026.service
            rm -rf -- /etc/systemd/system/wurb_2026.service.d
            rm -f -- /usr/local/sbin/wurb-service
            [[ -z "$project" ]] || archive_project "$project" wurb_2026 "$backup_root"
            ;;
        wirc)
            disable_loaded_unit wirc_2026.service
            remove_unit_file wirc_2026.service
            rm -rf -- /etc/systemd/system/wirc_2026.service.d
            rm -f -- /usr/local/sbin/wirc-service
            [[ -z "$project" ]] || archive_project "$project" wirc_2026 "$backup_root"
            ;;
        allsky)
            disable_loaded_unit allskyperiodic.timer
            disable_loaded_unit allsky.service
            unit_loaded allskyperiodic.service && systemctl stop allskyperiodic.service || true
            unit_loaded witty-allsky-compat.service && systemctl disable --now witty-allsky-compat.service >/dev/null 2>&1 || true
            rm -f -- /etc/apt/apt.conf.d/99-witty-allsky-compat \
                /etc/systemd/system/witty-allsky-compat.service \
                /etc/lighttpd/conf-enabled/98-witty-allsky-live.conf \
                /etc/lighttpd/conf-available/98-witty-allsky-live.conf
            unit_loaded wittypi5-allsky-firstboot.service && systemctl disable wittypi5-allsky-firstboot.service >/dev/null 2>&1 || true
            rm -f -- /etc/systemd/system/allsky.service.d/witty-time.conf \
                /etc/systemd/system/allsky.service.d/hotspot.conf \
                /etc/systemd/system/allskyperiodic.service.d/witty-time.conf \
                /etc/systemd/system/allskyperiodic.service.d/hotspot.conf
            remove_unit_file allskyperiodic.timer
            remove_unit_file allskyperiodic.service
            remove_unit_file allsky.service
            [[ -z "$project" ]] || remove_allsky_project "$project" || {
                echo "FEHLER: Der belegte Allsky-Ordner konnte nicht ausgehängt und entfernt werden."
                exit 1
            }
            remove_witty_allsky_backups
            if [[ -L /var/www/html/allsky ]]; then
                rm -f -- /var/www/html/allsky
            fi
            ;;
    esac
    systemctl daemon-reload
    systemctl reset-failed >/dev/null 2>&1 || true
    case "$COMPONENT" in
        wurb)
            if systemctl is-active --quiet wurb_2026.service || unit_loaded wurb_2026.service || \
               component_path_exists wurb || [[ -e /usr/local/sbin/wurb-service ]]; then
                echo "FEHLER: WURB ist nach der Deinstallation noch teilweise vorhanden."
                exit 1
            fi
            ;;
        wirc)
            if systemctl is-active --quiet wirc_2026.service || unit_loaded wirc_2026.service || \
               component_path_exists wirc || [[ -e /usr/local/sbin/wirc-service ]]; then
                echo "FEHLER: WIRC ist nach der Deinstallation noch teilweise vorhanden."
                exit 1
            fi
            ;;
        allsky)
            if systemctl is-active --quiet allsky.service || systemctl is-active --quiet allskyperiodic.service || \
               systemctl is-active --quiet allskyperiodic.timer || unit_loaded allsky.service || \
               unit_loaded allskyperiodic.service || unit_loaded allskyperiodic.timer || \
               component_path_exists allsky; then
                echo "FEHLER: Allsky ist nach der Deinstallation noch teilweise vorhanden."
                exit 1
            fi
            ;;
    esac
    if unit_loaded lighttpd.service; then
        systemctl reload lighttpd.service || true
    fi
    if [[ "$COMPONENT" == allsky ]]; then
        echo "=== Allsky-Deinstallation abgeschlossen; der Projektordner wurde ohne Sicherung entfernt ==="
    else
        echo "=== Deinstallation abgeschlossen; Benutzerdaten außerhalb des Projektordners wurden nicht gelöscht ==="
    fi
}

if [[ "$ACTION" == install ]]; then
    repair_interrupted_dpkg || exit 1
    "install_$COMPONENT"
else
    uninstall_component
fi
