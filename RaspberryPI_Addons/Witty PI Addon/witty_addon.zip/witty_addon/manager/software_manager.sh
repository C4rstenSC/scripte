#!/usr/bin/env bash
set -Eeuo pipefail

# This component manager is intentionally limited to WURB, WIRC and Allsky.
# It is launched by the local Witty web service and never provides a shell.
readonly ACTION="${1:-}"
readonly COMPONENT="${2:-}"
readonly APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
readonly WURB_REPO="https://github.com/cloudedbats/wurb_2026.git"
readonly WIRC_REPO="https://github.com/cloudedbats/wirc_2026.git"
readonly ALLSKY_REPO="https://github.com/AllskyTeam/allsky.git"
readonly PATCHER="/usr/local/lib/wittypi5-webserver/patch_navigation.py"

[[ "$EUID" -eq 0 ]] || { echo "FEHLER: Softwareverwaltung benötigt Root-Rechte."; exit 1; }
[[ "$ACTION" =~ ^(install|uninstall)$ ]] || { echo "FEHLER: Ungültige Aktion."; exit 2; }
[[ "$COMPONENT" =~ ^(wurb|wirc|allsky)$ ]] || { echo "FEHLER: Ungültige Software."; exit 2; }
export DEBIAN_FRONTEND=noninteractive

# Web-launched package operations run in a pseudo-terminal. Disable APT's
# carriage-return progress animation so the browser receives compact lines.
apt_plain() {
    command apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 \
        -o DPkg::Lock::Timeout=120 -o Dpkg::Options::=--force-confold "$@"
}

repair_interrupted_dpkg() {
    echo "Prüfe den Zustand der Debian-Paketverwaltung ..."
    if timeout 600s dpkg --force-confold --configure -a; then
        echo "Debian-Paketverwaltung ist bereit."
        return 0
    fi
    echo "Unvollständige Paketabhängigkeiten werden automatisch repariert ..."
    apt_plain --fix-broken install -y || {
        echo "FEHLER: Unterbrochene Debian-Paketinstallation konnte nicht repariert werden."
        return 1
    }
    timeout 600s dpkg --force-confold --configure -a || {
        echo "FEHLER: Debian-Pakete konnten nicht vollständig konfiguriert werden."
        return 1
    }
    echo "Debian-Paketverwaltung wurde erfolgreich repariert."
}

ensure_user() {
    if ! id wurb >/dev/null 2>&1; then
        useradd --create-home --shell /bin/bash wurb
    fi
    usermod -aG dialout,sudo,audio,video wurb
}

run_as_wurb() {
    runuser -u wurb -- env HOME=/home/wurb "$@"
}

update_or_clone() {
    local url="$1" destination="$2"
    if [[ -d "$destination/.git" ]]; then
        if ! run_as_wurb git -C "$destination" diff --quiet || ! run_as_wurb git -C "$destination" diff --cached --quiet; then
            echo "Lokale, versionierte Änderungen werden vor der Neuinstallation als Git-Sicherung abgelegt ..."
            run_as_wurb git -C "$destination" stash push -m "witty-addon-before-reinstall-$(date +%Y%m%d-%H%M%S)"
        fi
        run_as_wurb git -C "$destination" pull --ff-only
    elif [[ -e "$destination" ]]; then
        echo "FEHLER: $destination existiert, ist aber kein Git-Repository."
        exit 1
    else
        run_as_wurb git clone --depth 1 "$url" "$destination"
    fi
}

patch_pages() {
    [[ -x "$PATCHER" || -f "$PATCHER" ]] || return 0
    [[ -f /home/wurb/wurb_2026/wurb_app/templates/index.html ]] && \
        python3 "$PATCHER" --kind wurb --file /home/wurb/wurb_2026/wurb_app/templates/index.html || true
    [[ -f /home/wurb/wirc_2026/wirc_app/templates/index.html ]] && \
        python3 "$PATCHER" --kind wirc --file /home/wurb/wirc_2026/wirc_app/templates/index.html || true
    [[ -f /home/wurb/allsky/html/index.php ]] && \
        python3 "$PATCHER" --kind allsky --file /home/wurb/allsky/html/index.php || true
}

install_service_commands() {
    install -d -m 0755 /usr/local/sbin
    install -m 0755 "$APP_DIR/manager/wurb-service" /usr/local/sbin/wurb-service
    install -m 0755 "$APP_DIR/manager/wirc-service" /usr/local/sbin/wirc-service
}

wirc_port_ready() {
    timeout 1s bash -c '</dev/tcp/127.0.0.1/8082' >/dev/null 2>&1
}

wurb_port_ready() {
    timeout 1s bash -c '</dev/tcp/127.0.0.1/8080' >/dev/null 2>&1
}

wait_for_stable_wurb() {
    local attempt consecutive=0 inactive_seconds=0 port_wait_seconds=0 port_seen=0 state=""
    echo "Prüfe WURB-Dienst und Port 8080 acht Sekunden lang auf Stabilität ..."
    for attempt in $(seq 1 45); do
        state="$(systemctl is-active wurb_2026.service 2>/dev/null || true)"
        if [[ "$state" == active ]] && wurb_port_ready; then
            consecutive=$((consecutive + 1))
            inactive_seconds=0
            port_wait_seconds=0
            port_seen=1
            if (( consecutive >= 8 )); then
                echo "WURB läuft stabil und Port 8080 antwortet."
                return 0
            fi
            if (( attempt == 1 || attempt % 5 == 0 )); then
                echo "WURB-Prüfung: ${consecutive}/8 stabile Sekunden."
            fi
        else
            consecutive=0
            if [[ "$state" != active ]]; then
                inactive_seconds=$((inactive_seconds + 1))
                (( inactive_seconds < 5 )) || break
            else
                inactive_seconds=0
                if (( port_seen == 0 )); then
                    port_wait_seconds=$((port_wait_seconds + 1))
                    (( port_wait_seconds < 20 )) || break
                fi
            fi
        fi
        sleep 1
    done
    echo "FEHLER: WURB oder Port 8080 blieb nach der Installation nicht stabil."
    systemctl status wurb_2026.service --no-pager --full || true
    journalctl -u wurb_2026.service -n 80 --no-pager || true
    return 1
}

wait_for_stable_wirc() {
    local attempt consecutive=0 inactive_seconds=0 port_wait_seconds=0 port_seen=0 state=""
    echo "Prüfe kurz, ob WIRC-Dienst und Port 8082 erreichbar sind ..."
    for attempt in $(seq 1 25); do
        state="$(systemctl is-active wirc_2026.service 2>/dev/null || true)"
        if [[ "$state" == active ]] && wirc_port_ready; then
            consecutive=$((consecutive + 1))
            inactive_seconds=0
            port_wait_seconds=0
            port_seen=1
            if (( consecutive >= 3 )); then
                echo "WIRC läuft und Port 8082 antwortet."
                return 0
            fi
        else
            consecutive=0
            if [[ "$state" != active ]]; then
                inactive_seconds=$((inactive_seconds + 1))
                (( inactive_seconds < 5 )) || break
            else
                inactive_seconds=0
                if (( port_seen == 0 )); then
                    port_wait_seconds=$((port_wait_seconds + 1))
                    (( port_wait_seconds < 15 )) || break
                fi
            fi
        fi
        sleep 1
    done
    echo "FEHLER: WIRC oder Port 8082 blieb nach der Installation nicht stabil."
    systemctl status wirc_2026.service --no-pager --full || true
    journalctl -u wirc_2026.service -n 80 --no-pager || true
    for log_file in /home/wurb/wirc_logging/wirc_info_log.txt /home/wurb/wirc_logging/wirc_debug_log.txt; do
        if [[ -f "$log_file" ]]; then
            echo "--- $log_file ---"
            tail -n 80 "$log_file" || true
        fi
    done
    return 1
}

stop_unit_before_reinstall() {
    local unit="$1" label="$2"
    systemctl cat "$unit" >/dev/null 2>&1 || return 0
    if systemctl is-active --quiet "$unit"; then
        echo "$label wird für die Neuinstallation beendet ..."
        timeout 45s systemctl stop "$unit" || {
            echo "FEHLER: $label konnte vor der Neuinstallation nicht beendet werden."
            systemctl status "$unit" --no-pager --full || true
            exit 1
        }
    fi
}

install_wurb() {
    echo "=== WURB-2026 wird installiert ==="
    stop_unit_before_reinstall wurb_2026.service "WURB-Dienst"
    ensure_user
    apt_plain update
    if [[ -x /usr/local/sbin/witty-cloudedbats-trixie-compat ]] && \
       grep -Eq '^VERSION_CODENAME=trixie$' /etc/os-release 2>/dev/null; then
        /usr/local/sbin/witty-cloudedbats-trixie-compat prepare-wurb
    fi
    apt_plain install -y python3-venv python3-pip python3-dev git alsa-utils ffmpeg \
        libasound2-dev libopenblas-dev pmount python3-pyaudio portaudio19-dev usbutils
    update_or_clone "$WURB_REPO" /home/wurb/wurb_2026
    chown -R wurb:wurb /home/wurb/wurb_2026
    run_as_wurb bash -lc 'set -e; cd /home/wurb/wurb_2026; python3 -m venv venv; . venv/bin/activate; python -m pip install --quiet --upgrade pip; if [[ -f requirements.txt ]]; then python -m pip install --quiet --no-cache-dir -r requirements.txt; fi; python -X faulthandler -c "import numpy; import scipy; print(\"NumPy/SciPy OK\")"'
    if [[ -x /usr/local/sbin/witty-cloudedbats-trixie-compat ]]; then
        /usr/local/sbin/witty-cloudedbats-trixie-compat verify-wurb
    fi
    for pair in \
        "usb_pmount.rules:/etc/udev/rules.d/usb_pmount.rules:0644" \
        "usb_pmount_handler@.service:/lib/systemd/system/usb_pmount_handler@.service:0644" \
        "usb_pmount_script:/usr/local/bin/usb_pmount_script:0755" \
        "pettersson_m500_batmic.rules:/etc/udev/rules.d/pettersson_m500_batmic.rules:0644"; do
        IFS=: read -r source target mode <<<"$pair"
        [[ -f "/home/wurb/wurb_2026/raspberrypi_files/$source" ]] && \
            install -m "$mode" "/home/wurb/wurb_2026/raspberrypi_files/$source" "$target"
    done
    service_source=/home/wurb/wurb_2026/raspberrypi_files/wurb_2026.service
    [[ -f "$service_source" ]] || { echo "FEHLER: WURB-Servicevorlage fehlt."; exit 1; }
    install -m 0644 "$service_source" /etc/systemd/system/wurb_2026.service
    install -d -m 0755 /etc/systemd/system/wurb_2026.service.d
    cat > /etc/systemd/system/wurb_2026.service.d/witty-stability.conf <<'EOF'
[Unit]
StartLimitIntervalSec=180
StartLimitBurst=12

[Service]
Restart=always
RestartSec=10
EOF
    install_service_commands
    if [[ -r /etc/witty-addon.conf ]]; then
        # shellcheck disable=SC1091
        source /etc/witty-addon.conf
    fi
    if [[ "${GPS_MODE:-none}" =~ ^(usb|waveshare_l76x)$ && -x /usr/local/sbin/witty-gps-manager ]]; then
        /usr/local/sbin/witty-gps-manager configure "$GPS_MODE"
    fi
    udevadm control --reload-rules || true
    echo "WURB-Dienst wird für die Homepage-Aktualisierung angehalten ..."
    timeout 45s systemctl stop wurb_2026.service 2>/dev/null || true
    patch_pages
    systemctl daemon-reload
    systemctl enable wurb_2026.service
    systemctl reset-failed wurb_2026.service || true
    systemctl start wurb_2026.service
    wait_for_stable_wurb || exit 1
    echo "=== WURB-2026 wurde erfolgreich installiert ==="
}

install_wirc() {
    echo "=== WIRC-2026 wird installiert ==="
    stop_unit_before_reinstall wirc_2026.service "WIRC-Dienst"
    ensure_user
    apt_plain update
    if [[ -x /usr/local/sbin/witty-cloudedbats-trixie-compat ]] && \
       grep -Eq '^VERSION_CODENAME=trixie$' /etc/os-release 2>/dev/null; then
        /usr/local/sbin/witty-cloudedbats-trixie-compat prepare-wirc
    fi
    apt_plain install -y python3-venv python3-pip python3-dev git python3-picamera2 \
        python3-opencv ffmpeg usbutils pmount
    update_or_clone "$WIRC_REPO" /home/wurb/wirc_2026
    chown -R wurb:wurb /home/wurb/wirc_2026
    run_as_wurb bash -lc 'set -e; cd /home/wurb/wirc_2026; python3 -m venv --system-site-packages venv; . venv/bin/activate; python -m pip install --quiet --upgrade pip; if [[ -f requirements.txt ]]; then python -m pip install --quiet --no-cache-dir -r requirements.txt; fi'
    run_as_wurb /home/wurb/wirc_2026/venv/bin/python3 -c \
        'import cv2, picamera2, libcamera, fastapi, uvicorn, jinja2, PIL, yaml; print("WIRC Python-/Kamerabibliotheken: OK")'
    if [[ -x /usr/local/sbin/witty-cloudedbats-trixie-compat ]]; then
        /usr/local/sbin/witty-cloudedbats-trixie-compat verify-wirc
    fi
    run_as_wurb /home/wurb/wirc_2026/venv/bin/python3 -c \
        'import importlib.metadata as m; import fastapi, fastapi.templating, uvicorn, websockets; from python_multipart.multipart import parse_options_header; assert m.version("fastapi") == "0.115.12"; assert m.version("starlette") == "0.46.2"; assert m.version("uvicorn") == "0.34.3"; assert m.version("websockets") == "15.0.1"; assert m.version("python-multipart") == "0.0.20"; assert hasattr(fastapi.templating, "Jinja2Templates"); assert hasattr(uvicorn, "Config"); assert hasattr(uvicorn, "Server"); from uvicorn.protocols.websockets.websockets_impl import WebSocketProtocol; print("WIRC Python-Webschnittstelle: OK")'
    service_source=/home/wurb/wirc_2026/raspberrypi_files/wirc_2026.service
    if [[ -f "$service_source" ]]; then
        install -m 0644 "$service_source" /etc/systemd/system/wirc_2026.service
    else
        install -m 0644 "$APP_DIR/manager/wirc_2026.service" /etc/systemd/system/wirc_2026.service
    fi
    install -d -m 0755 /etc/systemd/system/wirc_2026.service.d
    cat > /etc/systemd/system/wirc_2026.service.d/witty-stability.conf <<'EOF'
[Unit]
StartLimitIntervalSec=180
StartLimitBurst=12

[Service]
Restart=always
RestartSec=10
EOF
    install_service_commands
    echo "WIRC-Dienst wird für die Homepage-Aktualisierung angehalten ..."
    timeout 45s systemctl stop wirc_2026.service 2>/dev/null || true
    patch_pages
    systemctl daemon-reload
    systemctl enable wirc_2026.service
    systemctl reset-failed wirc_2026.service || true
    systemctl start wirc_2026.service
    wait_for_stable_wirc || exit 1
    echo "=== WIRC-2026 wurde erfolgreich installiert ==="
}

prepare_allsky_usb_mount() {
    local source_dir="" temp_dir=""
    if [[ -f /home/wurb/wurb_2026/raspberrypi_files/usb_pmount.rules ]] && \
       [[ -f /home/wurb/wurb_2026/raspberrypi_files/usb_pmount_handler@.service ]] && \
       [[ -f /home/wurb/wurb_2026/raspberrypi_files/usb_pmount_script ]]; then
        source_dir=/home/wurb/wurb_2026/raspberrypi_files
    else
        temp_dir="$(mktemp -d /var/tmp/allsky-usb-pmount.XXXXXX)"
        run_as_wurb git clone --depth 1 "$WURB_REPO" "$temp_dir/repository"
        source_dir="$temp_dir/repository/raspberrypi_files"
    fi
    for required_file in usb_pmount.rules usb_pmount_handler@.service usb_pmount_script; do
        [[ -f "$source_dir/$required_file" ]] || {
            [[ -z "$temp_dir" ]] || rm -rf -- "$temp_dir"
            echo "FEHLER: Die Allsky-USB-Vorbereitung ist unvollständig: $required_file fehlt."
            exit 1
        }
    done
    install -m 0644 "$source_dir/usb_pmount.rules" /etc/udev/rules.d/usb_pmount.rules
    install -m 0644 "$source_dir/usb_pmount_handler@.service" /lib/systemd/system/usb_pmount_handler@.service
    install -m 0755 "$source_dir/usb_pmount_script" /usr/local/bin/usb_pmount_script
    [[ -z "$temp_dir" ]] || rm -rf -- "$temp_dir"
    systemctl daemon-reload
    udevadm control --reload-rules || true
}

install_allsky() {
    echo "=== Allsky wird installiert ==="
    echo "ACHTUNG: Für die Erstinstallation muss mindestens eine unterstützte Kamera angeschlossen sein."
    stop_unit_before_reinstall allskyperiodic.timer "Allsky-Zeitsteuerung"
    stop_unit_before_reinstall allskyperiodic.service "Allsky-Periodikdienst"
    stop_unit_before_reinstall allsky.service "Allsky-Dienst"
    ensure_user
    apt_plain update
    apt_plain install -y git curl wget ca-certificates build-essential make gcc g++ pkg-config cmake \
        gawk dialog jq bc rsync unzip zip usbutils v4l-utils python3 python3-pip python3-venv \
        python3-dev network-manager pmount
    apt_plain install -y jc || true
    if [[ -x /usr/local/sbin/witty-allsky-trixie-compat ]]; then
        /usr/local/sbin/witty-allsky-trixie-compat prepare
    elif grep -Eq '^VERSION_CODENAME=trixie$' /etc/os-release 2>/dev/null; then
        echo "FEHLER: Die benötigte Allsky-/Trixie-Kompatibilitätsschicht fehlt."
        exit 1
    fi
    update_or_clone "$ALLSKY_REPO" /home/wurb/allsky
    chown -R wurb:wurb /home/wurb/allsky
    prepare_allsky_usb_mount
    # The official installer may restart the Pi before this manager returns.
    # Prepare the one-shot navigation and dependency finaliser first.
    [[ -x /usr/local/lib/wittypi5-webserver/finalize_allsky.sh ]] || {
        echo "FEHLER: Der Allsky-Erststart-Finalisierer fehlt."; exit 1;
    }
    [[ -f /etc/systemd/system/wittypi5-allsky-firstboot.service ]] || {
        echo "FEHLER: Der Allsky-Erststart-Service fehlt."; exit 1;
    }
    systemctl daemon-reload
    systemctl enable wittypi5-allsky-firstboot.service
    echo "Der offizielle Allsky-Installer startet jetzt. Das blaue Fenster mit Pfeiltasten, Tabulator, Leertaste und Enter bedienen."
    run_as_wurb bash -lc 'cd /home/wurb/allsky && bash ./install.sh'
    systemctl daemon-reload
    systemctl show --property=LoadState --value allsky.service | grep -Fxq loaded || {
        echo "FEHLER: Allsky wurde beendet, aber allsky.service fehlt."; exit 1;
    }
    systemctl is-active --quiet allsky.service || {
        echo "FEHLER: Allsky wurde installiert, aber allsky.service läuft nicht."
        systemctl status allsky.service --no-pager --full || true
        journalctl -u allsky.service -n 80 --no-pager || true
        exit 1
    }
    timeout 8s curl --fail --silent --show-error --output /dev/null http://127.0.0.1/ || {
        echo "FEHLER: Der Allsky-Webserver antwortet nach der Installation nicht."
        systemctl status lighttpd.service --no-pager --full || true
        journalctl -u lighttpd.service -n 80 --no-pager || true
        exit 1
    }
    if [[ -x /usr/local/lib/wittypi5-webserver/finalize_allsky.sh ]]; then
        /usr/local/lib/wittypi5-webserver/finalize_allsky.sh
    else
        patch_pages
        systemctl reload lighttpd.service || true
    fi
    echo "=== Allsky wurde erfolgreich installiert ==="
}

archive_project() {
    local project="$1" name="$2" backup_root="$3"
    if [[ -e "$project" ]]; then
        mkdir -p "$backup_root"
        mv -- "$project" "$backup_root/$name"
        echo "Projekt wurde zur Wiederherstellung gesichert: $backup_root/$name"
    fi
}

find_component_project() {
    local candidate=""
    case "$1" in
        wurb)
            for candidate in /home/wurb/wurb_2026 /home/pi/wurb_2026 /opt/wurb_2026; do
                [[ -f "$candidate/wurb_main.py" ]] && { printf '%s\n' "$candidate"; return 0; }
            done
            ;;
        wirc)
            for candidate in /home/wurb/wirc_2026 /home/pi/wirc_2026 /opt/wirc_2026; do
                [[ -f "$candidate/wirc_main.py" ]] && { printf '%s\n' "$candidate"; return 0; }
            done
            ;;
        allsky)
            for candidate in /home/allsky /home/*/allsky /opt/allsky; do
                [[ -f "$candidate/allsky.sh" && -d "$candidate/html" ]] && { printf '%s\n' "$candidate"; return 0; }
            done
            ;;
    esac
    return 1
}

component_path_exists() {
    local candidate=""
    case "$1" in
        wurb) for candidate in /home/wurb/wurb_2026 /home/pi/wurb_2026 /opt/wurb_2026; do [[ ! -e "$candidate" ]] || return 0; done ;;
        wirc) for candidate in /home/wurb/wirc_2026 /home/pi/wirc_2026 /opt/wirc_2026; do [[ ! -e "$candidate" ]] || return 0; done ;;
        allsky) for candidate in /home/allsky /home/*/allsky /opt/allsky; do [[ ! -e "$candidate" ]] || return 0; done ;;
    esac
    return 1
}

remove_unit_file() {
    local unit="$1" fragment
    fragment="$(systemctl show --property=FragmentPath --value "$unit" 2>/dev/null || true)"
    if [[ "$fragment" == /etc/systemd/system/* && -f "$fragment" ]]; then
        rm -f -- "$fragment"
    fi
}

unit_loaded() {
    [[ "$(systemctl show --property=LoadState --value "$1" 2>/dev/null || true)" == loaded ]]
}

disable_loaded_unit() {
    local unit="$1"
    unit_loaded "$unit" || return 0
    systemctl disable --now "$unit" || true
}

uninstall_component() {
    local backup_root="/var/backups/witty-addon-uninstall/$(date +%Y%m%d-%H%M%S)-$COMPONENT"
    local project=""
    project="$(find_component_project "$COMPONENT" || true)"
    echo "=== $COMPONENT wird deinstalliert ==="
    case "$COMPONENT" in
        wurb)
            disable_loaded_unit wurb_2026.service
            remove_unit_file wurb_2026.service
            rm -rf -- /etc/systemd/system/wurb_2026.service.d
            rm -f -- /usr/local/sbin/wurb-service
            [[ -z "$project" ]] || archive_project "$project" wurb_2026 "$backup_root"
            ;;
        wirc)
            disable_loaded_unit wirc_2026.service
            remove_unit_file wirc_2026.service
            rm -rf -- /etc/systemd/system/wirc_2026.service.d
            rm -f -- /usr/local/sbin/wirc-service
            [[ -z "$project" ]] || archive_project "$project" wirc_2026 "$backup_root"
            ;;
        allsky)
            disable_loaded_unit allskyperiodic.timer
            disable_loaded_unit allsky.service
            unit_loaded allskyperiodic.service && systemctl stop allskyperiodic.service || true
            unit_loaded witty-allsky-compat.service && systemctl disable --now witty-allsky-compat.service >/dev/null 2>&1 || true
            rm -f -- /etc/apt/apt.conf.d/99-witty-allsky-compat
            unit_loaded wittypi5-allsky-firstboot.service && systemctl disable wittypi5-allsky-firstboot.service >/dev/null 2>&1 || true
            remove_unit_file allskyperiodic.timer
            remove_unit_file allskyperiodic.service
            remove_unit_file allsky.service
            [[ -z "$project" ]] || archive_project "$project" allsky "$backup_root"
            ;;
    esac
    systemctl daemon-reload
    systemctl reset-failed >/dev/null 2>&1 || true
    case "$COMPONENT" in
        wurb)
            if systemctl is-active --quiet wurb_2026.service || unit_loaded wurb_2026.service || \
               component_path_exists wurb || [[ -e /usr/local/sbin/wurb-service ]]; then
                echo "FEHLER: WURB ist nach der Deinstallation noch teilweise vorhanden."
                exit 1
            fi
            ;;
        wirc)
            if systemctl is-active --quiet wirc_2026.service || unit_loaded wirc_2026.service || \
               component_path_exists wirc || [[ -e /usr/local/sbin/wirc-service ]]; then
                echo "FEHLER: WIRC ist nach der Deinstallation noch teilweise vorhanden."
                exit 1
            fi
            ;;
        allsky)
            if systemctl is-active --quiet allsky.service || systemctl is-active --quiet allskyperiodic.service || \
               systemctl is-active --quiet allskyperiodic.timer || unit_loaded allsky.service || \
               unit_loaded allskyperiodic.service || unit_loaded allskyperiodic.timer || \
               component_path_exists allsky; then
                echo "FEHLER: Allsky ist nach der Deinstallation noch teilweise vorhanden."
                exit 1
            fi
            ;;
    esac
    patch_pages
    if unit_loaded lighttpd.service; then
        systemctl reload lighttpd.service || true
    fi
    echo "=== Deinstallation abgeschlossen; Benutzerdaten außerhalb des Projektordners wurden nicht gelöscht ==="
}

if [[ "$ACTION" == install ]]; then
    repair_interrupted_dpkg || exit 1
    "install_$COMPONENT"
else
    uninstall_component
fi
