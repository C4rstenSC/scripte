#!/usr/bin/env bash
set -Eeuo pipefail

# Inkrementelles Witty-Add-on-Update. Erst- und Neuinstallationen bleiben
# Aufgabe von installer_addon.sh beziehungsweise software_manager.sh.
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly PREFIX="[Witty-Update]"
readonly BACKEND_ONLY="${WITTY_BACKEND_ONLY:-0}"

log() { printf '%s %s\n' "$PREFIX" "$*"; }
die() { printf '%s FEHLER: %s\n' "$PREFIX" "$*" >&2; exit 1; }

[[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Bitte mit sudo starten: sudo ./update.sh"
for command_name in bash cmp curl find grep install journalctl python3 runuser sed seq systemctl timeout; do
    command -v "$command_name" >/dev/null 2>&1 || die "Das Programm '$command_name' fehlt."
done

package_version="$(tr -d '\r\n' < "$SCRIPT_DIR/VERSION" 2>/dev/null || true)"
[[ -n "$package_version" ]] || die "Die Paketversion fehlt in witty_addon/VERSION."

find_app_dir() {
    local candidate
    for candidate in \
        /home/wurb/wittypi5-webserver \
        /home/pi/wittypi5-webserver \
        /opt/wittypi5-webserver; do
        [[ -f "$candidate/VERSION" ]] && { printf '%s\n' "$candidate"; return 0; }
    done
    find /home -mindepth 2 -maxdepth 3 -type f -path '*/wittypi5-webserver/VERSION' \
        -printf '%h\n' -quit 2>/dev/null
}

app_dir="${WITTY_APP_DIR_OVERRIDE:-$(find_app_dir || true)}"
[[ -n "$app_dir" && -f "$app_dir/VERSION" ]] || \
    die "Das Witty-Add-on ist noch nicht installiert. Bitte installer.sh verwenden."
installed_version="$(tr -d '\r\n' < "$app_dir/VERSION" 2>/dev/null || true)"

if [[ "$installed_version" == "$package_version" ]]; then
    log "Version $package_version ist bereits installiert; gleiche Programmdateien werden übersprungen, die Homepage-Navigation wird erneut geprüft."
else
    log "Aktualisiere Add-on-Version ${installed_version:-unbekannt} auf $package_version."
fi
work_dir="$(mktemp -d /var/tmp/witty-addon-update.XXXXXX)"
backup_root=/var/backups/witty-addon-migration
backup_dir="$backup_root/$(date +%Y%m%d-%H%M%S)"
backup_created=false
changed_files=0
webserver_restart=false
unit_changed=false
wirc_repaired=false

cleanup() { [[ ! -d "${work_dir:-}" ]] || rm -rf -- "$work_dir"; }
cancel_update() {
    trap - INT TERM
    log "Update durch Benutzer abgebrochen."
    cleanup
    exit 130
}
trap cleanup EXIT
trap cancel_update INT TERM

backup_target() {
    local target="$1" relative
    [[ -e "$target" ]] || return 0
    relative="${target#/}"
    mkdir -p "$backup_dir/$(dirname "$relative")"
    cp -a -- "$target" "$backup_dir/$relative"
    backup_created=true
}

install_if_changed() {
    local source="$1" target="$2" mode="$3"
    [[ -f "$source" ]] || die "Paketdatei fehlt: ${source#$SCRIPT_DIR/}"
    if [[ -f "$target" ]] && cmp -s "$source" "$target"; then
        return 1
    fi
    backup_target "$target"
    install -D -o root -g root -m "$mode" -- "$source" "$target"
    changed_files=$((changed_files + 1))
    return 0
}

patch_navigation_if_needed() {
    local kind="$1" target="$2" temporary owner group mode
    [[ -f "$target" ]] || return 0
    temporary="$work_dir/navigation-$kind"
    cp -a -- "$target" "$temporary"
    python3 "$SCRIPT_DIR/installer/patch_navigation.py" --kind "$kind" --file "$temporary" || \
        die "Die Navigation konnte nicht vorbereitet werden: $target"
    if cmp -s "$temporary" "$target"; then
        log "Homepage-Navigation ist aktuell: $target"
        return 0
    fi
    backup_target "$target"
    owner="$(stat -c '%U' "$target")"
    group="$(stat -c '%G' "$target")"
    mode="$(stat -c '%a' "$target")"
    install -o "$owner" -g "$group" -m "$mode" -- "$temporary" "$target"
    changed_files=$((changed_files + 1))
    log "Homepage-Navigation aktualisiert: $target"
}

# Einzeldateiabgleich ohne install.sh, apt oder requirements.txt. VERSION wird
# erst nach vollständigem Erfolg geschrieben, damit ein Fehler wiederholbar ist.
while IFS= read -r -d '' source_file; do
    relative="${source_file#$SCRIPT_DIR/}"
    case "$relative" in
        VERSION|update_addon.sh|installer_addon.sh|install.sh) continue ;;
        */__pycache__/*|*.pyc) continue ;;
    esac
    target_file="$app_dir/$relative"
    mode=0644
    [[ -x "$source_file" ]] && mode=0755
    if install_if_changed "$source_file" "$target_file" "$mode"; then
        case "$relative" in
            web/server.py|web/index.html) webserver_restart=true ;;
        esac
    fi
done < <(find "$SCRIPT_DIR" -type f -print0)

# Auch den Home-Launcher synchronisieren. Der nächste manuelle Lauf verwendet
# dadurch garantiert denselben Updatecode wie das gerade installierte Paket.
launcher_user="${SUDO_USER:-}"
if [[ -z "$launcher_user" || "$launcher_user" == root ]]; then
    launcher_user="$(stat -c '%U' "$app_dir" 2>/dev/null || true)"
fi
if [[ -n "$launcher_user" && "$launcher_user" != root ]] && id "$launcher_user" >/dev/null 2>&1; then
    launcher_home="$(getent passwd "$launcher_user" | cut -d: -f6)"
    launcher_group="$(id -gn "$launcher_user")"
    if [[ -n "$launcher_home" && -d "$launcher_home" ]]; then
        home_update="$launcher_home/update.sh"
        if [[ ! -f "$home_update" ]] || ! cmp -s "$SCRIPT_DIR/launchers/update.sh" "$home_update"; then
            backup_target "$home_update"
            install -o "$launcher_user" -g "$launcher_group" -m 0755 \
                "$SCRIPT_DIR/launchers/update.sh" "$home_update"
            changed_files=$((changed_files + 1))
            log "Update-Starter aktualisiert: $home_update"
        fi
    fi
fi

# Die frueheren Papa-Starter wurden durch die allgemeinen, selbstladenden
# Starter ersetzt. Vor dem Entfernen wird eine vorhandene Altdatei gesichert.
for obsolete_launcher in installer_papa.sh update_papa.sh; do
    obsolete_path="$app_dir/launchers/$obsolete_launcher"
    if [[ -e "$obsolete_path" ]]; then
        backup_target "$obsolete_path"
        rm -f -- "$obsolete_path"
        changed_files=$((changed_files + 1))
    fi
done

# Globale Befehle ebenfalls nur bei Inhaltsänderung ersetzen.
install_if_changed "$SCRIPT_DIR/automation/windows_control.sh" \
    /usr/local/sbin/witty-windows-control 0755 || true
if [[ -e /usr/local/sbin/wurb-service ]] || \
   systemctl show --property=LoadState --value wurb_2026.service 2>/dev/null | grep -Fxq loaded; then
    install_if_changed "$SCRIPT_DIR/manager/wurb-service" \
        /usr/local/sbin/wurb-service 0755 || true
fi
if [[ -e /usr/local/sbin/wirc-service ]] || \
   systemctl show --property=LoadState --value wirc_2026.service 2>/dev/null | grep -Fxq loaded; then
    install_if_changed "$SCRIPT_DIR/manager/wirc-service" \
        /usr/local/sbin/wirc-service 0755 || true
fi
install_if_changed "$SCRIPT_DIR/installer/cloudedbats_trixie_compat.sh" \
    /usr/local/sbin/witty-cloudedbats-trixie-compat 0755 || true
install_if_changed "$SCRIPT_DIR/installer/allsky_trixie_compat.sh" \
    /usr/local/sbin/witty-allsky-trixie-compat 0755 || true
install_if_changed "$SCRIPT_DIR/installer/finalize_allsky.sh" \
    /usr/local/lib/wittypi5-webserver/finalize_allsky.sh 0755 || true
install_if_changed "$SCRIPT_DIR/installer/patch_navigation.py" \
    /usr/local/lib/wittypi5-webserver/patch_navigation.py 0755 || true
install_if_changed "$SCRIPT_DIR/backend/witty-gps-manager" \
    /usr/local/sbin/witty-gps-manager 0755 || true
install_if_changed "$SCRIPT_DIR/backend/witty-time-sync" \
    /usr/local/sbin/witty-time-sync 0755 || true
install_if_changed "$SCRIPT_DIR/backend/witty-disable-auto-time" \
    /usr/local/sbin/witty-disable-auto-time 0755 || true
rm -f -- /usr/local/sbin/wurb-system-to-rpi-rtc /usr/local/sbin/wurb-gps-to-witty
install_if_changed "$SCRIPT_DIR/backend/witty-no-gps-boot-sync" \
    /usr/local/sbin/witty-no-gps-boot-sync 0755 || true
if install_if_changed "$SCRIPT_DIR/backend/witty-no-gps-boot-sync.service" \
        /etc/systemd/system/witty-no-gps-boot-sync.service 0644; then
    unit_changed=true
fi
if install_if_changed "$SCRIPT_DIR/backend/witty-gps-time-once.service" \
        /etc/systemd/system/witty-gps-time-once.service 0644; then
    unit_changed=true
fi
if command -v wp5 >/dev/null 2>&1; then
    install_if_changed "$SCRIPT_DIR/backend/wurb-wp5-time" \
        /usr/local/sbin/wurb-wp5-time 0755 || true
fi
if install_if_changed "$SCRIPT_DIR/installer/wittypi5-allsky-firstboot.service" \
        /etc/systemd/system/wittypi5-allsky-firstboot.service 0644; then
    unit_changed=true
fi
if [[ -e /etc/systemd/system/witty-allsky-compat.service || \
      -e /etc/apt/apt.conf.d/99-witty-allsky-compat || \
      -e /etc/lighttpd/conf-enabled/98-witty-allsky-live.conf || \
      -e /etc/lighttpd/conf-available/98-witty-allsky-live.conf ]]; then
    systemctl disable --now witty-allsky-compat.service >/dev/null 2>&1 || true
    rm -f -- /etc/systemd/system/witty-allsky-compat.service \
        /etc/apt/apt.conf.d/99-witty-allsky-compat \
        /etc/lighttpd/conf-enabled/98-witty-allsky-live.conf \
        /etc/lighttpd/conf-available/98-witty-allsky-live.conf
    unit_changed=true
fi

# Sicherheitsmigration: alte Add-on-Zeitdienste nur aus dem naechsten Boot
# entfernen. Das Update startet/stoppt keine Witty-, RTC- oder GPS-Dienste und
# ruft keinen GPS-Manager auf. Dadurch kann ein Witty-Update weder in einer
# Zeitabfrage haengen noch einen Neustart-/Powerpfad beeinflussen.
for legacy_unit in \
    wurb-witty-hctosys.service \
    wurb-rtc-sync.service \
    wurb-rtc-sync.timer \
    wurb-gps-dst-sync.service \
    wurb-gps-dst-sync.timer; do
    systemctl stop --no-block "$legacy_unit" >/dev/null 2>&1 || true
done
rm -f -- \
    /etc/systemd/system/wurb-witty-hctosys.service \
    /etc/systemd/system/wurb-rtc-sync.service \
    /etc/systemd/system/wurb-rtc-sync.timer \
    /etc/systemd/system/wurb-gps-dst-sync.service \
    /etc/systemd/system/wurb-gps-dst-sync.timer \
    /etc/systemd/system/multi-user.target.wants/wurb-witty-hctosys.service \
    /etc/systemd/system/timers.target.wants/wurb-rtc-sync.timer \
    /etc/systemd/system/timers.target.wants/wurb-gps-dst-sync.timer \
    /etc/systemd/system/allsky.service.d/witty-time.conf \
    /etc/systemd/system/allskyperiodic.service.d/witty-time.conf
unit_changed=true
log "Alte automatische RTC-/GPS-Bootdienste sind deaktiviert; Kein GPS verwendet den schnellen offiziellen wp5d-Startpfad."

if id wurb >/dev/null 2>&1 && getent group i2c >/dev/null 2>&1; then
    usermod -aG i2c wurb
    printf '%s\n' 'f /run/lock/wittypi5_app.lock 0660 root i2c -' \
        > /etc/tmpfiles.d/wittypi5-app-lock.conf
    systemd-tmpfiles --create /etc/tmpfiles.d/wittypi5-app-lock.conf
    chown root:i2c /var/lock/wittypi5_app.lock
    chmod 0660 /var/lock/wittypi5_app.lock
    log "wp5 kann nach einer neuen Anmeldung als Benutzer wurb ohne sudo laufen."
fi

configured_gps_mode="$(sed -nE 's/^GPS_MODE=([^[:space:]]+)$/\1/p' /etc/witty-addon.conf 2>/dev/null | head -n1)"
/usr/local/sbin/witty-disable-auto-time || \
    die "Die automatische Zeitsynchronisation konnte nicht vollständig deaktiviert werden."
log "Netzwerkzeit ist aus; nur die ausgewählte Witty-/GPS-Zeitregel wird eingerichtet."
if [[ "$configured_gps_mode" =~ ^(none|usb|waveshare_l76x)$ ]]; then
    timeout 30s /usr/local/sbin/witty-gps-manager refresh-time "$configured_gps_mode" >/dev/null || \
        die "RTC-/Zeitmodus konnte nicht abschließend eingerichtet werden."
fi
if [[ "$configured_gps_mode" == none ]]; then
    log "Kein GPS: interne Raspberry-RTC aus; wp5d übernimmt die Witty-RTC beim Boot schnell nach Linux."
else
    log "Interne Raspberry-RTC ist aktiv; GPS darf rund fünf Minuten Linux, Pi-RTC und Witty-RTC setzen."
fi

# Der Backend-only-Modus wird von der Windows-Steuerung vor einem gezielten
# Komponentenupdate verwendet. Er aktualisiert nur die Witty-Verwaltung und
# fasst andere installierte Programme, Homepages und Dienste nicht an.
if [[ "$BACKEND_ONLY" != 1 ]]; then

# Eine vorhandene Allsky-Installation wird nur einmal von alten Witty-
# Überwachungsresten befreit. Es gibt weder apt update noch Bild-/HTTP-Prüfung.
allsky_home=""
if systemctl show --property=LoadState --value allsky.service 2>/dev/null | grep -Fxq loaded; then
    for candidate in /home/wurb/allsky /home/allsky /home/*/allsky /opt/allsky; do
        if [[ -f "$candidate/allsky.sh" && -d "$candidate/html" ]]; then
            allsky_home="$candidate"
            break
        fi
    done
fi
if [[ -n "$allsky_home" ]] && grep -Eq '^VERSION_CODENAME=trixie$' /etc/os-release 2>/dev/null; then
    log "Entferne alte Witty-Laufzeitprüfungen aus der vorhandenen Allsky-Installation."
    timeout --foreground --kill-after=30s 240s \
        /usr/local/sbin/witty-allsky-trixie-compat repair || \
        log "WARNUNG: Die Bereinigung war nicht vollständig; Allsky wird nicht angehalten."
else
    log "Allsky ist nicht installiert; keine Allsky-Nachbearbeitung."
fi

# Die Navigationsleisten der bereits installierten Programme werden bei jedem
# manuellen Software-Update erneut aus dem aktuellen Paket erzeugt. Das ist
# bewusst unabhängig von der Add-on-Versionsnummer, weil WURB/WIRC/Allsky ihre
# eigenen Startseiten zwischen zwei Add-on-Versionen ersetzt haben können.
wurb_home=""
for candidate in /home/wurb/wurb_2026 /home/pi/wurb_2026 /opt/wurb_2026; do
    [[ -f "$candidate/wurb_app/templates/index.html" ]] || continue
    wurb_home="$candidate"
    break
done
wirc_home=""
for candidate in /home/wurb/wirc_2026 /home/pi/wirc_2026 /opt/wirc_2026; do
    [[ -f "$candidate/wirc_app/templates/index.html" ]] || continue
    wirc_home="$candidate"
    break
done
[[ -z "$wurb_home" ]] || patch_navigation_if_needed wurb "$wurb_home/wurb_app/templates/index.html"
[[ -z "$wirc_home" ]] || patch_navigation_if_needed wirc "$wirc_home/wirc_app/templates/index.html"
[[ -z "$allsky_home" || ! -f "$allsky_home/html/index.php" ]] || \
    patch_navigation_if_needed allsky "$allsky_home/html/index.php"

web_python=/usr/bin/python3
[[ ! -x /var/lib/witty-addon/web-venv/bin/python3 ]] || \
    web_python=/var/lib/witty-addon/web-venv/bin/python3
sed -e "s|__APP_DIR__|$app_dir|g" -e "s|__PYTHON__|$web_python|g" \
    "$SCRIPT_DIR/installer/wittypi5-webserver.service" \
    > "$work_dir/wittypi5-webserver.service"
if [[ ! -f /etc/systemd/system/wittypi5-webserver.service ]] || \
   ! cmp -s "$work_dir/wittypi5-webserver.service" \
        /etc/systemd/system/wittypi5-webserver.service; then
    install_if_changed "$work_dir/wittypi5-webserver.service" \
        /etc/systemd/system/wittypi5-webserver.service 0644 || true
    unit_changed=true
    webserver_restart=true
fi
if [[ "$unit_changed" == true ]]; then
    timeout 20s systemctl daemon-reload || die "systemd konnte nicht neu geladen werden."
fi

wirc_home=/home/wurb/wirc_2026
wirc_python="$wirc_home/venv/bin/python3"
wirc_unit=wirc_2026.service
wirc_installed=false
if [[ -x "$wirc_python" ]] && \
   systemctl show --property=LoadState --value "$wirc_unit" 2>/dev/null | grep -Fxq loaded; then
    wirc_installed=true
fi

wirc_runtime_ok() {
    [[ "$wirc_installed" == true ]] || return 0
    "$wirc_python" -c \
        'import importlib.metadata as m; import fastapi, fastapi.templating, uvicorn, websockets; from python_multipart.multipart import parse_options_header; assert m.version("fastapi") == "0.115.12"; assert m.version("starlette") == "0.46.2"; assert m.version("uvicorn") == "0.34.3"; assert m.version("websockets") == "15.0.1"; assert m.version("python-multipart") == "0.0.20"; assert hasattr(fastapi.templating, "Jinja2Templates"); assert hasattr(uvicorn, "Config"); assert hasattr(uvicorn, "Server"); from uvicorn.protocols.websockets.websockets_impl import WebSocketProtocol' \
        >/dev/null 2>&1
}

if [[ "$wirc_installed" == true ]]; then
    if ! wirc_runtime_ok; then
        log "Repariere ausschließlich die inkompatible WIRC-Weblaufzeit."
        timeout 25s systemctl stop "$wirc_unit" 2>/dev/null || \
            die "WIRC konnte für die Laufzeitreparatur nicht angehalten werden."
        # Das äußere Limit lässt den zehn pip-Verbindungsversuchen genügend
        # Zeit. Strg+C wird weiterhin durch den Update-Trap sofort behandelt.
        timeout 600s "$SCRIPT_DIR/installer/cloudedbats_trixie_compat.sh" verify-wirc || \
            die "Die WIRC-Laufzeitumgebung konnte nicht repariert werden."
        wirc_runtime_ok || die "Die WIRC-Webschnittstelle bleibt inkompatibel."
        wirc_repaired=true
    else
        log "WIRC-Pythonpakete sind kompatibel; kein Paketabgleich erforderlich."
    fi

    if [[ "$wirc_repaired" == true ]] || ! systemctl is-active --quiet "$wirc_unit"; then
        systemctl reset-failed "$wirc_unit" 2>/dev/null || true
        timeout 25s systemctl restart "$wirc_unit" || die "WIRC konnte nicht gestartet werden."
    fi

    log "Prüfe kurz, ob WIRC auf Port 8082 erreichbar bleibt."
    wirc_ready=false
    for attempt in $(seq 1 20); do
        state="$(systemctl is-active "$wirc_unit" 2>/dev/null || true)"
        if [[ "$state" == active ]] && \
           timeout 1s bash -c '</dev/tcp/127.0.0.1/8082' >/dev/null 2>&1; then
            sleep 3
            if systemctl is-active --quiet "$wirc_unit" && \
               timeout 1s bash -c '</dev/tcp/127.0.0.1/8082' >/dev/null 2>&1; then
                wirc_ready=true
                break
            fi
        fi
        [[ "$state" =~ ^(failed|inactive)$ ]] && break
        sleep 1
    done
    if [[ "$wirc_ready" != true ]]; then
        systemctl status "$wirc_unit" --no-pager --full || true
        journalctl -u "$wirc_unit" -n 80 --no-pager || true
        die "WIRC läuft nach dem Update nicht stabil auf Port 8082."
    fi
    log "WIRC läuft und Port 8082 antwortet."
else
    log "WIRC ist nicht installiert; keine WIRC-Prüfung oder Paketänderung."
fi

else
    log "Backend-only-Modus: WURB, WIRC und Allsky bleiben vollständig unangetastet."
fi

if [[ "$webserver_restart" == true ]]; then
    log "Webserver-Programmdateien wurden geändert; starte nur diesen Dienst neu."
    timeout 25s systemctl restart wittypi5-webserver.service || \
        die "Der Witty-Webserver konnte nicht neu gestartet werden."
    sleep 2
    systemctl is-active --quiet wittypi5-webserver.service || \
        die "Der Witty-Webserver ist nach dem Neustart nicht aktiv."
    curl --fail --silent --show-error --max-time 8 --output /dev/null \
        http://127.0.0.1:8081/ || die "Der Witty-Webserver antwortet nicht auf Port 8081."
else
    log "Keine laufende Webserver-Programmdatei geändert; Dienst bleibt unangetastet."
fi

if [[ "$installed_version" != "$package_version" ]]; then
    backup_target "$app_dir/VERSION"
    install -o root -g root -m 0644 "$SCRIPT_DIR/VERSION" "$app_dir/VERSION"
fi

prune_backup_root() {
    local root="$1" name candidate removed=0
    local -a generations=()
    [[ -d "$root" ]] || return 0
    mapfile -t generations < <(
        find "$root" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null | \
            grep -E '^[0-9]{8}-[0-9]{6}$' | sort -r
    )
    for name in "${generations[@]:1}"; do
        [[ "$name" =~ ^[0-9]{8}-[0-9]{6}$ ]] || continue
        candidate="$root/$name"
        [[ -d "$candidate" && "$candidate" == "$root"/* ]] || continue
        rm -rf -- "$candidate"
        removed=$((removed + 1))
    done
    log "Sicherungen: neueste Generation behalten, $removed ältere gelöscht."
}

[[ "$backup_created" != true ]] || prune_backup_root "$backup_root"
log "Update auf Version $package_version erfolgreich; $changed_files geänderte Datei(en)."
[[ "$backup_created" != true ]] || log "Sicherung: $backup_dir"
