#!/usr/bin/env bash
set -Eeuo pipefail

# Inkrementelles Witty-Add-on-Update. Erst- und Neuinstallationen bleiben
# Aufgabe von installer_addon.sh beziehungsweise software_manager.sh.
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly PREFIX="[Witty-Update]"

log() { printf '%s %s\n' "$PREFIX" "$*"; }
die() { printf '%s FEHLER: %s\n' "$PREFIX" "$*" >&2; exit 1; }

[[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Bitte mit sudo starten: sudo ./update.sh"
for command_name in bash cmp curl find grep install journalctl runuser sed seq systemctl timeout; do
    command -v "$command_name" >/dev/null 2>&1 || die "Das Programm '$command_name' fehlt."
done

package_version="$(tr -d '\r\n' < "$SCRIPT_DIR/VERSION" 2>/dev/null || true)"
[[ -n "$package_version" ]] || die "Die Paketversion fehlt in witty_addon/VERSION."

find_app_dir() {
    local candidate
    for candidate in \
        /home/wurb/wittypi5-webserver \
        /home/pi/wittypi5-webserver \
        /opt/wittypi5-webserver; do
        [[ -f "$candidate/VERSION" ]] && { printf '%s\n' "$candidate"; return 0; }
    done
    find /home -mindepth 2 -maxdepth 3 -type f -path '*/wittypi5-webserver/VERSION' \
        -printf '%h\n' -quit 2>/dev/null
}

app_dir="${WITTY_APP_DIR_OVERRIDE:-$(find_app_dir || true)}"
[[ -n "$app_dir" && -f "$app_dir/VERSION" ]] || \
    die "Das Witty-Add-on ist noch nicht installiert. Bitte installer.sh verwenden."
installed_version="$(tr -d '\r\n' < "$app_dir/VERSION" 2>/dev/null || true)"

# Vor Sicherungen, Paketprüfungen und systemctl-Aufrufen beenden. Ein erneuter
# Aufruf derselben Version verändert somit weder Pakete noch Dienste.
if [[ "$installed_version" == "$package_version" ]]; then
    log "Version $package_version ist bereits installiert; keine Änderungen erforderlich."
    printf '[WITTY-CONTROL] event=update_skipped reason=already-current version=%s\n' "$package_version"
    exit 0
fi

log "Aktualisiere Add-on-Version ${installed_version:-unbekannt} auf $package_version."
work_dir="$(mktemp -d /var/tmp/witty-addon-update.XXXXXX)"
backup_root=/var/backups/witty-addon-migration
backup_dir="$backup_root/$(date +%Y%m%d-%H%M%S)"
backup_created=false
changed_files=0
webserver_restart=false
unit_changed=false
wirc_repaired=false

cleanup() { [[ ! -d "${work_dir:-}" ]] || rm -rf -- "$work_dir"; }
cancel_update() {
    trap - INT TERM
    log "Update durch Benutzer abgebrochen."
    cleanup
    exit 130
}
trap cleanup EXIT
trap cancel_update INT TERM

backup_target() {
    local target="$1" relative
    [[ -e "$target" ]] || return 0
    relative="${target#/}"
    mkdir -p "$backup_dir/$(dirname "$relative")"
    cp -a -- "$target" "$backup_dir/$relative"
    backup_created=true
}

install_if_changed() {
    local source="$1" target="$2" mode="$3"
    [[ -f "$source" ]] || die "Paketdatei fehlt: ${source#$SCRIPT_DIR/}"
    if [[ -f "$target" ]] && cmp -s "$source" "$target"; then
        return 1
    fi
    backup_target "$target"
    install -D -o root -g root -m "$mode" -- "$source" "$target"
    changed_files=$((changed_files + 1))
    return 0
}

# Einzeldateiabgleich ohne install.sh, apt oder requirements.txt. VERSION wird
# erst nach vollständigem Erfolg geschrieben, damit ein Fehler wiederholbar ist.
while IFS= read -r -d '' source_file; do
    relative="${source_file#$SCRIPT_DIR/}"
    case "$relative" in
        VERSION|update_addon.sh|installer_addon.sh|install.sh) continue ;;
        */__pycache__/*|*.pyc) continue ;;
    esac
    target_file="$app_dir/$relative"
    mode=0644
    [[ -x "$source_file" ]] && mode=0755
    if install_if_changed "$source_file" "$target_file" "$mode"; then
        case "$relative" in
            web/server.py|web/index.html) webserver_restart=true ;;
        esac
    fi
done < <(find "$SCRIPT_DIR" -type f -print0)

# Globale Befehle ebenfalls nur bei Inhaltsänderung ersetzen.
install_if_changed "$SCRIPT_DIR/automation/windows_control.sh" \
    /usr/local/sbin/witty-windows-control 0755 || true
install_if_changed "$SCRIPT_DIR/installer/cloudedbats_trixie_compat.sh" \
    /usr/local/sbin/witty-cloudedbats-trixie-compat 0755 || true
install_if_changed "$SCRIPT_DIR/installer/allsky_trixie_compat.sh" \
    /usr/local/sbin/witty-allsky-trixie-compat 0755 || true

web_python=/usr/bin/python3
[[ ! -x /var/lib/witty-addon/web-venv/bin/python3 ]] || \
    web_python=/var/lib/witty-addon/web-venv/bin/python3
sed -e "s|__APP_DIR__|$app_dir|g" -e "s|__PYTHON__|$web_python|g" \
    "$SCRIPT_DIR/installer/wittypi5-webserver.service" \
    > "$work_dir/wittypi5-webserver.service"
if [[ ! -f /etc/systemd/system/wittypi5-webserver.service ]] || \
   ! cmp -s "$work_dir/wittypi5-webserver.service" \
        /etc/systemd/system/wittypi5-webserver.service; then
    install_if_changed "$work_dir/wittypi5-webserver.service" \
        /etc/systemd/system/wittypi5-webserver.service 0644 || true
    unit_changed=true
    webserver_restart=true
fi
if [[ "$unit_changed" == true ]]; then
    timeout 20s systemctl daemon-reload || die "systemd konnte nicht neu geladen werden."
fi

wirc_home=/home/wurb/wirc_2026
wirc_python="$wirc_home/venv/bin/python3"
wirc_unit=wirc_2026.service
wirc_installed=false
if [[ -x "$wirc_python" ]] && \
   systemctl show --property=LoadState --value "$wirc_unit" 2>/dev/null | grep -Fxq loaded; then
    wirc_installed=true
fi

wirc_runtime_ok() {
    [[ "$wirc_installed" == true ]] || return 0
    "$wirc_python" -c \
        'import importlib.metadata as m; import fastapi, fastapi.templating, uvicorn, websockets; from python_multipart.multipart import parse_options_header; assert m.version("fastapi") == "0.115.12"; assert m.version("starlette") == "0.46.2"; assert m.version("uvicorn") == "0.34.3"; assert m.version("websockets") == "15.0.1"; assert m.version("python-multipart") == "0.0.20"; assert hasattr(fastapi.templating, "Jinja2Templates"); assert hasattr(uvicorn, "Config"); assert hasattr(uvicorn, "Server"); from uvicorn.protocols.websockets.websockets_impl import WebSocketProtocol' \
        >/dev/null 2>&1
}

if [[ "$wirc_installed" == true ]]; then
    if ! wirc_runtime_ok; then
        log "Repariere ausschließlich die inkompatible WIRC-Weblaufzeit."
        timeout 25s systemctl stop "$wirc_unit" 2>/dev/null || \
            die "WIRC konnte für die Laufzeitreparatur nicht angehalten werden."
        # Das äußere Limit lässt den zehn pip-Verbindungsversuchen genügend
        # Zeit. Strg+C wird weiterhin durch den Update-Trap sofort behandelt.
        timeout 600s "$SCRIPT_DIR/installer/cloudedbats_trixie_compat.sh" verify-wirc || \
            die "Die WIRC-Laufzeitumgebung konnte nicht repariert werden."
        wirc_runtime_ok || die "Die WIRC-Webschnittstelle bleibt inkompatibel."
        wirc_repaired=true
    else
        log "WIRC-Pythonpakete sind kompatibel; kein Paketabgleich erforderlich."
    fi

    if [[ "$wirc_repaired" == true ]] || ! systemctl is-active --quiet "$wirc_unit"; then
        systemctl reset-failed "$wirc_unit" 2>/dev/null || true
        timeout 25s systemctl restart "$wirc_unit" || die "WIRC konnte nicht gestartet werden."
    fi

    log "Prüfe kurz, ob WIRC auf Port 8082 erreichbar bleibt."
    wirc_ready=false
    for attempt in $(seq 1 20); do
        state="$(systemctl is-active "$wirc_unit" 2>/dev/null || true)"
        if [[ "$state" == active ]] && \
           timeout 1s bash -c '</dev/tcp/127.0.0.1/8082' >/dev/null 2>&1; then
            sleep 3
            if systemctl is-active --quiet "$wirc_unit" && \
               timeout 1s bash -c '</dev/tcp/127.0.0.1/8082' >/dev/null 2>&1; then
                wirc_ready=true
                break
            fi
        fi
        [[ "$state" =~ ^(failed|inactive)$ ]] && break
        sleep 1
    done
    if [[ "$wirc_ready" != true ]]; then
        systemctl status "$wirc_unit" --no-pager --full || true
        journalctl -u "$wirc_unit" -n 80 --no-pager || true
        die "WIRC läuft nach dem Update nicht stabil auf Port 8082."
    fi
    log "WIRC läuft und Port 8082 antwortet."
else
    log "WIRC ist nicht installiert; keine WIRC-Prüfung oder Paketänderung."
fi

if [[ "$webserver_restart" == true ]]; then
    log "Webserver-Programmdateien wurden geändert; starte nur diesen Dienst neu."
    timeout 25s systemctl restart wittypi5-webserver.service || \
        die "Der Witty-Webserver konnte nicht neu gestartet werden."
    sleep 2
    systemctl is-active --quiet wittypi5-webserver.service || \
        die "Der Witty-Webserver ist nach dem Neustart nicht aktiv."
    curl --fail --silent --show-error --max-time 8 --output /dev/null \
        http://127.0.0.1:8081/ || die "Der Witty-Webserver antwortet nicht auf Port 8081."
else
    log "Keine laufende Webserver-Programmdatei geändert; Dienst bleibt unangetastet."
fi

backup_target "$app_dir/VERSION"
install -o root -g root -m 0644 "$SCRIPT_DIR/VERSION" "$app_dir/VERSION"

prune_backup_root() {
    local root="$1" name candidate removed=0
    local -a generations=()
    [[ -d "$root" ]] || return 0
    mapfile -t generations < <(
        find "$root" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' 2>/dev/null | \
            grep -E '^[0-9]{8}-[0-9]{6}$' | sort -r
    )
    for name in "${generations[@]:1}"; do
        [[ "$name" =~ ^[0-9]{8}-[0-9]{6}$ ]] || continue
        candidate="$root/$name"
        [[ -d "$candidate" && "$candidate" == "$root"/* ]] || continue
        rm -rf -- "$candidate"
        removed=$((removed + 1))
    done
    log "Sicherungen: neueste Generation behalten, $removed ältere gelöscht."
}

[[ "$backup_created" != true ]] || prune_backup_root "$backup_root"
log "Update auf Version $package_version erfolgreich; $changed_files geänderte Datei(en)."
[[ "$backup_created" != true ]] || log "Sicherung: $backup_dir"
