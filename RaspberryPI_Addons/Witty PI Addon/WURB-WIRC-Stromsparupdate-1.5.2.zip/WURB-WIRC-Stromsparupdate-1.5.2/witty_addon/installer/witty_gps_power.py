"""Event-driven supervision for the add-on's patched WURB GPS reader."""
import asyncio
import time


def install(reader_class, protocol_class):
    if getattr(reader_class, '_witty_event_driven', False):
        return
    # Leave unmodified/upstream readers alone. This replaces only our own poller.
    if not all(hasattr(reader_class, name) for name in ('mark_gps_unavailable', 'witty_fresh_position')):
        return
    original_parse = reader_class.parse_nmea
    original_lost = protocol_class.connection_lost
    original_startup = getattr(reader_class, 'startup', None)

    def startup(reader):
        # A second UI/status client must reuse the recording GPS task instead
        # of resetting its fix counters or opening a second serial reader.
        task = getattr(reader, 'gps_control_task', None)
        if task is not None and not task.done():
            return
        return original_startup(reader)

    def cancel_deadline(reader):
        handle = getattr(reader, '_witty_fix_deadline', None)
        if handle is not None:
            handle.cancel()
        reader._witty_fix_deadline = None

    def parse_nmea(reader, data):
        before = getattr(reader, 'last_gps_data_monotonic', None)
        result = original_parse(reader, data)
        received = getattr(reader, 'last_gps_data_monotonic', None)
        if received is not None:
            reader._witty_had_fix_this_link = True
        if received != before:
            cancel_deadline(reader)
            if received is not None:
                # Renew a single deadline on a valid fix, instead of polling.
                remaining = max(0.0, 3.0 - (time.monotonic() - received))
                reader._witty_fix_deadline = asyncio.get_running_loop().call_later(
                    remaining, reader.mark_gps_unavailable)
        return result

    def connection_lost(protocol, error):
        try:
            original_lost(protocol, error)
        finally:
            reader = getattr(protocol, 'gps_manager', None)
            if reader is not None:
                cancel_deadline(reader)
                event = getattr(reader, '_witty_link_lost', None)
                if event is not None:
                    event.set()

    async def gps_control_loop(reader):
        retry_delay = 1.0
        try:
            while True:
                disabled = getattr(reader, 'gps_device_whitelist', ())
                if disabled and all(str(port) == '/dev/ttyGPS-disabled' for port in disabled):
                    # Reconfiguration restarts WURB; no physical device scan is
                    # useful while the loaded configuration explicitly disables GPS.
                    await asyncio.sleep(60)
                    continue
                try:
                    reader._witty_link_lost = asyncio.Event()
                    reader._witty_had_fix_this_link = False
                    connected_at = time.monotonic()
                    reader.serial_transport = None
                    await reader.start()
                    transport = reader.serial_transport
                    if transport is not None and not transport.is_closing():
                        # No timer wakes a healthy connection. Serial callbacks
                        # handle input, invalid fixes and the disconnect event.
                        await reader._witty_link_lost.wait()
                        if reader._witty_had_fix_this_link or time.monotonic() - connected_at >= 30:
                            retry_delay = 1.0
                    reader.mark_gps_unavailable()
                except asyncio.CancelledError:
                    raise
                except Exception as error:
                    reader.logger.debug('GPS reconnect: ' + str(error))
                    reader.mark_gps_unavailable()
                finally:
                    reader.stop()
                    cancel_deadline(reader)
                await asyncio.sleep(retry_delay)
                retry_delay = min(30.0, retry_delay * 2.0)
        except asyncio.CancelledError:
            reader.stop()
            cancel_deadline(reader)
            raise

    reader_class.parse_nmea = parse_nmea
    reader_class.gps_control_loop = gps_control_loop
    protocol_class.connection_lost = connection_lost
    if original_startup is not None:
        reader_class.startup = startup
    reader_class._witty_event_driven = True
