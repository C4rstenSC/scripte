"""Import the proposed worker against existing dependencies before changing files."""
import ast
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def check(app, source, python):
    app, source = Path(app), Path(source)
    for relative in ('web/server.py', 'installer/witty_gps_power.py'):
        ast.parse((source / relative).read_text())
    with tempfile.TemporaryDirectory(prefix='witty-power-preflight-') as folder:
        stage = Path(folder)
        (stage / 'web').mkdir()
        (stage / 'installer').mkdir()
        for relative in ('web/allsky_focus.py', 'installer/wpi_schedule.py'):
            original = app / relative
            if not original.is_file():
                raise RuntimeError('Vorhandene Add-on-Abhängigkeit fehlt: ' + str(original))
            (stage / relative).symlink_to(original.resolve())
        shutil.copyfile(source / 'web/server.py', stage / 'web/server.py')
        code = ('import sys,runpy;sys.dont_write_bytecode=True;'
                'sys.path.insert(0,sys.argv[1]);'
                'runpy.run_path(sys.argv[1]+"/server.py",run_name="witty_preflight")')
        result = subprocess.run([python, '-c', code, str(stage / 'web')],
                                capture_output=True, text=True, timeout=30)
        if result.returncode:
            raise RuntimeError('Webprozess kann nicht geladen werden: ' + result.stderr[-2000:])


if __name__ == '__main__':
    try:
        check(*sys.argv[1:])
    except Exception as error:
        print('FEHLER: Vorprüfung vor Änderungen: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
