#!/usr/bin/env bash
set -Eeuo pipefail
app_dir="$1"
# Retire the extra background reader on existing installations as well.
# WURB's recording GPS, boot RTC sync and calendar DST job remain independent.
systemctl disable --now witty-gps-watch.service >/dev/null 2>&1 || true
rm -f -- /etc/systemd/system/witty-gps-watch.service
rm -f -- "$app_dir/backend/witty-gps-watch"
systemctl daemon-reload

if [[ -x /usr/local/sbin/witty-time-sync ]]; then
    timeout 25s /usr/local/sbin/witty-time-sync schedule-dst || true
fi
