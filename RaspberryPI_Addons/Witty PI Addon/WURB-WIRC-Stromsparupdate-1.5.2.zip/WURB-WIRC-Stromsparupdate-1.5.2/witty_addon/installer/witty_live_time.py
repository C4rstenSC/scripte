"""Refresh local time rules and WURB solar caches inside the running process."""
import datetime
import os
from pathlib import Path
import sys
import threading
import time

_guard = threading.RLock()
_next_check = 0.0
_last_zone = None
_last_day_offset = None


def refresh():
    global _next_check, _last_zone, _last_day_offset
    now = time.monotonic()
    if now < _next_check:
        return
    with _guard:
        if now < _next_check:
            return
        _next_check = now + 1.0
        try:
            # Only metadata, never reread/hash the timezone file in the audio
            # or video path. A replacement or rewrite changes this signature.
            metadata = Path('/etc/localtime').stat()
            signature = (metadata.st_dev, metadata.st_ino, metadata.st_size,
                         metadata.st_mtime_ns, metadata.st_ctime_ns)
        except OSError:
            return
        changed = signature != _last_zone
        if changed and hasattr(time, 'tzset'):
            # Force libc to reload even when Witty/FixedOffset was rewritten
            # under the same name. These applications follow system policy.
            os.environ['TZ'] = 'UTC0'
            time.tzset()
            os.environ['TZ'] = ':/etc/localtime'
            time.tzset()
            os.environ.pop('TZ', None)
            time.tzset()
        local = time.localtime()
        day_offset = (local.tm_year, local.tm_yday, local.tm_gmtoff)
        if changed or day_offset != _last_day_offset:
            core = sys.modules.get('wurb_core')
            solar = getattr(core, 'sun_moon', None)
            cache = getattr(solar, 'memory_cache_dict', None)
            if isinstance(cache, dict):
                cache.clear()
            scheduler = getattr(core, 'rec_scheduler', None)
            if scheduler is not None:
                scheduler.solartime_last_used_key = ''
        _last_zone, _last_day_offset = signature, day_offset


def local_now(*args, **kwargs):
    refresh()
    return datetime.datetime.now(*args, **kwargs)


def strftime(*args, **kwargs):
    refresh()
    return time.strftime(*args, **kwargs)
