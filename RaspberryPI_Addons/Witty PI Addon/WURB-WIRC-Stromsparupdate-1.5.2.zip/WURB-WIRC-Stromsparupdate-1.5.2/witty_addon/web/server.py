#!/usr/bin/env python3
import json
import errno
import io
import base64
import fcntl
import grp
import hashlib
import hmac
import math
import mimetypes
import os
import pathlib
import posixpath
import pty
import pwd
import re
import select
import secrets
import shlex
import signal
import socket
import socket
import shutil
import sqlite3
import stat
import struct
import subprocess
import sys
import tarfile
import tempfile
import threading
import termios
import time
import uuid
import zipfile
from datetime import datetime
from zoneinfo import ZoneInfo, available_timezones
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from urllib.parse import parse_qs, quote, urlparse


APP_DIR = pathlib.Path(__file__).resolve().parent.parent
# The same pure analyzer supplies upload validation and the backend list.
sys.path.insert(0, str(APP_DIR / "installer"))
from wpi_schedule import count_events as count_wpi_events
WEB_DIR = APP_DIR / "web"
BACKEND = APP_DIR / "backend" / "witty_backend.sh"
from allsky_focus import FocusPreview, focus_error_text
ALLSKY_LOCK = threading.Lock()
FOCUS_PREVIEW = FocusPreview(operation_lock=ALLSKY_LOCK)
PORT = 8081
DOWNLOAD_DIR = APP_DIR / "downloads"
RESET_PROGRESS_FILE = pathlib.Path("/var/lib/witty-addon/reset-progress.json")
SCHEDULE_PROGRESS_FILE = pathlib.Path("/var/lib/witty-addon/schedule-transfer-progress.json")
SCHEDULE_RATE_FILE = pathlib.Path("/var/lib/witty-addon/i2c-transfer-rate.json")
SCHEDULE_METADATA_FILE = pathlib.Path("/var/lib/witty-addon/schedule-metadata.json")
SCHEDULE_TEMP_DIR = pathlib.Path("/run/witty-addon-schedules")
ALLSKY_PENDING_UPDATE_BACKUP = pathlib.Path("/var/lib/witty-addon/pending-allsky-update-backup")
SHUTDOWN_STATUS_FILE = pathlib.Path("/run/witty-addon/shutdown-status.json")
ALLSKY_BACKUP_DIR = APP_DIR / "allsky-backups"
SOFTWARE_BACKUP_DIR = APP_DIR / "software-backups"
SOFTWARE_TEMP_BACKUP_DIR = pathlib.Path("/run/witty-addon-downloads")
ALLSKY_OPERATION_LOCK = threading.Lock()
ALLSKY_OPERATION = {"action": "", "started": 0.0, "phase": "",
                    "total_files": 0, "copied_files": 0}
SOFTWARE_JOB_LOCK = threading.Lock()
SCHEDULE_TRANSFER_LOCK = threading.Lock()
SHUTDOWN_STATUS_LOCK = threading.Lock()
NAVIGATION_STATUS_LOCK = threading.Lock()
NAVIGATION_STATUS_READY = threading.Event()
NAVIGATION_STATUS_CACHE = {
    "payload": {"wurb": False, "wirc": False, "allsky": False,
                "allsky_active": False, "allsky_periodic_active": False,
                "wurb_active": False, "wirc_active": False,
                "witty": True, "witty_model": "", "ready": False},
    "updated": 0.0,
    "refreshing": False,
}
DEVELOPER_PASSWORD_SHA256 = "07480fb9e85b9396af06f006cf1c95024af2531c65fb505cfbd0add1e2f31573"
DEVELOPER_SESSION_COOKIE = "witty_developer_session"
DEVELOPER_SESSION_SECONDS = 12 * 60 * 60
DEVELOPER_SESSION_LOCK = threading.Lock()
DEVELOPER_SESSIONS = {}
DEVELOPER_SESSION_FILE = pathlib.Path("/run/witty-addon/developer-sessions.json")
DEVELOPER_SESSIONS_LOADED = False
SOFTWARE_JOB = {"running": False, "output": bytearray(), "output_start": 0, "output_total": 0,
                "process": None, "master_fd": None, "action": "", "component": "",
                "exit_code": None, "reboot_scheduled": False, "cancel_requested": False,
                "backup_path": "", "backup_temporary": False, "restore_backup": False}
SOFTWARE_JOB_IDLE_FILE = pathlib.Path("/run/witty-addon/last-software-job.json")
RECORDING_KINDS = {"wurb": "wurb_recordings", "wirc": "wirc_recordings"}
RECORDING_SUFFIXES = {"wurb": {".wav"}, "wirc": {".h264", ".mp4", ".mkv"}}


WINDOWS_SCHEDULE_CACHE = pathlib.Path("/var/lib/witty-addon/windows-schedule-status.json")
SCHEDULE_EVENT_CONDITION = threading.Condition()
SCHEDULE_EVENT_REVISION = 0
SCHEDULE_EVENT_PENDING = False
SCHEDULE_EVENT_DATA = None


def mark_windows_schedule_changed():
    global SCHEDULE_EVENT_PENDING
    with SCHEDULE_EVENT_CONDITION:
        SCHEDULE_EVENT_PENDING = True


def publish_windows_schedule_snapshot(data):
    global SCHEDULE_EVENT_PENDING, SCHEDULE_EVENT_REVISION, SCHEDULE_EVENT_DATA
    with SCHEDULE_EVENT_CONDITION:
        if not SCHEDULE_EVENT_PENDING:
            return
        SCHEDULE_EVENT_PENDING = False
        SCHEDULE_EVENT_REVISION += 1
        SCHEDULE_EVENT_DATA = dict(data)
        SCHEDULE_EVENT_CONDITION.notify_all()


def windows_schedule_event(after, timeout=25):
    # Wait only for a homepage notification; this never invokes the backend.
    with SCHEDULE_EVENT_CONDITION:
        if after < 0 or after > SCHEDULE_EVENT_REVISION:
            return {"ok": True, "revision": SCHEDULE_EVENT_REVISION, "data": None}
        SCHEDULE_EVENT_CONDITION.wait_for(lambda: SCHEDULE_EVENT_REVISION != after, timeout=timeout)
        changed = SCHEDULE_EVENT_REVISION != after
        return {"ok": True, "revision": SCHEDULE_EVENT_REVISION,
                "data": dict(SCHEDULE_EVENT_DATA) if changed and SCHEDULE_EVENT_DATA else None}


def confirm_navigation_service_state(action, service, payload):
    if action not in {"service_start", "service_stop"} or payload.get("ok") is not True:
        return
    key = {"wurb_2026": "wurb_active", "wirc_2026": "wirc_active", "allsky": "allsky_active"}.get(service)
    if key:
        with NAVIGATION_STATUS_LOCK:
            NAVIGATION_STATUS_CACHE["payload"][key] = action == "service_start"
            # The acknowledged state is newer than the regular cache scan.
            NAVIGATION_STATUS_CACHE["updated"] = time.monotonic()


def cache_windows_schedule_status(action, payload):
    # Reuse readings already requested by the homepage; never poll Witty here.
    if action in {"status", "status_quick"} and payload.get("ok") is True and payload.get("connected") is True:
        data = {name: payload.get(name, "") for name in ("active_script", "next_startup", "next_shutdown", "witty_time")}
        data.update(ok=True, connected=True, captured_at=time.time())
        try:
            WINDOWS_SCHEDULE_CACHE.parent.mkdir(parents=True, exist_ok=True)
            temporary = WINDOWS_SCHEDULE_CACHE.with_name(WINDOWS_SCHEDULE_CACHE.name + f".tmp.{os.getpid()}.{threading.get_ident()}")
            temporary.write_text(json.dumps(data), encoding="utf-8")
            os.replace(temporary, WINDOWS_SCHEDULE_CACHE)
        except OSError:
            pass
        publish_windows_schedule_snapshot(data)
    elif action == "schedule_list" and payload.get("ok") is True:
        # A content match identifies an already active schedule; keep the actual
        # capture time and reuse its times instead of querying hardware again.
        name = str(payload.get("active", ""))
        if not re.fullmatch(r"[A-Za-z0-9._-]{1,64}", name) or name.lower() == "schedule.wpi":
            return
        try:
            data = json.loads(WINDOWS_SCHEDULE_CACHE.read_text(encoding="utf-8"))
            if (data.get("ok") is not True or data.get("connected") is not True
                    or str(data.get("active_script", "")).lower() not in {"schedule", "schedule.wpi"}
                    or not 0 <= time.time() - float(data.get("captured_at", 0)) <= 30):
                return
            data["active_script"] = name
            temporary = WINDOWS_SCHEDULE_CACHE.with_name(WINDOWS_SCHEDULE_CACHE.name + f".tmp.{os.getpid()}.{threading.get_ident()}")
            temporary.write_text(json.dumps(data), encoding="utf-8")
            os.replace(temporary, WINDOWS_SCHEDULE_CACHE)
        except (OSError, ValueError, TypeError):
            return
        mark_windows_schedule_changed()
        publish_windows_schedule_snapshot(data)
    elif action == "clear_schedule" or action.startswith("schedule_") and action not in {"schedule_list", "schedule_remote_list", "schedule_preview"}:
        if action in {"schedule_activate", "clear_schedule"} and payload.get("ok") is True:
            mark_windows_schedule_changed()
        try:
            WINDOWS_SCHEDULE_CACHE.unlink(missing_ok=True)
        except OSError:
            pass


def backend_json(action, *arguments, timeout=420):
    result = subprocess.run([str(BACKEND), action, *map(str, arguments)],
                            capture_output=True, text=True, timeout=timeout)
    try:
        payload = json.loads(result.stdout or "{}")
    except json.JSONDecodeError as error:
        detail = (result.stderr or result.stdout or "").strip()[-2000:]
        raise RuntimeError(detail or "Backend returned invalid JSON") from error
    if result.returncode != 0 or not payload.get("ok"):
        raise RuntimeError(payload.get("error") or result.stderr.strip() or f"Backend exit code {result.returncode}")
    cache_windows_schedule_status(action, payload)
    return payload


def developer_session_token(handler):
    try:
        cookie = SimpleCookie(handler.headers.get("Cookie", ""))
        return cookie.get(DEVELOPER_SESSION_COOKIE).value if cookie.get(DEVELOPER_SESSION_COOKIE) else ""
    except (AttributeError, KeyError):
        return ""


def developer_session_active(handler):
    token = developer_session_token(handler)
    if not token:
        return False
    now = time.time()
    with DEVELOPER_SESSION_LOCK:
        load_developer_sessions()
        expired = [item for item, expires in DEVELOPER_SESSIONS.items() if expires <= now]
        for item in expired:
            DEVELOPER_SESSIONS.pop(item, None)
        expires = DEVELOPER_SESSIONS.get(token, 0)
        if expires <= now:
            return False
        DEVELOPER_SESSIONS[token] = now + DEVELOPER_SESSION_SECONDS
        save_developer_sessions()
    return True


def create_developer_session():
    token = secrets.token_urlsafe(32)
    with DEVELOPER_SESSION_LOCK:
        load_developer_sessions()
        DEVELOPER_SESSIONS[token] = time.time() + DEVELOPER_SESSION_SECONDS
        save_developer_sessions()
    return token


def remove_developer_session(handler):
    token = developer_session_token(handler)
    if token:
        with DEVELOPER_SESSION_LOCK:
            load_developer_sessions()
            DEVELOPER_SESSIONS.pop(token, None)
            save_developer_sessions()


def load_developer_sessions():
    """Called under the session lock; restore only unexpired root-owned tokens."""
    global DEVELOPER_SESSIONS_LOADED
    if DEVELOPER_SESSIONS_LOADED:
        return
    try:
        info = DEVELOPER_SESSION_FILE.stat()
        if info.st_uid != os.geteuid() or info.st_mode & 0o077:
            raise ValueError("Session store is not private")
        data = json.loads(DEVELOPER_SESSION_FILE.read_text())
        now = time.time()
        DEVELOPER_SESSIONS.update({token: float(expires) for token, expires in data.items()
                                  if isinstance(token, str) and isinstance(expires, (int, float)) and expires > now})
    except (OSError, ValueError, TypeError, AttributeError):
        pass
    DEVELOPER_SESSIONS_LOADED = True


def save_developer_sessions():
    """Persist the login across worker idle exits, never across a system reboot."""
    DEVELOPER_SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
    temporary = DEVELOPER_SESSION_FILE.with_name(DEVELOPER_SESSION_FILE.name + f".{os.getpid()}.tmp")
    try:
        descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(descriptor, "w") as stream:
            json.dump(DEVELOPER_SESSIONS, stream)
        os.chmod(temporary, 0o600)
        os.replace(temporary, DEVELOPER_SESSION_FILE)
    finally:
        temporary.unlink(missing_ok=True)


def shutdown_navigation_status(force=False):
    with SHUTDOWN_STATUS_LOCK:
        try:
            payload = json.loads(SHUTDOWN_STATUS_FILE.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                raise ValueError("invalid shutdown cache")
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            payload = {"ok": True, "witty_time": "", "next_shutdown": "",
                       "active_script": "", "captured_at": 0}
        try:
            captured_at = max(0.0, float(payload.get("captured_at", 0) or 0))
        except (TypeError, ValueError):
            captured_at = 0.0
        payload["cache_age_seconds"] = max(0, int(time.time() - captured_at)) if captured_at else 0
        navigation = navigation_status_cached()
        payload["navigation"] = {
            "witty": True,
            "wurb": bool(navigation.get("wurb_active")),
            "wirc": bool(navigation.get("wirc_active")),
            "allsky": bool(navigation.get("allsky_active")),
            "witty_model": str(navigation.get("witty_model", "")),
            "ready": bool(navigation.get("ready")),
        }
        return payload


def initialise_shutdown_status_cache():
    # Pro Raspberry-Start genau eine Witty-Abfrage. Alle Webseiten lesen danach
    # nur diese kleine RAM-Datei; Aktivieren/Deaktivieren schreibt sie neu.
    if SHUTDOWN_STATUS_FILE.is_file():
        return
    try:
        backend_json("shutdown_cache_refresh", timeout=45)
    except Exception:
        pass


def schedule_transfer_rate():
    try:
        payload = json.loads(SCHEDULE_RATE_FILE.read_text(encoding="utf-8"))
        value = float(payload.get("bytes_per_second", 0))
        if 128 <= value <= 1024 * 1024:
            return value
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        pass
    return 2048.0


def save_schedule_transfer_rate(previous, sample):
    sample = min(max(float(sample), 128.0), 1024 * 1024.0)
    value = sample if previous <= 0 else previous * 0.7 + sample * 0.3
    SCHEDULE_RATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    temporary = SCHEDULE_RATE_FILE.with_name(SCHEDULE_RATE_FILE.name + f".tmp.{os.getpid()}.{threading.get_ident()}")
    temporary.write_text(json.dumps({"bytes_per_second": round(value, 2), "updated_at": int(time.time())}) + "\n")
    temporary.chmod(0o644)
    os.replace(temporary, SCHEDULE_RATE_FILE)
    return value


def stage_schedule_metadata(scripts):
    """Write every validated ZIP entry to the local name/size cache before I2C upload."""
    try:
        metadata = json.loads(SCHEDULE_METADATA_FILE.read_text(encoding="utf-8")) \
            if SCHEDULE_METADATA_FILE.is_file() else {}
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        metadata = {}
    if not isinstance(metadata, dict):
        metadata = {}
    updated_at = int(time.time())
    for name, source, size, events in scripts:
        content = source.read_bytes()
        metadata[name] = {"bytes": size, "events": events,
                          "sha256": hashlib.sha256(content).hexdigest(),
                          "updated_at": updated_at}
    SCHEDULE_METADATA_FILE.parent.mkdir(parents=True, exist_ok=True)
    temporary = SCHEDULE_METADATA_FILE.with_name(
        SCHEDULE_METADATA_FILE.name + f".tmp.{os.getpid()}.{threading.get_ident()}")
    temporary.write_text(json.dumps(metadata, ensure_ascii=False, sort_keys=True,
                                    separators=(",", ":")) + "\n", encoding="utf-8")
    temporary.chmod(0o644)
    os.replace(temporary, SCHEDULE_METADATA_FILE)


def write_schedule_progress(state="idle", direction="", total_bytes=0, processed_bytes=0,
                            total_files=0, processed_files=0, rate=None, detail="", error=""):
    rate = schedule_transfer_rate() if rate is None else max(float(rate), 1.0)
    remaining = max(int(total_bytes) - int(processed_bytes), 0)
    percent = 100 if state == "complete" else (min(99, int(processed_bytes * 100 / total_bytes)) if total_bytes else 0)
    payload = {"ok": True, "active": state == "running", "state": state, "direction": direction,
               "total_bytes": int(total_bytes), "processed_bytes": int(processed_bytes),
               "total_files": int(total_files), "processed_files": int(processed_files),
               "percent": percent, "bytes_per_second": round(rate, 2),
               "eta_seconds": int(math.ceil(remaining / rate)) if state == "running" and remaining else 0,
               "detail": str(detail), "error": str(error), "updated_at": int(time.time())}
    SCHEDULE_PROGRESS_FILE.parent.mkdir(parents=True, exist_ok=True)
    temporary = SCHEDULE_PROGRESS_FILE.with_name(SCHEDULE_PROGRESS_FILE.name + f".tmp.{os.getpid()}.{threading.get_ident()}")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n")
    temporary.chmod(0o644)
    os.replace(temporary, SCHEDULE_PROGRESS_FILE)
    return payload


def cleanup_schedule_temp(max_age=3600):
    SCHEDULE_TEMP_DIR.mkdir(parents=True, exist_ok=True)
    cutoff = time.time() - max_age
    for path in SCHEDULE_TEMP_DIR.iterdir():
        try:
            if path.stat().st_mtime < cutoff:
                if path.is_dir() and not path.is_symlink():
                    shutil.rmtree(path)
                else:
                    path.unlink()
        except OSError:
            pass


def validate_wpi_content(filename, content, allow_long_name=False):
    maximum = 63 if allow_long_name else 26
    if not re.fullmatch(rf"[A-Za-z0-9][A-Za-z0-9._-]{{0,{maximum}}}\.wpi", filename, re.IGNORECASE):
        raise ValueError(f"Invalid WPI filename: {filename}")
    if len(content) == 0 or len(content) > 4000:
        raise ValueError(f"{filename}: file size must be 1 to 4000 bytes")
    try:
        text = content.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ValueError(f"{filename}: file is not valid UTF-8 text") from error
    if any(len(line.encode("utf-8")) >= 128 for line in text.splitlines()):
        raise ValueError(f"{filename}: a line is 128 bytes or longer")
    if any(character in text for character in "<|>"):
        raise ValueError(f"{filename}: contains a forbidden character")
    begin_match = re.search(r"(?mi)^BEGIN\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})", text)
    end_match = re.search(r"(?mi)^END\s+(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})", text)
    if not begin_match or not end_match:
        raise ValueError(f"{filename}: BEGIN or END is missing")
    begin = datetime.strptime(begin_match.group(1), "%Y-%m-%d %H:%M:%S")
    end = datetime.strptime(end_match.group(1), "%Y-%m-%d %H:%M:%S")
    if end <= begin:
        raise ValueError(f"{filename}: END date and time must be after BEGIN")
    durations = []
    factors = {"D": 86400, "H": 3600, "M": 60, "S": 1}
    for match in re.finditer(r"(?mi)^\s*(?:ON|OFF)\s+([^#\r\n]+)", text):
        duration = 0
        for token in match.group(1).split():
            token_match = re.fullmatch(r"([DHMS])(\d+)", token)
            if not token_match:
                raise ValueError(f"{filename}: invalid ON/OFF duration {token}")
            duration += factors[token_match.group(1)] * int(token_match.group(2))
        durations.append(duration)
    if not durations or len(durations) > 128 or sum(durations) <= 0:
        raise ValueError(f"{filename}: invalid ON/OFF sequence")
    events = count_wpi_events(content)
    if events > 4096:
        raise ValueError(f"{filename}: generates more than 4096 events")
    return events


def page_identity():
    hostname = socket.gethostname().split(".", 1)[0].strip()
    name = hostname.casefold()
    if name.startswith("allsky"):
        purpose = "Cloud Images"
    elif name.startswith(("wurb", "wirc")):
        purpose = "BAT-Detector"
    elif allsky_project_path() is not None:
        purpose = "Cloud Images"
    elif project_path("wurb_2026") is not None or project_path("wirc_2026") is not None:
        purpose = "BAT-Detector"
    else:
        purpose = "Raspberry Pi"
    return {"device_hostname": hostname, "device_purpose": purpose}


def raspberry_pi_model():
    try:
        return pathlib.Path("/proc/device-tree/model").read_bytes().rstrip(b"\0").decode("utf-8", errors="replace")
    except OSError:
        try:
            config = pathlib.Path("/etc/witty-addon.conf").read_text(encoding="utf-8")
            match = re.search(r"^RPI_MODEL=([345])$", config, re.MULTILINE)
            return f"Raspberry Pi {match.group(1)}" if match else ""
        except OSError:
            return ""

TIMEZONE_FINDER = None
TIMEZONE_FINDER_READY = False
TIMEZONE_FINDER_LOCK = threading.Lock()


def coordinate_timezone_finder():
    # The optional GPS database (and its imports) can be expensive on a cold Pi.
    # Only coordinate lookup needs it; bind the web server and serve status first.
    global TIMEZONE_FINDER, TIMEZONE_FINDER_READY
    with TIMEZONE_FINDER_LOCK:
        if not TIMEZONE_FINDER_READY:
            try:
                from timezonefinder import TimezoneFinder
                TIMEZONE_FINDER = TimezoneFinder()
            except Exception:
                TIMEZONE_FINDER = None
            TIMEZONE_FINDER_READY = True
        return TIMEZONE_FINDER

# Exactly one familiar place is shown for each currently valid UTC offset.
# A GPS-derived IANA zone replaces this default only for its own current offset.
CANONICAL_TIMEZONES = (
    "Pacific/Pago_Pago", "Pacific/Honolulu", "America/Anchorage",
    "America/Los_Angeles", "America/Denver", "America/Chicago",
    "America/New_York", "America/Halifax", "America/St_Johns",
    "America/Sao_Paulo", "Atlantic/South_Georgia", "Atlantic/Azores",
    "Etc/UTC", "Europe/London", "Europe/Berlin", "Europe/Athens",
    "Asia/Tehran", "Asia/Dubai", "Asia/Kabul", "Asia/Karachi",
    "Asia/Kolkata", "Asia/Kathmandu", "Asia/Dhaka", "Asia/Yangon",
    "Asia/Bangkok", "Asia/Shanghai", "Asia/Tokyo",
    "Pacific/Noumea", "Pacific/Auckland", "Pacific/Chatham",
    "Pacific/Tongatapu", "Pacific/Kiritimati",
    "Australia/Perth", "Australia/Eucla", "Australia/Darwin",
    "Australia/Broken_Hill", "Australia/Lord_Howe", "Australia/Adelaide",
    "Australia/Brisbane", "Australia/Lindeman", "Australia/Hobart",
    "Australia/Melbourne", "Australia/Sydney",
)

AUSTRALIAN_TIMEZONE_PLACES = (
    ("Perth", "Australia/Perth", -31.9523, 115.8613),
    ("Eucla", "Australia/Eucla", -31.6777, 128.8835),
    ("Darwin", "Australia/Darwin", -12.4634, 130.8456),
    ("Adelaide", "Australia/Adelaide", -34.9285, 138.6007),
    ("Broken Hill", "Australia/Broken_Hill", -31.9539, 141.4539),
    ("Brisbane", "Australia/Brisbane", -27.4698, 153.0251),
    ("Sydney", "Australia/Sydney", -33.8688, 151.2093),
    ("Canberra", "Australia/Sydney", -35.2809, 149.1300),
    ("Melbourne", "Australia/Melbourne", -37.8136, 144.9631),
    ("Hobart", "Australia/Hobart", -42.8821, 147.3272),
    ("Lord Howe", "Australia/Lord_Howe", -31.5553, 159.0821),
)


def saved_regional_timezone(fallback):
    saved = pathlib.Path("/var/lib/witty-addon/regional_timezone")
    try:
        value = saved.read_text().strip()
        if value in available_timezones() and value != "Witty/FixedOffset":
            return value
    except OSError:
        pass
    # Migrate the originally configured region; an old offset representative
    # such as Lindeman must not replace Sydney when GPS is unplugged.
    try:
        for line in pathlib.Path("/etc/witty-addon.conf").read_text().splitlines():
            if line.startswith("TIMEZONE="):
                value = line.split("=", 1)[1].strip().strip("\"'")
                if value in available_timezones() and value != "Witty/FixedOffset":
                    return value
    except OSError:
        pass
    return fallback


def timezone_offset_minutes(name):
    local_now = datetime.now(ZoneInfo.no_cache(name))
    delta = local_now.utcoffset()
    return int(delta.total_seconds() // 60)


def timezone_from_coordinates(latitude, longitude):
    try:
        latitude = float(latitude)
        longitude = float(longitude)
        if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
            return ""
        finder = coordinate_timezone_finder()
        if finder is None:
            return ""
        return finder.timezone_at(lng=longitude, lat=latitude) or ""
    except (TypeError, ValueError, OverflowError):
        return ""


def australian_timezone_place(latitude, longitude, gps_zone):
    try:
        latitude = float(latitude)
        longitude = float(longitude)
        if not (-44.5 <= latitude <= -9.0 and 112.0 <= longitude <= 160.5):
            return ""
        gps_minutes = timezone_offset_minutes(gps_zone)
    except (TypeError, ValueError, OSError):
        return ""
    candidates = []
    for name, zone, place_latitude, place_longitude in AUSTRALIAN_TIMEZONE_PLACES:
        try:
            if timezone_offset_minutes(zone) != gps_minutes:
                continue
        except (ValueError, OSError):
            continue
        latitude_scale = math.cos(math.radians((latitude + place_latitude) / 2))
        distance = (latitude - place_latitude) ** 2 + ((longitude - place_longitude) * latitude_scale) ** 2
        candidates.append((distance, name))
    return min(candidates)[1] if candidates else ""


def timezone_abbreviation(name, minutes):
    if name == "Australia/Perth":
        return "AWST"
    if name == "Australia/Eucla":
        return "ACWST"
    if name == "Australia/Darwin":
        return "ACST"
    if name in {"Australia/Adelaide", "Australia/Broken_Hill"}:
        return "ACDT" if minutes == 630 else "ACST"
    if name in {"Australia/Brisbane", "Australia/Lindeman"}:
        return "AEST"
    if name in {"Australia/Sydney", "Australia/Melbourne", "Australia/Hobart"}:
        return "AEDT" if minutes == 660 else "AEST"
    if name == "Australia/Lord_Howe":
        return "LHDT" if minutes == 660 else "LHST"
    return datetime.now(ZoneInfo.no_cache(name)).tzname() or ""


def timezone_choices(current_zone, gps_zone="", gps_label=""):
    available = available_timezones()
    representatives = {}
    for name in sorted(available):
        try:
            representatives.setdefault(timezone_offset_minutes(name), name)
        except (ValueError, OSError):
            continue
    for name in CANONICAL_TIMEZONES:
        if name not in available:
            continue
        try:
            representatives[timezone_offset_minutes(name)] = name
        except (ValueError, OSError):
            continue
    if gps_zone in available:
        try:
            representatives[timezone_offset_minutes(gps_zone)] = gps_zone
        except (ValueError, OSError):
            gps_zone = ""
    zones = []
    for minutes in sorted(representatives):
        name = representatives[minutes]
        zones.append({
            "minutes": minutes,
            "timezone": name,
            "abbreviation": timezone_abbreviation(name, minutes),
            "label": gps_label if gps_label and name == gps_zone else name.rsplit("/", 1)[-1].replace("_", " "),
        })
    return zones, gps_zone


def wurb_valid_location(candidates=None):
    if candidates is None:
        candidates = [pathlib.Path("/home/wurb/wurb_settings/wurb_settings.db")]
        candidates.extend(pathlib.Path("/home").glob("*/wurb_settings/wurb_settings.db"))
    for database in dict.fromkeys(candidates):
        if not database.is_file():
            continue
        try:
            connection = sqlite3.connect(f"file:{database}?mode=ro", uri=True, timeout=0.5)
            try:
                values = dict(connection.execute(
                    "SELECT key, value FROM key_value_data WHERE identity='location'"
                ).fetchall())
            finally:
                connection.close()

            def number(key):
                try:
                    return float(values.get(key, 0.0) or 0.0)
                except (TypeError, ValueError):
                    return 0.0

            latitude = number("latitudeDd")
            longitude = number("longitudeDd")
            if latitude == 0.0 or longitude == 0.0:
                if str(values.get("geoSource", "")) == "geo-gps-or-last-found":
                    latitude = number("lastGpsLatitudeDd")
                    longitude = number("lastGpsLongitudeDd")
                if latitude == 0.0 or longitude == 0.0:
                    latitude = number("defaultLatitudeDd")
                    longitude = number("defaultLongitudeDd")
            if (latitude != 0.0 and longitude != 0.0
                    and -90 <= latitude <= 90 and -180 <= longitude <= 180):
                return latitude, longitude
        except (OSError, ValueError, sqlite3.Error):
            continue
    return None


def systemd_unit_installed(unit):
    try:
        result = subprocess.run(["systemctl", "show", "--property=LoadState", "--value", unit],
                                capture_output=True, text=True, timeout=3)
        return result.returncode == 0 and result.stdout.strip() == "loaded"
    except (OSError, subprocess.SubprocessError):
        return False


def allsky_project_path():
    if not systemd_unit_installed("allsky.service"):
        return None
    candidates = {
        pathlib.Path("/home/allsky"),
        pathlib.Path("/opt/allsky"),
        *(pathlib.Path("/home").glob("*/allsky")),
    }
    for path in candidates:
        if ((path / "allsky.sh").is_file() and (path / "html").is_dir()
                and ((path / "config/settings.json").exists() or (path / "config/config.sh").is_file())):
            return path.resolve()
    return None


def allsky_initial_setup_required():
    project = allsky_project_path()
    if project is None:
        return False
    try:
        settings = json.loads((project / "config/settings.json").read_text())
    except (OSError, ValueError):
        return False
    return isinstance(settings, dict) and not str(settings.get("lastchanged") or "").strip()


def validate_allsky_backup_name(value):
    name = str(value).strip()
    if name.lower().endswith(".tar.gz"):
        name = name[:-7]
    if (not re.fullmatch(r"[A-Za-z0-9ÄÖÜäöüß][A-Za-z0-9ÄÖÜäöüß ._-]{0,79}", name)
            or name in {".", ".."}):
        raise ValueError("Invalid backup name")
    return name.rstrip(" .") + ".tar.gz"


def allsky_backup_path(name):
    safe_name = pathlib.Path(str(name)).name
    if safe_name != str(name) or not safe_name.lower().endswith(".tar.gz") or safe_name.startswith("."):
        raise ValueError("Invalid backup filename")
    path = (ALLSKY_BACKUP_DIR / safe_name).resolve()
    if path.parent != ALLSKY_BACKUP_DIR.resolve():
        raise ValueError("Invalid backup path")
    return path


def _allsky_runtime_paths(project):
    """Read the paths that the installed Allsky release defines itself."""
    variables = project / "variables.sh"
    if not variables.is_file():
        raise FileNotFoundError("Allsky variables.sh is missing")
    script = r'''
export ALLSKY_HOME="$1"
source "$1/variables.sh" >/dev/null || exit $?
printf '%s\0' "$ALLSKY_IMAGES" "$ALLSKY_IMAGES_ORIGINAL" "$ALLSKY_USER_VARIABLES" \
  "$ALLSKY_CONFIG" "$ALLSKY_MODULES" "$ALLSKY_MODULE_LOCATION" "$ALLSKY_ENV" \
  "$ALLSKY_WEBSITE_CONFIGURATION_FILE" "$ALLSKY_WEBSITE_MYFILES_DIR" \
  "$ALLSKY_WEBSITE_VIEWSETTINGS_DIRECTORY"
'''
    result = subprocess.run(["bash", "-c", script, "witty-allsky-paths", str(project)],
                            capture_output=True, timeout=20, check=True)
    values = result.stdout.split(b"\0")
    if len(values) < 10:
        raise RuntimeError("Allsky variables.sh returned incomplete path information")
    names = ("images", "images_original", "user_variables", "config", "module_config",
             "module_location", "env", "website_configuration", "website_myfiles",
             "website_viewsettings")
    paths = {}
    for name, value in zip(names, values):
        decoded = value.decode("utf-8")
        paths[name] = pathlib.Path(decoded) if decoded else None
    return paths


def allsky_images_path(project):
    return _allsky_runtime_paths(project)["images"]


def _human_size(value):
    try:
        size = int(value)
    except (TypeError, ValueError):
        return ""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return ""


def allsky_storage_backend(project):
    try:
        version = (project / "version").read_text(encoding="utf-8").splitlines()[0].strip()
    except (OSError, IndexError):
        version = ""
    match = re.match(r"v?(\d{4})\.", version)
    modern = int(match.group(1)) >= 2026 if match else (project / "variables.json").is_file()
    result = {"method": "variables-json" if modern else "php-defines", "version": version}
    try:
        metadata = json.loads((project / '.git/witty-source.json').read_text())
        identity = allsky_software_identity(project)
        catalog = json.loads((APP_DIR / 'installer/allsky-versions.json').read_text())
        entry = next((item for item in catalog['versions'] if item['commit'] == identity['commit']), None)
        if metadata.get('commit') == identity['commit'] and entry:
            result.update(source_kind='github' if metadata.get('selection') == 'latest-github' else 'archive',
                          source_date=entry.get('snapshotDate', ''), source_selection=entry['version'])
    except (OSError, ValueError, KeyError, TypeError):
        pass
    return result


def _allsky_owner_command(project, command):
    owner = pwd.getpwuid(project.stat().st_uid)
    if owner.pw_uid == 0:
        return command
    return ["runuser", "-u", owner.pw_name, "--", "env",
            f"HOME={owner.pw_dir}", f"USER={owner.pw_name}",
            f"LOGNAME={owner.pw_name}", *command]


def _refresh_allsky_variables_json(project):
    """Use the 2026 release's generator so PHP and Python share current paths."""
    helper = project / "scripts/installUpgradeFunctions.sh"
    if not helper.is_file():
        raise FileNotFoundError("Allsky 2026: installUpgradeFunctions.sh fehlt")
    target = project / "variables.json"
    previous = target.read_bytes() if target.exists() else None
    script = r'''export ALLSKY_HOME="$1"
source "$1/variables.sh" --force >/dev/null || exit $?
source "$1/scripts/installUpgradeFunctions.sh" >/dev/null || exit $?
create_variables_json witty-storage
'''
    try:
        result = subprocess.run(_allsky_owner_command(project, ["bash", "-c", script, "witty-storage", str(project)]),
                                cwd=project, capture_output=True, text=True, timeout=60)
        if result.returncode != 0:
            raise RuntimeError((result.stderr or result.stdout or "Allsky variables.json generation failed").strip()[-2000:])
        data = json.loads(target.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or pathlib.Path(str(data.get("ALLSKY_IMAGES", ""))) != allsky_images_path(project):
            raise RuntimeError("Allsky variables.json enthält nicht den ausgewählten Bildspeicherort")
    except Exception:
        if previous is None:
            target.unlink(missing_ok=True)
        elif target.exists():
            _replace_file_preserving_metadata(target, previous.decode("utf-8"))
        else:
            target.write_bytes(previous)
        raise


def _allsky_json_storage_stale(project):
    if allsky_storage_backend(project)["method"] != "variables-json":
        return False
    try:
        data = json.loads((project / "variables.json").read_text(encoding="utf-8"))
        return pathlib.Path(str(data.get("ALLSKY_IMAGES", ""))) != allsky_images_path(project)
    except (OSError, ValueError, AttributeError):
        return True


def allsky_storage_choices(project):
    """Return the local directory plus mounted data disks offered by the UI."""
    runtime = _allsky_runtime_paths(project)
    local_path = runtime["images_original"]
    current = runtime["images"]
    choices = [{"id": "local", "kind": "local", "name": "SD-Karte (Standard)",
                "mount": str(project.parent), "path": str(local_path), "size": "", "available": ""}]
    seen = {str(local_path)}
    try:
        result = subprocess.run(
            ["findmnt", "--json", "--bytes", "--real", "--output",
             "TARGET,SOURCE,FSTYPE,SIZE,AVAIL,LABEL"],
            capture_output=True, text=True, timeout=10, check=True)
        filesystems = json.loads(result.stdout).get("filesystems", [])
        flat = []
        def walk(items):
            for item in items:
                flat.append(item)
                walk(item.get("children", []))
        walk(filesystems)
        ignored = {"/", "/boot", "/boot/firmware"}
        ignored_types = {"tmpfs", "devtmpfs", "proc", "sysfs", "overlay", "squashfs", "cgroup2"}
        for item in flat:
            mount = pathlib.Path(str(item.get("target", "")))
            source = str(item.get("source", ""))
            fstype = str(item.get("fstype", ""))
            if (not mount.is_absolute() or str(mount) in ignored or fstype in ignored_types
                    or not source.startswith("/dev/") or not mount.is_dir()):
                continue
            destination = mount / "allsky-images"
            if str(destination) in seen:
                continue
            seen.add(str(destination))
            label = str(item.get("label") or "").strip()
            device = pathlib.Path(source).name
            choices.append({"id": f"disk-{len(choices)}", "kind": "mounted",
                            "name": label or device, "device": source, "mount": str(mount),
                            "path": str(destination), "size": _human_size(item.get("size")),
                            "available": _human_size(item.get("avail"))})
    except (OSError, subprocess.SubprocessError, ValueError, TypeError, json.JSONDecodeError):
        pass
    current_text = str(current)
    if current_text != str(local_path) and current_text not in seen:
        choices.append({"id": "current", "kind": "current", "name": "Aktueller externer Speicherort",
                        "mount": str(current.parent), "path": current_text, "size": "", "available": ""})
    return {"current": current_text, "local": str(local_path), "external": current != local_path,
            "choices": choices, "backend": allsky_storage_backend(project)}


def _update_allsky_operation(**values):
    with ALLSKY_OPERATION_LOCK:
        ALLSKY_OPERATION.update(values)


def _allsky_operation_snapshot():
    with ALLSKY_OPERATION_LOCK:
        return dict(ALLSKY_OPERATION)


def _allsky_transfer_inventory(source):
    directories = []
    entries = []
    if not source.exists():
        return directories, entries
    for root, names, files in os.walk(source, followlinks=False):
        root_path = pathlib.Path(root)
        relative_root = root_path.relative_to(source)
        directories.append(relative_root)
        for name in list(names):
            path = root_path / name
            if path.is_symlink():
                entries.append((path, path.relative_to(source)))
                names.remove(name)
        for name in files:
            path = root_path / name
            entries.append((path, path.relative_to(source)))
    return directories, entries


def _allsky_entry_needs_copy(source, destination):
    try:
        if source.is_symlink():
            return not destination.is_symlink() or os.readlink(source) != os.readlink(destination)
        source_stat = source.stat()
        destination_stat = destination.stat()
        return (not destination.is_file() or source_stat.st_size != destination_stat.st_size
                or source_stat.st_mtime_ns != destination_stat.st_mtime_ns)
    except (FileNotFoundError, OSError):
        return True


def _copy_allsky_entry(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    source_stat = os.lstat(source)
    if source.is_symlink():
        if os.path.lexists(destination):
            if destination.is_dir() and not destination.is_symlink():
                shutil.rmtree(destination)
            else:
                destination.unlink()
        destination.symlink_to(os.readlink(source))
        os.chown(destination, source_stat.st_uid, source_stat.st_gid, follow_symlinks=False)
        return
    if destination.is_symlink() or destination.is_dir():
        if destination.is_dir() and not destination.is_symlink():
            shutil.rmtree(destination)
        else:
            destination.unlink()
    shutil.copy2(source, destination)
    os.chown(destination, source_stat.st_uid, source_stat.st_gid)


def _copy_allsky_directory_metadata(source, destination, directories):
    for relative in reversed(directories):
        source_directory = source / relative
        destination_directory = destination / relative
        try:
            source_stat = source_directory.stat()
            shutil.copystat(source_directory, destination_directory)
            os.chown(destination_directory, source_stat.st_uid, source_stat.st_gid)
        except FileNotFoundError:
            pass


def _copy_allsky_images(source, destination, final_pass=False):
    destination.mkdir(parents=True, exist_ok=True)
    if not source.exists():
        return
    directories, entries = _allsky_transfer_inventory(source)
    for relative in directories:
        (destination / relative).mkdir(parents=True, exist_ok=True)
    if final_pass:
        entries = [(path, relative) for path, relative in entries
                   if _allsky_entry_needs_copy(path, destination / relative)]
        current = _allsky_operation_snapshot()
        copied = int(current.get("copied_files", 0) or 0)
        _update_allsky_operation(phase="finalising", total_files=copied + len(entries))
    else:
        copied = 0
        _update_allsky_operation(phase="copying", total_files=len(entries), copied_files=0)
    for source_path, relative in entries:
        try:
            if _allsky_entry_needs_copy(source_path, destination / relative):
                _copy_allsky_entry(source_path, destination / relative)
        except FileNotFoundError:
            # ALLSKY can finish or rotate an image while the first pass runs.
            # The final pass will pick up the stable current set.
            pass
        copied += 1
        _update_allsky_operation(copied_files=copied)
    _copy_allsky_directory_metadata(source, destination, directories)


def _remove_allsky_image_contents(path):
    if not path.exists() or path.is_symlink():
        return
    for child in path.iterdir():
        if child.is_dir() and not child.is_symlink():
            shutil.rmtree(child)
        else:
            child.unlink()


def _write_allsky_images_setting(project, destination):
    runtime = _allsky_runtime_paths(project)
    user_variables = runtime["user_variables"]
    original = runtime["images_original"]
    try:
        previous = user_variables.read_bytes()
    except FileNotFoundError:
        previous = None
    text = previous.decode("utf-8") if previous is not None else ""
    lines = [line for line in text.splitlines() if not re.match(r"^\s*(?:export\s+)?ALLSKY_IMAGES\s*=", line)]
    if destination != original:
        lines.append(f"ALLSKY_IMAGES={shlex.quote(str(destination))}")
    updated = "\n".join(lines).rstrip()
    if updated:
        user_variables.parent.mkdir(parents=True, exist_ok=True)
        user_variables.write_text(updated + "\n", encoding="utf-8")
        user_variables.chmod(0o664)
        if previous is None:
            owner = project.stat()
            os.chown(user_variables, owner.st_uid, owner.st_gid)
    else:
        user_variables.unlink(missing_ok=True)
    return user_variables, previous


def _restore_allsky_images_setting(user_variables, previous):
    if previous is None:
        user_variables.unlink(missing_ok=True)
    else:
        user_variables.parent.mkdir(parents=True, exist_ok=True)
        user_variables.write_bytes(previous)


def _run_allsky_change_images(project):
    if allsky_storage_backend(project)["method"] == "variables-json":
        # 2026 no longer creates allskyDefines.inc. Regenerate its authoritative
        # JSON and update only the image alias, preserving Trixie PHP-FPM settings.
        generated = project / "variables.json"
        previous = generated.read_bytes() if generated.exists() else None
        try:
            _refresh_allsky_variables_json(project)
            _refresh_allsky_image_path_directly(project)
        except Exception:
            if previous is None:
                generated.unlink(missing_ok=True)
            else:
                _replace_file_preserving_metadata(generated, previous.decode("utf-8"))
            raise
        return
    installer = project / "install.sh"
    if not installer.is_file():
        raise FileNotFoundError("Allsky install.sh is missing")
    # The Witty web service runs as root, while Allsky's installer derives
    # ALLSKY_OWNER, HOME and generated file ownership from the invoking user.
    # Calling it directly as root can therefore write root-owned configuration
    # and makes do_change_images fail on otherwise healthy installations.
    owner = pwd.getpwuid(project.stat().st_uid)
    command = ["bash", str(installer), "--function", "do_change_images"]
    if owner.pw_uid != 0:
        command = ["runuser", "-u", owner.pw_name, "--", "env",
                   f"HOME={owner.pw_dir}", f"USER={owner.pw_name}",
                   f"LOGNAME={owner.pw_name}", *command]
    result = subprocess.run(command, cwd=project, capture_output=True, text=True,
                            timeout=10 * 60)
    if result.returncode == 0:
        # Some ALLSKY releases returned success although one of the generated
        # WebUI paths was left unchanged. Validate the effective configuration
        # and use the version-independent repair below when necessary.
        expected = str(allsky_images_path(project)).rstrip("/") + "/"
        defines = project / "html/includes/allskyDefines.inc"
        lighttpd_config = pathlib.Path("/etc/lighttpd/lighttpd.conf")
        try:
            defines_text = defines.read_text(encoding="utf-8")
            lighttpd_text = lighttpd_config.read_text(encoding="utf-8")
            expected_php = expected.rstrip("/").replace("\\", "\\\\").replace("'", "\\'")
            expected_lighttpd = expected.replace("\\", "\\\\").replace('"', '\\"')
            if (re.search(r"define\(\s*'ALLSKY_IMAGES'\s*,\s*'"
                          + re.escape(expected_php) + r"'\s*\)\s*;", defines_text)
                    and re.search(r'alias\.url\s*\+=\s*\(\s*"/images/"\s*=>\s*"'
                                  + re.escape(expected_lighttpd) + r'"\s*\)', lighttpd_text)):
                return
        except OSError:
            pass
        _refresh_allsky_image_path_directly(project)
        return
    official_error = (result.stderr or result.stdout or "").strip()[-3000:]
    try:
        _refresh_allsky_image_path_directly(project)
    except Exception as fallback_error:
        detail = official_error or f"exit status {result.returncode}"
        raise RuntimeError(
            "Allsky konnte den Bildspeicher weder über install.sh noch über "
            f"die kompatible Direktaktualisierung übernehmen. install.sh: {detail}; "
            f"Direktaktualisierung: {fallback_error}") from fallback_error


def _replace_file_preserving_metadata(path, content):
    path = pathlib.Path(path)
    current = path.stat()
    temporary = path.with_name(f".{path.name}.witty-{uuid.uuid4().hex}.new")
    try:
        temporary.write_text(content, encoding="utf-8")
        os.chmod(temporary, stat.S_IMODE(current.st_mode))
        os.chown(temporary, current.st_uid, current.st_gid)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _refresh_allsky_image_path_directly(project):
    """Refresh generated WebUI paths using the installed release's format."""
    destination = str(allsky_images_path(project))
    modern = allsky_storage_backend(project)["method"] == "variables-json"
    defines = project / "html/includes/allskyDefines.inc"
    lighttpd_config = pathlib.Path("/etc/lighttpd/lighttpd.conf")
    if not lighttpd_config.is_file() or (not modern and not defines.is_file()):
        raise FileNotFoundError("Allsky-Webkonfiguration ist unvollständig")
    original_lighttpd = lighttpd_config.read_bytes()
    original_defines = None if modern else defines.read_bytes()
    if modern:
        if _allsky_json_storage_stale(project):
            raise RuntimeError("Allsky variables.json enthält einen veralteten Bildspeicherort")
    else:
        php_path = destination.replace("\\", "\\\\").replace("'", "\\'")
        defines_text, count = re.subn(
            r"define\(\s*'ALLSKY_IMAGES'\s*,\s*'[^']*'\s*\)\s*;",
            lambda _: f"define('ALLSKY_IMAGES',  '{php_path}');",
            original_defines.decode("utf-8"), count=1)
        if count != 1:
            raise RuntimeError("ALLSKY_IMAGES wurde in der PHP-Konfiguration nicht eindeutig gefunden")
    lighttpd_path = destination.replace("\\", "\\\\").replace('"', '\\"').rstrip("/") + "/"
    lighttpd_text, count = re.subn(
        r'alias\.url\s*\+=\s*\(\s*"/images/"\s*=>\s*"[^\"]*"\s*\)',
        lambda _: f'alias.url             += ("/images/" => "{lighttpd_path}")',
        original_lighttpd.decode("utf-8"), count=1)
    if count != 1:
        raise RuntimeError("Der Allsky-Bildalias wurde in lighttpd nicht eindeutig gefunden")
    try:
        if not modern:
            _replace_file_preserving_metadata(defines, defines_text)
        _replace_file_preserving_metadata(lighttpd_config, lighttpd_text)
        lighttpd = shutil.which("lighttpd") or "/usr/sbin/lighttpd"
        check = subprocess.run([lighttpd, "-tt", "-f", str(lighttpd_config)], capture_output=True, text=True, timeout=30)
        if check.returncode != 0:
            raise RuntimeError((check.stderr or check.stdout or "lighttpd-Konfiguration ungültig").strip())
        subprocess.run(["systemctl", "restart", "lighttpd.service"], timeout=60, check=True)
    except Exception:
        if original_defines is not None:
            _replace_file_preserving_metadata(defines, original_defines.decode("utf-8"))
        _replace_file_preserving_metadata(lighttpd_config, original_lighttpd.decode("utf-8"))
        subprocess.run(["systemctl", "restart", "lighttpd.service"], timeout=60, check=False)
        raise


def configure_allsky_storage(project, requested_path, transfer, manage_services=True):
    """Apply the official ALLSKY_IMAGES setting plus move/copy/leave semantics."""
    transfer = str(transfer).lower()
    if transfer not in {"move", "copy", "leave"}:
        raise ValueError("Invalid image transfer option")
    info = allsky_storage_choices(project)
    choices = {entry["path"]: entry for entry in info["choices"]}
    allowed = set(choices)
    requested_path = str(requested_path)
    if requested_path not in allowed:
        raise ValueError("Selected storage location is no longer mounted or allowed")
    selected = choices[requested_path]
    if selected.get("kind") == "mounted":
        mount = str(selected.get("mount", ""))
        mounted = subprocess.run(
            ["findmnt", "--noheadings", "--output", "TARGET", "--target", mount],
            capture_output=True, text=True, timeout=10, check=False)
        active_target = mounted.stdout.strip().splitlines()[-1] if mounted.stdout.strip() else ""
        if mounted.returncode != 0 or pathlib.Path(active_target).resolve() != pathlib.Path(mount).resolve():
            raise RuntimeError("Selected USB storage is no longer mounted")
    current = allsky_images_path(project)
    destination = pathlib.Path(requested_path)
    if current == destination:
        if _allsky_json_storage_stale(project):
            _run_allsky_change_images(project)
        return allsky_storage_choices(project)

    active_units = allsky_service_states() if manage_services else {}
    stopped = []
    try:
        destination.mkdir(parents=True, exist_ok=True)
        destination.chmod(0o775)
        owner = project.stat()
        subprocess.run(["chown", f"{owner.st_uid}:{owner.st_gid}", str(destination)],
                       timeout=60, check=False)

        # Copy the large historical image set while ALLSKY is still running.
        # A second pass after stopping the camera catches files created during
        # this first pass. This keeps the actual service interruption short.
        if manage_services and transfer in {"move", "copy"}:
            _copy_allsky_images(current, destination)

        if manage_services:
            _update_allsky_operation(phase="stopping-services")
            for unit in ("allskyperiodic.timer", "allskyperiodic.service", "allsky.service"):
                if active_units.get(unit, False):
                    subprocess.run(["systemctl", "stop", unit], timeout=90, check=True)
                    stopped.append(unit)

        user_variables, previous = _write_allsky_images_setting(project, destination)
        try:
            _update_allsky_operation(phase="configuring")
            _run_allsky_change_images(project)
            if transfer in {"move", "copy"}:
                _copy_allsky_images(current, destination, final_pass=True)
            if transfer == "move":
                _update_allsky_operation(phase="cleaning-source")
                _remove_allsky_image_contents(current)
        except Exception:
            _restore_allsky_images_setting(user_variables, previous)
            _run_allsky_change_images(project)
            raise
    finally:
        if manage_services:
            _update_allsky_operation(phase="restoring-services")
            _restore_allsky_storage_services(active_units)
    return allsky_storage_choices(project)


def _restore_allsky_storage_services(active_units):
    """Restore and verify the important service state after path changes."""
    subprocess.run(["systemctl", "daemon-reload"], timeout=30, check=False)
    start_order = ("allsky.service", "allskyperiodic.service",
                   "allskyperiodic.timer", "lighttpd.service")
    for unit in start_order:
        if active_units.get(unit, False):
            subprocess.run(["systemctl", "reset-failed", unit], timeout=30, check=False)
            subprocess.run(["systemctl", "start", unit], timeout=90, check=False)
        elif service_active(unit):
            subprocess.run(["systemctl", "stop", unit], timeout=90, check=False)

    # allskyperiodic.service can be a short-lived oneshot unit. Validate only
    # persistent services and the timer whose previous active state matters.
    failed = []
    for unit in ("allsky.service", "allskyperiodic.timer", "lighttpd.service"):
        if not active_units.get(unit, False):
            continue
        for attempt in range(30):
            if service_active(unit):
                break
            if attempt == 14:
                subprocess.run(["systemctl", "reset-failed", unit], timeout=30, check=False)
                subprocess.run(["systemctl", "restart", unit], timeout=90, check=False)
            time.sleep(1)
        else:
            failed.append(unit)
    if failed:
        details = []
        for unit in failed:
            journal = subprocess.run(
                ["journalctl", "-u", unit, "-n", "20", "--no-pager", "--output=cat"],
                capture_output=True, text=True, timeout=30).stdout.strip()
            if journal:
                details.append(f"{unit}: {journal}")
        raise RuntimeError("ALLSKY-Dienstzustand konnte nach dem Speicherwechsel "
                           "nicht wiederhergestellt werden: " + ", ".join(failed)
                           + (f"; {'; '.join(details)}" if details else ""))


def _normalise_allsky_coordinate(value, axis):
    """Accept decimal or N/S/E/W input and return ALLSKY's canonical format."""
    text = str(value).strip().upper().replace(",", ".").replace(" ", "")
    match = re.fullmatch(r"([+-]?(?:\d+(?:\.\d*)?|\.\d+))([NSEW]?)", text)
    if not match:
        raise ValueError(f"Invalid {axis}")
    number = float(match.group(1))
    suffix = match.group(2)
    allowed_suffixes = {"latitude": {"", "N", "S"},
                        "longitude": {"", "E", "W"}}[axis]
    if suffix not in allowed_suffixes:
        raise ValueError(f"Invalid {axis} hemisphere")
    limit = 90.0 if axis == "latitude" else 180.0
    if not math.isfinite(number) or abs(number) > limit:
        raise ValueError(f"{axis.capitalize()} must be between {-limit:g} and {limit:g}")
    if suffix:
        number = abs(number) * (-1 if suffix in {"S", "W"} else 1)
    hemisphere = ("S" if number < 0 else "N") if axis == "latitude" else ("W" if number < 0 else "E")
    magnitude = f"{abs(number):.7f}".rstrip("0").rstrip(".") or "0"
    return magnitude + hemisphere


def configure_allsky_location(project, latitude, longitude):
    """Update the coordinates used by ALLSKY's sun-angle calculation."""
    latitude = _normalise_allsky_coordinate(latitude, "latitude")
    longitude = _normalise_allsky_coordinate(longitude, "longitude")
    settings_path = _allsky_runtime_paths(project)["config"] / "settings.json"
    original = settings_path.read_text(encoding="utf-8")
    settings = json.loads(original)
    if not isinstance(settings, dict):
        raise ValueError("ALLSKY settings have an unexpected format")
    settings["latitude"] = latitude
    settings["longitude"] = longitude
    was_active = service_active("allsky.service")
    try:
        _replace_file_preserving_metadata(
            settings_path, json.dumps(settings, ensure_ascii=False, indent=4) + "\n")
        if was_active:
            subprocess.run(["systemctl", "restart", "allsky.service"], timeout=90, check=True)
            if not service_active("allsky.service"):
                raise RuntimeError("ALLSKY did not restart after changing its GPS position")
    except Exception:
        _replace_file_preserving_metadata(settings_path, original)
        if was_active:
            subprocess.run(["systemctl", "restart", "allsky.service"], timeout=90, check=False)
        raise
    return {"latitude": latitude, "longitude": longitude,
            "runtime": allsky_runtime_diagnostics(project)}


class AllskyCameraSettingsError(ValueError):
    def __init__(self, german, english):
        super().__init__(german)
        self.english = english


def _gs_camera_helper():
    import importlib.util
    spec = importlib.util.spec_from_file_location("witty_gs_camera", APP_DIR / "installer/allsky_gs_camera.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def allsky_gs_camera_status(project):
    config = _allsky_runtime_paths(project)["config"]
    settings = json.loads((config / "settings.json").read_text(encoding="utf-8"))
    try:
        sensor = str(json.loads((config / "cc.json").read_text()).get("sensor", ""))
    except (OSError, ValueError):
        sensor = ""
    model = str(settings.get("cameramodel", ""))
    compatible = (settings.get("cameratype") == "RPi" and
                  (sensor.lower().startswith("imx296") or "imx296" in model.lower() or "global shutter" in model.lower()))
    limits = {key: settings.get(key) for key in
              ("daymaxautoexposure", "nightmaxautoexposure", "dayexposure", "nightexposure")}
    safe = True
    for value in limits.values():
        try:
            safe = safe and math.isfinite(float(value)) and 0.03 <= float(value) <= 15000
        except (TypeError, ValueError):
            safe = False
    for key in ("daymean", "nightmean"):
        try:
            safe = safe and float(settings.get(key, 0)) > 0
        except (TypeError, ValueError):
            safe = False
    return {"enabled": compatible and settings.get("wittygscamera") is True and safe,
            "compatible": compatible, "sensor": sensor, "model": model, "limits_ms": limits,
            "auto": {"day": settings.get("dayautoexposure") is True,
                     "night": settings.get("nightautoexposure") is True}}


def _save_allsky_camera_settings(project, original, updated):
    path = _allsky_runtime_paths(project)["config"] / "settings.json"
    helper = _gs_camera_helper()
    was_active = service_active("allsky.service")
    if was_active:
        subprocess.run(["systemctl", "stop", "allsky.service"], timeout=90, check=True)
    try:
        helper.write_settings(path, updated)
        # Read the actual Allsky file back; do not report success from the
        # request alone. Allsky reads these values on the next service start.
        actual = json.loads(path.read_text(encoding="utf-8"))
        if actual != updated:
            raise AllskyCameraSettingsError("Allsky-Belichtungswerte konnten nicht bestätigt werden.", "Allsky exposure values could not be confirmed.")
        if was_active:
            subprocess.run(["systemctl", "start", "allsky.service"], timeout=90, check=True)
            if not service_active("allsky.service"):
                raise AllskyCameraSettingsError("Allsky konnte mit den Kamera-Einstellungen nicht gestartet werden.", "Allsky could not start with the camera settings; previous values were restored.")
    except Exception:
        helper.write_settings(path, original)
        if was_active:
            subprocess.run(["systemctl", "start", "allsky.service"], timeout=90, check=False)
        raise
    return {**allsky_gs_camera_status(project), "service_restarted": was_active}


def configure_allsky_exposure(project, values, auto):
    keys = {"dayexposure", "nightexposure", "daymaxautoexposure", "nightmaxautoexposure"}
    if not isinstance(values, dict) or set(values) != keys:
        raise AllskyCameraSettingsError("Bitte alle vier Belichtungswerte in Sekunden angeben.", "Enter all four exposure values in seconds.")
    if not isinstance(auto, dict) or set(auto) != {"day", "night"} or any(type(v) is not bool for v in auto.values()):
        raise AllskyCameraSettingsError("Ungültige Auswahl der automatischen Belichtung.", "Invalid automatic exposure selection.")
    config = _allsky_runtime_paths(project)["config"]
    original = json.loads((config / "settings.json").read_text(encoding="utf-8"))
    updated = dict(original)
    options = json.loads((config / "options.json").read_text(encoding="utf-8"))
    if not isinstance(options, list):
        raise AllskyCameraSettingsError("Allsky-Kameragrenzen fehlen oder haben ein unbekanntes Format.", "Allsky camera limits are missing or have an unknown format.")
    options = {o.get("name"): o for o in options if isinstance(o, dict)}
    gs = allsky_gs_camera_status(project)["compatible"]
    for key in sorted(keys):
        try:
            if isinstance(values[key], bool):
                raise ValueError()
            seconds = float(values[key])
            option = options[key]
            minimum = float(option["minimum"])
            maximum = float(option["maximum"])
        except (ValueError, TypeError, KeyError):
            raise AllskyCameraSettingsError("Ungültiger Belichtungswert oder fehlende Allsky-Kameragrenze: " + key, "Invalid exposure value or missing Allsky camera limit: " + key)
        milliseconds = seconds * 1000
        if gs:
            maximum = min(maximum, 15500)
        if not all(math.isfinite(v) for v in (milliseconds, minimum, maximum)) or not minimum <= milliseconds <= maximum:
            raise AllskyCameraSettingsError(f"{key}: Erlaubt sind {minimum / 1000:g} bis {maximum / 1000:g} Sekunden.", f"{key}: Allowed range is {minimum / 1000:g} to {maximum / 1000:g} seconds.")
        updated[key] = milliseconds
    for phase in ("day", "night"):
        updated[phase + "autoexposure"] = auto[phase]
        # Enable the bounded Allsky algorithm when automatic mode is chosen.
        if auto[phase] and float(updated.get(phase + "mean", 0) or 0) <= 0:
            updated[phase + "mean"] = 0.5
    return _save_allsky_camera_settings(project, original, updated)


def configure_allsky_gs_camera(project, enabled):
    if type(enabled) is not bool:
        raise AllskyCameraSettingsError("GS-Kamera muss als Ja/Nein übergeben werden.", "GS camera selection must be a boolean.")
    state = allsky_gs_camera_status(project)
    if enabled and not state["compatible"]:
        raise AllskyCameraSettingsError("Die aktuell in Allsky ausgewählte Kamera ist keine GS-Kamera (IMX296). Bitte zuerst die GS-Kamera in Allsky auswählen.", "The camera selected in Allsky is not a GS camera (IMX296). Select the GS camera in Allsky first.")
    path = _allsky_runtime_paths(project)["config"] / "settings.json"
    original = json.loads(path.read_text(encoding="utf-8"))
    helper = _gs_camera_helper()
    updated = helper.gs_settings(original, enabled)
    return _save_allsky_camera_settings(project, original, updated)


def _path_is_within(path, roots):
    """Return True when path is inside one of the resolved directory roots."""
    for root in roots:
        if root is None:
            continue
        try:
            path.relative_to(pathlib.Path(root).resolve())
            return True
        except (OSError, ValueError):
            continue
    return False


def _add_allsky_tree(archive, source, archive_name, excluded_top_level,
                     allowed_link_directories, forbidden_link_targets):
    """Archive a config tree without emitting links or silently losing linked files."""
    materialized_links = []
    source = pathlib.Path(source)

    def add_item(actual, relative, ancestors):
        archive_path = str(pathlib.PurePosixPath(archive_name) / relative)
        is_link = actual.is_symlink()
        try:
            resolved = actual.resolve(strict=True) if is_link else actual
        except OSError as error:
            raise ValueError(f"Broken ALLSKY configuration link: {actual}") from error
        if is_link and _path_is_within(resolved, forbidden_link_targets):
            raise ValueError(f"ALLSKY configuration link points to captured/runtime data: {actual}")
        if is_link:
            materialized_links.append({"archive_path": archive_path,
                                       "target": str(resolved),
                                       "kind": "directory" if resolved.is_dir() else "file"})
        if resolved.is_dir():
            if is_link and not _path_is_within(resolved, allowed_link_directories):
                raise ValueError(f"ALLSKY configuration directory link has an unsupported target: {actual}")
            identity = (resolved.stat().st_dev, resolved.stat().st_ino)
            if identity in ancestors:
                raise ValueError(f"Recursive ALLSKY configuration link: {actual}")
            info = tarfile.TarInfo(archive_path.rstrip("/") + "/")
            current_stat = resolved.stat()
            info.type = tarfile.DIRTYPE
            info.mode = stat.S_IMODE(current_stat.st_mode)
            info.mtime = int(current_stat.st_mtime)
            archive.addfile(info)
            next_ancestors = ancestors | {identity}
            for child in sorted(resolved.iterdir(), key=lambda item: item.name):
                if not relative.parts and child.name in excluded_top_level:
                    continue
                add_item(child, relative / child.name, next_ancestors)
            return
        if not resolved.is_file():
            raise ValueError(f"Unsupported ALLSKY configuration entry: {actual}")
        # SQLite's backup API includes committed WAL data in one consistent
        # database. Copying .db, -wal and -shm individually can lose records.
        if resolved.name.endswith(("-wal", "-shm")):
            database = resolved.with_name(resolved.name.rsplit("-", 1)[0])
            if database.is_file():
                with database.open("rb") as stream:
                    if stream.read(16) == b"SQLite format 3\x00":
                        return
        with resolved.open("rb") as stream:
            is_sqlite = stream.read(16) == b"SQLite format 3\x00"
        if is_sqlite:
            with tempfile.TemporaryDirectory(prefix="allsky-db-backup-") as temporary:
                snapshot = pathlib.Path(temporary) / resolved.name
                deadline = time.monotonic() + 60
                def progress(status, remaining, total):
                    if time.monotonic() > deadline:
                        raise TimeoutError(f"ALLSKY database snapshot timed out: {actual}")
                with sqlite3.connect(resolved.as_uri() + "?mode=ro", uri=True, timeout=5) as source_db:
                    with sqlite3.connect(snapshot) as target_db:
                        source_db.backup(target_db, pages=256, progress=progress)
                file_stat = snapshot.stat()
                if file_stat.st_size > 1024 * 1024 * 1024:
                    raise ValueError(f"ALLSKY database exceeds the backup limit: {actual}")
                info = tarfile.TarInfo(archive_path)
                info.size = file_stat.st_size
                info.mode = stat.S_IMODE(resolved.stat().st_mode)
                info.mtime = int(resolved.stat().st_mtime)
                with snapshot.open("rb") as stream:
                    archive.addfile(info, stream)
            return
        file_stat = resolved.stat()
        if file_stat.st_size > 64 * 1024 * 1024:
            raise ValueError(f"ALLSKY configuration file is unexpectedly large: {actual}")
        info = tarfile.TarInfo(archive_path)
        info.size = file_stat.st_size
        info.mode = stat.S_IMODE(file_stat.st_mode)
        info.mtime = int(file_stat.st_mtime)
        with resolved.open("rb") as stream:
            archive.addfile(info, stream)

    add_item(source, pathlib.PurePosixPath(), set())
    return materialized_links


def allsky_software_identity(project):
    """Read the installed release and original Git revision without modifying it."""
    project = pathlib.Path(project)
    try:
        version = (project / "version").read_text(encoding="utf-8").splitlines()[0].strip()
    except (OSError, UnicodeError, IndexError):
        version = ""
    if not re.fullmatch(r"v?\d{4}\.\d{2}\.\d{2}(?:_\d+)?", version):
        raise ValueError("Die installierte Allsky-Version kann nicht sicher ermittelt werden. Sicherung/Wiederherstellung abgebrochen.")
    commit = ""
    try:
        result = subprocess.run(["git", "-c", "safe.directory=" + str(project), "-C", str(project),
                                 "rev-parse", "HEAD"], capture_output=True, text=True, timeout=15)
        if result.returncode == 0 and re.fullmatch(r"[0-9a-f]{40,64}", result.stdout.strip()):
            commit = result.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        pass
    return {"version": version if version.startswith("v") else "v" + version, "commit": commit}


def validate_allsky_backup_version(project, metadata):
    installed = allsky_software_identity(project)
    saved = str((metadata or {}).get("allsky_version", "")).strip()
    saved_commit = str((metadata or {}).get("allsky_commit", "")).strip()
    if not saved:
        raise ValueError(
            "Die Sicherung stammt von Allsky-Version unbekannt (älteres Backup ohne Versionsangabe). "
            f"Installiert ist {installed['version']}. Backups können nur auf denselben Softwarestand "
            "wieder eingespielt werden. Bitte eine neue Sicherung mit Versionsangabe erstellen.")
    if not saved.startswith("v"):
        saved = "v" + saved
    if saved != installed["version"]:
        raise ValueError(
            f"Die Sicherung stammt von Allsky-Version {saved}; installiert ist {installed['version']}. "
            "Backups können nur auf denselben Softwarestand wieder eingespielt werden.")
    if installed["commit"] and saved_commit != installed["commit"]:
        raise ValueError(
            f"Die Sicherung stammt von Allsky {saved}, Git-Stand {saved_commit or 'unbekannt'}; "
            f"installiert ist {installed['version']}, Git-Stand {installed['commit']}. "
            "Backups können nur auf denselben Softwarestand wieder eingespielt werden.")
    return installed


def validate_allsky_backup_camera(project, archive_path):
    """Never replace another camera's settings/schema with a complete backup."""
    config = _allsky_runtime_paths(project)["config"]
    installed = json.loads((config / "settings.json").read_text(encoding="utf-8"))
    with tarfile.open(archive_path, "r:gz") as archive:
        names = {posixpath.normpath(member.name): member for member in archive.getmembers()}
        member = names.get("allsky/config/settings.json") or names.get("settings.json")
        if member is None:
            raise ValueError("ALLSKY camera settings are missing from backup")
        saved = json.loads(archive.extractfile(member).read().decode("utf-8"))
    def identity(settings):
        return tuple(str(settings.get(key, "")).strip() for key in ("cameratype", "cameramodel"))
    current_camera, saved_camera = identity(installed), identity(saved)
    if not all(current_camera) or not all(saved_camera):
        raise ValueError("ALLSKY-Kamera kann nicht sicher verglichen werden. Bitte zuerst die aktuelle Kamera in Allsky einrichten; Kameraangaben müssen auch in der Sicherung vorhanden sein.")
    if tuple(value.casefold() for value in current_camera) != tuple(value.casefold() for value in saved_camera):
        raise ValueError(f"Die Sicherung gehört zur Kamera {' / '.join(saved_camera)}; aktuell eingerichtet ist {' / '.join(current_camera)}. Vollständige Wiederherstellung abgebrochen. Bitte dieselbe Kamera in Allsky einrichten oder eine passende Sicherung verwenden.")


def read_allsky_configuration_json(path):
    path=pathlib.Path(path)
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError,ValueError,UnicodeError) as error:
        raise ValueError(f"ALLSKY-Konfigurationsdatei ist leer, unlesbar oder ungültig: {path}. "
                         "Die vorhandene ursprüngliche Updatesicherung muss für die Wiederaufnahme erhalten bleiben.") from error


def create_allsky_archive(project, destination, strict_overlays=True):
    """Back up every user-configurable Allsky area without captured media."""
    software_identity = allsky_software_identity(project)
    runtime = _allsky_runtime_paths(project)
    config = runtime["config"]
    env = runtime.get("env")
    if env is not None:
        if not env.is_file():
            raise FileNotFoundError(f"ALLSKY env.json is missing: {env}; complete backup aborted")
        if not isinstance(read_allsky_configuration_json(env), dict):
            raise ValueError("ALLSKY env.json must contain a JSON object; backup aborted")
    missing = [name for name in ("settings.json", "options.json") if not (config / name).is_file()]
    if missing:
        raise FileNotFoundError("Allsky configuration file(s) missing: " + ", ".join(missing))
    storage = allsky_storage_choices(project)
    try:
        settings_data = read_allsky_configuration_json(config / "settings.json")
        options_data = read_allsky_configuration_json(config / "options.json")
    except (OSError, ValueError, TypeError) as error:
        raise ValueError(f"Allsky settings/options configuration is not readable: {error}") from error
    if not isinstance(settings_data, dict) or not isinstance(options_data, (dict, list)):
        raise ValueError("Allsky settings/options configuration has an invalid structure")
    selected_overlays = []
    configuration_warnings = []
    for setting_name in ("daytimeoverlay", "nighttimeoverlay"):
        overlay_name = str(settings_data.get(setting_name, "")).strip()
        if not overlay_name:
            continue
        if pathlib.Path(overlay_name).name != overlay_name or not overlay_name.lower().endswith(".json"):
            raise ValueError(f"Invalid ALLSKY overlay selection in {setting_name}")
        candidates = (config / "overlay/myTemplates" / overlay_name,
                      config / "overlay/config" / overlay_name)
        selected = next((candidate for candidate in candidates if candidate.is_file()), None)
        if selected is None:
            message = f"Selected ALLSKY overlay {overlay_name} ({setting_name}) does not exist"
            if strict_overlays:
                raise FileNotFoundError(message)
            configuration_warnings.append(message)
            continue
        try:
            overlay_data = json.loads(selected.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, ValueError) as error:
            message = f"Selected ALLSKY overlay is invalid: {overlay_name}"
            if strict_overlays:
                raise ValueError(message) from error
            configuration_warnings.append(message)
            continue
        if not isinstance(overlay_data, dict):
            message = f"Selected ALLSKY overlay is invalid: {overlay_name}"
            if strict_overlays:
                raise ValueError(message)
            configuration_warnings.append(message)
            continue
        selected_overlays.append({
            "setting": setting_name,
            "name": overlay_name,
            "archive_path": str(pathlib.PurePosixPath("allsky/config")
                                / selected.relative_to(config)),
        })
    sources = [(config, "allsky/config")]
    for source, archive_name in (
            (runtime.get("user_variables"), "allsky/user-variables"),
            (runtime.get("module_config"), "allsky/module-config"),
            (runtime["env"], "allsky/env.json"),
            (runtime["website_configuration"], "allsky/website/configuration.json"),
            (runtime.get("website_myfiles"), "allsky/website/myFiles"),
            (runtime.get("website_viewsettings"), "allsky/website/viewSettings"),
            (runtime["module_location"] / "modules", "allsky/user-modules")):
        if source is not None and source.exists():
            sources.append((source, archive_name))
    volatile_config = {"logs", "messages.txt", "status.json", "connected_cameras.txt",
                       "piversion.txt", "newestversion.json"}
    forbidden_targets = tuple(path for path in (
        runtime.get("images"), runtime.get("images_original"), project / "darks",
        project / "tmp", project / "logs") if path is not None)
    allowed_link_directories = (config, project / "config_repo", runtime.get("user_variables"),
                                runtime.get("module_config"), runtime.get("website_myfiles"),
                                runtime.get("website_viewsettings"),
                                runtime["module_location"] / "modules")
    destination = pathlib.Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.parent / f".{destination.name}.{uuid.uuid4().hex}.tmp"
    materialized_links = []
    try:
        with tarfile.open(temporary, "w:gz", dereference=False) as archive:
            for source, archive_name in sources:
                materialized_links.extend(_add_allsky_tree(
                    archive, source, archive_name,
                    volatile_config if source == config else set(),
                    allowed_link_directories, forbidden_targets))
            metadata = json.dumps({
                "format": "witty-allsky-backup-v6",
                "allsky_version": software_identity["version"],
                "allsky_commit": software_identity["commit"],
                "created_at": datetime.now().astimezone().isoformat(),
                "camera": {key: str(settings_data.get(key, "")) for key in ("cameratype", "cameramodel")},
                "images_path": storage["current"],
                "images_external": storage["external"],
                "storage_method": storage.get("backend", {}).get("method", ""),
                "images_included": False,
                "selected_overlays": selected_overlays,
                "overlay_layouts": sorted(str(pathlib.PurePosixPath("allsky/config/overlay") / entry.relative_to(config / "overlay"))
                                          for folder in ("config", "myTemplates")
                                          for entry in (config / "overlay" / folder).glob("*.json")
                                          if entry.is_file()),
                "configuration_warnings": configuration_warnings,
                "materialized_links": materialized_links,
                "includes": [archive_name for _, archive_name in sources],
                "excludes": ["captured images", "videos", "dark frames", "logs",
                             "temporary status", "program files"],
            }, ensure_ascii=False, indent=2).encode("utf-8")
            manifest = tarfile.TarInfo("witty-allsky-backup.json")
            manifest.size = len(metadata); manifest.mode = 0o644; manifest.mtime = int(time.time())
            archive.addfile(manifest, io.BytesIO(metadata))
        # Enforce restore limits before presenting an archive as successful.
        validate_allsky_archive(temporary)
        os.replace(temporary, destination)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise


def software_project_path(component):
    names = {"wurb": "wurb_2026", "wirc": "wirc_2026", "allsky": "allsky"}
    name = names.get(component)
    if not name:
        return None
    candidates = [pathlib.Path("/home/wurb") / name]
    candidates.extend(pathlib.Path("/home").glob(f"*/{name}"))
    return next((path.resolve() for path in candidates if path.is_dir()), None)


def create_component_backup(component, keep_local):
    project = software_project_path(component)
    if project is None:
        raise FileNotFoundError("Software is not installed")
    timestamp = datetime.now().astimezone().strftime("%Y-%m-%d--%H-%M-%S")
    filename = f"{component}_settings_{timestamp}.tar.gz"
    if keep_local:
        target_directory = ALLSKY_BACKUP_DIR if component == "allsky" else SOFTWARE_BACKUP_DIR
        target_directory.mkdir(parents=True, exist_ok=True)
        destination = target_directory / filename
    else:
        SOFTWARE_TEMP_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        destination = SOFTWARE_TEMP_BACKUP_DIR / f"{uuid.uuid4().hex}.tar.gz"
    if component == "allsky":
        create_allsky_archive(project, destination)
    else:
        settings_dir = pathlib.Path("/home/wurb") / f"{component}_settings"
        sources = []
        if settings_dir.exists():
            sources.append((settings_dir, f"{component}/settings"))
        for candidate in (project / "config", project / "settings"):
            if candidate.exists():
                sources.append((candidate, f"{component}/project-{candidate.name}"))
        for candidate in sorted(project.glob("*.yaml")) + sorted(project.glob("*.yml")) + sorted(project.glob("*.json")):
            if candidate.is_file() and candidate.stat().st_size <= 8 * 1024 * 1024:
                sources.append((candidate, f"{component}/project-files/{candidate.name}"))
        metadata = json.dumps({
            "format": "witty-software-settings-v1", "component": component,
            "created_at": datetime.now().astimezone().isoformat(), "source": str(project),
            "includes": [archive_name for _, archive_name in sources],
            "excludes": ["recordings", "venv", ".git", "logs"],
        }, ensure_ascii=False, indent=2).encode("utf-8")
        with tarfile.open(destination, "w:gz", dereference=False) as archive:
            manifest = tarfile.TarInfo("witty-software-backup.json")
            manifest.size = len(metadata); manifest.mode = 0o644; manifest.mtime = int(time.time())
            archive.addfile(manifest, io.BytesIO(metadata))
            for source, archive_name in sources:
                archive.add(source, arcname=archive_name, recursive=True)
    destination.chmod(0o640)
    return destination, filename


def restore_component_backup(component, archive_path):
    archive_path = pathlib.Path(archive_path)
    if component == "allsky":
        project = allsky_project_path()
        if project is None:
            raise FileNotFoundError("Allsky is not installed after reinstallation")
        restore_allsky_archive(project, archive_path)
        return
    project = software_project_path(component)
    if project is None:
        raise FileNotFoundError(f"{component.upper()} is not installed after reinstallation")
    prefix = f"{component}/"
    with tarfile.open(archive_path, "r:gz") as archive:
        members = archive.getmembers()
        manifest_member = next((item for item in members if item.name == "witty-software-backup.json"), None)
        if manifest_member is None:
            raise ValueError("Software backup manifest is missing")
        manifest_stream = archive.extractfile(manifest_member)
        manifest = json.loads(manifest_stream.read().decode("utf-8")) if manifest_stream else {}
        if manifest.get("format") != "witty-software-settings-v1" or manifest.get("component") != component:
            raise ValueError("Software backup does not match the selected component")
        for member in members:
            normalised = posixpath.normpath(member.name)
            if (member.name.startswith("/") or normalised.startswith("../") or normalised == ".."
                    or (normalised != "witty-software-backup.json" and not normalised.startswith(prefix))
                    or member.isdev() or member.isfifo() or member.islnk() or member.issym()):
                raise ValueError("Software backup contains an unsafe entry")
        with tempfile.TemporaryDirectory(prefix=f"{component}-restore-", dir=APP_DIR) as temporary:
            staging = pathlib.Path(temporary)
            archive.extractall(staging, filter="data")
            staged = staging / component
            replacements = []
            if (staged / "settings").is_dir():
                replacements.append((staged / "settings", pathlib.Path("/home/wurb") / f"{component}_settings"))
            for name in ("config", "settings"):
                source = staged / f"project-{name}"
                if source.is_dir():
                    replacements.append((source, project / name))
            project_files = staged / "project-files"
            if project_files.is_dir():
                replacements.extend((source, project / source.name) for source in project_files.iterdir() if source.is_file())
            unit = f"{component}_2026.service"
            was_active = service_active(unit)
            if was_active:
                subprocess.run(["systemctl", "stop", unit], check=True, timeout=60)
            try:
                for source, target in replacements:
                    if target.is_symlink() or target.is_file():
                        target.unlink()
                    elif target.is_dir():
                        shutil.rmtree(target)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(source), str(target))
                    subprocess.run(["chown", "-R", "wurb:wurb", str(target)], check=False, timeout=60)
            finally:
                if was_active:
                    subprocess.run(["systemctl", "start", unit], check=True, timeout=60)


def resolve_software_backup_reference(reference):
    reference = str(reference or "")
    if reference.startswith("local:"):
        name = pathlib.Path(reference[6:]).name
        if name != reference[6:] or not name.endswith(".tar.gz"):
            raise ValueError("Invalid local backup reference")
        for directory in (SOFTWARE_BACKUP_DIR, ALLSKY_BACKUP_DIR):
            target = directory / name
            if target.is_file() and not target.is_symlink():
                return target.resolve(), False
    elif reference.startswith("temporary:"):
        token = reference[10:]
        if re.fullmatch(r"[a-f0-9]{32}", token):
            target = SOFTWARE_TEMP_BACKUP_DIR / f"{token}.tar.gz"
            if target.is_file() and not target.is_symlink():
                return target.resolve(), True
    raise FileNotFoundError("Selected software backup is not available")


def validate_allsky_archive(path):
    """Validate current complete backups and legacy two-file backups."""
    legacy_files = {
        "settings.json": "settings.json",
        "options.json": "options.json",
        "allsky/config/settings.json": "settings.json",
        "allsky/config/options.json": "options.json",
    }
    found = set()
    metadata = None
    members = []
    total_size = 0
    with tarfile.open(path, "r:gz") as archive:
        for member in archive:
            members.append(member)
            if len(members) > 20000:
                raise ValueError("Allsky backup contains too many entries")
            normalised = posixpath.normpath(member.name)
            if member.name.startswith("/") or normalised.startswith("../") or normalised == "..":
                raise ValueError("Backup contains an unsafe path")
            if member.isdev() or member.isfifo() or member.islnk() or member.issym():
                raise ValueError("Backup contains an unsupported special entry")
            total_size += max(0, member.size)
            if total_size > 1024 * 1024 * 1024:
                raise ValueError("Allsky backup is unexpectedly large")
            if normalised == "witty-allsky-backup.json":
                if member.isdir() or member.size > 64 * 1024:
                    raise ValueError("Allsky backup manifest is invalid")
                stream = archive.extractfile(member)
                if stream is not None:
                    metadata = json.loads(stream.read().decode("utf-8"))
                    if not isinstance(metadata, dict):
                        raise ValueError("Allsky backup manifest is invalid")
                continue
            if member.isdir() and normalised in {"allsky", "allsky/config", "allsky/website",
                                                 "allsky/user-variables", "allsky/module-config",
                                                 "allsky/website/myFiles",
                                                 "allsky/website/viewSettings",
                                                 "allsky/user-modules"}:
                continue
            complete_path = (normalised.startswith("allsky/config/")
                             or normalised.startswith("allsky/user-variables/")
                             or normalised == "allsky/user-variables"
                             or normalised.startswith("allsky/module-config/")
                             or normalised == "allsky/module-config"
                             or normalised == "allsky/env.json"
                             or normalised == "allsky/website/configuration.json"
                             or normalised.startswith("allsky/website/myFiles/")
                             or normalised.startswith("allsky/website/viewSettings/")
                             or normalised.startswith("allsky/user-modules/"))
            if normalised not in legacy_files and not complete_path:
                raise ValueError(f"Allsky backup contains an unsupported path: {member.name}")
            if normalised in legacy_files:
                found.add(legacy_files[normalised])
            elif normalised == "allsky/config/settings.json":
                found.add("settings.json")
            elif normalised == "allsky/config/options.json":
                found.add("options.json")
    if found != {"settings.json", "options.json"}:
        raise ValueError("Allsky backup must contain settings.json and options.json")
    archive_names = {posixpath.normpath(member.name): member for member in members}
    if len(archive_names) != len(members):
        raise ValueError("Allsky backup contains duplicate entries")
    with tarfile.open(path, "r:gz") as archive:
        for name, expected_type in (("allsky/env.json", dict), ("allsky/config/settings.json", dict),
                                    ("settings.json", dict), ("allsky/config/options.json", (dict, list)),
                                    ("options.json", (dict, list))):
            member = archive_names.get(name)
            if member is None:
                continue
            if not member.isfile() or member.size > 64 * 1024 * 1024:
                raise ValueError(f"Invalid ALLSKY configuration entry: {name}")
            stream = archive.extractfile(member)
            try:
                data = json.loads(stream.read().decode("utf-8"))
            except (UnicodeError, ValueError, AttributeError) as error:
                raise ValueError(f"Invalid ALLSKY JSON in backup: {name}") from error
            if not isinstance(data, expected_type):
                raise ValueError(f"Invalid ALLSKY JSON structure in backup: {name}")
    if metadata and "allsky/env.json" in metadata.get("includes", []) and "allsky/env.json" not in archive_names:
        raise ValueError("ALLSKY env.json declared in backup but missing")
    backup_format = str((metadata or {}).get("format", "legacy"))
    if backup_format not in {"legacy", "witty-allsky-backup-v2", "witty-allsky-backup-v3",
                             "witty-allsky-backup-v4", "witty-allsky-backup-v5",
                             "witty-allsky-backup-v6"}:
        raise ValueError("Unsupported Allsky backup format")
    if backup_format in {"witty-allsky-backup-v4", "witty-allsky-backup-v5",
                         "witty-allsky-backup-v6"}:
        archive_names = {posixpath.normpath(member.name): member for member in members}
        selected_overlays = (metadata or {}).get("selected_overlays", [])
        if not isinstance(selected_overlays, list):
            raise ValueError("Allsky backup overlay metadata is invalid")
        for overlay in selected_overlays:
            if not isinstance(overlay, dict):
                raise ValueError("Allsky backup overlay metadata is invalid")
            archive_name = posixpath.normpath(str(overlay.get("archive_path", "")))
            member = archive_names.get(archive_name)
            if (not archive_name.startswith("allsky/config/overlay/") or member is None
                    or not member.isfile() or member.size > 16 * 1024 * 1024):
                raise ValueError(f"Selected overlay is missing from backup: {overlay.get('name', '')}")
            with tarfile.open(path, "r:gz") as archive:
                stream = archive.extractfile(member)
                try:
                    overlay_data = json.loads(stream.read().decode("utf-8")) if stream else None
                except (UnicodeDecodeError, ValueError) as error:
                    raise ValueError(f"Selected overlay is invalid: {overlay.get('name', '')}") from error
                if not isinstance(overlay_data, dict):
                    raise ValueError(f"Selected overlay is invalid: {overlay.get('name', '')}")
    return members, legacy_files, metadata


def allsky_service_states():
    units = ("allsky.service", "allskyperiodic.service", "allskyperiodic.timer",
             "allskyserver.service", "lighttpd.service")
    return {unit: service_active(unit) for unit in units}


def _allsky_capture_policy():
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "witty_allsky_capture_policy", APP_DIR / "installer/allsky_capture_policy.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def allsky_runtime_diagnostics(project):
    """Report ALLSKY's sun-angle state without changing its configuration."""
    runtime = _allsky_runtime_paths(project)
    result = {"status": "", "phase": "unknown", "waiting_for_night": False,
              "latitude": "", "longitude": "", "angle": "", "transitions": "",
              "day_capture": None, "night_capture": None}
    try:
        status_data = json.loads((runtime["config"] / "status.json").read_text(encoding="utf-8"))
        result["status"] = str(status_data.get("status", ""))
    except (OSError, ValueError, TypeError):
        pass
    try:
        settings = json.loads((runtime["config"] / "settings.json").read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return result
    result["latitude"] = str(settings.get("latitude", ""))
    result["longitude"] = str(settings.get("longitude", ""))
    result["angle"] = str(settings.get("angle", ""))
    result["day_capture"] = settings.get("takedaytimeimages") is True
    result["night_capture"] = settings.get("takenighttimeimages") is not False
    sunwait = project / "bin/sunwait"
    if not sunwait.is_file():
        found = shutil.which("sunwait")
        sunwait = pathlib.Path(found) if found else None
    if sunwait is None or not all((result["latitude"], result["longitude"], result["angle"])):
        return result
    arguments = [str(result["angle"]), result["latitude"], result["longitude"]]
    policy = _allsky_capture_policy()
    environment = policy.runtime_environment()
    selected = policy.read_state()
    local_engine = project / '.witty-bin/sunwait'
    if policy.follows_witty(selected) and local_engine.is_file():
        sunwait = local_engine
        try:
            raw = subprocess.run([str(sunwait), 'witty-status', 'angle', *arguments],
                                 capture_output=True, text=True, timeout=8, env=environment, check=True)
            solar = json.loads(raw.stdout)
            result.update(solar_epoch=solar['epoch'], next_transition_epoch=solar['next_epoch'])
        except (OSError, ValueError, KeyError, subprocess.SubprocessError):
            result['solar_error'] = 'Allsky solar state unavailable'

    try:
        poll = subprocess.run([str(sunwait), "poll", "exit", "angle", *arguments],
                              capture_output=True, text=True, timeout=8, env=environment)
        if poll.returncode == 2:
            result["phase"] = "day"
        elif poll.returncode == 3:
            result["phase"] = "night"
        listing = subprocess.run([str(sunwait), "list", "angle", *arguments],
                                 capture_output=True, text=True, timeout=8, env=environment)
        if listing.returncode == 0:
            result["transitions"] = listing.stdout.strip()[:200]
    except (OSError, subprocess.SubprocessError):
        pass
    result["waiting_for_night"] = bool(
        service_active("allsky.service")
        and result["status"] == "Starting"
        and result["phase"] == "day"
        and result["day_capture"] is False
        and result["night_capture"] is True
    )
    return result


def _extract_allsky_archive(archive_path, destination):
    with tarfile.open(archive_path, "r:gz") as archive:
        archive.extractall(destination, filter="data")


def _copy_allsky_configuration(staging, project, legacy_files, metadata, after_update=False):
    """Merge a validated backup while retaining runtime and unarchived config."""
    runtime = _allsky_runtime_paths(project)
    backup_format = str((metadata or {}).get("format", "legacy"))
    config = runtime["config"]
    config.mkdir(parents=True, exist_ok=True)
    if backup_format in {"witty-allsky-backup-v3", "witty-allsky-backup-v4",
                         "witty-allsky-backup-v5", "witty-allsky-backup-v6"}:
        staged_config = staging / "allsky/config"
        if not staged_config.is_dir():
            raise ValueError("Complete Allsky configuration directory is missing")
        # Do not clear the installed config tree.  Older backups and symlinked
        # ALLSKY layouts may not contain every overlay template or generated
        # default.  Removing the tree first therefore made a settings restore
        # erase otherwise valid overlays.  Files present in the archive win;
        # files absent from it remain untouched.
        for source in staged_config.iterdir():
            target = config / source.name
            if after_update:
                # Keep generated schema/camera capabilities from the installed
                # release. Old options hide new controls in the WebUI.
                if source.name in {"options.json", "cc.json"} or source.name.startswith(("options_", "cc_")):
                    continue
                if source.name == "settings.json" or source.name.startswith("settings_"):
                    if target.is_file():
                        current = json.loads(target.read_text(encoding="utf-8"))
                        saved = json.loads(source.read_text(encoding="utf-8"))
                        if not isinstance(current, dict) or not isinstance(saved, dict):
                            raise ValueError("Invalid camera settings during update restore")
                        current.update(saved)
                        target.write_text(json.dumps(current, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
                        continue
            if source.is_dir():
                if target.exists() and not target.is_dir():
                    target.unlink()
                shutil.copytree(source, target, copy_function=shutil.copy2,
                                dirs_exist_ok=True)
            else:
                if target.is_dir() and not target.is_symlink():
                    shutil.rmtree(target)
                shutil.copy2(source, target)
        replacements = (
            (staging / "allsky/user-variables", runtime.get("user_variables")),
            (staging / "allsky/module-config", runtime.get("module_config")),
            (staging / "allsky/env.json", runtime["env"]),
            (staging / "allsky/website/configuration.json", runtime["website_configuration"]),
            (staging / "allsky/website/myFiles", runtime.get("website_myfiles")),
            (staging / "allsky/website/viewSettings", runtime.get("website_viewsettings")),
            (staging / "allsky/user-modules", runtime["module_location"] / "modules"),
        )
        for source, target in replacements:
            if target is None or not source.exists():
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            if source.is_dir():
                if target.exists() and not target.is_dir():
                    target.unlink()
                shutil.copytree(source, target, copy_function=shutil.copy2,
                                dirs_exist_ok=True)
            else:
                if target.is_dir() and not target.is_symlink():
                    shutil.rmtree(target)
                shutil.copy2(source, target)
    else:
        for archive_name, target_name in legacy_files.items():
            source = staging / archive_name
            if source.is_file():
                shutil.copy2(source, config / target_name)
    # SQLite snapshots are self-contained. Discard stale sidecars in every
    # restored area, including website/myFiles and user module databases.
    database_roots = ((staging / "allsky/config", config),
                      (staging / "allsky/module-config", runtime.get("module_config")),
                      (staging / "allsky/website/myFiles", runtime.get("website_myfiles")),
                      (staging / "allsky/website/viewSettings", runtime.get("website_viewsettings")),
                      (staging / "allsky/user-modules", runtime["module_location"] / "modules"))
    for source_root, target_root in database_roots:
        if target_root is None or not source_root.exists():
            continue
        entries = source_root.rglob("*") if source_root.is_dir() else (source_root,)
        for source in entries:
            if not source.is_file():
                continue
            with source.open("rb") as stream:
                is_database = stream.read(16) == b"SQLite format 3\x00"
            if is_database:
                target = target_root / source.relative_to(source_root) if source_root.is_dir() else target_root
                for suffix in ("-wal", "-shm"):
                    pathlib.Path(str(target) + suffix).unlink(missing_ok=True)
    repair_allsky_configuration_permissions(project)


def repair_allsky_configuration_permissions(project):
    """Match Allsky's installer: owner + web-server group, not owner's group.

    Tar's data filter deliberately strips group-write bits. Reapply only the
    installed configuration policy, never archive-supplied owners or special bits.
    env.json contains passwords and must not become world-readable.
    """
    runtime = _allsky_runtime_paths(project)
    owner = project.stat().st_uid
    web_group = grp.getgrnam("www-data").gr_gid
    roots = [path for path in (runtime["config"], runtime.get("user_variables"),
             runtime.get("module_config"), runtime.get("env"),
             runtime.get("website_configuration"), runtime.get("website_myfiles"),
             runtime.get("website_viewsettings"), runtime["module_location"] / "modules")
             if path is not None and path.exists()]
    allowed = [path.resolve() for path in roots] + [(project / "config_repo").resolve()]
    seen = set()

    def apply(path):
        real = path.resolve(strict=True)
        if path.is_symlink() and not _path_is_within(real, allowed):
            return  # Leave unrelated, unarchived external targets alone.
        if real in seen:
            return
        seen.add(real)
        current = real.stat()
        if real.is_dir():
            os.chown(real, owner, web_group)
            os.chmod(real, 0o775)
            for child in real.iterdir():
                apply(child)
        elif real.is_file():
            secret = (runtime.get("env") is not None and real == runtime["env"].resolve()) or real.name == "secrets.json"
            mode = 0o660 if secret else 0o664 | (stat.S_IMODE(current.st_mode) & 0o111)
            os.chown(real, owner, web_group)
            os.chmod(real, mode)

    for root in roots:
        apply(root)
    env = runtime.get("env")
    if env is not None:
        if not env.is_file():
            raise FileNotFoundError(f"ALLSKY configuration is incomplete: {env} is missing")
        if not isinstance(json.loads(env.read_text(encoding="utf-8")), dict):
            raise ValueError("ALLSKY env.json must contain a JSON object")


def verify_allsky_overlay_selection(project):
    """Refuse a restore that would leave a selected overlay undefined."""
    config = _allsky_runtime_paths(project)["config"]
    try:
        settings = json.loads((config / "settings.json").read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError) as error:
        raise ValueError(f"Restored ALLSKY settings are not readable: {error}") from error
    for setting_name in ("daytimeoverlay", "nighttimeoverlay"):
        # ALLSKY falls back to overlay.json for an empty setting. Check that
        # file too, or the editor reports a missing active layout after restore.
        overlay_name = str(settings.get(setting_name, "overlay.json") or "overlay.json").strip()
        if pathlib.Path(overlay_name).name != overlay_name or not overlay_name.lower().endswith(".json"):
            raise ValueError(f"Restored ALLSKY setting {setting_name} is invalid")
        candidates = (config / "overlay/myTemplates" / overlay_name,
                      config / "overlay/config" / overlay_name)
        selected = next((candidate for candidate in candidates if candidate.is_file()), None)
        if selected is None:
            raise FileNotFoundError(
                f"Restored ALLSKY overlay {overlay_name} ({setting_name}) is missing; restore was rolled back")
        try:
            layout = json.loads(selected.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, ValueError) as error:
            raise ValueError(f"Restored ALLSKY overlay {overlay_name} is invalid") from error
        if not isinstance(layout, dict):
            raise ValueError(f"Restored ALLSKY overlay {overlay_name} is invalid")


def disable_allsky_login(project):
    """Keep the appliance-style ALLSKY WebUI available without Basic Auth."""
    settings_path = project / "config" / "settings.json"
    settings = json.loads(settings_path.read_text(encoding="utf-8"))
    if not isinstance(settings, dict):
        raise ValueError("Restored ALLSKY settings have an unexpected format")
    if settings.get("uselogin") is False:
        return
    settings["uselogin"] = False
    _replace_file_preserving_metadata(
        settings_path, json.dumps(settings, ensure_ascii=False, indent=4) + "\n")


def restore_allsky_archive(project, archive_path, after_update=False):
    _, legacy_files, metadata = validate_allsky_archive(archive_path)
    approved_update = False
    if after_update and ALLSKY_PENDING_UPDATE_BACKUP.is_file():
        marker_info = ALLSKY_PENDING_UPDATE_BACKUP.stat()
        if marker_info.st_uid == 0 and not marker_info.st_mode & 0o022:
            approved_update = (pathlib.Path(ALLSKY_PENDING_UPDATE_BACKUP.read_text().strip()).resolve()
                               == pathlib.Path(archive_path).resolve())
    if approved_update:
        # This privileged update migration uses a backup of the previous
        # release; ordinary user restores still require an identical release.
        saved = str((metadata or {}).get("allsky_version", "")).strip()
        if not re.fullmatch(r"v?\d{4}\.\d{2}\.\d{2}(?:_\d+)?", saved):
            raise ValueError("Allsky update backup has no valid source version")
        verifier = APP_DIR / "installer/verify_allsky_source.py"
        subprocess.run(["python3", str(verifier), str(project)], check=True, timeout=20)
    else:
        validate_allsky_backup_version(project, metadata)
    validate_allsky_backup_camera(project, archive_path)
    storage_before = allsky_storage_choices(project)
    if metadata and metadata.get("images_external") is True:
        restored_path = str(metadata.get("images_path", ""))
        mounted_paths = {entry["path"] for entry in storage_before["choices"]
                         if entry.get("kind") == "mounted"}
        if restored_path not in mounted_paths:
            raise FileNotFoundError("The external drive from this backup is not mounted at the saved path")
    active_units = allsky_service_states()
    stopped = []
    rollback = ALLSKY_BACKUP_DIR / (
        f"allsky-before-restore-{datetime.now():%Y%m%d-%H%M%S}-{uuid.uuid4().hex[:8]}.tar.gz")
    # A broken current overlay must not prevent restoring a known-good backup.
    # The rollback still records that damaged state and its warning in the
    # manifest so recovery remains possible if a later restore step fails.
    create_allsky_archive(project, rollback, strict_overlays=False)
    try:
        # Stop the timer before its service and stop the main camera service
        # last.  Otherwise systemd can start a periodic job again while the
        # configuration files are being replaced.
        # lighttpd serves the ALLSKY setup page but does not write the restored
        # configuration.  Keeping it online preserves the browser connection
        # and avoids the systemd semantics of try-reload-or-restart, which
        # deliberately leaves an inactive service stopped.
        stop_order = ("allskyperiodic.timer", "allskyperiodic.service",
                      "allsky.service", "allskyserver.service")
        for unit in stop_order:
            was_active = active_units.get(unit, False)
            if was_active:
                subprocess.run(["systemctl", "stop", unit], check=True, timeout=60)
                stopped.append(unit)
        with tempfile.TemporaryDirectory(prefix="allsky-restore-", dir=APP_DIR) as temporary:
            staging = pathlib.Path(temporary)
            _extract_allsky_archive(archive_path, staging)
            _copy_allsky_configuration(staging, project, legacy_files, metadata, after_update=after_update)
            if metadata and metadata.get("format") == "witty-allsky-backup-v2":
                restored_path = (str(metadata.get("images_path", ""))
                                 if metadata.get("images_external") is True else storage_before["local"])
                configure_allsky_storage(project, restored_path, "leave", manage_services=False)
            elif metadata and metadata.get("format") in {"witty-allsky-backup-v3",
                                                          "witty-allsky-backup-v4",
                                                          "witty-allsky-backup-v5",
                                                          "witty-allsky-backup-v6"}:
                # do_change_images reinstalls parts of the web server and can take
                # several minutes.  ALLSKY only requires it when ALLSKY_IMAGES
                # actually changed; running it for an ordinary settings restore
                # unnecessarily delays the camera restart and can interrupt the
                # WebUI used to report restore progress.
                if allsky_images_path(project) != pathlib.Path(storage_before["current"]) or _allsky_json_storage_stale(project):
                    _run_allsky_change_images(project)
            disable_allsky_login(project)
            verify_allsky_overlay_selection(project)
        if not all((project / "config" / name).is_file() for name in ("settings.json", "options.json")):
            raise RuntimeError("Restored Allsky settings are incomplete")
    except Exception:
        try:
            _, rollback_legacy, rollback_metadata = validate_allsky_archive(rollback)
            with tempfile.TemporaryDirectory(prefix="allsky-rollback-", dir=APP_DIR) as temporary:
                staging = pathlib.Path(temporary)
                _extract_allsky_archive(rollback, staging)
                _copy_allsky_configuration(staging, project, rollback_legacy, rollback_metadata)
                if allsky_images_path(project) != pathlib.Path(storage_before["current"]) or _allsky_json_storage_stale(project):
                    _run_allsky_change_images(project)
        finally:
            for unit in reversed(stopped):
                subprocess.run(["systemctl", "start", unit], timeout=60, check=False)
            if active_units.get("lighttpd.service", False):
                subprocess.run(["systemctl", "start", "lighttpd.service"], timeout=60, check=False)
            elif service_active("lighttpd.service"):
                subprocess.run(["systemctl", "stop", "lighttpd.service"], timeout=60, check=False)
        raise
    subprocess.run(["systemctl", "daemon-reload"], timeout=30, check=True)
    # Restore the exact pre-upload service state.  A successful systemd start
    # is sufficient: ALLSKY deliberately remains in its own "Starting" status
    # while daytime capture is disabled and it waits for the configured sun
    # angle.  Waiting for the first image here would incorrectly time out.
    if active_units.get("allsky.service", False):
        subprocess.run(["systemctl", "reset-failed", "allsky.service"], timeout=30, check=False)
        subprocess.run(["systemctl", "start", "allsky.service"], timeout=90, check=False)
    if active_units.get("allskyserver.service", False):
        subprocess.run(["systemctl", "start", "allskyserver.service"], timeout=60, check=False)
    elif service_active("allskyserver.service"):
        subprocess.run(["systemctl", "stop", "allskyserver.service"], timeout=60, check=True)
    if active_units.get("allskyperiodic.service", False):
        subprocess.run(["systemctl", "start", "allskyperiodic.service"], timeout=60, check=False)
    if active_units.get("allskyperiodic.timer", False):
        subprocess.run(["systemctl", "start", "allskyperiodic.timer"], timeout=60, check=False)
    if active_units.get("lighttpd.service", False):
        subprocess.run(["systemctl", "reload-or-restart", "lighttpd.service"],
                       timeout=60, check=False)
        if not service_active("lighttpd.service"):
            subprocess.run(["systemctl", "reset-failed", "lighttpd.service"],
                           timeout=30, check=False)
            subprocess.run(["systemctl", "start", "lighttpd.service"],
                           timeout=60, check=False)
    elif service_active("lighttpd.service"):
        subprocess.run(["systemctl", "stop", "lighttpd.service"], timeout=60, check=True)
    expected_active = [unit for unit, was_active in active_units.items() if was_active]
    # systemctl can return after a successful job while a service is still
    # changing state.  Allow a short settling period before declaring the
    # restore unsuccessful.
    failed_units = []
    for unit in expected_active:
        for _ in range(15):
            if service_active(unit):
                break
            time.sleep(1)
        else:
            failed_units.append(unit)
    if failed_units:
        diagnostic_parts = []
        for unit in failed_units:
            details = subprocess.run(
                ["journalctl", "-u", unit, "-n", "25", "--no-pager", "--output=cat"],
                capture_output=True, text=True, timeout=30).stdout.strip()
            if details:
                diagnostic_parts.append(f"{unit}: {details}")
        raise RuntimeError("ALLSKY service state could not be restored: "
                           + ", ".join(failed_units)
                           + (f"; {'; '.join(diagnostic_parts)}" if diagnostic_parts else ""))
    return sorted(unit for unit, was_active in active_units.items() if was_active)


def allsky_backup_listing():
    project = allsky_project_path()
    if project is None:
        raise FileNotFoundError("Allsky is not installed")
    ALLSKY_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    files = []
    for path in ALLSKY_BACKUP_DIR.iterdir():
        if path.is_file() and not path.is_symlink() and not path.name.startswith(".") and path.name.lower().endswith(".tar.gz"):
            stat = path.stat()
            files.append({"name": path.name, "size": stat.st_size, "modified": int(stat.st_mtime)})
    files.sort(key=lambda item: (item["modified"], item["name"]), reverse=True)
    operation_state = _allsky_operation_snapshot()
    operation_action = str(operation_state.get("action", ""))
    operation_started = float(operation_state.get("started", 0.0) or 0.0)
    total_files = max(0, int(operation_state.get("total_files", 0) or 0))
    copied_files = max(0, int(operation_state.get("copied_files", 0) or 0))
    operation = {"running": bool(operation_action), "action": operation_action,
                 "elapsed": max(0, int(time.time() - operation_started)) if operation_started else 0,
                 "phase": str(operation_state.get("phase", "")),
                 "total_files": total_files, "copied_files": copied_files,
                 "percent": min(100, int(copied_files * 100 / total_files)) if total_files else 0}
    return {"ok": True, "installed": True, "project": str(project), "files": files,
            "service_active": service_active("allsky.service"),
            "runtime": allsky_runtime_diagnostics(project),
            "capture_policy": _allsky_capture_policy().status(project),
            "storage": allsky_storage_choices(project), "gs_camera": allsky_gs_camera_status(project), "operation": operation}


def is_recording_file(kind, path):
    return path.is_file() and not path.is_symlink() and path.suffix.lower() in RECORDING_SUFFIXES[kind]


def validate_upload_filename(kind, filename):
    filename = str(filename).strip()
    if (not filename or filename in {".", ".."} or "/" in filename or "\\" in filename
            or pathlib.Path(filename).name != filename):
        raise ValueError("Invalid filename")
    if pathlib.Path(filename).suffix.lower() not in RECORDING_SUFFIXES[kind]:
        raise ValueError("File type is not allowed for this recording page")
    return filename


def project_path(name):
    candidates = (pathlib.Path("/home/wurb") / name,
                  pathlib.Path("/home/pi") / name,
                  pathlib.Path("/opt") / name)
    if name == "wurb_2026":
        return next((path for path in candidates if (path / "wurb_main.py").is_file()
                     and (path / "wurb_app/templates/index.html").is_file()), None)
    if name == "wirc_2026":
        return next((path for path in candidates if (path / "wirc_main.py").is_file()
                     and (path / "wirc_app/templates/index.html").is_file()), None)
    return None


def project_installed(name):
    if name == "allsky":
        project=allsky_project_path()
        if project is None or ALLSKY_PENDING_UPDATE_BACKUP.exists():return False
        marker=project/".git/witty-install-state.json"
        if marker.is_file():
            try:
                if json.loads(marker.read_text()).get("state")!="installed":return False
            except (OSError,ValueError):return False
        return True
    if name in {"wurb_2026", "wirc_2026"}:
        return project_path(name) is not None and systemd_unit_installed(f"{name}.service")
    return False


def component_path_present(component):
    names = {"wurb": "wurb_2026", "wirc": "wirc_2026", "allsky": "allsky"}
    name = names.get(component)
    if not name:
        return True
    candidates = {
        pathlib.Path("/home/wurb") / name,
        pathlib.Path("/home/pi") / name,
        pathlib.Path("/opt") / name,
        *(pathlib.Path("/home").glob(f"*/{name}")),
    }
    return any(path.exists() for path in candidates)


def component_fully_removed(component):
    """Require both project files and systemd units to be gone."""
    if component == "wurb":
        return (not component_path_present("wurb")
                and not systemd_unit_installed("wurb_2026.service")
                and not service_active("wurb_2026.service")
                and not pathlib.Path("/usr/local/sbin/wurb-service").exists())
    if component == "wirc":
        return (not component_path_present("wirc")
                and not systemd_unit_installed("wirc_2026.service")
                and not service_active("wirc_2026.service")
                and not pathlib.Path("/usr/local/sbin/wirc-service").exists())
    if component == "allsky":
        units = ("allsky.service", "allskyperiodic.service", "allskyperiodic.timer")
        return (not component_path_present("allsky")
                and all(not systemd_unit_installed(unit) and not service_active(unit)
                        for unit in units))
    return False


def yaml_scalar(value):
    """Decode the simple scalar values used by CloudedBats record.targets."""
    value = value.split(" #", 1)[0].strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        value = value[1:-1]
    if value.lower() in {"true", "yes"}:
        return True
    if value.lower() in {"false", "no"}:
        return False
    try:
        return float(value)
    except ValueError:
        return value


def configured_record_targets(config_path):
    """Read record.targets without adding a PyYAML dependency to the webserver."""
    if not config_path.is_file():
        return []
    targets, current = [], None
    in_record = in_targets = False
    for raw_line in config_path.read_text(encoding="utf-8", errors="replace").splitlines():
        if not raw_line.strip() or raw_line.lstrip().startswith("#"):
            continue
        indent = len(raw_line) - len(raw_line.lstrip(" "))
        stripped = raw_line.strip()
        if indent == 0:
            in_record = stripped == "record:"
            in_targets = False
            continue
        if in_record and indent == 2:
            in_targets = stripped == "targets:"
            continue
        if not in_targets:
            continue
        if indent <= 2:
            break
        if indent == 4 and stripped.startswith("-"):
            if current:
                targets.append(current)
            current = {}
            stripped = stripped[1:].strip()
            if ":" in stripped:
                key, value = stripped.split(":", 1)
                current[key.strip()] = yaml_scalar(value)
        elif current is not None and indent >= 6 and ":" in stripped:
            key, value = stripped.split(":", 1)
            current[key.strip()] = yaml_scalar(value)
    if current:
        targets.append(current)
    return targets


def target_recording_path(project, target, require_free_space=True):
    rec_dir = str(target.get("rec_dir", "")).strip()
    if not rec_dir or str(target.get("os", "Linux")) not in {"", "Linux"}:
        return None
    rec_path = pathlib.Path(rec_dir)
    media_value = str(target.get("media_path", "")).strip()
    if rec_path.is_absolute():
        base, candidate = rec_path.parent, rec_path
    elif bool(target.get("executable_path_as_base", False)):
        base, candidate = project, project / rec_path
    elif media_value:
        base = pathlib.Path(media_value)
        if not base.is_mount():
            return None
        candidate = base / rec_path
    else:
        base, candidate = project, project / rec_path
    try:
        free_limit = float(target.get("free_disk_limit", 100)) * (2 ** 20)
        if not base.exists() or (require_free_space and shutil.disk_usage(base).free < free_limit):
            return None
        candidate.mkdir(parents=True, exist_ok=True)
        return candidate.resolve()
    except (OSError, TypeError, ValueError):
        return None


def recording_target_choices(kind):
    if kind not in RECORDING_KINDS:
        raise ValueError("Unknown recording type")
    project = project_path(f"{kind}_2026")
    if project is None:
        raise FileNotFoundError(f"{kind.upper()}-2026 is not installed")
    config_path = project.parent / f"{kind}_settings" / f"{kind}_config.yaml"
    default_path = project / f"{kind}_config_default.yaml"
    targets = configured_record_targets(config_path)
    if not targets:
        targets = configured_record_targets(default_path)
    active_path = next((path for configured_target in targets
                        if (path := target_recording_path(project, configured_target, True)) is not None), None)
    choices, used_ids = [], set()
    for index, configured_target in enumerate(targets, 1):
        path = target_recording_path(project, configured_target, False)
        if path is None:
            continue
        base_id = str(configured_target.get("id", "")).strip() or f"target-{index}"
        target_id, suffix = base_id, 2
        while target_id in used_ids:
            target_id = f"{base_id}-{suffix}"; suffix += 1
        used_ids.add(target_id)
        choices.append({"id": target_id,
                        "name": str(configured_target.get("name", "")).strip() or base_id,
                        "path": path,
                        "active": active_path is not None and path == active_path})
    if not choices:
        fallback = project.parent / RECORDING_KINDS[kind]
        fallback.mkdir(parents=True, exist_ok=True)
        choices.append({"id": "local", "name": "Local", "path": fallback.resolve(), "active": True})
    elif not any(choice["active"] for choice in choices):
        choices[0]["active"] = True
    return choices


def recording_root(kind, target_id="", strict=False):
    choices = recording_target_choices(kind)
    if target_id:
        selected = next((choice for choice in choices if choice["id"] == target_id), None)
        if selected is not None:
            return selected["path"]
        if strict:
            raise ValueError("Selected recording target is not available")
    return next((choice["path"] for choice in choices if choice["active"]), choices[0]["path"])


def safe_recording_path(root, relative="", must_exist=True):
    value = str(relative or "").replace("\\", "/")
    candidate_relative = pathlib.PurePosixPath(value)
    if candidate_relative.is_absolute() or ".." in candidate_relative.parts:
        raise ValueError("Invalid path")
    candidate = (root / pathlib.Path(*candidate_relative.parts)).resolve(strict=must_exist)
    if candidate != root and root not in candidate.parents:
        raise ValueError("Path outside recording directory")
    return candidate


def deletion_sources(root, kind, relative_paths):
    if not isinstance(relative_paths, list) or not relative_paths:
        raise ValueError("No files or folders selected")
    candidates = []
    for relative in dict.fromkeys(str(value) for value in relative_paths):
        source = safe_recording_path(root, relative)
        if source == root or source.is_symlink() or not (source.is_dir() or is_recording_file(kind, source)):
            raise ValueError(f"Can not delete {source.name}")
        candidates.append(source)
    candidates.sort(key=lambda item: len(item.parts))
    selected_roots = []
    for source in candidates:
        if not any(parent in selected_roots for parent in source.parents):
            selected_roots.append(source)
    folders_with_files = sum(
        1 for source in selected_roots
        if source.is_dir() and any(item.is_file() or item.is_symlink() for item in source.rglob("*"))
    )
    return selected_roots, folders_with_files


def recording_listing(kind, target_id=""):
    choices = recording_target_choices(kind)
    selected = next((choice for choice in choices if choice["id"] == target_id), None)
    if selected is None:
        selected = next((choice for choice in choices if choice["active"]), choices[0])
    root = selected["path"]
    directories, files = [], []
    for item in root.rglob("*"):
        try:
            resolved = item.resolve(strict=True)
            if resolved != root and root not in resolved.parents:
                continue
            relative = item.relative_to(root).as_posix()
            stat = item.stat()
            parent_relative = item.parent.relative_to(root)
            parent_name = "" if parent_relative == pathlib.Path(".") else parent_relative.as_posix()
            if item.is_dir() and not item.is_symlink():
                directories.append({"path": relative, "name": item.name,
                                    "parent": parent_name})
            elif is_recording_file(kind, item):
                files.append({"path": relative, "name": item.name,
                              "parent": parent_name,
                              "size": stat.st_size, "modified": int(stat.st_mtime)})
        except (OSError, ValueError):
            continue
    directories.sort(key=lambda item: (item["parent"].lower(), item["name"].lower()))
    files.sort(key=lambda item: (-item["modified"], item["name"].lower()))
    public_targets = [{"id": choice["id"], "name": choice["name"],
                       "path": str(choice["path"]), "active": choice["active"]}
                      for choice in choices]
    return {"ok": True, "kind": kind, "root": str(root), "selected_target": selected["id"],
            "targets": public_targets, "directories": directories, "files": files,
            "updated": datetime.now().astimezone().isoformat()}


def cleanup_old_downloads():
    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    limit = time.time() - 3600
    for item in list(DOWNLOAD_DIR.glob("*.zip")) + list(DOWNLOAD_DIR.glob("*.tar.gz")):
        try:
            if item.stat().st_mtime < limit:
                item.unlink()
        except OSError:
            pass


def create_recording_zip(kind, relative_paths, folder_path="", target_id=""):
    root = recording_root(kind, target_id, strict=True)
    selected = []
    if folder_path:
        folder = safe_recording_path(root, folder_path)
        if not folder.is_dir():
            raise ValueError("Folder not found")
        selected = [item for item in folder.rglob("*") if is_recording_file(kind, item)]
        archive_label = folder.name
    else:
        if not isinstance(relative_paths, list) or not relative_paths:
            raise ValueError("No files selected")
        for relative in relative_paths:
            item = safe_recording_path(root, relative)
            if not is_recording_file(kind, item):
                raise ValueError("Only files can be selected")
            selected.append(item)
        archive_label = f"{kind}_recordings_{datetime.now().astimezone():%Y-%m-%d--%H-%M-%S}"
    cleanup_old_downloads()
    token = uuid.uuid4().hex
    archive = DOWNLOAD_DIR / f"{token}.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as output:
        used_names = set()
        for item in selected:
            if folder_path:
                member_name = item.relative_to(root).as_posix()
            else:
                # A ZIP created from individually selected files is flat. If
                # different directories contain an identical filename, retain
                # both using a stable numeric suffix instead of overwriting.
                member_name = item.name
                counter = 2
                while member_name.casefold() in used_names:
                    member_name = f"{item.stem}_{counter}{item.suffix}"
                    counter += 1
                used_names.add(member_name.casefold())
            output.write(item, member_name)
    return token, re.sub(r"[^A-Za-z0-9._-]+", "_", archive_label).strip("._") + ".zip"


def service_active(name):
    try:
        return subprocess.run(
            ["systemctl", "is-active", "--quiet", name], timeout=3
        ).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def navigation_status_live():
    witty_model = ""
    try:
        config = pathlib.Path("/etc/witty-addon.conf").read_text(encoding="utf-8")
        match = re.search(r"^WITTY_MODEL=(3|4|5|none)$", config, re.MULTILINE)
        witty_model = match.group(1) if match else ""
    except OSError:
        pass
    gs_camera = False
    allsky_project = allsky_project_path()
    if allsky_project is not None:
        try:
            settings = json.loads((allsky_project / "config/settings.json").read_text())
            cc = json.loads((allsky_project / "config/cc.json").read_text()) if (allsky_project / "config/cc.json").is_file() else {}
            model = str(settings.get("cameramodel", "")).lower()
            gs_camera = (settings.get("cameratype") == "RPi" and
                         (str(cc.get("sensor", "")).lower().startswith("imx296") or "imx296" in model or "global shutter" in model))
        except (OSError, ValueError, TypeError):
            pass
    return {
        **page_identity(),
        "allsky_gs_camera": gs_camera,
        "wurb": project_installed("wurb_2026"),
        "wirc": project_installed("wirc_2026"),
        "allsky": "Raspberry Pi 5" in raspberry_pi_model() and project_installed("allsky"),
        "allsky_active": service_active("allsky.service"),
        "allsky_periodic_active": service_active("allskyperiodic.timer"),
        "wurb_active": service_active("wurb_2026.service"),
        "wirc_active": service_active("wirc_2026.service"),
        # This reports the independent add-on page, not vendor hardware.  The
        # page exists in all supported modes; witty_model selects only the
        # hardware-specific backend and label.
        "witty": True,
        "witty_model": witty_model,
        "ready": True,
    }


def refresh_navigation_status():
    try:
        payload = navigation_status_live()
        with NAVIGATION_STATUS_LOCK:
            NAVIGATION_STATUS_CACHE["payload"] = payload
            NAVIGATION_STATUS_CACHE["updated"] = time.monotonic()
        NAVIGATION_STATUS_READY.set()
    finally:
        with NAVIGATION_STATUS_LOCK:
            NAVIGATION_STATUS_CACHE["refreshing"] = False


def navigation_status_cached(wait_for_initial=False, force=False):
    """Return the last confirmed state and refresh slow systemd checks in the background.

    During boot the default values are deliberately marked as unconfirmed.  A browser
    request may briefly wait for the first real scan so installed software is never
    presented as "not installed" merely because systemd was still starting.
    """
    with NAVIGATION_STATUS_LOCK:
        payload = dict(NAVIGATION_STATUS_CACHE["payload"])
        stale = force or time.monotonic() - float(NAVIGATION_STATUS_CACHE["updated"] or 0) > 15
        if stale and not NAVIGATION_STATUS_CACHE["refreshing"]:
            NAVIGATION_STATUS_CACHE["refreshing"] = True
            threading.Thread(target=refresh_navigation_status, daemon=True).start()
    if wait_for_initial and not payload.get("ready"):
        NAVIGATION_STATUS_READY.wait(timeout=8)
        with NAVIGATION_STATUS_LOCK:
            payload = dict(NAVIGATION_STATUS_CACHE["payload"])
    return payload


def append_software_output(chunk):
    with SOFTWARE_JOB_LOCK:
        SOFTWARE_JOB["output"].extend(chunk)
        SOFTWARE_JOB["output_total"] += len(chunk)
        if len(SOFTWARE_JOB["output"]) > 2000000:
            removed = len(SOFTWARE_JOB["output"]) - 1500000
            del SOFTWARE_JOB["output"][:removed]
            SOFTWARE_JOB["output_start"] += removed


def software_job_snapshot(cursor=None):
    with SOFTWARE_JOB_LOCK:
        output = bytes(SOFTWARE_JOB["output"][-750000:]).decode("utf-8", errors="replace")
        output = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", output)
        start = SOFTWARE_JOB["output_start"]
        total = SOFTWARE_JOB["output_total"]
        requested = start if cursor is None else max(0, int(cursor))
        reset_required = requested < start or requested > total
        if reset_required:
            requested = start
        raw = bytes(SOFTWARE_JOB["output"][requested - start:])
        return {"ok": True, "running": SOFTWARE_JOB["running"], "action": SOFTWARE_JOB["action"],
                "component": SOFTWARE_JOB["component"], "exit_code": SOFTWARE_JOB["exit_code"],
                "reboot_scheduled": SOFTWARE_JOB["reboot_scheduled"],
                "cancel_requested": SOFTWARE_JOB["cancel_requested"], "output": output,
                "terminal_base64": base64.b64encode(raw).decode("ascii"),
                "terminal_cursor": total, "terminal_reset": reset_required}


def finish_software_job(process, master_fd):
    while True:
        try:
            ready, _, _ = select.select([master_fd], [], [], 0.5)
            if ready:
                chunk = os.read(master_fd, 65536)
                if not chunk:
                    break
                append_software_output(chunk)
            elif process.poll() is not None:
                try:
                    chunk = os.read(master_fd, 65536)
                    if chunk:
                        append_software_output(chunk)
                except OSError:
                    pass
                break
        except OSError:
            break
    return_code = process.wait()
    try:
        os.close(master_fd)
    except OSError:
        pass
    with SOFTWARE_JOB_LOCK:
        completed_component = SOFTWARE_JOB["component"]
        completed_action = SOFTWARE_JOB["action"]
        backup_path = SOFTWARE_JOB.get("backup_path", "")
        backup_temporary = SOFTWARE_JOB.get("backup_temporary", False)
        restore_backup = SOFTWARE_JOB.get("restore_backup", False)
    if return_code == 0 and completed_action == "install" and restore_backup and backup_path:
        try:
            append_software_output(b"\nSettings backup is being restored ...\n")
            restore_component_backup(completed_component, backup_path)
            append_software_output(b"Settings backup was restored successfully.\n")
        except Exception as error:
            append_software_output(f"BACKUP RESTORE ERROR: {error}\n".encode("utf-8", errors="replace"))
            return_code = 1
    if (return_code == 0 and completed_action == "uninstall"
            and not component_fully_removed(completed_component)):
        append_software_output(
            b"\nERROR: Removal verification failed; files or a service are still present.\n"
        )
        return_code = 1
    if backup_temporary and backup_path:
        try:
            pathlib.Path(backup_path).unlink()
        except OSError:
            pass
    # Refresh the installation cache before the job is exposed as finished.
    # Otherwise the UI can retain the pre-uninstall ALLSKY state for another
    # cache interval and show neither the correct install action nor the
    # service controls expected for the new state.
    try:
        refresh_navigation_status()
    except Exception:
        pass
    with SOFTWARE_JOB_LOCK:
        SOFTWARE_JOB["running"] = False
        SOFTWARE_JOB["exit_code"] = return_code
        SOFTWARE_JOB["master_fd"] = None
        SOFTWARE_JOB["process"] = None
        # WURB and WIRC are fully activated and started by their installers.
        # Only Allsky retains the reboot/finalisation path.
        SOFTWARE_JOB["reboot_scheduled"] = (return_code == 0
                                              and not SOFTWARE_JOB["cancel_requested"]
                                              and completed_component == "allsky"
                                              and SOFTWARE_JOB["action"] == "install")
        reboot_scheduled = SOFTWARE_JOB["reboot_scheduled"]
    if reboot_scheduled:
        timer = threading.Timer(5, lambda: subprocess.run(["systemctl", "reboot"], check=False))
        timer.daemon = True
        timer.start()


def start_software_job(action, component, backup_reference="", restore_backup=False):
    raise ValueError("Installation und Deinstallation sind nur im Windows-Programm verfügbar.")


def cancel_software_job():
    with SOFTWARE_JOB_LOCK:
        process = SOFTWARE_JOB.get("process")
        if not SOFTWARE_JOB["running"] or process is None:
            raise RuntimeError("No software operation is running")
        SOFTWARE_JOB["cancel_requested"] = True
        process_id = process.pid
        cancelled_allsky_install = (SOFTWARE_JOB.get("component") == "allsky"
                                    and SOFTWARE_JOB.get("action") == "install")
    try:
        os.killpg(process_id, signal.SIGTERM)
    except ProcessLookupError:
        pass

    def disable_incomplete_allsky_finaliser():
        if cancelled_allsky_install:
            subprocess.run(["systemctl", "disable", "wittypi5-allsky-firstboot.service"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)

    disable_incomplete_allsky_finaliser()

    def force_stop():
        if process.poll() is None:
            try:
                os.killpg(process_id, signal.SIGKILL)
            except ProcessLookupError:
                pass
        disable_incomplete_allsky_finaliser()

    timer = threading.Timer(5, force_stop)
    timer.daemon = True
    timer.start()
    return software_job_snapshot()


TIME_STATUS_LOCK = threading.Lock()
TIME_STATUS_READ_LOCK = threading.Lock()
TIME_STATUS_CACHE = None
TIME_STATUS_REFRESHING = False
TIME_STATUS_UPDATED = 0.0

def cached_time_status():
    global TIME_STATUS_REFRESHING
    with TIME_STATUS_LOCK:
        cached = TIME_STATUS_CACHE
        if cached is None or time.monotonic() - TIME_STATUS_UPDATED > 45:
            return None
        if not TIME_STATUS_REFRESHING and time.monotonic() - TIME_STATUS_UPDATED > 15:
            TIME_STATUS_REFRESHING = True
            threading.Thread(target=refresh_time_status, daemon=True).start()
        if cached is not None and time.monotonic() - TIME_STATUS_UPDATED <= 45:
            payload = dict(cached)
            payload["response_epoch"] = time.time()
            payload["status_age_seconds"] = time.monotonic() - TIME_STATUS_UPDATED
            return payload
    return None

def refresh_time_status():
    # Concurrent browsers/desktop requests share a single hardware snapshot.
    with TIME_STATUS_READ_LOCK:
        with TIME_STATUS_LOCK:
            if TIME_STATUS_CACHE is not None and time.monotonic() - TIME_STATUS_UPDATED <= 15:
                global TIME_STATUS_REFRESHING
                TIME_STATUS_REFRESHING = False
                return
        _refresh_time_status_locked()


def _refresh_time_status_locked():
    global TIME_STATUS_CACHE, TIME_STATUS_REFRESHING, TIME_STATUS_UPDATED
    try:
        result = subprocess.run([str(BACKEND), "status_quick"], capture_output=True, text=True, timeout=15)
        payload = json.loads(result.stdout or "{}")
        if result.returncode == 0 and payload.get("ok"):
            payload["raspberry_pi_model"] = raspberry_pi_model()
            payload["desktop_time_modes"] = True
            payload["regional_timezone"] = saved_regional_timezone(payload.get("timezone", "Etc/UTC"))
            payload.update(page_identity())
            with TIME_STATUS_LOCK:
                TIME_STATUS_CACHE = payload
                TIME_STATUS_UPDATED = time.monotonic()
    except Exception:
        pass
    finally:
        with TIME_STATUS_LOCK:
            TIME_STATUS_REFRESHING = False

class Handler(BaseHTTPRequestHandler):
    server_version = "wittypi5-webserver/1.0"

    def allowed_cors_origin(self):
        origin = self.headers.get("Origin", "")
        if not origin:
            return ""
        try:
            origin_url = urlparse(origin)
            host_url = urlparse(f"//{self.headers.get('Host', '')}")
            if (origin_url.scheme in {"http", "https"} and origin_url.hostname
                    and origin_url.hostname == host_url.hostname):
                return origin
        except ValueError:
            pass
        return ""

    def send_response_headers(self, status=200, content_type="application/json; charset=utf-8",
                              extra_headers=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        cors_origin = self.allowed_cors_origin()
        if cors_origin:
            self.send_header("Access-Control-Allow-Origin", cors_origin)
            self.send_header("Access-Control-Allow-Credentials", "true")
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        for name, value in (extra_headers or {}).items():
            self.send_header(name, value)
        self.end_headers()

    def do_OPTIONS(self):
        self.send_response_headers(204)

    def send_json(self, payload, status=200, extra_headers=None):
        encoded = json.dumps(payload).encode()
        self.send_response_headers(status, extra_headers=extra_headers)
        self.wfile.write(encoded)

    def send_download(self, target, download_name, delete_after=False):
        completed = False
        try:
            self.send_response(200)
            self.send_header("Content-Type", mimetypes.guess_type(download_name)[0] or "application/octet-stream")
            ascii_name = re.sub(r"[^A-Za-z0-9._-]+", "_", download_name)
            self.send_header("Content-Disposition", f"attachment; filename=\"{ascii_name}\"; filename*=UTF-8''{quote(download_name)}")
            self.send_header("Content-Length", str(target.stat().st_size))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with target.open("rb") as source:
                shutil.copyfileobj(source, self.wfile, length=1024 * 1024)
            completed = True
        finally:
            if delete_after and completed:
                try:
                    target.unlink()
                except OSError:
                    pass

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        if path == "/api/windows-schedule-events":
            try:
                after = int(query.get("after", ["-1"])[0])
                self.send_json(windows_schedule_event(after))
            except (TypeError, ValueError):
                self.send_json({"ok": False, "error": "Invalid event revision"}, 400)
            return
        if path == "/api/allsky-focus/frame":
            try:
                frame = FOCUS_PREVIEW.image()
                self.send_response_headers(200 if frame else 204, "image/jpeg", extra_headers={"Cache-Control": "no-store"})
                if frame:
                    self.wfile.write(frame)
            except Exception as error:
                self.send_json({"ok": False, "error": focus_error_text(error, query.get('language', ['de'])[0])}, 409)
            return
        if path == "/api/navigation":
            payload = navigation_status_cached(
                wait_for_initial=True,
                force="reconnect" in query or query.get("refresh", [""])[0] == "1",
            )
            payload["developer_mode"] = developer_session_active(self)
            try:
                # Keep the address already resolved by this browser. Replacing
                # it with the socket IP sends every service link away from DNS.
                requested_host = urlparse("//" + self.headers.get("Host", "")).hostname
                if requested_host:
                    payload["access_host"] = (f"[{requested_host}]" if ":" in requested_host else requested_host)
            except (AttributeError, ValueError):
                pass
            self.send_response_headers()
            self.wfile.write(json.dumps(payload).encode())
            return
        if path == "/api/software-job":
            try:
                cursor = int(query.get("cursor", ["0"])[0])
            except ValueError:
                cursor = 0
            self.send_json(software_job_snapshot(cursor))
            return
        if path == "/api/allsky-backups":
            try:
                self.send_json(allsky_backup_listing())
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 404)
            return
        if path == "/api/timezones":
            current_zone = subprocess.run(
                ["timedatectl", "show", "--property=Timezone", "--value"],
                capture_output=True, text=True, timeout=3
            ).stdout.strip() or "Etc/UTC"
            current_fixed_offset_minutes = timezone_offset_minutes(current_zone) if current_zone == "Witty/FixedOffset" else None
            if current_zone == "Witty/FixedOffset":
                try:
                    current_zone = pathlib.Path("/var/lib/witty-addon/previous_timezone").read_text().strip() or "Etc/UTC"
                except OSError:
                    current_zone = "Etc/UTC"
            gps_zone = timezone_from_coordinates(
                query.get("lat", [None])[0], query.get("lon", [None])[0]
            ) if "lat" in query and "lon" in query else ""
            gps_label = australian_timezone_place(
                query.get("lat", [None])[0], query.get("lon", [None])[0], gps_zone
            ) if gps_zone.startswith("Australia/") else ""
            zones, gps_zone = timezone_choices(current_zone, gps_zone, gps_label)
            self.send_response_headers()
            self.wfile.write(json.dumps({"ok": True, "zones": zones,
                                         "current_timezone": current_zone,
                                         "regional_timezone": saved_regional_timezone(current_zone),
                                         "regional_timezones": sorted(available_timezones() - {"Witty/FixedOffset"}),
                                         "current_fixed_offset_minutes": current_fixed_offset_minutes,
                                         "gps_timezone": gps_zone,
                                         "coordinate_lookup_available": TIMEZONE_FINDER is not None}).encode())
            return
        if path == "/api/log-progress":
            log_dir = APP_DIR / "logs"
            candidates = [item for item in log_dir.glob("download/**/*.log") if item.is_file()]
            received = max((item.stat().st_size for item in candidates), default=0)
            self.send_response_headers()
            self.wfile.write(json.dumps({
                "ok": True,
                "active": (log_dir / ".log-download-active").is_file(),
                "received_bytes": received,
                "local_available": any(
                    item.is_file() and item.stat().st_size > 0
                    for item in (log_dir / "WittyPi5.log", log_dir / "WittyPi4.log")
                ),
                "local_size": max(
                    (item.stat().st_size for item in
                     (log_dir / "WittyPi5.log", log_dir / "WittyPi4.log")
                     if item.is_file()), default=0
                ),
            }).encode())
            return
        if path == "/api/reset-progress":
            try:
                payload = json.loads(RESET_PROGRESS_FILE.read_text(encoding="utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Invalid reset progress")
            except (OSError, ValueError, json.JSONDecodeError):
                payload = {"ok": True, "active": False, "state": "idle", "phase": "idle",
                           "current": 0, "total": 1, "percent": 0, "detail": "",
                           "started_at": 0, "updated_at": 0}
            self.send_json(payload)
            return
        if path == "/api/schedule-transfer-progress":
            try:
                payload = json.loads(SCHEDULE_PROGRESS_FILE.read_text(encoding="utf-8"))
                if not isinstance(payload, dict):
                    raise ValueError("Invalid schedule transfer progress")
            except (OSError, ValueError, json.JSONDecodeError):
                payload = write_schedule_progress()
            self.send_json(payload)
            return
        if path == "/api/shutdown-status":
            try:
                self.send_json(shutdown_navigation_status(force=query.get("fresh", [""])[0] == "1"))
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 502)
            return
        if path == "/schedule-bulk-download":
            try:
                token = query.get("token", [""])[0]
                if not re.fullmatch(r"[a-f0-9]{32}", token):
                    raise ValueError("Invalid download token")
                target = SCHEDULE_TEMP_DIR / f"{token}.zip"
                if not target.is_file() or target.is_symlink():
                    raise FileNotFoundError("Schedule ZIP not found")
                self.send_download(target, "Witty-Skripte.zip", delete_after=True)
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 404)
            return
        if path in {"/logs/WittyPi5.log", "/logs/WittyPi4.log"}:
            target = APP_DIR / "logs" / pathlib.Path(path).name
            if not target.is_file():
                self.send_response_headers(404)
                self.wfile.write(b'{"ok":false,"error":"Log not found"}')
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Disposition", 'attachment; filename="WittyPi5.log"')
            self.send_header("Content-Length", str(target.stat().st_size))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with target.open("rb") as source:
                shutil.copyfileobj(source, self.wfile, length=64 * 1024)
            return
        if path == "/allsky-backup":
            try:
                if allsky_project_path() is None:
                    raise FileNotFoundError("Allsky is not installed")
                target = allsky_backup_path(query.get("name", [""])[0])
                if not target.is_file() or target.is_symlink():
                    raise FileNotFoundError("Backup not found")
                self.send_download(target, target.name)
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 404)
            return
        if path == "/software-backup":
            try:
                temporary = query.get("temporary", ["false"])[0] == "true"
                name = pathlib.Path(query.get("name", [""])[0]).name
                if name != query.get("name", [""])[0] or not name.endswith(".tar.gz"):
                    raise ValueError("Invalid backup filename")
                if temporary:
                    token = query.get("token", [""])[0]
                    if not re.fullmatch(r"[a-f0-9]{32}", token):
                        raise ValueError("Invalid backup token")
                    target = SOFTWARE_TEMP_BACKUP_DIR / f"{token}.tar.gz"
                else:
                    target = SOFTWARE_BACKUP_DIR / name
                    if not target.is_file():
                        target = ALLSKY_BACKUP_DIR / name
                if not target.is_file() or target.is_symlink():
                    raise FileNotFoundError("Backup not found")
                retain = query.get("retain", ["false"])[0] == "true"
                self.send_download(target, name, delete_after=temporary and not retain)
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 404)
            return
        if path == "/api/recordings":
            try:
                self.send_json(recording_listing(query.get("kind", [""])[0], query.get("target", [""])[0]))
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 400)
            return
        if path == "/recording-file":
            try:
                kind = query.get("kind", [""])[0]
                relative = query.get("path", [""])[0]
                root = recording_root(kind, query.get("target", [""])[0], strict=True)
                target = safe_recording_path(root, relative)
                if not is_recording_file(kind, target):
                    raise FileNotFoundError("Recording not found")
                self.send_download(target, target.name)
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 404)
            return
        if path == "/recording-zip":
            token = query.get("token", [""])[0]
            name = query.get("name", ["recordings.zip"])[0]
            if not re.fullmatch(r"[a-f0-9]{32}", token):
                self.send_json({"ok": False, "error": "Invalid download token"}, 400)
                return
            target = DOWNLOAD_DIR / f"{token}.zip"
            if not target.is_file():
                self.send_json({"ok": False, "error": "ZIP file not found"}, 404)
                return
            self.send_download(target, pathlib.Path(name).name, delete_after=True)
            return
        files = {
            "/": WEB_DIR / "index.html",
            "/index.html": WEB_DIR / "index.html",
            "/manual": WEB_DIR / "manual.html",
            "/manual.html": WEB_DIR / "manual.html",
            "/allsky-setup": WEB_DIR / "allsky_setup.html",
            "/allsky-setup.html": WEB_DIR / "allsky_setup.html",
            "/recordings/wurb": WEB_DIR / "recordings.html",
            "/recordings/wirc": WEB_DIR / "recordings.html",
            "/assets/bulma-v1.0.4.min.css": WEB_DIR / "assets" / "bulma-v1.0.4.min.css",
            "/assets/cloudedbats_logo.png": WEB_DIR / "assets" / "cloudedbats_logo.png",
            "/assets/xterm.js": WEB_DIR / "assets" / "xterm.js",
            "/assets/xterm.css": WEB_DIR / "assets" / "xterm.css",
            "/assets/shutdown-nav.js": WEB_DIR / "assets" / "shutdown-nav.js",
            "/assets/witty-time.js": WEB_DIR / "assets" / "witty-time.js",
            "/assets/witty-navigation.css": WEB_DIR / "assets" / "witty-navigation.css",
            "/assets/wurb-mobile-location.js": WEB_DIR / "assets" / "wurb-mobile-location.js",
            "/assets/witty-mobile-contrast.css": WEB_DIR / "assets" / "witty-mobile-contrast.css",
        }
        target = files.get(path)
        if not target or not target.is_file():
            self.send_response_headers(404)
            self.wfile.write(b'{"ok":false,"error":"Not found"}')
            return
        mime = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response_headers(200, mime)
        self.wfile.write(target.read_bytes())

    def do_POST(self):
        request_path = urlparse(self.path).path
        if request_path == "/api/allsky-focus":
            request = {}
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 4096:
                    raise ValueError("Invalid request size")
                request = json.loads(self.rfile.read(length))
                action = request.get("action")
                if action == "start":
                    project = allsky_project_path()
                    if not project:
                        raise ValueError("Allsky ist nicht installiert.")
                    result = FOCUS_PREVIEW.start(project)
                elif action == "stop":
                    result = FOCUS_PREVIEW.close()
                else:
                    raise ValueError("Invalid focus action")
                result = {**result, 'error': focus_error_text(result.get('error', ''), request.get('language', 'de'))}
                self.send_json(result)
            except Exception as error:
                self.send_json({"ok": False, "error": focus_error_text(error, request.get('language', 'de') if isinstance(request, dict) else 'de')}, 409)
            return
        if request_path == "/api/developer-session":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 2 or length > 4096:
                    raise ValueError("Invalid request size")
                request = json.loads(self.rfile.read(length))
                action = str(request.get("action", "login"))
                if action == "logout":
                    remove_developer_session(self)
                    self.send_json({"ok": True, "developer_mode": False}, extra_headers={
                        "Set-Cookie": f"{DEVELOPER_SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"
                    })
                    return
                if action != "login":
                    raise ValueError("Action not allowed")
                password_hash = hashlib.sha256(str(request.get("password", "")).encode("utf-8")).hexdigest()
                if not hmac.compare_digest(password_hash, DEVELOPER_PASSWORD_SHA256):
                    self.send_json({"ok": False, "error": "Falsches Passwort."}, 403)
                    return
                token = create_developer_session()
                self.send_json({"ok": True, "developer_mode": True}, extra_headers={
                    "Set-Cookie": (f"{DEVELOPER_SESSION_COOKIE}={token}; Path=/; HttpOnly; "
                                   f"SameSite=Strict; Max-Age={DEVELOPER_SESSION_SECONDS}")
                })
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 400)
            return
        if request_path == "/api/schedule-bulk-export":
            self.handle_schedule_bulk_export()
            return
        if request_path == "/api/schedule-bulk-upload":
            self.handle_schedule_bulk_upload()
            return
        if request_path == "/api/software-backup":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 2 or length > 16 * 1024:
                    raise ValueError("Invalid request size")
                request = json.loads(self.rfile.read(length))
                component = str(request.get("component", ""))
                if component not in {"wurb", "wirc", "allsky"}:
                    raise ValueError("Invalid software component")
                keep_local = request.get("keep_local") is True
                restore_after = request.get("restore_after") is True
                target, filename = create_component_backup(component, keep_local)
                if keep_local:
                    url = f"/software-backup?name={quote(filename)}"
                    backup_reference = f"local:{filename}"
                else:
                    token = target.stem.split(".", 1)[0]
                    url = f"/software-backup?temporary=true&retain={'true' if restore_after else 'false'}&token={token}&name={quote(filename)}"
                    backup_reference = f"temporary:{token}"
                self.send_json({"ok": True, "name": filename, "size": target.stat().st_size,
                                "kept_local": keep_local, "url": url,
                                "backup_reference": backup_reference})
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 400)
            return
        if request_path == "/api/software-job":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length < 2 or length > 16 * 1024:
                    raise ValueError("Invalid request size")
                request = json.loads(self.rfile.read(length))
                operation = str(request.get("operation", ""))
                if operation == "start":
                    action = str(request.get("action", ""))
                    component = str(request.get("component", ""))
                    if request.get("confirmation") != f"{action}:{component}":
                        raise ValueError("Software operation was not confirmed")
                    payload = start_software_job(action, component,
                                                 str(request.get("backup_reference", "")),
                                                 request.get("restore_backup") is True)
                elif operation == "input":
                    data = str(request.get("data", ""))
                    with SOFTWARE_JOB_LOCK:
                        if (not SOFTWARE_JOB["running"] or SOFTWARE_JOB["component"] != "allsky"
                                or SOFTWARE_JOB["action"] != "install" or SOFTWARE_JOB["master_fd"] is None):
                            raise RuntimeError("No interactive Allsky installation is running")
                        if len(data) > 256 or "\x00" in data:
                            raise ValueError("Invalid installer input")
                        os.write(SOFTWARE_JOB["master_fd"], data.encode("utf-8"))
                    payload = {"ok": True}
                elif operation == "resize":
                    cols = int(request.get("cols", 100))
                    rows = int(request.get("rows", 40))
                    if not 40 <= cols <= 240 or not 20 <= rows <= 80:
                        raise ValueError("Invalid terminal size")
                    with SOFTWARE_JOB_LOCK:
                        if (not SOFTWARE_JOB["running"] or SOFTWARE_JOB["component"] != "allsky"
                                or SOFTWARE_JOB["action"] != "install" or SOFTWARE_JOB["master_fd"] is None):
                            raise RuntimeError("No interactive Allsky installation is running")
                        fcntl.ioctl(SOFTWARE_JOB["master_fd"], termios.TIOCSWINSZ,
                                    struct.pack("HHHH", rows, cols, 0, 0))
                        process = SOFTWARE_JOB.get("process")
                        if process is not None:
                            try:
                                os.killpg(process.pid, signal.SIGWINCH)
                            except ProcessLookupError:
                                pass
                    payload = {"ok": True}
                elif operation == "cancel":
                    payload = cancel_software_job()
                else:
                    raise ValueError("Action not allowed")
                self.send_json(payload)
            except RuntimeError as error:
                self.send_json({"ok": False, "error": str(error)}, 409)
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 400)
            return
        if request_path == "/api/recording-upload":
            self.handle_recording_upload()
            return
        if request_path == "/api/allsky-restore-upload":
            self.handle_allsky_restore_upload()
            return
        if request_path == "/api/allsky-backups":
            self.handle_allsky_action()
            return
        if request_path not in {"/api", "/api/recordings"}:
            self.send_response_headers(404); self.wfile.write(b'{"ok":false,"error":"Not found"}'); return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 2 or length > 8 * 1024 * 1024:
                raise ValueError("Invalid request size")
            request = json.loads(self.rfile.read(length))
            if request_path == "/api/recordings":
                self.handle_recording_action(request)
                return
            action = request.get("action", "")
            allowed = {
                "status", "status_quick", "gps_status", "system_to_witty", "witty_to_system", "manual_to_system", "manual_to_witty",
                "gps_to_system", "gps_to_witty", "clear_schedule", "read_schedule", "read_named_schedule",
                "upload_schedule", "read_log", "read_local_log", "delete_log", "reboot", "shutdown", "internal_rtc_toggle",
                "log_status", "logging_enable", "logging_disable", "witty_reset",
                "voltage_protection_enable", "voltage_protection_disable",
                "low_voltage_set", "low_voltage_disable", "recovery_voltage_set", "recovery_voltage_disable",
                "over_temperature_set", "over_temperature_disable", "below_temperature_set", "below_temperature_disable",
                "other_setting_set",
                "service_start", "service_stop",
                "gps_configure", "gps_remove",
                "fixed_timezone",
                "schedule_list", "schedule_activate", "schedule_delete",
            }
            if action not in allowed:
                raise ValueError("Action not allowed")
            if action == "service_start" and request.get("service") == "allsky" and FOCUS_PREVIEW.status()["running"]:
                raise ValueError("Bitte zuerst das Livebild-Fenster schließen.")
            if action == "service_start" and request.get("service") == "allsky" and allsky_initial_setup_required():
                english = str(request.get("language", "de")).startswith("en")
                self.send_json({"ok": False, "code": "allsky-setup-required",
                                "error": ("Complete the initial setup on the Allsky settings page and save the settings before starting the service."
                                          if english else "Bitte zuerst die Ersteinrichtung auf der Allsky-Einstellungsseite durchführen und die Einstellungen speichern. Danach kann der Dienst gestartet werden."),
                                "setup_path": "/index.php?page=settings"}, 409)
                return
            if action in {"status", "status_quick"} and not request.get("force_fresh"):
                cached = cached_time_status()
                if cached is None:
                    refresh_time_status()
                    cached = cached_time_status()
                if cached is not None:
                    self.send_json(cached)
                    return
            if action == "fixed_timezone" and request.get("enabled") is False:
                try:
                    fix = backend_json("gps_status", timeout=8)
                    if fix.get("gps_valid") is True:
                        detected = timezone_from_coordinates(fix.get("gps_latitude"), fix.get("gps_longitude"))
                        if detected:
                            request["timezone"] = detected
                except (OSError, ValueError, subprocess.SubprocessError):
                    pass
            arguments = [str(BACKEND), action]
            if action in {"manual_to_system", "manual_to_witty"}:
                arguments.append(str(request.get("value", "")))
            elif action == "upload_schedule":
                arguments.extend((str(request.get("filename", "")), str(request.get("content_base64", ""))))
            elif action in {"service_start", "service_stop"}:
                arguments.append(str(request.get("service", "")))
            elif action in {"gps_configure", "gps_remove"}:
                arguments.append(str(request.get("mode", "")))
            elif action == "fixed_timezone":
                arguments.extend((str(bool(request.get("enabled", False))).lower(),
                                  str(request.get("timezone", "Etc/UTC"))))
                if request.get("enabled") is True and "offset_minutes" in request:
                    minutes = request["offset_minutes"]
                    if type(minutes) is not int or not -720 <= minutes <= 840:
                        raise ValueError("Invalid fixed UTC offset")
                    arguments.append(str(minutes))
            elif action == "voltage_protection_enable":
                arguments.extend((str(request.get("low_voltage", "")),
                                  str(request.get("recovery_voltage", ""))))
            elif action in {"low_voltage_set", "recovery_voltage_set"}:
                arguments.append(str(request.get("value", "")))
            elif action in {"over_temperature_set", "below_temperature_set"}:
                arguments.extend((str(request.get("temperature_action", "")),
                                  str(request.get("temperature", ""))))
            elif action == "other_setting_set":
                arguments.extend((str(request.get("setting", "")), str(request.get("value", ""))))
            elif action in {"schedule_activate", "schedule_delete", "read_named_schedule"}:
                arguments.append(str(request.get("filename", "")))
            timeout_seconds = 1800 if action in {"read_log", "witty_reset"} else (60 if action in {"read_schedule", "read_named_schedule"} else 420)
            result = subprocess.run(arguments, capture_output=True, text=True, timeout=timeout_seconds)
            try:
                payload = json.loads(result.stdout or "{}")
            except json.JSONDecodeError:
                detail = (result.stderr or result.stdout or "").strip()[-2000:]
                payload = {"ok": False, "error": detail or "Backend lieferte keine gültige JSON-Antwort"}
            if result.returncode == 0 and payload.get("ok"):
                if action == "fixed_timezone":
                    payload["applied_timezone"] = request["timezone"]
                    regional_file = pathlib.Path("/var/lib/witty-addon/regional_timezone")
                    regional_file.parent.mkdir(parents=True, exist_ok=True)
                    regional_file.write_text(str(request["timezone"]) + "\n")
                confirm_navigation_service_state(action, str(request.get("service", "")), payload)
                cache_windows_schedule_status(action, payload)
            if action in {"status", "status_quick"} and payload.get("ok"):
                payload["desktop_time_modes"] = True
                payload["regional_timezone"] = saved_regional_timezone(payload.get("timezone", "Etc/UTC"))
                payload["raspberry_pi_model"] = raspberry_pi_model()
                payload.update(page_identity())
            if not payload.get("ok") and not payload.get("error"):
                detail = (result.stderr or result.stdout or "").strip()[-2000:]
                payload["error"] = detail or f"Backend wurde mit Code {result.returncode} beendet"
            global TIME_STATUS_CACHE, TIME_STATUS_UPDATED
            if action in {"status", "status_quick"} and payload.get("ok"):
                with TIME_STATUS_LOCK:
                    TIME_STATUS_CACHE = dict(payload)
                    TIME_STATUS_UPDATED = time.monotonic()
            elif action != "gps_status" and payload.get("ok"):
                with TIME_STATUS_LOCK:
                    TIME_STATUS_CACHE = None
                    TIME_STATUS_UPDATED = 0.0
            status = 200 if result.returncode == 0 and payload.get("ok") else 502
        except Exception as error:
            status, payload = 400, {"ok": False, "error": str(error)}
        self.send_response_headers(status)
        self.wfile.write(json.dumps(payload).encode())

    def handle_schedule_bulk_export(self):
        if not SCHEDULE_TRANSFER_LOCK.acquire(blocking=False):
            self.send_json({"ok": False, "error": "A schedule transfer is already running"}, 409)
            return
        target = None
        try:
            cleanup_schedule_temp()
            # Der Windows-/Web-ZIP-Export darf ausschließlich Dateien enthalten,
            # die die Witty-Firmware aktuell selbst auflistet. Lokale Kopien in
            # /var/lib/witty-addon sind nur Arbeitscache und gehören nicht hinein.
            listing = backend_json("schedule_remote_list")
            names = [name for name in listing.get("files", [])
                     if isinstance(name, str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}\.wpi", name, re.IGNORECASE)]
            if not names:
                raise FileNotFoundError("No WPI scripts are available")
            metadata = listing.get("metadata", {}) if isinstance(listing.get("metadata"), dict) else {}
            estimated_sizes = {name: max(1, int(metadata.get(name, {}).get("bytes", 4000))) for name in names}
            total_bytes = sum(estimated_sizes.values())
            processed = 0
            rate = schedule_transfer_rate()
            write_schedule_progress("running", "download", total_bytes, 0, len(names), 0, rate,
                                    "Preparing WPI downloads")
            token = uuid.uuid4().hex
            target = SCHEDULE_TEMP_DIR / f"{token}.zip"
            with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
                for index, name in enumerate(names, 1):
                    started = time.monotonic()
                    payload = backend_json("read_remote_schedule", name, timeout=180)
                    try:
                        content = base64.b64decode(payload.get("content_base64", ""), validate=True)
                    except (ValueError, TypeError) as error:
                        raise ValueError(f"Invalid data returned for {name}") from error
                    events = validate_wpi_content(name, content, allow_long_name=True)
                    archive.writestr(name, content)
                    elapsed = max(time.monotonic() - started, 0.05)
                    rate = save_schedule_transfer_rate(rate, len(content) / elapsed)
                    processed += len(content)
                    remaining_estimate = sum(estimated_sizes[item] for item in names[index:])
                    total_bytes = max(processed + remaining_estimate, processed)
                    write_schedule_progress("running", "download", total_bytes, processed, len(names), index,
                                            rate, f"{name} · {events} events")
            write_schedule_progress("complete", "download", processed, processed, len(names), len(names), rate,
                                    "ZIP is ready for download")
            self.send_json({"ok": True, "name": "Witty-Skripte.zip", "files": len(names),
                            "bytes": processed, "url": f"/schedule-bulk-download?token={token}"})
            target = None
        except Exception as error:
            write_schedule_progress("failed", "download", error=str(error))
            if target is not None:
                try:
                    target.unlink()
                except OSError:
                    pass
            self.send_json({"ok": False, "error": str(error)}, 400)
        finally:
            SCHEDULE_TRANSFER_LOCK.release()

    def handle_schedule_bulk_upload(self):
        if not SCHEDULE_TRANSFER_LOCK.acquire(blocking=False):
            self.send_json({"ok": False, "error": "A schedule transfer is already running"}, 409)
            return
        upload_path = None
        extraction = None
        try:
            cleanup_schedule_temp()
            parsed = urlparse(self.path)
            original_name = pathlib.Path(parse_qs(parsed.query).get("name", [""])[0]).name
            if not original_name.lower().endswith(".zip"):
                raise ValueError("A ZIP file is required")
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 8 * 1024 * 1024:
                raise ValueError("ZIP upload must be between 1 byte and 8 MiB")
            token = uuid.uuid4().hex
            upload_path = SCHEDULE_TEMP_DIR / f".{token}.upload.zip"
            with upload_path.open("xb") as output:
                remaining = length
                while remaining:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ConnectionError("ZIP upload was interrupted")
                    output.write(chunk)
                    remaining -= len(chunk)
                output.flush()
                os.fsync(output.fileno())
            extraction = pathlib.Path(tempfile.mkdtemp(prefix=f"{token}-", dir=SCHEDULE_TEMP_DIR))
            scripts = []
            seen = set()
            with zipfile.ZipFile(upload_path, "r") as archive:
                entries = archive.infolist()
                if not entries or len(entries) > 128:
                    raise ValueError("ZIP must contain 1 to 128 WPI files")
                for info in entries:
                    normalised = posixpath.normpath(info.filename)
                    mode = info.external_attr >> 16
                    file_type = stat.S_IFMT(mode)
                    if (info.flag_bits & 1) or info.is_dir() or normalised != pathlib.PurePosixPath(normalised).name:
                        raise ValueError(f"Unsupported ZIP entry: {info.filename}")
                    if file_type and file_type != stat.S_IFREG:
                        raise ValueError(f"ZIP contains a special file: {info.filename}")
                    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,26}\.wpi", normalised, re.IGNORECASE):
                        raise ValueError(f"Invalid WPI filename: {info.filename}")
                    key = normalised.casefold()
                    if key in seen:
                        raise ValueError(f"Duplicate WPI filename: {normalised}")
                    seen.add(key)
                    if info.file_size <= 0 or info.file_size > 4000 or info.compress_size > 1024 * 1024:
                        raise ValueError(f"Invalid WPI size: {normalised}")
                    content = archive.read(info)
                    events = validate_wpi_content(normalised, content)
                    destination = extraction / normalised
                    destination.write_bytes(content)
                    scripts.append((normalised, destination, len(content), events))
            total_bytes = sum(item[2] for item in scripts)
            # Namen, Größen, Ereigniszahl und Prüfsumme aller Dateien stehen
            # bereits vor dem ersten Witty-/I²C-Upload in der Cacheliste.
            stage_schedule_metadata(scripts)
            processed = 0
            rate = schedule_transfer_rate()
            write_schedule_progress("running", "upload", total_bytes, 0, len(scripts), 0, rate,
                                    "ZIP validated; starting individual WPI uploads")
            for index, (name, source, size, events) in enumerate(scripts, 1):
                started = time.monotonic()
                encoded = base64.b64encode(source.read_bytes()).decode("ascii")
                backend_json("upload_schedule", name, encoded, timeout=240)
                elapsed = max(time.monotonic() - started, 0.05)
                rate = save_schedule_transfer_rate(rate, size / elapsed)
                processed += size
                write_schedule_progress("running", "upload", total_bytes, processed, len(scripts), index,
                                        rate, f"{name} · {events} events")
            write_schedule_progress("complete", "upload", total_bytes, processed, len(scripts), len(scripts), rate,
                                    "All WPI scripts were uploaded")
            self.send_json({"ok": True, "files": len(scripts), "bytes": total_bytes})
        except Exception as error:
            write_schedule_progress("failed", "upload", error=str(error))
            self.send_json({"ok": False, "error": str(error)}, 400)
        finally:
            if extraction is not None:
                shutil.rmtree(extraction, ignore_errors=True)
            if upload_path is not None:
                try:
                    upload_path.unlink()
                except OSError:
                    pass
            SCHEDULE_TRANSFER_LOCK.release()

    def handle_allsky_action(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length < 2 or length > 64 * 1024:
            self.send_json({"ok": False, "error": "Invalid request size"}, 400)
            return
        request = {}
        try:
            request = json.loads(self.rfile.read(length))
            if not isinstance(request, dict):
                request = {}
                raise ValueError("Expected a JSON object")
        except (ValueError, json.JSONDecodeError) as error:
            self.send_json({"ok": False, "error": (getattr(error, "english", str(error)) if request.get("language") == "en" else str(error))}, 400)
            return
        action = str(request.get("action", ""))
        if not ALLSKY_LOCK.acquire(blocking=False):
            self.send_json({"ok": False, "code": "allsky_busy",
                            "operation": _allsky_operation_snapshot().get("action", ""),
                            "error": "An ALLSKY operation is still running"}, 409)
            return
        operation_action = (f"set-storage-{request.get('transfer', '')}"
                            if action == "set-storage" else action)
        _update_allsky_operation(action=operation_action, started=time.time(), phase="preparing",
                                 total_files=0, copied_files=0)
        temporary = None
        try:
            project = allsky_project_path()
            if project is None:
                raise FileNotFoundError("Allsky is not installed")
            ALLSKY_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            if action == "create":
                filename = validate_allsky_backup_name(request.get("name", ""))
                destination = allsky_backup_path(filename)
                if destination.exists() or destination.is_symlink():
                    raise FileExistsError("A backup with this name already exists")
                temporary = ALLSKY_BACKUP_DIR / f".{uuid.uuid4().hex}.creating.tar.gz"
                create_allsky_archive(project, temporary)
                validate_allsky_archive(temporary)
                temporary.chmod(0o640)
                os.replace(temporary, destination)
                temporary = None
                payload = {"ok": True, "name": filename, "size": destination.stat().st_size,
                           "url": f"/allsky-backup?name={quote(filename)}"}
            elif action == "delete":
                destination = allsky_backup_path(str(request.get("name", "")))
                if not destination.is_file() or destination.is_symlink():
                    raise FileNotFoundError("Backup not found")
                destination.unlink()
                payload = {"ok": True}
            elif action == "set-storage":
                storage = configure_allsky_storage(
                    project, str(request.get("path", "")), str(request.get("transfer", "")))
                payload = {"ok": True, "storage": storage}
            elif action == "set-gs-camera":
                payload = {"ok": True, "gs_camera": configure_allsky_gs_camera(project, request.get("enabled"))}
            elif action == "set-exposure":
                payload = {"ok": True, "gs_camera": configure_allsky_exposure(
                    project, request.get("values_seconds"), request.get("auto"))}
            elif action == "set-capture-policy":
                payload = {"ok": True, "capture_policy": _allsky_capture_policy().configure(
                    project, request.get("feature"), request.get("enabled"))}
            elif action == "set-location":
                payload = {"ok": True, **configure_allsky_location(
                    project, request.get("latitude", ""), request.get("longitude", ""))}
            else:
                raise ValueError("Action not allowed")
            self.send_json(payload)
        except FileExistsError as error:
            self.send_json({"ok": False, "error": str(error)}, 409)
        except Exception as error:
            if temporary is not None:
                try:
                    temporary.unlink()
                except OSError:
                    pass
            self.send_json({"ok": False, "error": (getattr(error, "english", str(error)) if request.get("language") == "en" else str(error))}, 400)
        finally:
            _update_allsky_operation(action="", started=0.0, phase="",
                                     total_files=0, copied_files=0)
            ALLSKY_LOCK.release()

    def handle_allsky_restore_upload(self):
        if not ALLSKY_LOCK.acquire(blocking=False):
            self.send_json({"ok": False, "code": "allsky_busy",
                            "operation": _allsky_operation_snapshot().get("action", ""),
                            "error": "An ALLSKY operation is still running"}, 409)
            return
        _update_allsky_operation(action="restore", started=time.time(), phase="preparing",
                                 total_files=0, copied_files=0)
        write_path = None
        stored_path = None
        try:
            project = allsky_project_path()
            if project is None:
                raise FileNotFoundError("Allsky is not installed")
            query = parse_qs(urlparse(self.path).query, keep_blank_values=True)
            original_name = validate_allsky_backup_name(query.get("name", [""])[0])
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 1024 ** 3:
                raise ValueError("Invalid backup upload size")
            ALLSKY_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            if shutil.disk_usage(ALLSKY_BACKUP_DIR).free < length * 3 + 64 * 1024 * 1024:
                raise OSError("Not enough free space to validate and restore this backup")
            write_path = ALLSKY_BACKUP_DIR / f".{uuid.uuid4().hex}.upload.tar.gz"
            remaining = length
            with write_path.open("xb") as output:
                while remaining:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ConnectionError("Backup upload was interrupted")
                    output.write(chunk)
                    remaining -= len(chunk)
                output.flush()
                os.fsync(output.fileno())
            validate_allsky_archive(write_path)
            stored_name = original_name
            stored_path = allsky_backup_path(stored_name)
            if stored_path.exists():
                base = original_name[:-7]
                stored_name = f"{base}-uploaded-{datetime.now():%Y%m%d-%H%M%S}.tar.gz"
                stored_path = allsky_backup_path(stored_name)
            write_path.chmod(0o640)
            os.replace(write_path, stored_path)
            write_path = None
            restarted = restore_allsky_archive(project, stored_path)
            stored_path.unlink(missing_ok=True)
            self.send_json({"ok": True, "name": stored_name, "restarted": restarted})
        except Exception as error:
            if write_path is not None:
                try:
                    write_path.unlink()
                except OSError:
                    pass
            if stored_path is not None:
                try:
                    stored_path.unlink()
                except OSError:
                    pass
            self.send_json({"ok": False, "error": str(error)}, 400)
        finally:
            _update_allsky_operation(action="", started=0.0, phase="",
                                     total_files=0, copied_files=0)
            ALLSKY_LOCK.release()

    def handle_recording_upload(self):
        destination_file = None
        write_path = None
        created = False
        try:
            query = parse_qs(urlparse(self.path).query, keep_blank_values=True)
            kind = query.get("kind", [""])[0]
            target_id = query.get("target", [""])[0]
            folder_name = query.get("folder", [""])[0]
            filename = validate_upload_filename(kind, query.get("name", [""])[0])
            overwrite = query.get("overwrite", ["false"])[0].lower() == "true"
            root = recording_root(kind, target_id, strict=True)
            folder = safe_recording_path(root, folder_name)
            if not folder.is_dir() or folder.is_symlink():
                raise ValueError("Upload folder not found")
            destination_file = safe_recording_path(
                root, (folder / filename).relative_to(root).as_posix(), must_exist=False
            )
            if destination_file.exists() and (destination_file.is_symlink() or not destination_file.is_file()):
                raise ValueError("Upload destination is not a regular file")
            if destination_file.exists() and not overwrite:
                raise FileExistsError(filename)
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 1024 ** 4:
                raise ValueError("Invalid upload size")
            reclaimable = destination_file.stat().st_size if overwrite and destination_file.exists() else 0
            if shutil.disk_usage(folder).free + reclaimable < length + 16 * 1024 * 1024:
                raise OSError("Not enough free space for upload")
            remaining = length
            write_path = folder / f".{uuid.uuid4().hex}.recording-upload"
            with write_path.open("xb") as output:
                created = True
                while remaining:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ConnectionError("Upload was interrupted")
                    output.write(chunk)
                    remaining -= len(chunk)
                output.flush()
                os.fsync(output.fileno())
            write_path.chmod(0o644)
            if destination_file.exists() and not overwrite:
                raise FileExistsError(filename)
            os.replace(write_path, destination_file)
            created = False
            self.send_json({"ok": True, "name": filename, "size": length})
        except FileExistsError:
            self.send_json({"ok": False, "error": "A file with this name already exists"}, 409)
        except Exception as error:
            if created and write_path is not None:
                try:
                    write_path.unlink()
                except OSError:
                    pass
            self.send_json({"ok": False, "error": str(error)}, 400)

    def handle_recording_action(self, request):
        try:
            kind = str(request.get("kind", ""))
            action = str(request.get("action", ""))
            target_id = str(request.get("target", ""))
            root = recording_root(kind, target_id, strict=True)
            if action == "create_folder":
                name = str(request.get("name", "")).strip()
                if not re.fullmatch(r"[A-Za-z0-9ÄÖÜäöüß][A-Za-z0-9ÄÖÜäöüß ._-]{0,79}", name) or name in {".", ".."}:
                    raise ValueError("Invalid folder name")
                parent = safe_recording_path(root, str(request.get("parent", "")))
                if not parent.is_dir() or parent.is_symlink():
                    raise ValueError("Parent folder not found")
                target = safe_recording_path(root, (parent / name).relative_to(root).as_posix(), must_exist=False)
                target.mkdir(exist_ok=False)
                payload = {"ok": True}
            elif action == "upload_check":
                folder = safe_recording_path(root, str(request.get("folder", "")))
                if not folder.is_dir() or folder.is_symlink():
                    raise ValueError("Upload folder not found")
                names = request.get("names", [])
                if not isinstance(names, list) or not names:
                    raise ValueError("No files selected")
                checked = [validate_upload_filename(kind, name) for name in names]
                conflicts = [name for name in dict.fromkeys(checked) if (folder / name).exists()]
                payload = {"ok": True, "conflicts": conflicts}
            elif action == "delete_check":
                paths = request.get("paths", [])
                sources, folders_with_files = deletion_sources(root, kind, paths)
                payload = {"ok": True, "requires_confirmation": folders_with_files > 0,
                           "folders_with_files": folders_with_files, "items": len(sources)}
            elif action == "delete":
                sources, folders_with_files = deletion_sources(root, kind, request.get("paths", []))
                if folders_with_files and request.get("confirm_recursive") is not True:
                    raise ValueError("A selected folder contains files; confirmation is required")
                for source in sources:
                    if source.is_dir():
                        shutil.rmtree(source)
                    else:
                        source.unlink()
                payload = {"ok": True}
            elif action == "move":
                paths = request.get("paths", [])
                if not isinstance(paths, list) or not paths:
                    raise ValueError("No files or folders selected")
                destination = safe_recording_path(root, request.get("destination", ""))
                if not destination.is_dir() or destination.is_symlink():
                    raise ValueError("Destination folder not found")
                candidates = []
                for relative in dict.fromkeys(str(value) for value in paths):
                    source = safe_recording_path(root, relative)
                    if source == root or source.is_symlink() or not (source.is_dir() or is_recording_file(kind, source)):
                        raise ValueError(f"Can not move {source.name}")
                    candidates.append(source)
                candidates.sort(key=lambda item: len(item.parts))
                selected_roots = []
                for source in candidates:
                    if not any(parent in selected_roots for parent in source.parents):
                        selected_roots.append(source)
                sources, targets = [], set()
                for source in selected_roots:
                    if destination == source or source in destination.parents:
                        raise ValueError(f"Can not move {source.name} into itself")
                    target = destination / source.name
                    if target.exists() or target in targets:
                        raise ValueError(f"Can not move {source.name}")
                    targets.add(target)
                    sources.append((source, target))
                for source, target in sources:
                    shutil.move(str(source), str(target))
                payload = {"ok": True}
            elif action == "create_zip":
                token, name = create_recording_zip(kind, request.get("paths", []), str(request.get("folder", "")), target_id)
                payload = {"ok": True, "url": f"/recording-zip?token={token}&name={quote(name)}"}
            else:
                raise ValueError("Action not allowed")
            self.send_json(payload)
        except Exception as error:
            self.send_json({"ok": False, "error": str(error)}, 400)

    def log_message(self, fmt, *args):
        print("wittypi5-webserver:", fmt % args, flush=True)


def store_automation_backup(generated, destination):
    """Publish a completed backup, including when /run is a separate filesystem."""
    try:
        os.replace(generated, destination)
        return
    except OSError as error:
        if error.errno != errno.EXDEV:
            raise
    # The original stays intact until the destination copy is complete, flushed
    # and byte-verified. Publish from a sibling file to retain atomic rename.
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=destination.parent, prefix='.witty-backup-', suffix='.partial', delete=False) as output:
            temporary = pathlib.Path(output.name)
            with generated.open('rb') as source:
                shutil.copyfileobj(source, output, length=1024*1024)
            output.flush()
            os.fsync(output.fileno())
        def digest(path):
            checksum = hashlib.sha256()
            with path.open('rb') as file:
                for block in iter(lambda: file.read(1024*1024), b''):
                    checksum.update(block)
            return checksum.digest()
        if temporary.stat().st_size != generated.stat().st_size or digest(temporary) != digest(generated):
            raise IOError('Backup copy failed integrity verification; original retained')
        temporary.chmod(0o640)
        os.replace(temporary, destination)
        generated.unlink()
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def automation_config_command(arguments):
    """Reuse the website's validated configuration archive implementation."""
    if len(arguments) == 2 and arguments[0] == "--repair-allsky-permissions":
        project = pathlib.Path(arguments[1])
        if not project.is_absolute() or not (project / "variables.sh").is_file():
            raise ValueError("Invalid Allsky project for permission repair")
        repair_allsky_configuration_permissions(project)
        print("ALLSKY configuration permissions repaired")
        return
    if len(arguments) != 3 or arguments[0] not in {
            "--automation-config-backup", "--automation-config-restore",
            "--automation-config-restore-after-update"}:
        raise ValueError("Invalid automation configuration command")
    action, component, supplied_path = arguments
    if component not in {"wurb", "wirc", "allsky"}:
        raise ValueError("Invalid software component")
    if action == "--automation-config-backup":
        output_directory = pathlib.Path(supplied_path)
        if (not output_directory.is_absolute() or output_directory.is_symlink()
                or not output_directory.is_dir()):
            raise ValueError("Invalid automation backup directory")
        output_directory = output_directory.resolve(strict=True)
        generated, filename = create_component_backup(component, False)
        destination = output_directory / filename
        if destination.exists() or destination.is_symlink():
            raise FileExistsError("The destination backup already exists")
        store_automation_backup(generated, destination)
        destination.chmod(0o640)
        print(destination)
        return
    archive_path = pathlib.Path(supplied_path)
    if (not archive_path.is_absolute() or archive_path.is_symlink()
            or not archive_path.is_file()):
        raise ValueError("Invalid automation restore file")
    if action == "--automation-config-restore-after-update":
        if component != "allsky":
            raise ValueError("Update configuration restore only supports Allsky")
        project = allsky_project_path()
        if project is None:
            raise FileNotFoundError("Allsky is not installed after update")
        restore_allsky_archive(project, archive_path.resolve(strict=True), after_update=True)
    else:
        restore_component_backup(component, archive_path.resolve(strict=True))
    print(archive_path.resolve(strict=True))


class DemandHTTPServer(ThreadingHTTPServer):
    """A systemd-owned listening socket survives this process's idle exit."""
    def __init__(self, address, handler, *, inherited_fd=None, idle_seconds=30):
        self.activity_lock = threading.Lock()
        self.active_requests = 0
        self.last_activity = time.monotonic()
        self.idle_seconds = idle_seconds
        super().__init__(address, handler, bind_and_activate=inherited_fd is None)
        if inherited_fd is not None:
            self.socket.close()
            self.socket = socket.socket(fileno=inherited_fd)
            self.server_address = self.socket.getsockname()
        self.timeout = min(5.0, idle_seconds)

    def process_request(self, request, client_address):
        with self.activity_lock:
            self.active_requests += 1
            self.last_activity = time.monotonic()
        try:
            super().process_request(request, client_address)
        except BaseException:
            with self.activity_lock:
                self.active_requests -= 1
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            with self.activity_lock:
                self.active_requests -= 1
                self.last_activity = time.monotonic()

    def idle(self):
        # Never interrupt a requested install, transfer, download or live view.
        with self.activity_lock:
            quiet = self.active_requests == 0 and time.monotonic() - self.last_activity >= self.idle_seconds
        with SOFTWARE_JOB_LOCK:
            job_running = SOFTWARE_JOB["running"]
        return quiet and not job_running and not SCHEDULE_TRANSFER_LOCK.locked() and not FOCUS_PREVIEW.status()["running"]


def save_idle_software_job():
    # Keep completed terminal output when an idle worker exits. Never pretend
    # a running job can survive a process exit; idle() forbids that exit.
    with SOFTWARE_JOB_LOCK:
        if SOFTWARE_JOB["running"]:
            return
        if not SOFTWARE_JOB["action"] and not SOFTWARE_JOB["output"]:
            return
        data = {key: value for key, value in SOFTWARE_JOB.items()
                if key not in {"process", "master_fd", "output"}}
        data["output_base64"] = base64.b64encode(SOFTWARE_JOB["output"]).decode("ascii")
    SOFTWARE_JOB_IDLE_FILE.parent.mkdir(parents=True, exist_ok=True)
    temporary = SOFTWARE_JOB_IDLE_FILE.with_name(SOFTWARE_JOB_IDLE_FILE.name + f".{os.getpid()}.tmp")
    try:
        descriptor = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(descriptor, "w") as stream:
            json.dump(data, stream)
        os.chmod(temporary, 0o600)
        os.replace(temporary, SOFTWARE_JOB_IDLE_FILE)
    finally:
        temporary.unlink(missing_ok=True)


def restore_idle_software_job():
    try:
        info = SOFTWARE_JOB_IDLE_FILE.stat()
        if info.st_uid != os.geteuid() or info.st_mode & 0o077 or info.st_size > 4000000:
            return
        data = json.loads(SOFTWARE_JOB_IDLE_FILE.read_text())
        output = bytearray(base64.b64decode(data.pop("output_base64"), validate=True))
        if data.get("running") is not False or not isinstance(data.get("output_total"), int):
            return
        if len(output) > data["output_total"] or not isinstance(data.get("output_start"), int):
            return
        with SOFTWARE_JOB_LOCK:
            SOFTWARE_JOB.update({key: value for key, value in data.items()
                                 if key in SOFTWARE_JOB and key not in {"process", "master_fd", "output"}})
            SOFTWARE_JOB["output"] = output
    except (OSError, ValueError, TypeError, KeyError, AttributeError):
        pass


def serve_addon():
    inherited = (os.environ.get("LISTEN_PID") == str(os.getpid())
                 and int(os.environ.get("LISTEN_FDS", "0")) == 1)
    if not inherited:
        # Legacy service behaviour is retained outside the WURB/WIRC update.
        ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
        return
    for name in ("LISTEN_PID", "LISTEN_FDS", "LISTEN_FDNAMES"):
        os.environ.pop(name, None)
    restore_idle_software_job()
    with DemandHTTPServer(("0.0.0.0", PORT), Handler, inherited_fd=3,
                          idle_seconds=float(os.environ.get("WITTY_IDLE_SECONDS", "30"))) as server:
        while not server.idle():
            server.handle_request()
        try:
            save_idle_software_job()
        except OSError as error:
            # A full/unavailable runtime filesystem must not turn idle exit
            # into a failure/restart loop.
            print(f"Completed job output could not be retained: {error}", file=sys.stderr)


if __name__ == "__main__":
    if len(sys.argv) > 1:
        try:
            automation_config_command(sys.argv[1:])
        except Exception as error:
            print(str(error), file=sys.stderr)
            raise SystemExit(1)
    else:
        navigation_status_cached()
        threading.Thread(target=initialise_shutdown_status_cache, daemon=True).start()
        serve_addon()
