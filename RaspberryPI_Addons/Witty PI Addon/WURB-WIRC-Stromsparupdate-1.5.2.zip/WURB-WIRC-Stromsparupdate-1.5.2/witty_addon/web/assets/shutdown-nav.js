(() => {
    "use strict";
    const source = document.currentScript && document.currentScript.src ? document.currentScript.src : `${location.protocol}//${location.hostname}:8081/assets/shutdown-nav.js`;
    const apiBase = new URL(source, location.href).origin;
    let statusDot = null, widget = null, labelNode = null, minutesNode = null, dateNode = null, disableButton = null, snapshot = null, refreshBusy = false, refreshFailed = false, retryTimer = null, navigationState = {};

    const style = document.createElement("style");
    const agent = navigator.userAgent || "";
    const smartphone = /iPhone|iPod/i.test(agent) || (/Android/i.test(agent) && /Mobile/i.test(agent));
    const hideMobileOrphans = smartphone && document.documentElement.dataset.wittyPage === "wurb";
    document.documentElement.classList.toggle("witty-smartphone", smartphone);
    style.textContent = ".witty-nav-status-dot{display:none}.witty-home-status-dot{display:none;width:.72rem;height:.72rem;flex:none;align-self:center;border-radius:50%;margin:0 .15rem;background:#d64545;box-shadow:0 0 .3rem rgba(214,69,69,.8)}html.witty-smartphone .witty-home-status-dot:not([hidden]){display:inline-block}.witty-home-status-dot[hidden]{display:none!important}.witty-home-status-dot.is-connected{background:#35c46a;box-shadow:0 0 .35rem rgba(53,196,106,.85)}.witty-shutdown-widget{display:inline-flex;align-items:center;flex-wrap:wrap;gap:.42rem;margin-left:1cm;color:#ff4f5e!important;font-weight:800;font-variant-numeric:tabular-nums}.witty-shutdown-widget[hidden]{display:none!important}.witty-shutdown-widget.is-deactivated{color:#35c46a!important}.witty-shutdown-widget button{background:#f1f1f1!important;border:1px solid #ff4f5e!important;border-radius:4px;color:#b00020!important;font-weight:800;padding:.38rem .58rem;cursor:pointer}.witty-shutdown-widget button:disabled{opacity:.5;cursor:wait}html.witty-smartphone .system-navigation .buttons,html.witty-smartphone #wittypi5-navigation{flex-wrap:nowrap!important;overflow-x:auto;align-items:center}html.witty-smartphone .witty-mobile-primary,html.witty-smartphone .witty-mobile-primary-dot{order:0!important}html.witty-smartphone .witty-shutdown-widget{order:1!important;margin-left:.3rem;flex-wrap:nowrap;white-space:nowrap;gap:.25rem;font-size:.78rem}html.witty-smartphone .witty-shutdown-date,html.witty-smartphone .witty-shutdown-spacer{display:none}html.witty-smartphone .witty-shutdown-widget button{padding:.26rem .38rem;font-size:.72rem;white-space:nowrap}html.witty-smartphone .witty-mobile-secondary,html.witty-smartphone .witty-mobile-secondary-dot{order:2!important}html.witty-smartphone .witty-mobile-aux{order:3!important}html.witty-smartphone .witty-model-link,html.witty-smartphone .witty-home{order:4!important;margin-left:.5rem!important}";
    document.head.appendChild(style);

    // A cached root page may contain an older inline navigation patch.
    // Apply layout independently whenever this shared asset is loaded/restored.
    const allskyBar = document.getElementById("wittypi5-navigation");
    if (allskyBar && !allskyBar.dataset.wittyLayoutMounted) {
        allskyBar.dataset.wittyLayoutMounted = "1";
        const layoutStyle = document.createElement("style");
        layoutStyle.textContent = "#wittypi5-navigation{position:fixed!important;top:0!important;left:0;right:0;z-index:1100!important;display:flex;flex-wrap:wrap;background:#000;padding:8px;gap:8px}body>.header,body>.navbar-fixed-top{top:var(--witty-nav-height,60px)!important}body>.sidebar{top:calc(var(--witty-nav-height,60px) + var(--as-sidebar-top,68px))!important}body>.content{top:calc(var(--witty-nav-height,60px) + var(--as-content-top,75px))!important}#witty-gs-exposure-warning{position:fixed;top:var(--witty-nav-only-height,60px);left:0;right:0;z-index:1100;background:#000}";
        document.head.appendChild(layoutStyle);
        const warning = document.getElementById("witty-gs-exposure-warning");
        const fitAllsky = () => {
            const height = Math.ceil(allskyBar.getBoundingClientRect().height);
            document.documentElement.style.setProperty("--witty-nav-only-height", height + "px");
            const extra = warning && !warning.hidden ? Math.ceil(warning.getBoundingClientRect().height) : 0;
            document.documentElement.style.setProperty("--witty-nav-height", (height + extra) + "px");
        };
        fitAllsky();
        if (typeof ResizeObserver !== "undefined") {
            const resize = new ResizeObserver(fitAllsky); resize.observe(allskyBar);
            if (warning) resize.observe(warning);
        }
        if (warning && typeof MutationObserver !== "undefined")
            new MutationObserver(fitAllsky).observe(warning, {attributes:true,attributeFilter:["hidden","style"]});
        window.addEventListener("resize", fitAllsky);
        window.addEventListener("pageshow", fitAllsky);
        document.addEventListener("visibilitychange", () => { if (!document.hidden) fitAllsky(); });
    }

    const navigationCss = document.createElement("link");
    navigationCss.rel = "stylesheet";
    navigationCss.href = `${apiBase}/assets/witty-navigation.css`;
    document.head.appendChild(navigationCss);

    function wallClockValue(value) {
        if (window.WittyTime) return window.WittyTime.parse(value)?.milliseconds ?? null;
        // This script is also loaded by other service pages without index.html.
        const match = String(value || "").match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?$/);
        if (!match) return null;
        const ms = Date.UTC(+match[1], +match[2]-1, +match[3], +match[4], +match[5], +match[6]);
        const date = new Date(ms);
        return date.getUTCFullYear() === +match[1] && date.getUTCMonth() === +match[2]-1 && date.getUTCDate() === +match[3] && +match[4] < 24 && +match[5] < 60 && +match[6] < 60 ? ms : null;
    }
    function mount() {
        const witty = document.querySelector(".witty-model-link,.nav-witty,.witty-home");
        if (!witty || witty.id === "wittyNavModel") return false;
        if (!statusDot) { statusDot = document.createElement("span"); statusDot.className = "witty-nav-status-dot"; statusDot.setAttribute("aria-hidden", "true"); }
        if (!widget) {
            widget = document.createElement("span"); widget.className = "witty-shutdown-widget"; widget.hidden = true;
            labelNode = document.createElement("span"); labelNode.textContent = "Next Shutdown: deactivated";
            minutesNode = document.createElement("span"); minutesNode.textContent = "-- min";
            const spacer = document.createElement("span"); spacer.className = "witty-shutdown-spacer"; spacer.textContent = "\u00a0\u00a0\u00a0\u00a0";
            dateNode = document.createElement("span"); dateNode.className = "witty-shutdown-date"; dateNode.textContent = "--.--.----";
            disableButton = document.createElement("button"); disableButton.type = "button";
            disableButton.textContent = "Deactivate auto switch off"; disableButton.disabled = true;
            disableButton.addEventListener("click", disableSchedule);
            widget.append(labelNode, minutesNode, spacer, dateNode, disableButton);
        }
        if (statusDot.previousElementSibling !== witty) witty.insertAdjacentElement("afterend", statusDot);
        if (widget.previousElementSibling !== statusDot) statusDot.insertAdjacentElement("afterend", widget);
        const hasWittyHardware = navigationState.witty_model === "4" || navigationState.witty_model === "5";
        statusDot.hidden = !hasWittyHardware;
        widget.hidden = !hasWittyHardware;
        if (!hasWittyHardware) snapshot = null;
        const serviceLinks = [];
        document.querySelectorAll("a").forEach(link => {
            const text = String(link.textContent || "").trim().toLowerCase();
            let service = text.includes("wurb-2026") ? "wurb"
                : text.includes("wirc-2026") ? "wirc"
                : text === "allsky" ? "allsky" : "";
            const auxiliary = /recordings|setup/.test(text);
            link.classList.toggle("witty-mobile-aux", auxiliary);
            if (!service || link.classList.contains("witty-model-link") || auxiliary) return;
            link.dataset.wittyMobileService = service;
            serviceLinks.push(link);
            let dot = link.previousElementSibling;
            if (!dot || !dot.classList.contains("witty-home-status-dot")) {
                dot = document.createElement("span"); dot.className = "witty-home-status-dot"; dot.setAttribute("aria-hidden", "true");
                link.insertAdjacentElement("beforebegin", dot);
            }
            // A hidden/uninstalled service must not leave an orphan red light
            // beside the next visible link after mobile flex reordering.
            dot.hidden = hideMobileOrphans && (link.hidden || navigationState[service] !== true);
            dot.classList.toggle("is-connected", navigationState[service] === true);
        });
        const primary = serviceLinks.find(link => link.dataset.wittyMobileService === "wurb")
            || serviceLinks.find(link => link.dataset.wittyMobileService === "allsky");
        serviceLinks.forEach(link => {
            const isPrimary = link === primary;
            link.classList.toggle("witty-mobile-primary", isPrimary);
            link.classList.toggle("witty-mobile-secondary", !isPrimary);
            const dot = link.previousElementSibling;
            if (dot && dot.classList.contains("witty-home-status-dot")) {
                dot.classList.toggle("witty-mobile-primary-dot", isPrimary);
                dot.classList.toggle("witty-mobile-secondary-dot", !isPrimary);
            }
        });
        updateCountdown(); return true;
    }
    function updateCountdown() {
        if (!widget) return;
        if (refreshFailed) { labelNode.textContent="Next Shutdown: status unavailable"; widget.classList.remove("is-deactivated"); minutesNode.hidden=true; dateNode.hidden=true; disableButton.disabled=true; return; }
        if (!snapshot) { labelNode.textContent=smartphone ? "Next Shutd.: deactivated" : "Next Shutdown: deactivated"; widget.classList.add("is-deactivated"); minutesNode.hidden=true; dateNode.hidden=true; disableButton.disabled = true; disableButton.textContent=smartphone ? "Shutdown deactivate" : "Deactivate auto switch off"; return; }
        labelNode.textContent=smartphone ? "Next Shutd.:" : "Next Shutdown:"; widget.classList.remove("is-deactivated"); minutesNode.hidden=false; dateNode.hidden=smartphone;
        const remaining = snapshot.shutdownMs - (snapshot.wittyMs + (Date.now() - snapshot.received));
        minutesNode.textContent = `${Math.max(0, Math.ceil(remaining / 60000))} min`;
        dateNode.textContent = snapshot.date; disableButton.textContent=smartphone ? "Shutdown deactivate" : "Deactivate auto switch off"; disableButton.disabled = refreshBusy || remaining <= 0;
    }
    async function refresh(force = false) {
        if (document.hidden || navigator.onLine === false) return;
        if (refreshBusy) return; refreshBusy = true; updateCountdown();
        try {
            const controller = new AbortController();
            const timeout = window.setTimeout(() => controller.abort(), 5000);
            const response = await fetch(`${apiBase}/api/shutdown-status`, { cache:"no-store", signal:controller.signal });
            window.clearTimeout(timeout);
            const data = await response.json(); if (!response.ok || !data.ok) throw new Error(data.error || response.statusText);
            statusDot && statusDot.classList.add("is-connected");
            refreshFailed = false;
            if (data.navigation && typeof data.navigation === "object" && data.navigation.ready !== false) navigationState = data.navigation;
            if (navigationState.device_hostname) {
                const host = String(navigationState.device_hostname).split(".")[0];
                document.title = `${host.charAt(0).toUpperCase() + host.slice(1)} - ${navigationState.device_purpose || "Raspberry Pi"}`;
            }
            if (data.navigation && data.navigation.ready === false) scheduleRetry(1000);
            const wittyMs = wallClockValue(data.witty_time), shutdownMs = wallClockValue(data.next_shutdown);
            const dateMatch = String(data.next_shutdown || "").match(/(\d{4})-(\d{2})-(\d{2})/);
            const cacheAge = Math.max(0, Number(data.cache_age_seconds) || 0) * 1000;
            snapshot = wittyMs !== null && shutdownMs !== null && dateMatch ? { wittyMs, shutdownMs, received:Date.now()-cacheAge, date:`${dateMatch[3]}.${dateMatch[2]}.${dateMatch[1]}` } : null;
        } catch (error) { refreshFailed = true; statusDot && statusDot.classList.remove("is-connected"); scheduleRetry(5000); }
        finally { refreshBusy = false; mount(); updateCountdown(); }
    }
    async function disableSchedule() {
        if (refreshBusy || !snapshot || widget.hidden) return; refreshBusy = true; updateCountdown();
        try {
            const response = await fetch(`${apiBase}/api`, { method:"POST", headers:{"Content-Type":"application/json"}, cache:"no-store", body:JSON.stringify({action:"clear_schedule"}) });
            const result = await response.json(); if (!response.ok || !result.ok) throw new Error(result.error || response.statusText);
            snapshot = null;
        } finally { refreshBusy = false; updateCountdown(); window.setTimeout(() => refresh(true), 750); }
    }
    function scheduleRetry(delay) {
        if (retryTimer !== null) return;
        retryTimer = window.setTimeout(() => { retryTimer = null; refresh(); }, delay);
    }
    // Allsky Setup rebuilds its own links on status/language refresh. Watch
    // only this navigation's immediate children, never the whole page.
    const navigationRoot = document.getElementById("mainNavigation")
        || document.getElementById("wittypi5-navigation")
        || document.querySelector(".system-navigation .buttons");
    if (navigationRoot && typeof MutationObserver !== "undefined")
        new MutationObserver(() => mount()).observe(navigationRoot, {childList:true});
    window.addEventListener("pageshow", () => { mount(); if (refreshFailed) refresh(); });
    document.addEventListener("visibilitychange", () => { if (!document.hidden) refresh(); });
    window.addEventListener("online", () => refresh());
    mount(); refresh(); window.setInterval(updateCountdown,1000);
})();
