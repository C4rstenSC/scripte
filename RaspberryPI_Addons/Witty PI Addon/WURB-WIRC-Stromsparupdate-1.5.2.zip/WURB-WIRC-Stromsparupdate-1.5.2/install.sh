#!/usr/bin/env bash
# Targeted update only. No AllSky, OS, mount, firmware or manufacturer changes.
set -Eeuo pipefail
fail(){ printf 'FEHLER: %s\n' "$*" >&2; exit 1; }
source_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
# This guard precedes every mutation, including the backup and service stops.
[[ ! -e /var/lib/witty-addon/allsky-witty-clock ]] || fail 'AllSky-Profil erkannt. Dieses Update ändert hier nichts.'
case "${INSTALL_ALLSKY:-false}" in true|1|yes) fail 'AllSky ausgewählt. Dieses Update ändert hier nichts.';; esac
for project in /home/*/allsky /opt/allsky; do
    [[ ! -d "$project" ]] || fail 'AllSky-Installation erkannt. Dieses Update ändert hier nichts.'
done
if command -v systemctl >/dev/null 2>&1; then
    allsky_state="$(systemctl show allsky.service --property=LoadState --value 2>/dev/null || true)"
    [[ -z "$allsky_state" || "$allsky_state" == not-found ]] || fail 'AllSky-Dienst erkannt. Dieses Update ändert hier nichts.'
fi
[[ "${EUID:-$(id -u)}" -eq 0 ]] || fail 'Dieses Installationsupdate benötigt sudo.'
app_dir=''
for candidate in /home/wurb/wittypi5-webserver /home/*/wittypi5-webserver /home/wittypi5-webserver /opt/wittypi5-webserver; do
    if [[ -f "$candidate/VERSION" && -f "$candidate/web/server.py" ]]; then app_dir="$candidate"; break; fi
done
command -v systemd-run >/dev/null 2>&1 || fail 'systemd-run fehlt; keine Änderungen vorgenommen.'
[[ -n "$app_dir" ]] || fail 'Vorhandenes Witty-Add-on nicht gefunden; dieses Paket ist nur ein Update.'
projects=()
for candidate in /home/*/wurb_2026 /home/*/wirc_2026 /opt/wurb_2026 /opt/wirc_2026; do
    [[ ! -d "$candidate" ]] || projects+=("$candidate")
done
[[ ${#projects[@]} -gt 0 ]] || fail 'Keine WURB-/WIRC-Installation gefunden; nichts geändert.'
web_python=/usr/bin/python3
[[ ! -x /var/lib/witty-addon/web-venv/bin/python3 ]] || web_python=/var/lib/witty-addon/web-venv/bin/python3
"$web_python" "$source_dir/witty_addon/installer/preflight_power_update.py" "$app_dir" "$source_dir/witty_addon" "$web_python"
# Preserve a local rollback copy of only the files affected by this update.
backup="/var/backups/witty-wurb-power/$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$backup"
backup_file(){ [[ ! -f "$1" ]] || cp --parents -a -- "$1" "$backup/"; }
for relative in backend/witty-gps-raw-fanout backend/witty-gps-nmea-bridge web/server.py web/index.html web/assets/shutdown-nav.js installer/witty_live_time.py installer/witty_gps_power.py backend/witty-bluetooth-off; do
    backup_file "$app_dir/$relative"
    mode=0644; [[ "$relative" != backend/* ]] || mode=0755
    install -D -m "$mode" "$source_dir/witty_addon/$relative" "$app_dir/$relative"
done
for helper in witty-gps-raw-fanout witty-gps-nmea-bridge; do
    backup_file "/usr/local/sbin/$helper"
    install -D -m 0755 "$source_dir/witty_addon/backend/$helper" "/usr/local/sbin/$helper"
done
backup_file /etc/systemd/system/witty-gps-watch.service
backup_file "$app_dir/backend/witty-gps-watch"
systemctl disable --now witty-gps-watch.service >/dev/null 2>&1 || true
rm -f -- /etc/systemd/system/witty-gps-watch.service "$app_dir/backend/witty-gps-watch"
# Remove a leftover five-minute RTC poll only when its service is one of
# this add-on's legacy helpers. Never touch a user-defined timer/service.
legacy_service=/etc/systemd/system/wurb-rtc-sync.service
if [[ -f "$legacy_service" ]] && grep -Eq '^ExecStart=/usr/local/sbin/wurb-gps-to-(witty|rtc)([[:space:]]|$)' "$legacy_service"; then
    backup_file "$legacy_service"
    backup_file /etc/systemd/system/wurb-rtc-sync.timer
    systemctl disable --now wurb-rtc-sync.timer >/dev/null 2>&1 || true
    rm -f -- /etc/systemd/system/wurb-rtc-sync.timer
    rm -f -- /etc/systemd/system/timers.target.wants/wurb-rtc-sync.timer
    # An in-flight one-shot may finish normally; do not interrupt an RTC write.
fi
for project in "${projects[@]}"; do
    reader="$project/wurb_core/record/gps_reader.py"
    if [[ -f "$reader" ]] && grep -q 'def mark_gps_unavailable' "$reader" && grep -q 'def witty_fresh_position' "$reader"; then
        backup_file "$reader"
        backup_file "$project/witty_gps_power.py"
        install -m 0644 "$source_dir/witty_addon/installer/witty_gps_power.py" "$project/witty_gps_power.py"
        python3 - "$reader" <<'GPSPOWER'
import ast,os,pathlib,sys,tempfile
path=pathlib.Path(sys.argv[1]);source=path.read_text()
marker='# Witty event-driven GPS supervision (no periodic healthy-link polling).'
addition='\n'+marker+'\nfrom witty_gps_power import install as _witty_install_gps_power\n_witty_install_gps_power(GpsReader, ReadGpsSerialNmea)\n'
if marker not in source:
    changed=source.rstrip()+addition
    ast.parse(changed)
    info=path.stat();fd,temp=tempfile.mkstemp(dir=path.parent,prefix=path.name+'.')
    try:
        with os.fdopen(fd,'w') as stream:stream.write(changed)
        os.chown(temp,info.st_uid,info.st_gid);os.chmod(temp,info.st_mode)
        os.replace(temp,path)
    finally:
        if os.path.exists(temp):os.unlink(temp)
GPSPOWER
    fi
    if [[ -f "$project/witty_live_time.py" ]]; then
        backup_file "$project/witty_live_time.py"
        # Preserve project ownership; replace content of the existing helper.
        cat "$source_dir/witty_addon/installer/witty_live_time.py" > "$project/witty_live_time.py"
    fi
done
for name in VERSION BUILD_REVISION PACKAGE_REVISION RELEASE_DATE; do backup_file "$app_dir/$name"; done
printf '1.5.2\n' > "$app_dir/VERSION"
printf '20261114.152.3\n' > "$app_dir/BUILD_REVISION"
printf '20261114.152.3\n' > "$app_dir/PACKAGE_REVISION"
printf '2026-11-14\n' > "$app_dir/RELEASE_DATE"
backup_file /etc/systemd/system/wittypi5-webserver.socket
backup_file /etc/systemd/system/wittypi5-webserver-worker.service
backup_file /etc/systemd/system/wittypi5-webserver.service.d/on-demand.conf
install -d -m 0755 /etc/systemd/system/wittypi5-webserver.service.d
cat > /etc/systemd/system/wittypi5-webserver.socket <<'UNIT'
[Unit]
Description=WURB/WIRC Add-on HTTP listener
PartOf=wittypi5-webserver.service
[Socket]
ListenStream=0.0.0.0:8081
Service=wittypi5-webserver-worker.service
UNIT
cat > /etc/systemd/system/wittypi5-webserver-worker.service <<UNIT
[Unit]
Description=WURB/WIRC Add-on Python worker on demand
Requires=wittypi5-webserver.socket
After=wittypi5-webserver.socket
PartOf=wittypi5-webserver.service
ConditionPathExists=$app_dir/web/server.py
[Service]
Type=simple
User=root
WorkingDirectory=$app_dir
Environment=NUMBA_DISABLE_JIT=1
Environment=WITTY_IDLE_SECONDS=30
ExecStart=$web_python $app_dir/web/server.py
Restart=on-failure
RestartSec=3
UNIT
cat > /etc/systemd/system/wittypi5-webserver.service.d/on-demand.conf <<'UNIT'
[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=
ExecStart=/usr/bin/systemctl start wittypi5-webserver.socket
ExecStop=
ExecStop=/usr/bin/systemctl stop wittypi5-webserver.socket wittypi5-webserver-worker.service
Restart=no
UNIT
systemctl daemon-reload
# The existing service remains the Windows start/stop/status entry point.
# Active (exited) consumes no process; only the worker runs Python when needed.
systemctl disable wittypi5-webserver.socket >/dev/null 2>&1 || true
systemctl enable wittypi5-webserver.service
# Keep wp5d, shutdown hooks, RTC boot sync, recording settings and DST job intact.
for unit in wurb-gps-bridge.service wurb_2026.service wirc_2026.service; do
    if systemctl is-active --quiet "$unit"; then
        timeout 30s systemctl restart "$unit" || fail "Neustart von $unit fehlgeschlagen; Sicherung: $backup"
    fi
done
if command -v rfkill >/dev/null 2>&1; then
    bash "$app_dir/backend/witty-bluetooth-off"
else
    printf 'Bluetooth unverändert: rfkill ist nicht installiert; keine Systempakete nachinstalliert.\n'
fi
# Queue activation last: service restarts above must finish before this timer.
systemd-run --quiet --collect --unit="witty-wurb-power-activate-$$" --on-active=10s \
    /bin/sh -c 'systemctl stop wittypi5-webserver.service wittypi5-webserver-worker.service wittypi5-webserver.socket && systemctl start wittypi5-webserver.service'
printf 'WURB/WIRC-Stromsparupdate 1.5.2 installiert. Sicherung: %s\n' "$backup"
