#!/usr/bin/env bash
# Targeted update only. No AllSky, OS, mount, firmware or manufacturer changes.
set -Eeuo pipefail
fail(){ printf 'FEHLER: %s\n' "$*" >&2; exit 1; }
source_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
# This guard precedes every mutation, including the backup and service stops.
[[ ! -e /var/lib/witty-addon/allsky-witty-clock ]] || fail 'AllSky-Profil erkannt. Dieses Update ändert hier nichts.'
case "${INSTALL_ALLSKY:-false}" in true|1|yes) fail 'AllSky ausgewählt. Dieses Update ändert hier nichts.';; esac
for project in /home/*/allsky /opt/allsky; do
    [[ ! -d "$project" ]] || fail 'AllSky-Installation erkannt. Dieses Update ändert hier nichts.'
done
if command -v systemctl >/dev/null 2>&1; then
    allsky_state="$(systemctl show allsky.service --property=LoadState --value 2>/dev/null || true)"
    [[ -z "$allsky_state" || "$allsky_state" == not-found ]] || fail 'AllSky-Dienst erkannt. Dieses Update ändert hier nichts.'
fi
[[ "${EUID:-$(id -u)}" -eq 0 ]] || fail 'Dieses Installationsupdate benötigt sudo.'
app_dir=''
for candidate in /home/wurb/wittypi5-webserver /home/*/wittypi5-webserver /home/wittypi5-webserver /opt/wittypi5-webserver; do
    if [[ -f "$candidate/VERSION" && -f "$candidate/web/server.py" ]]; then app_dir="$candidate"; break; fi
done
command -v systemd-run >/dev/null 2>&1 || fail 'systemd-run fehlt; keine Änderungen vorgenommen.'
[[ -n "$app_dir" ]] || fail 'Vorhandenes Witty-Add-on nicht gefunden; dieses Paket ist nur ein Update.'
projects=()
for candidate in /home/*/wurb_2026 /home/*/wirc_2026 /opt/wurb_2026 /opt/wirc_2026; do
    [[ ! -d "$candidate" ]] || projects+=("$candidate")
done
[[ ${#projects[@]} -gt 0 ]] || fail 'Keine WURB-/WIRC-Installation gefunden; nichts geändert.'
# Preserve a local rollback copy of only the files affected by this update.
backup="/var/backups/witty-wurb-power/$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$backup"
backup_file(){ [[ ! -f "$1" ]] || cp --parents -a -- "$1" "$backup/"; }
for relative in backend/witty-gps-raw-fanout backend/witty-gps-nmea-bridge web/server.py web/index.html web/assets/shutdown-nav.js installer/witty_live_time.py; do
    backup_file "$app_dir/$relative"
    mode=0644; [[ "$relative" != backend/* ]] || mode=0755
    install -D -m "$mode" "$source_dir/witty_addon/$relative" "$app_dir/$relative"
done
for helper in witty-gps-raw-fanout witty-gps-nmea-bridge; do
    backup_file "/usr/local/sbin/$helper"
    install -D -m 0755 "$source_dir/witty_addon/backend/$helper" "/usr/local/sbin/$helper"
done
backup_file /etc/systemd/system/witty-gps-watch.service
backup_file "$app_dir/backend/witty-gps-watch"
systemctl disable --now witty-gps-watch.service >/dev/null 2>&1 || true
rm -f -- /etc/systemd/system/witty-gps-watch.service "$app_dir/backend/witty-gps-watch"
for project in "${projects[@]}"; do
    if [[ -f "$project/witty_live_time.py" ]]; then
        backup_file "$project/witty_live_time.py"
        # Preserve project ownership; replace content of the existing helper.
        cat "$source_dir/witty_addon/installer/witty_live_time.py" > "$project/witty_live_time.py"
    fi
done
for name in VERSION BUILD_REVISION PACKAGE_REVISION RELEASE_DATE; do backup_file "$app_dir/$name"; done
printf '1.5.1\n' > "$app_dir/VERSION"
printf '20261114.151.2\n' > "$app_dir/BUILD_REVISION"
printf '20261114.151.2\n' > "$app_dir/PACKAGE_REVISION"
printf '2026-11-14\n' > "$app_dir/RELEASE_DATE"
backup_file /etc/systemd/system/wittypi5-webserver.socket
backup_file /etc/systemd/system/wittypi5-webserver.service.d/on-demand.conf
install -d -m 0755 /etc/systemd/system/wittypi5-webserver.service.d
cat > /etc/systemd/system/wittypi5-webserver.socket <<'UNIT'
[Unit]
Description=WURB/WIRC Add-on: start only on HTTP access
[Socket]
ListenStream=0.0.0.0:8081
Service=wittypi5-webserver.service
[Install]
WantedBy=sockets.target
UNIT
cat > /etc/systemd/system/wittypi5-webserver.service.d/on-demand.conf <<'UNIT'
[Unit]
Requires=wittypi5-webserver.socket
After=wittypi5-webserver.socket
[Service]
Environment=WITTY_IDLE_SECONDS=30
Restart=on-failure
UNIT
systemctl daemon-reload
systemctl disable wittypi5-webserver.service >/dev/null 2>&1 || true
systemctl enable wittypi5-webserver.socket
# The updater can be a child of this web service. Activate outside its cgroup
# after returning the update result, so stopping the service cannot kill us.
systemd-run --quiet --collect --unit="witty-wurb-power-activate-$$" --on-active=10s \
    /bin/sh -c 'systemctl stop wittypi5-webserver.service && systemctl start wittypi5-webserver.socket'
# Keep wp5d, shutdown hooks, RTC boot sync, recording settings and DST job intact.
for unit in wurb-gps-bridge.service wurb_2026.service wirc_2026.service; do
    if systemctl is-active --quiet "$unit"; then
        timeout 30s systemctl restart "$unit" || fail "Neustart von $unit fehlgeschlagen; Sicherung: $backup"
    fi
done
printf 'WURB/WIRC-Stromsparupdate 1.5.1 installiert. Sicherung: %s\n' "$backup"
