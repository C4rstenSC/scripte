# Raspi-Scripte 0.6 – update process

- The application checks `update-manifest.json` in GitHub folder `RaspberryPI_Addons/Raspi-Scripte`.
- Text, theme, terminal files, help and the embedded Witty package are delivered in `Raspi-Scripte-Content.zip`.
- The content package is extracted to a temporary directory, validated and then activated atomically.
- EXE changes are applied through `Raspi-Scripte.zip` and the separate updater.
- Both update paths retain configuration under `%APPDATA%\RaspberryPI_Scripte`; setup does not need to be reinstalled.
