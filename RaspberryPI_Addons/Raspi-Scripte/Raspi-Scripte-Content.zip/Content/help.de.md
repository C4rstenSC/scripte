# Raspi-Scripte 0.6 – Updateverfahren

- Das Programm prüft `update-manifest.json` im GitHub-Ordner `RaspberryPI_Addons/Raspi-Scripte`.
- Reine Inhalte wie Texte, Design, Terminaldateien, Hilfe und das eingebettete Witty-Paket kommen aus `Raspi-Scripte-Content.zip`.
- Das Inhaltspaket wird zuerst in einen temporären Ordner entpackt, geprüft und anschließend atomar aktiviert.
- Änderungen an der EXE werden über `Raspi-Scripte.zip` und den separaten Updater eingespielt.
- In beiden Fällen bleiben Konfigurationen unter `%APPDATA%\RaspberryPI_Scripte` erhalten; eine erneute Setup-Installation ist nicht erforderlich.
