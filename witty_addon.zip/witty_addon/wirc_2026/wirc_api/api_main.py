#!/usr/bin/python3
# -*- coding:utf-8 -*-
# Project: https://github.com/cloudedbats/wirc_2026
# Author: Arnold Andreasson, info@cloudedbats.org
# License: MIT License (see LICENSE or http://opensource.org/licenses/mit).

import logging
import pathlib
import fastapi
import fastapi.staticfiles
import fastapi.templating
import fastapi.responses

import wirc_core
import wirc_api

logger = logging.getLogger(wirc_core.logger_name)


def installed_services():
    """Return installed companion services without checking whether they run."""
    home_path = pathlib.Path("/home")
    home_directories = list(home_path.iterdir()) if home_path.is_dir() else []

    def exists_below_home(*names):
        wanted = {name.lower() for name in names}
        for parent in [home_path, *home_directories]:
            if parent.is_dir():
                for child in parent.iterdir():
                    if child.is_dir() and child.name.lower() in wanted:
                        return True
        return False

    return {
        "wurb": exists_below_home("wurb_2026"),
        "wirc": exists_below_home("wirc_2026"),
        "allsky": exists_below_home("allsky"),
        "witty": exists_below_home(
            "wittypi", "wittypi5", "witty-pi-5-software", "wp5"
        ),
    }

app = fastapi.FastAPI(
    title="CloudedBats WIRC-2026",
    description="CloudedBats WIRC-2026. The DIY infrared/thermal camera system for bat monitoring.",
    version=wirc_core.__version__,
)

# Relative paths.
static_path = pathlib.Path(wirc_core.workdir_path, "wirc_app/static")
templates_path = pathlib.Path(wirc_core.workdir_path, "wirc_app/templates")

app.mount(
    "/static",
    fastapi.staticfiles.StaticFiles(directory=static_path),
    name="static",
)
templates = fastapi.templating.Jinja2Templates(directory=templates_path)


# @app.on_event("startup")
# async def startup_event():
#     """ """
#     logger.debug("API called: startup.")


# @app.on_event("shutdown")
# async def shutdown_event():
#     """ """
#     logger.debug("API called: shutdown.")


# Include modules.
app.include_router(wirc_api.camera_router)
app.include_router(wirc_api.preview_router)
app.include_router(wirc_api.directories_router)
app.include_router(wirc_api.files_router)
app.include_router(wirc_api.system_router)

# Include modules.
app.include_router(wirc_api.html_camera_router)
app.include_router(wirc_api.html_about_router)


@app.get("/", tags=["HTML pages"], description="Main application page (HTML).")
async def load_main_application_page(request: fastapi.Request):
    """ """
    try:
        logger.debug("API called: webpage.")
        services = installed_services()
        return templates.TemplateResponse(
            request=request,
            name="index.html",
            context={
                "wurb_version": wirc_core.__version__,
                "wurb_installed": services["wurb"],
                "allsky_installed": services["allsky"],
                "witty_installed": services["witty"],
            },
            # "index.html",
            # {
            #     "request": request,
            #     "wirc_version": wirc_core.__version__,
            # },
        )
    except Exception as e:
        message = "API - load_main_application_page. Exception: " + str(e)
        logger.debug(message)


@app.get("/navigation/services", include_in_schema=False)
async def get_installed_navigation_services():
    return installed_services()


@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    try:
        favicon_path = pathlib.Path(
            wirc_core.workdir_path, "wirc_app/static/images/favicon.ico"
        )
        return fastapi.responses.FileResponse(favicon_path)
    except Exception as e:
        message = "API - favicon. Exception: " + str(e)
        logger.debug(message)
