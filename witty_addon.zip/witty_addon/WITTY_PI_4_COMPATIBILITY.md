# Witty Pi 4 compatibility

The installer writes `/etc/witty-addon.conf` only after the selected board has
answered on I2C. Witty Pi 4 is accepted at address `0x08` with firmware ID
`0x26` (standard) or `0x37` (L3V7). Witty Pi 5 is accepted at address `0x51`.

Witty Pi 4 uses UUGear's `~/wittypi` software. Its schedules and logs are local
files, unlike the Witty Pi 5 `wp5` firmware storage. The web add-on therefore
dispatches to separate backends. On Witty Pi 4 the page supports RTC reads and
writes, GPS-to-RTC sync, schedule upload/list/read/activate/delete, shutdown and
the local `wittyPi.log` plus `schedule.log`. Firmware-only Witty Pi 5 operations
are not sent to a Witty Pi 4.

The Raspberry Pi 4 has no built-in RTC. The “internal Raspberry Pi RTC” control
is consequently reported unavailable; Witty Pi 4 remains the hardware RTC.
