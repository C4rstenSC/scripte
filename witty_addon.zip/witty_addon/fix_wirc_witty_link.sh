#!/usr/bin/env bash
set -Eeuo pipefail

readonly ADDON_URL="https://raw.githubusercontent.com/C4rstenSC/scripte/main/witty_addon.zip"
log() { printf '[wirc-witty-fix] %s\n' "$*"; }
die() { printf '[wirc-witty-fix] FEHLER: %s\n' "$*" >&2; exit 1; }

if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    die "Bitte mit sudo starten: sudo bash $0"
fi
for command_name in curl unzip find install systemctl stat; do
    command -v "$command_name" >/dev/null 2>&1 || die "Das Programm '$command_name' fehlt."
done

work_dir="$(mktemp -d /var/tmp/wirc-witty-fix.XXXXXX)"
cleanup() { rm -rf -- "$work_dir"; }
trap cleanup EXIT
archive="$work_dir/witty_addon.zip"

curl --fail --location --show-error --silent --retry 3 --output "$archive" "$ADDON_URL"
unzip -tq "$archive" >/dev/null || die "Das heruntergeladene ZIP ist ungueltig."
unzip -q "$archive" -d "$work_dir/files"
source_dir="$work_dir/files/witty_addon/wirc_2026"
[[ -f "$source_dir/wirc_app/templates/index.html" ]] || die "WIRC-Vorlage fehlt im ZIP."
[[ -f "$source_dir/wirc_app/static/witty.html" ]] || die "WIRC-Weiterleitung fehlt im ZIP."

wirc_home=""
for candidate in /home/wurb/wirc_2026 /home/pi/wirc_2026 /opt/wirc_2026; do
    [[ -d "$candidate/wirc_app" ]] && { wirc_home="$candidate"; break; }
done
if [[ -z "$wirc_home" ]]; then
    wirc_home="$(find /home -mindepth 2 -maxdepth 3 -type d -name wirc_2026 -print -quit 2>/dev/null || true)"
fi
[[ -n "$wirc_home" ]] || die "WIRC-2026-Installation wurde nicht gefunden."

backup_dir="/var/backups/witty-addon/wirc-link-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$backup_dir"
cp -a "$wirc_home/wirc_app/templates/index.html" "$backup_dir/index.html" 2>/dev/null || true
cp -a "$wirc_home/wirc_app/static/witty.html" "$backup_dir/witty.html" 2>/dev/null || true
owner_uid="$(stat -c '%u' "$wirc_home/wirc_app")"
owner_gid="$(stat -c '%g' "$wirc_home/wirc_app")"

install -m 0644 -o "$owner_uid" -g "$owner_gid" \
    "$source_dir/wirc_app/templates/index.html" "$wirc_home/wirc_app/templates/index.html"
install -m 0644 -o "$owner_uid" -g "$owner_gid" \
    "$source_dir/wirc_app/static/witty.html" "$wirc_home/wirc_app/static/witty.html"
find "$wirc_home" -type d -name __pycache__ -prune -exec rm -r -- {} + 2>/dev/null || true
systemctl restart wirc_2026.service

log "WIRC-Link und Port-8082-Weiterleitung wurden installiert."
log "Nur WIRC wurde neu gestartet. Sicherung: $backup_dir"
