Witty Pi 5 eigener Webserver
============================

Paketversion: 2026-09-13.42

Ergebnis:
- unabhaengiger systemd-Dienst wittypi5-webserver.service
- Port 8081
- Installation in /home/wurb/wittypi5-webserver, wenn /home/wurb vorhanden ist
- WURB und WIRC bleiben Uvicorn-Dienste auf Port 8080 bzw. 8082
- Stoppen von WURB oder WIRC beendet den Witty-Webserver nicht
- vorhandene Homepage-Dateien werden gesichert und nur in-place ergaenzt
- keine kompletten WURB-, WIRC- oder Allsky-Dateien sind im ZIP enthalten

Installation aus dem entpackten ZIP:
    sudo bash witty_addon/install.sh

Direktinstallation ueber die einzelne GitHub-Datei:
    sudo bash install_wittypi5_webserver.sh

Aufruf:
    http://RASPBERRY-IP:8081/

Kontrolle:
    systemctl status wittypi5-webserver.service
    journalctl -u wittypi5-webserver.service -n 100 --no-pager
