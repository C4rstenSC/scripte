Witty Pi 5 eigener Webserver
============================

Paketversion: 2026-09-14.75

Ergebnis:
- unabhaengiger systemd-Dienst wittypi5-webserver.service
- Port 8081
- Installation in /home/wurb/wittypi5-webserver, wenn /home/wurb vorhanden ist
- WURB und WIRC bleiben Uvicorn-Dienste auf Port 8080 bzw. 8082
- Stoppen von WURB oder WIRC beendet den Witty-Webserver nicht
- vorhandene Homepage-Dateien werden gesichert und nur in-place ergaenzt
- keine kompletten WURB-, WIRC- oder Allsky-Dateien sind im ZIP enthalten
- WURB- und WIRC-Aufnahmeverwaltung auf Port 8081, nur bei vorhandener Installation
- sichere Einzel- und ZIP-Downloads, Ordneranlage, Verschieben und Loeschen von Aufnahmen
- temporaere ZIP-Dateien werden nach erfolgreicher HTTP-Uebertragung geloescht
- Zielordner hierarchisch und ohne wiederholte Pfadnamen dargestellt
- Recordings-Schaltflaechen direkt neben WURB/WIRC; Witty Pi 5 rechts abgesetzt
- ZIPs aus ausgewaehlten Dateien ohne Ordnerstruktur und mit Download-Zeitstempel
- Aufnahmeziel aus record.targets der aktiven WURB/WIRC-Konfiguration ermittelt
- tatsaechlicher lokaler, USB- oder Festplatten-Speicherort auf der Webseite angezeigt
- WURB-Dateifilter: WAV; WIRC-Dateifilter: H264, MP4 und MKV
- zweisprachiger Leerhinweis in geoeffneten Ordnern ohne passende Aufnahmen
- Unterordner in beliebiger Tiefe erstellbar; Dateien und ganze Ordner verschiebbar
- Dienst-stoppen-Schaltflaechen und zugehoerige Handler aus WURB/WIRC entfernt
- Recording-Ziel wird bei jedem Backend-Aufruf erneut aus record.targets bestimmt
- Auswahl aller verfuegbaren konfigurierten Recording-Speicher auf WURB/WIRC-Seiten
- aktive Aufnahmequelle markiert; alle Datei- und Ordneraktionen an die Auswahl gebunden
- Witty-Pi-5-Navigation auf allen Seiten sichtbar und ca. 2 cm vom vorherigen Navigationsziel abgesetzt
- Allsky bei vorhandener Installation auf allen Seiten unmittelbar links vor Witty Pi 5
- Leerhinweis nur im tiefsten leeren Ordner, nicht zusaetzlich in dessen Elternordnern
- gemeinsame Sprachauswahl fuer Witty, WURB Recordings und WIRC Recordings inklusive Live-Tab-Synchronisierung
- Auswahl loeschen fuer Dateien und Ordner; Inhaltspruefung und zweisprachige Rueckfrage vor rekursivem Loeschen
- gestreamter Mehrfach-Upload mit Zielordnerwahl und Fortschritt; WAV fuer WURB, H264/MP4/MKV fuer WIRC
- Konfliktpruefung vor Upload: vorhandene/mehrfach gewaehlte Namen wahlweise ueberschreiben oder gezielt ueberspringen
- nach erfolgreichem Upload zuerst Dateistruktur aktualisieren und danach Upload-Fenster automatisch schliessen
- Erfolgsmeldung nach Upload zwei Sekunden sichtbar, bevor sich das Fenster schliesst
- Verschieben-Schaltflaeche links vor der Zielordner-Auswahl angeordnet

Installation aus dem entpackten ZIP:
    sudo bash witty_addon/install.sh

Direktinstallation ueber die einzelne GitHub-Datei:
    sudo bash install_wittypi5_webserver.sh

Aufruf:
    http://RASPBERRY-IP:8081/
    http://RASPBERRY-IP:8081/recordings/wurb
    http://RASPBERRY-IP:8081/recordings/wirc

Kontrolle:
    systemctl status wittypi5-webserver.service
    journalctl -u wittypi5-webserver.service -n 100 --no-pager
