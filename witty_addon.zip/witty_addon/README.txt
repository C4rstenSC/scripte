Witty Pi 5 eigener Webserver
============================

Paketversion: 2026-09-15.119

Ergebnis:
- unabhaengiger systemd-Dienst wittypi5-webserver.service
- Port 8081
- Installation in /home/wurb/wittypi5-webserver, wenn /home/wurb vorhanden ist
- WURB und WIRC bleiben Uvicorn-Dienste auf Port 8080 bzw. 8082
- Stoppen von WURB oder WIRC beendet den Witty-Webserver nicht
- vorhandene Homepage-Dateien werden gesichert und nur in-place ergaenzt
- keine kompletten WURB-, WIRC- oder Allsky-Dateien sind im ZIP enthalten
- WURB- und WIRC-Aufnahmeverwaltung auf Port 8081, nur bei vorhandener Installation
- sichere Einzel- und ZIP-Downloads, Ordneranlage, Verschieben und Loeschen von Aufnahmen
- temporaere ZIP-Dateien werden nach erfolgreicher HTTP-Uebertragung geloescht
- Zielordner hierarchisch und ohne wiederholte Pfadnamen dargestellt
- Recordings-Schaltflaechen direkt neben WURB/WIRC; Witty Pi 5 rechts abgesetzt
- ZIPs aus ausgewaehlten Dateien ohne Ordnerstruktur und mit Download-Zeitstempel
- Aufnahmeziel aus record.targets der aktiven WURB/WIRC-Konfiguration ermittelt
- tatsaechlicher lokaler, USB- oder Festplatten-Speicherort auf der Webseite angezeigt
- WURB-Dateifilter: WAV; WIRC-Dateifilter: H264, MP4 und MKV
- zweisprachiger Leerhinweis in geoeffneten Ordnern ohne passende Aufnahmen
- Unterordner in beliebiger Tiefe erstellbar; Dateien und ganze Ordner verschiebbar
- Dienst-stoppen-Schaltflaechen und zugehoerige Handler aus WURB/WIRC entfernt
- Recording-Ziel wird bei jedem Backend-Aufruf erneut aus record.targets bestimmt
- Auswahl aller verfuegbaren konfigurierten Recording-Speicher auf WURB/WIRC-Seiten
- aktive Aufnahmequelle markiert; alle Datei- und Ordneraktionen an die Auswahl gebunden
- Witty-Pi-5-Navigation auf allen Seiten sichtbar und ca. 2 cm vom vorherigen Navigationsziel abgesetzt
- Allsky bei vorhandener Installation auf allen Seiten unmittelbar links vor Witty Pi 5
- Witty-Kopfbereich einschliesslich Navigation, Dienststatus und Seitentitel bleibt beim Scrollen sichtbar
- Witty-Reset zeigt Arbeitsschritt, prozentualen Fortschritt und sekundengenaue Laufzeit
- Wiederherstellung laedt zuerst alle WPI-Dateien hoch und liest die Firmware-Dateiliste erst danach gemeinsam ein
- aktiver Zeitmodus steht direkt neben der Bezeichnung; Umschaltflaechen sind rechtsbuendig angeordnet
- deutsch- und australisch-englische Anleitung in kurze Erklaerungen und Schritt-fuer-Schritt-Ablaeufe gegliedert
- Leerhinweis nur im tiefsten leeren Ordner, nicht zusaetzlich in dessen Elternordnern
- gemeinsame Sprachauswahl fuer Witty, WURB Recordings und WIRC Recordings inklusive Live-Tab-Synchronisierung
- Auswahl loeschen fuer Dateien und Ordner; Inhaltspruefung und zweisprachige Rueckfrage vor rekursivem Loeschen
- gestreamter Mehrfach-Upload mit Zielordnerwahl und Fortschritt; WAV fuer WURB, H264/MP4/MKV fuer WIRC
- Konfliktpruefung vor Upload: vorhandene/mehrfach gewaehlte Namen wahlweise ueberschreiben oder gezielt ueberspringen
- nach erfolgreichem Upload zuerst Dateistruktur aktualisieren und danach Upload-Fenster automatisch schliessen
- Erfolgsmeldung nach Upload zwei Sekunden sichtbar, bevor sich das Fenster schliesst
- Verschieben-Schaltflaeche links vor der Zielordner-Auswahl angeordnet
- Allsky-Erkennung fuer /home/allsky, Benutzer-Home-Verzeichnisse und /opt korrigiert
- neue zweisprachige Seite "Allsky - Setup" fuer validierte Einstellungs-Sicherungen
- Allsky-Wiederherstellung mit Rueckrollkopie und kontrolliertem Dienst-Neustart
- jeder erneute Witty-Logabruf ersetzt die lokale Kopie durch einen frischen Firmware-Snapshot
- wiederholte Schedule-Dateiverwaltungsmeldungen werden nur im Logfenster zusammengefasst; der Download bleibt vollstaendig
- Allsky-Statusampel und manuelle Start-/Stoppsteuerung auf Witty- und Allsky-Setup-Seite
- farbige Zeitmodus-Anzeige direkt hinter der aktuellen Witty-RTC-Zeit im Skripteditor
- Skriptnamensfeld direkt unter Editor und Schaltzeitenvorschau vor den Dateiaktionen
- Beispielknopf links neben dem Knopf zum Leeren des Editorfensters angeordnet
- vollstaendige Anzeige grosser Witty-Logs ohne die alte 512-KiB-Grenze
- Anzeige der bekannten Loggroesse; Witty Pi 5 liefert vor dem Download keine Dateigroesse
- abgesicherter Witty-Reset mit Skript-Backup, Wiederherstellung und erneuter Aktivierung
- Zeitplanpruefung akzeptiert bis einschliesslich 4096 Ereignisse
- zweisprachige vollstaendige Bedienungsanleitung fuer Witty sowie WURB-/WIRC-Recordings
- Anleitung-Button rechts unterhalb der Ueberschrift auf allen drei Bedienseiten
- sichtbarer 5-mm-Abstand zwischen den beiden Zeitmodus-Schaltflaechen
- Dienstampeln: grau bei nicht installiert, rot bei installiert/gestoppt und gruen bei laufendem Dienst
- eingeschraenkte Web-Installation und Deinstallation fuer WURB-2026, WIRC-2026 und Allsky mit Neustart
- Allsky-Kamerawarnung vor der Bestaetigung und interaktive Ausgabe des offiziellen Installers
- Installationslinks verwenden die beim Seitenaufruf erreichte IP-Adresse und funktionieren dadurch auch am Hotspot
- vollstaendige Allsky-Erkennung verlangt Projektstruktur und geladene allsky.service
- WURB-, WIRC- und Allsky-Status stehen untereinander; Installationsknopf heisst Software installieren
- GPS-Koordinaten werden offline einer exakten IANA-Zeitzone zugeordnet; je UTC-Offset erscheint nur ein Referenzort
- ohne installierte GPS-Option wird ausdruecklich "Zeitzonenermittlung nicht moeglich" angezeigt
- australische GPS-Orte und Sonderoffsets werden einzeln als Perth, Eucla, Darwin, Adelaide, Broken Hill, Brisbane, Sydney, Canberra, Melbourne, Hobart oder Lord Howe bezeichnet
- fehlende GPS-Koordinaten werden alle zehn Sekunden erneut abgefragt; der letzte vollständige Fix wird 15 Minuten einschließlich Position zwischengespeichert
- falls gpsd noch keinen Fix an die Witty-Seite geliefert hat, wird dieselbe gueltige Position aus wurb_settings.db verwendet, mit der WURB seine Sonnenzeiten berechnet

Installation aus dem entpackten ZIP:
    sudo bash witty_addon/install.sh

Direktinstallation ueber die einzelne GitHub-Datei:
    sudo bash install_wittypi5_webserver.sh

Aufruf:
    http://RASPBERRY-IP:8081/
    http://RASPBERRY-IP:8081/recordings/wurb
    http://RASPBERRY-IP:8081/recordings/wirc

Kontrolle:
    systemctl status wittypi5-webserver.service
    journalctl -u wittypi5-webserver.service -n 100 --no-pager
