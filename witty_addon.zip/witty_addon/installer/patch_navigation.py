#!/usr/bin/env python3
"""Idempotent, small navigation patches; never replaces whole application files."""
import argparse
import pathlib
import re

SCRIPT = '''
<!-- wittypi5-addon:start -->
<script>
document.querySelectorAll('[data-wittypi5-port]').forEach(function (link) {
    link.href = window.location.protocol + '//' + window.location.hostname + ':' + link.dataset.wittypi5Port + '/';
});
document.querySelectorAll('[data-wittypi5-root]').forEach(function (link) {
    link.href = window.location.protocol + '//' + window.location.hostname + '/';
});
async function wittypi5Service(action) {
    try {
        const response = await fetch(window.location.protocol + '//' + window.location.hostname + ':8081/api', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body:JSON.stringify({action:action, service:'__SERVICE__'})
        });
        const result = await response.json();
        if (!response.ok || !result.ok) throw new Error(result.error || 'Backend-Fehler');
        window.location.replace(window.location.protocol + '//' + window.location.hostname + ':8081/');
    } catch (error) { console.error(error); }
}
document.getElementById('__STOP_ID__').addEventListener('click', function(){wittypi5Service('service_stop');});
</script>
<!-- wittypi5-addon:end -->
'''


def patch_cloudedbats(path, kind):
    text = path.read_text(encoding="utf-8")
    text = re.sub(r'<!-- wittypi5-addon:start -->.*?<!-- wittypi5-addon:end -->\s*', '', text,
                  flags=re.DOTALL)
    text = re.sub(r'<!-- wittypi5-navigation:start -->.*?<!-- wittypi5-navigation:end -->\s*', '', text,
                  flags=re.DOTALL)
    text = re.sub(r'<script>[^<]*(?:controlWurbService|controlWircService).*?</script>\s*', '', text,
                  flags=re.DOTALL)
    # Remove navigation anchors from older addon versions, including optional
    # Jinja conditions. They are reconstructed below from installed units.
    anchor_pattern = re.compile(
        r'(?:\{%\s*if\s+(?:wurb|wirc|witty)_installed\s*%\}\s*)?'
        r'<a\b[^>]*>\s*(?:WURB-2026|WIRC-2026|Witty Pi 5)\s*</a>'
        r'(?:\s*\{%\s*endif\s*%\})?', re.IGNORECASE | re.DOTALL
    )
    text = anchor_pattern.sub('', text)

    links = []
    if kind == "wurb" or project_installed("wurb_2026"):
        links.append('<a data-wittypi5-port="8080" class="button is-small" href="#">WURB-2026</a>')
    if kind == "wirc" or project_installed("wirc_2026"):
        links.append('<a data-wittypi5-port="8082" class="button is-small" href="#">WIRC-2026</a>')
    if project_installed("allsky"):
        links.append('<a data-wittypi5-root="1" class="button is-small" href="/">Allsky</a>')
    links.append('<a data-wittypi5-port="8081" class="button is-small" href="#">Witty Pi 5</a>')
    navigation = (
        '<!-- wittypi5-navigation:start -->'
        '<div class="navbar-item p-0 system-navigation"><div class="buttons m-2">'
        + ''.join(links)
        + '</div></div><!-- wittypi5-navigation:end -->\n'
    )
    marker = re.search(r'</nav\s*>', text, flags=re.IGNORECASE)
    if not marker:
        raise RuntimeError(f"Navigationsleiste nicht gefunden: {path}")
    text = text[:marker.start()] + navigation + text[marker.start():]
    start_id = "wurbServiceStartButton" if kind == "wurb" else "wircServiceStartButton"
    stop_id = "wurbServiceStopButton" if kind == "wurb" else "wircServiceStopButton"
    service = "wurb_2026" if kind == "wurb" else "wirc_2026"
    text = re.sub(r'<!-- wittypi5-service-controls:start -->.*?<!-- wittypi5-service-controls:end -->\s*', '', text, flags=re.DOTALL)
    text = re.sub(
        rf'<div class="container is-fluid (?:mb-2|my-3)"><div class="buttons is-centered">\s*'
        rf'(?:<button\b[^>]*id="(?:{start_id}|{stop_id})"[^>]*>.*?</button>\s*)*'
        rf'</div></div>', '', text, flags=re.DOTALL
    )
    text = re.sub(rf'<button\b[^>]*id="{start_id}"[^>]*>.*?</button>', '', text, flags=re.DOTALL)
    text = re.sub(rf'<button\b[^>]*id="{stop_id}"[^>]*>.*?</button>', '', text, flags=re.DOTALL)
    controls = (f'<!-- wittypi5-service-controls:start -->'
                f'<div class="container is-fluid my-3"><div class="buttons is-centered">'
                f'<button id="{stop_id}" class="button is-medium has-text-weight-bold">Dienst stoppen</button>'
                f'</div></div><!-- wittypi5-service-controls:end -->')
    text = text.replace("</nav>", "</nav>\n" + controls, 1)
    script = (SCRIPT.replace("__SERVICE__", service)
                    .replace("__START_ID__", start_id).replace("__STOP_ID__", stop_id))
    text = text.replace("</body>", script + "\n</body>", 1)
    if ('data-wittypi5-port="8081"' not in text
            or "<!-- wittypi5-navigation:start -->" not in text
            or "<!-- wittypi5-addon:start -->" not in text):
        raise RuntimeError(f"Witty-Navigation konnte nicht eingefuegt werden: {path}")
    path.write_text(text, encoding="utf-8")


def patch_allsky(path):
    text = path.read_text(encoding="utf-8")
    text = re.sub(r'\s*<!-- wittypi5-allsky:start -->.*?<!-- wittypi5-allsky:end -->', '', text,
                  flags=re.DOTALL)
    text = re.sub(r'\s*<!-- wittypi5-allsky-nav:start -->.*?<!-- wittypi5-allsky-nav:end -->', '', text,
                  flags=re.DOTALL)
    text = re.sub(r'<script>\s*document\.querySelectorAll\(\'#wittypi5-navigation.*?</script>\s*', '', text,
                  flags=re.DOTALL)
    text = re.sub(r'\s*<div class="witty-system-navigation".*?</div>', '', text,
                  flags=re.DOTALL)
    text = re.sub(r'<script>\s*const navigationProtocol.*?</script>\s*', '', text,
                  flags=re.DOTALL)
    style = '''
<!-- wittypi5-allsky:start -->
<style>
#wittypi5-navigation { background:#000; padding:8px; display:flex; gap:8px; flex-wrap:wrap; }
#wittypi5-navigation a { background:#b5b5b5; border:1px solid #8f8f8f; color:#000; font-weight:700; padding:6px 10px; border-radius:4px; text-decoration:none; }
</style>
<!-- wittypi5-allsky:end -->
'''
    text = text.replace("</head>", style + "\n</head>", 1)
    links = []
    if project_installed("wurb_2026"):
        links.append('<a href="#" data-port="8080">WURB-2026</a>')
    if project_installed("wirc_2026"):
        links.append('<a href="#" data-port="8082">WIRC-2026</a>')
    links.extend(('<a href="/">Allsky</a>', '<a href="#" data-port="8081">Witty Pi 5</a>'))
    bar = ('<!-- wittypi5-allsky-nav:start --><div id="wittypi5-navigation">'
           + ''.join(links) + '</div><!-- wittypi5-allsky-nav:end -->')
    body = re.search(r'<body\b[^>]*>', text, re.IGNORECASE)
    if not body:
        raise RuntimeError(f"body nicht gefunden: {path}")
    text = text[:body.end()] + "\n" + bar + text[body.end():]
    port_script = '''<script>
document.querySelectorAll('#wittypi5-navigation [data-port]').forEach(function(link) {
 link.href=window.location.protocol+'//'+window.location.hostname+':'+link.dataset.port+'/';
});
</script>'''
    text = text.replace("</body>", port_script + "\n</body>", 1)
    path.write_text(text, encoding="utf-8")


def project_installed(name):
    if name == "allsky":
        candidates = tuple(pathlib.Path(base) / "allsky" for base in
                           ("/home/wurb", "/home/pi", "/home/allsky", "/opt"))
        return any((path / "allsky.sh").is_file()
                   and (path / "config/config.sh").is_file()
                   and (path / "html/index.php").is_file()
                   for path in candidates)
    candidates = tuple(pathlib.Path(base) / name for base in
                       ("/home/wurb", "/home/pi", "/opt"))
    if name == "wurb_2026":
        return any((path / "wurb_main.py").is_file()
                   and (path / "wurb_app/templates/index.html").is_file()
                   for path in candidates)
    if name == "wirc_2026":
        return any((path / "wirc_main.py").is_file()
                   and (path / "wirc_app/templates/index.html").is_file()
                   for path in candidates)
    return False


parser = argparse.ArgumentParser()
parser.add_argument("--kind", choices=("wurb", "wirc", "allsky"), required=True)
parser.add_argument("--file", type=pathlib.Path, required=True)
args = parser.parse_args()
if args.kind in ("wurb", "wirc"):
    patch_cloudedbats(args.file, args.kind)
else:
    patch_allsky(args.file)
