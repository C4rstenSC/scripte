#!/usr/bin/env python3
"""Idempotent, small navigation patches; never replaces whole application files."""
import argparse
import pathlib
import re

SCRIPT = '''
<!-- wittypi5-addon:start -->
<script>
document.querySelectorAll('[data-wittypi5-port]').forEach(function (link) {
    link.href = window.location.protocol + '//' + window.location.hostname + ':' + link.dataset.wittypi5Port + '/';
});
async function wittypi5Service(action) {
    try {
        const response = await fetch(window.location.protocol + '//' + window.location.hostname + ':8081/api', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body:JSON.stringify({action:action, service:'__SERVICE__'})
        });
        const result = await response.json();
        if (!response.ok || !result.ok) throw new Error(result.error || 'Backend-Fehler');
        alert(result.message || 'OK');
    } catch (error) { alert(error.message); }
}
document.getElementById('__START_ID__').addEventListener('click', function(){wittypi5Service('service_start');});
document.getElementById('__STOP_ID__').addEventListener('click', function(){wittypi5Service('service_stop');});
</script>
<!-- wittypi5-addon:end -->
'''


def patch_cloudedbats(path, kind):
    text = path.read_text(encoding="utf-8")
    text = re.sub(r'<!-- wittypi5-addon:start -->.*?<!-- wittypi5-addon:end -->\s*', '', text,
                  flags=re.DOTALL)
    text = re.sub(r'<!-- wittypi5-navigation:start -->.*?<!-- wittypi5-navigation:end -->\s*', '', text,
                  flags=re.DOTALL)
    text = re.sub(r'<script>[^<]*(?:controlWurbService|controlWircService).*?</script>\s*', '', text,
                  flags=re.DOTALL)
    # Remove navigation anchors from older addon versions, including optional
    # Jinja conditions. They are reconstructed below from installed units.
    anchor_pattern = re.compile(
        r'(?:\{%\s*if\s+(?:wurb|wirc|witty)_installed\s*%\}\s*)?'
        r'<a\b[^>]*>\s*(?:WURB-2026|WIRC-2026|Witty Pi 5)\s*</a>'
        r'(?:\s*\{%\s*endif\s*%\})?', re.IGNORECASE | re.DOTALL
    )
    text = anchor_pattern.sub('', text)

    links = []
    if kind == "wurb" or unit_installed("wurb_2026.service"):
        links.append('<a data-wittypi5-port="8080" class="button is-small" href="#">WURB-2026</a>')
    if kind == "wirc" or unit_installed("wirc_2026.service"):
        links.append('<a data-wittypi5-port="8082" class="button is-small" href="#">WIRC-2026</a>')
    links.append('<a data-wittypi5-port="8081" class="button is-small" href="#">Witty Pi 5</a>')
    navigation = (
        '<!-- wittypi5-navigation:start -->'
        '<div class="navbar-item p-0 system-navigation"><div class="buttons m-2">'
        + ''.join(links)
        + '</div></div><!-- wittypi5-navigation:end -->\n'
    )
    marker = re.search(r'</nav\s*>', text, flags=re.IGNORECASE)
    if not marker:
        raise RuntimeError(f"Navigationsleiste nicht gefunden: {path}")
    text = text[:marker.start()] + navigation + text[marker.start():]
    start_id = "wurbServiceStartButton" if kind == "wurb" else "wircServiceStartButton"
    stop_id = "wurbServiceStopButton" if kind == "wurb" else "wircServiceStopButton"
    service = "wurb_2026" if kind == "wurb" else "wirc_2026"
    for button_id in (start_id, stop_id):
        text = re.sub(rf'(<button\b[^>]*id="{button_id}"[^>]*)\sdisabled(\b[^>]*>)', r'\1\2', text)
    if f'id="{start_id}"' not in text:
        controls = (f'<div class="container is-fluid mb-2"><div class="buttons is-centered">'
                    f'<button id="{start_id}" class="button is-small">Dienst starten</button>'
                    f'<button id="{stop_id}" class="button is-small">Dienst stoppen</button>'
                    f'</div></div>')
        text = text.replace("</nav>", "</nav>\n" + controls, 1)
    script = (SCRIPT.replace("__SERVICE__", service)
                    .replace("__START_ID__", start_id).replace("__STOP_ID__", stop_id))
    text = text.replace("</body>", script + "\n</body>", 1)
    if ('data-wittypi5-port="8081"' not in text
            or "<!-- wittypi5-navigation:start -->" not in text
            or "<!-- wittypi5-addon:start -->" not in text):
        raise RuntimeError(f"Witty-Navigation konnte nicht eingefuegt werden: {path}")
    path.write_text(text, encoding="utf-8")


def patch_allsky(path):
    text = path.read_text(encoding="utf-8")
    text = re.sub(r'\s*<div class="witty-system-navigation".*?</div>', '', text,
                  flags=re.DOTALL)
    text = re.sub(r'<script>\s*const navigationProtocol.*?</script>\s*', '', text,
                  flags=re.DOTALL)
    if "<!-- wittypi5-allsky:start -->" not in text:
        style = '''
<!-- wittypi5-allsky:start -->
<style>
#wittypi5-navigation { background:#000; padding:8px; display:flex; gap:8px; flex-wrap:wrap; }
#wittypi5-navigation a { background:#b5b5b5; border:1px solid #8f8f8f; color:#000; font-weight:700; padding:6px 10px; border-radius:4px; text-decoration:none; }
</style>
<!-- wittypi5-allsky:end -->
'''
        text = text.replace("</head>", style + "\n</head>", 1)
        links = []
        if unit_installed("wurb_2026.service"):
            links.append('<a href="#" data-port="8080">WURB-2026</a>')
        if unit_installed("wirc_2026.service"):
            links.append('<a href="#" data-port="8082">WIRC-2026</a>')
        links.extend(('<a href="/">Allsky</a>', '<a href="#" data-port="8081">Witty Pi 5</a>'))
        bar = ('<!-- wittypi5-allsky-nav:start --><div id="wittypi5-navigation">'
               + ''.join(links) + '</div><!-- wittypi5-allsky-nav:end -->')
        body = re.search(r'<body\b[^>]*>', text, re.IGNORECASE)
        if not body:
            raise RuntimeError(f"body nicht gefunden: {path}")
        text = text[:body.end()] + "\n" + bar + text[body.end():]
        port_script = '''<script>
document.querySelectorAll('#wittypi5-navigation [data-port]').forEach(function(link) {
 link.href=window.location.protocol+'//'+window.location.hostname+':'+link.dataset.port+'/';
});
</script>'''
        text = text.replace("</body>", port_script + "\n</body>", 1)
    path.write_text(text, encoding="utf-8")


def unit_installed(name):
    return any((pathlib.Path(base) / name).is_file() for base in (
        "/etc/systemd/system", "/usr/lib/systemd/system", "/lib/systemd/system"
    ))


parser = argparse.ArgumentParser()
parser.add_argument("--kind", choices=("wurb", "wirc", "allsky"), required=True)
parser.add_argument("--file", type=pathlib.Path, required=True)
args = parser.parse_args()
if args.kind in ("wurb", "wirc"):
    patch_cloudedbats(args.file, args.kind)
else:
    patch_allsky(args.file)
