#!/usr/bin/env bash
set -Eeuo pipefail

readonly PATCHER="/usr/local/lib/wittypi5-webserver/patch_navigation.py"
find_allsky() {
    local base
    for base in /home/allsky /home/wurb/allsky /home/pi/allsky /home/allsky/allsky /opt/allsky; do
        [[ -f "$base/html/index.php" ]] && { printf '%s\n' "$base"; return 0; }
    done
    return 1
}

allsky_home="$(find_allsky || true)"
[[ -n "$allsky_home" ]] || { echo "Allsky-Homepage noch nicht gefunden; erneuter Versuch beim nächsten Boot." >&2; exit 1; }
python3 "$PATCHER" --kind allsky --file "$allsky_home/html/index.php"
systemctl reload lighttpd.service 2>/dev/null || systemctl try-restart lighttpd.service 2>/dev/null || true
systemctl disable wittypi5-allsky-firstboot.service >/dev/null 2>&1 || true
echo "Allsky-Navigation einmalig ergänzt: $allsky_home/html/index.php"
