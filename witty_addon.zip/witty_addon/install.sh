#!/usr/bin/env bash
set -Eeuo pipefail

log() { printf '[wittypi5-webserver] %s\n' "$*"; }
die() { printf '[wittypi5-webserver] FEHLER: %s\n' "$*" >&2; exit 1; }
[[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Bitte mit sudo starten: sudo bash $0"

source_dir="$(cd "$(dirname "$0")" && pwd)"
for command_name in python3 install systemctl find stat timeout curl; do
    command -v "$command_name" >/dev/null 2>&1 || die "Das Programm '$command_name' fehlt."
done

if [[ -d /home/wurb ]]; then
    app_dir="/home/wurb/wittypi5-webserver"
elif [[ -n "${SUDO_USER:-}" && "${SUDO_USER}" != root ]]; then
    user_home="$(getent passwd "$SUDO_USER" | cut -d: -f6)"
    app_dir="$user_home/wittypi5-webserver"
else
    app_dir="/home/wittypi5-webserver"
fi

backup_dir="/var/backups/wittypi5-webserver/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$backup_dir" "$app_dir/web/assets" "$app_dir/backend" "$app_dir/logs"
[[ -d "$app_dir" ]] && cp -a "$app_dir/." "$backup_dir/webserver" 2>/dev/null || true

install -m 0755 "$source_dir/web/server.py" "$app_dir/web/server.py"
install -m 0644 "$source_dir/web/index.html" "$app_dir/web/index.html"
install -m 0644 "$source_dir/web/assets/bulma-v1.0.4.min.css" "$app_dir/web/assets/bulma-v1.0.4.min.css"
install -m 0644 "$source_dir/web/assets/cloudedbats_logo.png" "$app_dir/web/assets/cloudedbats_logo.png"
install -m 0755 "$source_dir/backend/witty_backend.sh" "$app_dir/backend/witty_backend.sh"
install -D -m 0755 "$source_dir/installer/finalize_allsky.sh" /usr/local/lib/wittypi5-webserver/finalize_allsky.sh
install -D -m 0755 "$source_dir/installer/patch_navigation.py" /usr/local/lib/wittypi5-webserver/patch_navigation.py
install -m 0644 "$source_dir/installer/wittypi5-allsky-firstboot.service" /etc/systemd/system/wittypi5-allsky-firstboot.service

patch_file() {
    local kind="$1" file="$2"
    [[ -f "$file" ]] || return 0
    mkdir -p "$backup_dir/$(dirname "${file#/}")"
    cp -a "$file" "$backup_dir/${file#/}"
    python3 "$source_dir/installer/patch_navigation.py" --kind "$kind" --file "$file"
    log "Navigation ergaenzt: $file"
}

find_project() {
    local name="$1" candidate
    for candidate in "/home/wurb/$name" "/home/pi/$name" "/opt/$name"; do
        [[ -d "$candidate" ]] && { printf '%s\n' "$candidate"; return; }
    done
    find /home -mindepth 2 -maxdepth 3 -type d -name "$name" -print -quit 2>/dev/null
}

wurb_home="$(find_project wurb_2026 || true)"
wirc_home="$(find_project wirc_2026 || true)"
[[ -n "$wurb_home" ]] && patch_file wurb "$wurb_home/wurb_app/templates/index.html"
[[ -n "$wirc_home" ]] && patch_file wirc "$wirc_home/wirc_app/templates/index.html"

allsky_home="$(find_project allsky || true)"
if [[ -n "$allsky_home" && -f "$allsky_home/html/index.php" ]]; then
    patch_file allsky "$allsky_home/html/index.php"
fi

sed "s|__APP_DIR__|$app_dir|g" "$source_dir/installer/wittypi5-webserver.service" \
    > /etc/systemd/system/wittypi5-webserver.service
chmod 0644 /etc/systemd/system/wittypi5-webserver.service
timeout 20s systemctl daemon-reload || die "systemd konnte nicht neu geladen werden."
if [[ -n "$allsky_home" && -f "$allsky_home/html/index.php" ]]; then
    systemctl disable wittypi5-allsky-firstboot.service >/dev/null 2>&1 || true
elif [[ "${WITTY_ADDON_EXPECT_ALLSKY:-0}" == 1 ]]; then
    timeout 15s systemctl enable wittypi5-allsky-firstboot.service || \
        die "Die einmalige Allsky-Nachbearbeitung konnte nicht aktiviert werden."
    log "Allsky-Navigation wird beim ersten Neustart automatisch ergänzt."
fi
timeout 15s systemctl enable wittypi5-webserver.service || \
    die "wittypi5-webserver.service konnte nicht für den Autostart aktiviert werden."
# enable --now startet einen bereits aktiven Dienst nicht neu. Nach einem Update
# würde sonst der alte Python-Prozess mit dem vorherigen server.py-Code weiterlaufen.
timeout 25s systemctl restart wittypi5-webserver.service || \
    die "wittypi5-webserver.service konnte nicht neu gestartet werden."
[[ -n "$wurb_home" ]] && timeout 25s systemctl try-restart wurb_2026.service || true
[[ -n "$wirc_home" ]] && timeout 25s systemctl try-restart wirc_2026.service || true
if [[ -n "$allsky_home" ]]; then timeout 20s systemctl reload lighttpd.service 2>/dev/null || true; fi

sleep 2
systemctl is-active --quiet wittypi5-webserver.service || \
    die "wittypi5-webserver.service ist nach der Installation nicht aktiv."

http_ok=false
for attempt in 1 2 3 4 5; do
    if curl --fail --silent --show-error --max-time 5 \
            --output /dev/null http://127.0.0.1:8081/; then
        http_ok=true
        break
    fi
    sleep 1
done
$http_ok || die "Der Witty-Webserver liefert auf Port 8081 keine gültige HTTP-Antwort."

log "Installiert in $app_dir"
log "Witty-Homepage: http://$(hostname):8081/"
log "Sicherung: $backup_dir"
