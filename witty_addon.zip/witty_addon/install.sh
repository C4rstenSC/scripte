#!/usr/bin/env bash
set -Eeuo pipefail

log() { printf '[wittypi5-webserver] %s\n' "$*"; }
die() { printf '[wittypi5-webserver] FEHLER: %s\n' "$*" >&2; exit 1; }
[[ "${EUID:-$(id -u)}" -eq 0 ]] || die "Bitte mit sudo starten: sudo bash $0"

source_dir="$(cd "$(dirname "$0")" && pwd)"
for command_name in python3 install systemctl find stat timeout curl flock cmp; do
    command -v "$command_name" >/dev/null 2>&1 || die "Das Programm '$command_name' fehlt."
done

if [[ -d /home/wurb ]]; then
    app_dir="/home/wurb/wittypi5-webserver"
elif [[ -n "${SUDO_USER:-}" && "${SUDO_USER}" != root ]]; then
    user_home="$(getent passwd "$SUDO_USER" | cut -d: -f6)"
    app_dir="$user_home/wittypi5-webserver"
else
    app_dir="/home/wittypi5-webserver"
fi

backup_dir="/var/backups/wittypi5-webserver/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$backup_dir" "$app_dir/web/assets" "$app_dir/backend" "$app_dir/logs"
[[ -d "$app_dir" ]] && cp -a "$app_dir/." "$backup_dir/webserver" 2>/dev/null || true

# Remove the obsolete backend location used by early add-on releases. Keeping
# it allowed an old API implementation to survive beside the current website.
rm -f -- /usr/local/lib/witty-addon/witty_backend.sh

install -m 0755 "$source_dir/web/server.py" "$app_dir/web/server.py"
install -m 0644 "$source_dir/web/index.html" "$app_dir/web/index.html"
install -m 0644 "$source_dir/web/recordings.html" "$app_dir/web/recordings.html"
install -m 0644 "$source_dir/web/manual.html" "$app_dir/web/manual.html"
install -m 0644 "$source_dir/web/assets/bulma-v1.0.4.min.css" "$app_dir/web/assets/bulma-v1.0.4.min.css"
install -m 0644 "$source_dir/web/assets/cloudedbats_logo.png" "$app_dir/web/assets/cloudedbats_logo.png"
install -m 0755 "$source_dir/backend/witty_backend.sh" "$app_dir/backend/witty5_backend.sh"
install -m 0755 "$source_dir/backend/witty4_backend.sh" "$app_dir/backend/witty4_backend.sh"
install -m 0755 "$source_dir/backend/witty_backend_dispatch.sh" "$app_dir/backend/witty_backend.sh"
cmp -s "$source_dir/backend/witty_backend.sh" "$app_dir/backend/witty5_backend.sh" || \
    die "Das Witty-Pi-5-Backend wurde nicht vollständig ersetzt."
if grep -Fq 'Die interne Pi-5-RTC kann nicht sicher zur Laufzeit deaktiviert werden' \
        "$app_dir/backend/witty5_backend.sh"; then
    die "Im installierten Backend wurde noch die veraltete RTC-Sperre gefunden."
fi
if [[ -f "$source_dir/backend/wurb-wp5-time" ]] && command -v wp5 >/dev/null 2>&1; then
    install -o root -g root -m 0755 "$source_dir/backend/wurb-wp5-time" /usr/local/sbin/wurb-wp5-time
fi
install -o root -g root -m 0755 "$source_dir/backend/witty-gps-manager" /usr/local/sbin/witty-gps-manager
install -o root -g root -m 0755 "$source_dir/backend/witty-time-sync" /usr/local/sbin/witty-time-sync

# Der Hauptinstaller übergibt die gewählte Platine. Bei Einzel-Updates bleibt
# eine vorhandene Auswahl erhalten; andernfalls entscheidet der Dispatcher
# ausschließlich anhand tatsächlich ansprechbarer Hardware.
if [[ "${WITTY_MODEL:-}" =~ ^[45]$ ]]; then
    printf 'RPI_MODEL=%s\nWITTY_MODEL=%s\nGPS_MODE=%s\n' \
        "${RPI_MODEL:-}" "$WITTY_MODEL" "${GPS_MODE:-unknown}" > /etc/witty-addon.conf
    chmod 0644 /etc/witty-addon.conf
fi
install -D -m 0755 "$source_dir/installer/finalize_allsky.sh" /usr/local/lib/wittypi5-webserver/finalize_allsky.sh
install -D -m 0755 "$source_dir/installer/patch_navigation.py" /usr/local/lib/wittypi5-webserver/patch_navigation.py
install -m 0644 "$source_dir/installer/wittypi5-allsky-firstboot.service" /etc/systemd/system/wittypi5-allsky-firstboot.service

patch_file() {
    local kind="$1" file="$2"
    [[ -f "$file" ]] || return 0
    mkdir -p "$backup_dir/$(dirname "${file#/}")"
    cp -a "$file" "$backup_dir/${file#/}"
    python3 "$source_dir/installer/patch_navigation.py" --kind "$kind" --file "$file"
    log "Navigation ergaenzt: $file"
}

find_project() {
    local name="$1" candidate
    if [[ "$name" == allsky ]]; then
        for candidate in /home/allsky /home/*/allsky /opt/allsky; do
            [[ -f "$candidate/allsky.sh" && -d "$candidate/html" ]] && { printf '%s\n' "$candidate"; return; }
        done
        return 1
    fi
    for candidate in "/home/wurb/$name" "/home/pi/$name" "/opt/$name"; do
        [[ -d "$candidate" ]] && { printf '%s\n' "$candidate"; return; }
    done
    find /home -mindepth 2 -maxdepth 3 -type d -name "$name" -print -quit 2>/dev/null
}

wurb_home="$(find_project wurb_2026 || true)"
wirc_home="$(find_project wirc_2026 || true)"

# Keep the physical GPS port owned by gpsd. WURB receives the replicated
# NMEA stream through /dev/ttyUSB9, while this add-on remains another gpsd
# client. Apply the same correction during updates of existing installations.
configured_gps_mode="${GPS_MODE:-unknown}"
if [[ -r /etc/witty-addon.conf ]]; then
    # shellcheck disable=SC1091
    source /etc/witty-addon.conf
    configured_gps_mode="${GPS_MODE:-$configured_gps_mode}"
fi
# Older add-on releases did not always persist the GPS selection.  Only fill
# an unknown value automatically; an explicit "none" selection stays intact.
if [[ "$configured_gps_mode" == "unknown" ]]; then
    if [[ -r /etc/default/gpsd ]] && \
       grep -Eq '^[[:space:]]*DEVICES="/dev/(ttyAMA0|serial0)"' /etc/default/gpsd; then
        configured_gps_mode="waveshare_l76x"
    else
        for gps_candidate in /dev/ttyACM* /dev/ttyUSB*; do
            [[ -e "$gps_candidate" && "$gps_candidate" != "/dev/ttyUSB9" ]] || continue
            configured_gps_mode="usb"
            break
        done
    fi
fi
if [[ "$configured_gps_mode" =~ ^(usb|waveshare_l76x)$ ]]; then
    for bridge_command in socat gpspipe; do
        command -v "$bridge_command" >/dev/null 2>&1 || die "Das Programm '$bridge_command' für die GPS-Bridge fehlt."
    done
    cat > /etc/systemd/system/wurb-gps-bridge.service << 'EOF'
[Unit]
Description=WURB GPS Virtual Serial Port Bridge
After=gpsd.service
Requires=gpsd.service

[Service]
Type=simple
ExecStart=/usr/bin/socat PTY,link=/dev/ttyWURB,raw,echo=0,group=dialout,mode=660 EXEC:"/usr/bin/gpspipe -r"
ExecStartPost=/usr/bin/ln -sf /dev/ttyWURB /dev/ttyUSB9
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
    mkdir -p /etc/systemd/system/multi-user.target.wants
    ln -sfn ../wurb-gps-bridge.service /etc/systemd/system/multi-user.target.wants/wurb-gps-bridge.service
fi
if [[ "$configured_gps_mode" =~ ^(usb|waveshare_l76x)$ && -n "$wurb_home" ]]; then
    wurb_owner="$(stat -c '%U' "$wurb_home")"
    wurb_group="$(stat -c '%G' "$wurb_home")"
    wurb_parent="$(dirname "$wurb_home")"
    wurb_local_config="$wurb_parent/wurb_settings/wurb_config.yaml"
    if [[ ! -f "$wurb_local_config" && -f "$wurb_home/wurb_config_default.yaml" ]]; then
        install -d -o "$wurb_owner" -g "$wurb_group" -m 0755 "$(dirname "$wurb_local_config")"
        install -o "$wurb_owner" -g "$wurb_group" -m 0644 "$wurb_home/wurb_config_default.yaml" "$wurb_local_config"
    fi
    if [[ -f "$wurb_local_config" ]]; then
        python3 - "$wurb_local_config" << 'PY'
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
lines = path.read_text().splitlines()
result = []
inside = False
found = False
for line in lines:
    if line.strip() == "gps_device_whitelist:":
        result.extend((line, "    - /dev/ttyUSB9 # Installer-owned shared gpsd bridge."))
        inside = True
        found = True
        continue
    if inside and (not line.strip() or line.startswith("    - ") or line.startswith("    #")):
        continue
    inside = False
    result.append(line)
if not found:
    raise SystemExit("gps_device_whitelist was not found in the WURB configuration")
path.write_text("\n".join(result) + "\n")
PY
        chown "$wurb_owner:$wurb_group" "$wurb_local_config"
    fi
    wurb_settings_db="$wurb_parent/wurb_settings/wurb_settings.db"
    if [[ -f "$wurb_settings_db" ]]; then
        python3 - "$wurb_settings_db" << 'PY'
import sqlite3
import sys

database = sys.argv[1]
connection = sqlite3.connect(database, timeout=15)
try:
    cursor = connection.cursor()

    def value(identity, key):
        row = cursor.execute(
            "SELECT value FROM key_value_data WHERE identity=? AND key=?",
            (identity, key),
        ).fetchone()
        return row[0] if row else ""

    latitude = float(value("location", "defaultLatitudeDd") or 0)
    longitude = float(value("location", "defaultLongitudeDd") or 0)
    source = value("location", "geoSource")
    if source in {"", "geo-default"} and latitude == 0.0 and longitude == 0.0:
        for identity in ("location", "startupLocation", "userLocation"):
            cursor.execute(
                "INSERT OR REPLACE INTO key_value_data(identity,key,value) VALUES(?,?,?)",
                (identity, "geoSource", "geo-gps-or-last-found"),
            )
        for identity in ("settings", "startupSettings", "userSettings"):
            cursor.execute(
                "INSERT OR REPLACE INTO key_value_data(identity,key,value) VALUES(?,?,?)",
                (identity, "lastGpsAtStartup", "keep"),
            )
        connection.commit()
finally:
    connection.close()
PY
        chown "$wurb_owner:$wurb_group" "$wurb_settings_db"
    fi
    mkdir -p /etc/systemd/system/wurb_2026.service.d
    rm -f /etc/systemd/system/wurb_2026.service.d/waveshare-gps-bridge.conf
    cat > /etc/systemd/system/wurb_2026.service.d/gps-bridge.conf << 'EOF'
[Unit]
Wants=wurb-gps-bridge.service
After=wurb-gps-bridge.service
EOF
fi
[[ -n "$wurb_home" ]] && patch_file wurb "$wurb_home/wurb_app/templates/index.html"
[[ -n "$wirc_home" ]] && patch_file wirc "$wirc_home/wirc_app/templates/index.html"

allsky_home="$(find_project allsky || true)"
if [[ -n "$allsky_home" && -f "$allsky_home/html/index.php" ]]; then
    patch_file allsky "$allsky_home/html/index.php"
fi

sed "s|__APP_DIR__|$app_dir|g" "$source_dir/installer/wittypi5-webserver.service" \
    > /etc/systemd/system/wittypi5-webserver.service
chmod 0644 /etc/systemd/system/wittypi5-webserver.service
timeout 20s systemctl daemon-reload || die "systemd konnte nicht neu geladen werden."
if [[ "$configured_gps_mode" =~ ^(usb|waveshare_l76x)$ && -n "$wurb_home" ]]; then
    timeout 20s systemctl enable wurb-gps-bridge.service >/dev/null || \
        die "Die WURB-GPS-Bridge konnte nicht aktiviert werden."
    timeout 25s systemctl restart wurb-gps-bridge.service || \
        die "Die WURB-GPS-Bridge konnte nicht gestartet werden."
    bridge_ready=false
    for attempt in 1 2 3 4 5; do
        if [[ -e /dev/ttyWURB && -e /dev/ttyUSB9 ]]; then
            bridge_ready=true
            break
        fi
        sleep 1
    done
    [[ "$bridge_ready" == true ]] || \
        die "Die GPS-Bridge läuft, aber /dev/ttyUSB9 wurde nicht angelegt."
    grep -Fq -- '- /dev/ttyUSB9' "$wurb_local_config" || \
        die "WURB wurde nicht auf die virtuelle GPS-Schnittstelle /dev/ttyUSB9 umgestellt."
fi
if [[ -n "$allsky_home" && -f "$allsky_home/html/index.php" ]]; then
    systemctl disable wittypi5-allsky-firstboot.service >/dev/null 2>&1 || true
elif [[ "${WITTY_ADDON_EXPECT_ALLSKY:-0}" == 1 ]]; then
    timeout 15s systemctl enable wittypi5-allsky-firstboot.service || \
        die "Die einmalige Allsky-Nachbearbeitung konnte nicht aktiviert werden."
    log "Allsky-Navigation wird beim ersten Neustart automatisch ergänzt."
fi
timeout 15s systemctl enable wittypi5-webserver.service || \
    die "wittypi5-webserver.service konnte nicht für den Autostart aktiviert werden."
# enable --now startet einen bereits aktiven Dienst nicht neu. Nach einem Update
# würde sonst der alte Python-Prozess mit dem vorherigen server.py-Code weiterlaufen.
timeout 25s systemctl restart wittypi5-webserver.service || \
    die "wittypi5-webserver.service konnte nicht neu gestartet werden."
[[ -n "$wurb_home" ]] && timeout 25s systemctl try-restart wurb_2026.service || true
[[ -n "$wirc_home" ]] && timeout 25s systemctl try-restart wirc_2026.service || true
if [[ -n "$allsky_home" ]]; then timeout 20s systemctl reload lighttpd.service 2>/dev/null || true; fi

sleep 2
systemctl is-active --quiet wittypi5-webserver.service || \
    die "wittypi5-webserver.service ist nach der Installation nicht aktiv."
if [[ "$configured_gps_mode" =~ ^(usb|waveshare_l76x)$ && -n "$wurb_home" ]]; then
    systemctl is-active --quiet wurb-gps-bridge.service || \
        die "Die WURB-GPS-Bridge ist nach der Installation nicht aktiv."
    [[ "$(readlink -f /dev/ttyUSB9 2>/dev/null || true)" == /dev/pts/* ]] || \
        die "/dev/ttyUSB9 verweist nicht auf die virtuelle GPS-Bridge."
fi

http_ok=false
for attempt in 1 2 3 4 5; do
    if curl --fail --silent --show-error --max-time 5 \
            --output /dev/null http://127.0.0.1:8081/; then
        http_ok=true
        break
    fi
    sleep 1
done
$http_ok || die "Der Witty-Webserver liefert auf Port 8081 keine gültige HTTP-Antwort."

log "Installiert in $app_dir"
log "Witty-Homepage: http://$(hostname):8081/"
log "Sicherung: $backup_dir"
