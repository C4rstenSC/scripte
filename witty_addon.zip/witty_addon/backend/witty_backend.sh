#!/usr/bin/env bash
set -Eeuo pipefail

# Privilegierter Befehlsadapter fuer die Witty-Pi-5-Webseite.
# Jeder wp5-Aufruf wird serialisiert; ein aktiver wp5d wird kurz angehalten und
# danach wieder gestartet. Dadurch entsteht keine zweite parallele wp5-Instanz.

readonly LOCK_FILE="/run/lock/witty-addon.lock"
readonly STATE_DIR="/var/lib/witty-addon"
readonly SELF_PATH="$(readlink -f "$0")"
readonly APP_DIR="$(dirname "$(dirname "$SELF_PATH")")"
readonly LOG_DIR="$APP_DIR/logs"
readonly LOG_PROGRESS_FILE="$LOG_DIR/.log-download-active"
readonly OFFSET_FILE="$STATE_DIR/fixed_offset_minutes"
readonly PREVIOUS_TZ_FILE="$STATE_DIR/previous_timezone"
readonly WP5_BIN="${WP5_BIN:-/usr/local/bin/wp5}"
mkdir -p "$STATE_DIR" "$LOG_DIR"
exec 9>"$LOCK_FILE"
flock -w 150 9 || { printf '{"ok":false,"error":"Witty ist beschaeftigt"}\n'; exit 1; }

json_escape() {
    local value="${1-}"
    value=${value//\\/\\\\}; value=${value//\"/\\\"}
    value=${value//$'\n'/\\n}; value=${value//$'\r'/\\r}; value=${value//$'\t'/\\t}
    printf '%s' "$value"
}

fail() { printf '{"ok":false,"error":"%s"}\n' "$(json_escape "$1")"; exit 1; }
success() { printf '{"ok":true,"message":"%s"}\n' "$(json_escape "${1:-OK}")"; }

find_wp5() {
    local candidate
    for candidate in "$WP5_BIN" /usr/bin/wp5 /usr/local/sbin/wp5 /home/*/Witty-Pi-5-Software/wp5 /home/*/witty-pi-5-software/wp5; do
        [[ -x "$candidate" ]] && { printf '%s\n' "$candidate"; return; }
    done
    return 1
}

run_wp5() {
    local input="$1" max_seconds="${2:-45}" working_dir="${3:-$STATE_DIR}" output service_was_active=0 wp5
    wp5="$(find_wp5)" || fail "wp5 wurde nicht gefunden"
    systemctl is-active --quiet wp5d.service && service_was_active=1 || true
    if (( service_was_active )); then
        systemctl stop wp5d.service || fail "wp5d konnte nicht angehalten werden"
    fi
    output="$(cd "$working_dir" && timeout "${max_seconds}s" "$wp5" <<<"$input" 2>&1)" || {
        local rc=$?
        (( service_was_active )) && systemctl start wp5d.service || true
        fail "wp5-Aufruf fehlgeschlagen (Code $rc): $output"
    }
    (( service_was_active )) && systemctl start wp5d.service || true
    printf '%s\n' "$output"
}

probe_wp5() {
    local input="$1" output service_was_active=0 wp5
    wp5="$(find_wp5)" || fail "wp5 wurde nicht gefunden"
    systemctl is-active --quiet wp5d.service && service_was_active=1 || true
    (( service_was_active )) && systemctl stop wp5d.service || true
    set +e
    output="$(cd "$STATE_DIR" && timeout 12s "$wp5" <<<"$input" 2>&1)"
    set -e
    (( service_was_active )) && systemctl start wp5d.service || true
    printf '%s\n' "$output"
}

remote_file_index() {
    local menu_option="$1" filename="$2" output escaped
    # Leere Eingabe bricht die Dateiauswahl ab, 5 verlaesst das Untermenue und
    # 14 beendet wp5. Ohne diese Eingaben wartet wp5 rekursiv bis zum Timeout.
    output="$(probe_wp5 $'6\n'"$menu_option"$'\n\n5\n14')"
    escaped="$(printf '%s' "$filename" | sed 's/[][\\.^$*+?{}|()]/\\&/g')"
    # Unterstützt u.a. "[1] name", "1) name", "1 - name" sowie
    # nachgestellte Kennzeichnungen wie "(in use)" oder "(active)".
    sed -nE "s/^[[:space:]]*[([]?([0-9]+)[])]?[[:space:].:-]+$escaped([[:space:]]+.*)?[[:space:]]*$/\\1/Ip" \
        <<<"$output" | tail -n1
}

local_file_index() {
    local filename="$1"
    find "$STATE_DIR" -maxdepth 1 -type f \
        \( -iname '*.wpi' -o -iname '*.act' -o -iname '*.skd' \) -printf '%f\n' 2>/dev/null \
        | sort -f | awk -v target="$filename" '$0 == target { print NR; exit }'
}

parse_remote_schedule_files() {
    sed -nE 's/^[[:space:]]*[([]?[0-9]+[])]?[[:space:].:-]+([^[:space:]]+\.wpi)([[:space:]]+.*)?[[:space:]]*$/\1/Ip' \
        | awk 'tolower($0) != "schedule.wpi" && $0 ~ /^[A-Za-z0-9][A-Za-z0-9._-]*\.wpi$/' | sort -fu
}

remote_activation_files() {
    probe_wp5 $'6\n2\n\n5\n14' | parse_remote_schedule_files
}

remote_download_files() {
    probe_wp5 $'6\n3\n\n5\n14' | parse_remote_schedule_files
}

remote_schedule_files() {
    { remote_activation_files; remote_download_files; } | sort -fu
}

infer_active_schedule_name() {
    local activation_file download_file candidate count
    activation_file="$(mktemp "$STATE_DIR/activation.XXXXXX")"
    download_file="$(mktemp "$STATE_DIR/download.XXXXXX")"
    remote_activation_files >"$activation_file"
    remote_download_files >"$download_file"
    candidate="$(comm -23 "$download_file" "$activation_file" | head -n1)"
    count="$(comm -23 "$download_file" "$activation_file" | sed '/^$/d' | wc -l)"
    rm -f -- "$activation_file" "$download_file"
    [[ "$count" -eq 1 ]] && printf '%s\n' "$candidate"
}

schedule_list_json() {
    local active inferred file separator=""
    if schedule_is_in_use; then
        active="$(tracked_schedule_name)"
        inferred="$(infer_active_schedule_name || true)"
        if [[ -n "$inferred" ]]; then
            active="$inferred"
            printf '%s\n' "$active" >"$STATE_DIR/active_schedule_name"
        fi
    else
        active=""
        rm -f -- "$STATE_DIR/active_schedule_name"
    fi
    printf '{"ok":true,"active":"%s","files":[' "$(json_escape "$active")"
    while IFS= read -r file; do
        [[ -n "$file" ]] || continue
        printf '%s"%s"' "$separator" "$(json_escape "$file")"
        separator=,
    done < <({ [[ -n "$active" ]] && printf '%s\n' "$active"; remote_schedule_files; find "$STATE_DIR" -maxdepth 1 -type f \
        -iname '*.wpi' ! -iname 'schedule.wpi' -printf '%f\n' 2>/dev/null; } | sort -fu)
    printf ']}\n'
}

schedule_is_in_use() {
    local output
    output="$(probe_wp5 $'14')"
    grep -qiE 'Manage schedule scripts.*\(in use\)|schedule scripts.*in use' <<<"$output"
}

expand_next_event() {
    local raw="$1" day clock candidate
    [[ "$raw" =~ ^([0-9]{1,2})[[:space:]]+([0-9]{2}:[0-9]{2}:[0-9]{2})$ ]] || { printf '%s\n' "$raw"; return; }
    day="${BASH_REMATCH[1]}"; clock="${BASH_REMATCH[2]}"
    candidate="$(date -d "$(date +%Y-%m)-$day $clock" --iso-8601=seconds 2>/dev/null || true)"
    if [[ -n "$candidate" ]] && (( $(date -d "$candidate" +%s) <= $(date +%s) )); then
        candidate="$(date -d "$(date -d 'next month' +%Y-%m)-$day $clock" --iso-8601=seconds 2>/dev/null || true)"
    fi
    printf '%s\n' "${candidate:-$raw}"
}

tracked_schedule_name() {
    local tracked
    tracked="$(cat "$STATE_DIR/active_schedule_name" 2>/dev/null || true)"
    printf '%s\n' "${tracked:-schedule.wpi}"
}

upload_local_schedule() {
    local filename="$1" local_index upload_output
    local_index="$(local_file_index "$filename")"
    [[ "$local_index" =~ ^[0-9]+$ ]] || fail "Die lokale Datei $filename wurde nicht gefunden"
    upload_output="$(run_wp5 $'6\n1\n'"$local_index"$'\n5\n14')"
    grep -Fqi "Uploaded $filename to Witty Pi." <<<"$upload_output" || \
        fail "Witty hat den Upload nicht bestaetigt: $upload_output"
    # Firmware-Datentraeger nach dem Schreiben kurz abschliessen lassen. Eine
    # sofortige Aktivierung liefert bei Firmware 1.6 gelegentlich I/O error.
    sleep 2
}

ACTIVATION_OUTPUT=""
activate_remote_schedule() {
    local filename="$1" attempt index
    ACTIVATION_OUTPUT=""
    for attempt in 1 2 3; do
        index="$(remote_file_index 2 "$filename")"
        # Ein bereits aktives Skript wird von der Aktivierungsliste verborgen.
        [[ "$index" =~ ^[0-9]+$ ]] || return 2
        ACTIVATION_OUTPUT="$(run_wp5 $'6\n2\n'"$index"$'\n5\n14')"
        if ! grep -qiE 'activation failed|failed|not found|invalid|requires firmware|timed out|I/O error' \
                <<<"$ACTIVATION_OUTPUT" \
                && grep -qiE 'Waiting for script processing.*done|Scheduled (startup|shutdown)' \
                <<<"$ACTIVATION_OUTPUT"; then
            return 0
        fi
        (( attempt < 3 )) && sleep 3
    done
    return 1
}

gps_time() {
    local value
    command -v gpspipe >/dev/null 2>&1 || return 1
    command -v jq >/dev/null 2>&1 || return 1
    # Sofort den ersten gültigen TPV-Fix verwenden. Die frühere Variante wartete
    # noch auf insgesamt zwölf gpsd-Meldungen und setzte dadurch eine alte Zeit.
    value="$(set +o pipefail; timeout 2.5s gpspipe -w 2>/dev/null | jq -er \
        'select(.class=="TPV" and (.mode // 0) >= 2 and .time) | .time' | head -n1)"
    [[ -n "$value" ]] || return 1
    printf '%s\n' "$value"
}

sync_internal_rtc() {
    local rtc_device
    rtc_device="$(internal_rtc_device || true)"
    if [[ -n "$rtc_device" ]] && command -v hwclock >/dev/null 2>&1; then
        timeout 8s hwclock --systohc --rtc "$rtc_device" >/dev/null 2>&1 || \
            fail "Systemzeit gesetzt, aber Raspberry-Pi-RTC konnte nicht geschrieben werden"
    fi
}

internal_rtc_device() {
    local rtc_path rtc_name device
    # Raspberry Pi 5 meldet seine interne RTC normalerweise als rtc-rp5c01;
    # die Nummer kann je nach weiteren RTC-Treibern rtc0 oder rtc1 sein.
    for rtc_path in /sys/class/rtc/rtc*; do
        [[ -d "$rtc_path" ]] || continue
        rtc_name="$(cat "$rtc_path/name" 2>/dev/null || true)"
        if [[ "$rtc_name" =~ (rp5c01|raspberry|rpi) ]]; then
            device="/dev/$(basename "$rtc_path")"
            [[ -e "$device" ]] && { printf '%s\n' "$device"; return 0; }
        fi
    done
    # Kompatibilitaets-Fallback fuer Kernel, die keinen eindeutigen Namen
    # bereitstellen. Es wird bewusst nicht nur rtc0 angenommen.
    for device in /dev/rtc0 /dev/rtc1 /dev/rtc2; do
        [[ -e "$device" ]] && { printf '%s\n' "$device"; return 0; }
    done
    return 1
}

normalise_display_time() {
    local value="$1" mode="${2:-local}" now_epoch value_epoch difference
    [[ -n "$value" ]] || return 0
    now_epoch="$(date +%s)"
    value_epoch="$(date -d "$value" +%s 2>/dev/null || true)"
    if [[ "$value_epoch" =~ ^[0-9]+$ ]]; then
        difference=$((now_epoch - value_epoch)); (( difference < 0 )) && difference=$((-difference))
        # RTCs zeigen nur ganze Sekunden. Werte innerhalb einer Sekunde gehören
        # zum selben Messzeitpunkt und werden auf den Antwortzeitpunkt gebracht.
        if (( difference <= 5 )); then
            [[ "$mode" == utc ]] && date -u --iso-8601=seconds || date --iso-8601=seconds
            return
        fi
    fi
    printf '%s\n' "$value"
}

timezone_name() {
    timedatectl show --property=Timezone --value 2>/dev/null || printf 'Europe/Berlin\n'
}

apply_fixed_timezone() {
    local enabled="$1" selected_zone="$2" current offset_text offset sign absolute hours minutes zone_source
    [[ "$enabled" == true || "$enabled" == false ]] || fail "Ungueltiger Umschaltwert"
    command -v timedatectl >/dev/null 2>&1 || fail "timedatectl wurde nicht gefunden"
    timedatectl list-timezones | grep -Fxq "$selected_zone" || fail "Ungueltige Zeitzone: $selected_zone"
    if [[ "$enabled" == true ]]; then
        command -v zic >/dev/null 2>&1 || fail "zic aus dem Paket tzdata wurde nicht gefunden"
        current="$(timezone_name)"
        printf '%s\n' "$selected_zone" >"$PREVIOUS_TZ_FILE"
        offset_text="$(TZ="$selected_zone" date +%z)"
        hours=$((10#${offset_text:1:2})); minutes=$((10#${offset_text:3:2}))
        offset=$((hours * 60 + minutes))
        if [[ "${offset_text:0:1}" == "-" ]]; then offset=$((-offset)); fi
        sign="+"
        if (( offset < 0 )); then sign="-"; fi
        absolute=$(( offset < 0 ? -offset : offset )); hours=$((absolute / 60)); minutes=$((absolute % 60))
        zone_source="$STATE_DIR/fixed-offset.zone"
        printf 'Zone Witty/FixedOffset %s%02d:%02d - WIT\n' "$sign" "$hours" "$minutes" >"$zone_source"
        zic -d /usr/share/zoneinfo "$zone_source" || fail "Feste Zeitzone konnte nicht erstellt werden"
        timedatectl set-timezone Witty/FixedOffset || fail "Feste Zeitzone konnte nicht aktiviert werden"
        printf '%s\n' "$offset" >"$OFFSET_FILE"
    else
        timedatectl set-timezone "$selected_zone" || fail "Zeitzone $selected_zone konnte nicht aktiviert werden"
        printf '%s\n' "$selected_zone" >"$PREVIOUS_TZ_FILE"
        offset_text="$(date +%z)"; hours=$((10#${offset_text:1:2})); minutes=$((10#${offset_text:3:2}))
        offset=$((hours * 60 + minutes))
        if [[ "${offset_text:0:1}" == "-" ]]; then offset=$((-offset)); fi
        printf '%s\n' "$offset" >"$OFFSET_FILE"
    fi
    run_wp5 $'1\n14' >/dev/null
}

status_action() {
    local output rtc_time model firmware voltage temperature startup shutdown active gps internal fixed_offset fixed_timezone selected_timezone
    # GPS und Witty laufen parallel. Zuvor begann die bis zu vier Sekunden
    # dauernde GPS-Abfrage erst nach dem vollständigen wp5-Aufruf.
    exec 8< <(gps_time || true)
    output="$(run_wp5 $'14')"
    model="$(sed -n 's/^  Model: //p' <<<"$output" | head -n1)"
    firmware="$(sed -nE 's/.*(Firmware|FW)([[:space:]]+Version)?[^0-9]*([0-9]+([.][0-9]+)+).*/\3/Ip' <<<"$output" | head -n1)"
    rtc_time="$(sed -n 's/^  RTC Time: *//p' <<<"$output" | head -n1)"
    voltage="$(sed -nE 's/.*V-(IN|USB): ([0-9.]+V).*/\2/p' <<<"$output" | head -n1)"
    temperature="$(sed -nE 's/^  Temperature: ([^ ]+).*/\1/p' <<<"$output" | head -n1)"
    startup="$(sed -nE 's/.*Schedule next startup *\[([^]]+)\].*/\1/p' <<<"$output" | head -n1)"
    shutdown="$(sed -nE 's/.*Schedule next shutdown *\[([^]]+)\].*/\1/p' <<<"$output" | head -n1)"
    startup="$(expand_next_event "$startup")"
    shutdown="$(expand_next_event "$shutdown")"
    if grep -qi 'schedule scripts.*in use' <<<"$output" || [[ -n "$startup$shutdown" ]]; then
        active="$(tracked_schedule_name)"
    else
        active=""
    fi
    IFS= read -r gps <&8 || gps=""
    exec 8<&-
    rtc_time="$(normalise_display_time "$rtc_time")"
    gps="$(normalise_display_time "$gps" utc)"
    [[ -n "$(internal_rtc_device || true)" ]] && internal=true || internal=false
    fixed_offset="$(cat "$OFFSET_FILE" 2>/dev/null || printf '60')"
    [[ "$(timezone_name)" == Witty/FixedOffset ]] && fixed_timezone=true || fixed_timezone=false
    selected_timezone="$(timezone_name)"
    [[ "$selected_timezone" == Witty/FixedOffset ]] && selected_timezone="$(cat "$PREVIOUS_TZ_FILE" 2>/dev/null || printf 'Etc/UTC')"
    printf '{"ok":true,"connected":true,"model":"%s","firmware":"%s","system_time":"%s","witty_time":"%s","gps_valid":%s,"gps_time":"%s","internal_rtc":%s,"fixed_offset_minutes":%s,"fixed_timezone":%s,"timezone":"%s","voltage":"%s","temperature":"%s","active_script":"%s","next_startup":"%s","next_shutdown":"%s"}\n' \
        "$(json_escape "$model")" "$(json_escape "$firmware")" "$(date --iso-8601=seconds)" "$(json_escape "$rtc_time")" \
        "$([[ -n "$gps" ]] && printf true || printf false)" "$(json_escape "$gps")" "$internal" \
        "$fixed_offset" "$fixed_timezone" "$(json_escape "$selected_timezone")" \
        "$(json_escape "$voltage")" "$(json_escape "$temperature")" "$(json_escape "$active")" \
        "$(json_escape "$startup")" "$(json_escape "$shutdown")"
}

write_uploaded_schedule() {
    local filename="$1" encoded="$2" target bytes lines
    local begin_text end_text begin_epoch end_epoch period=0 events=1 current duration token number factor state_line
    local -a durations=()
    [[ "$filename" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{0,59}\.wpi$ ]] || fail "Ungueltiger Dateiname"
    [[ "${filename,,}" != "schedule.wpi" ]] || fail "Der reservierte Dateiname schedule.wpi ist nicht erlaubt"
    target="$STATE_DIR/$filename"
    printf '%s' "$encoded" | base64 -d >"$target" 2>/dev/null || fail "Ungueltige Skriptdaten"
    bytes="$(wc -c <"$target")"
    (( bytes > 0 && bytes <= 4000 )) || fail "Das Skript muss 1 bis 4000 Byte enthalten"
    lines="$(grep -Eic '^[[:space:]]*(ON|OFF)[[:space:]]+' "$target" || true)"
    (( lines <= 128 )) || fail "Mehr als 128 ON/OFF-Zeilen"
    while IFS= read -r state_line; do
        (( $(printf '%s' "$state_line" | wc -c) < 128 )) || fail "Eine Skriptzeile ist mindestens 128 Byte lang"
    done <"$target"
    grep -Eq '^[[:space:]]*BEGIN[[:space:]]+[0-9]{4}-[0-9]{2}-[0-9]{2}[[:space:]]+[0-9]{2}:[0-9]{2}:[0-9]{2}' "$target" || fail "BEGIN fehlt oder ist ungueltig"
    grep -Eq '^[[:space:]]*END[[:space:]]+[0-9]{4}-[0-9]{2}-[0-9]{2}[[:space:]]+[0-9]{2}:[0-9]{2}:[0-9]{2}' "$target" || fail "END fehlt oder ist ungueltig"
    ! grep -q '[<|>]' "$target" || fail "Die Zeichen <, | und > sind nicht erlaubt"
    begin_text="$(sed -nE 's/^[[:space:]]*BEGIN[[:space:]]+([0-9-]+)[[:space:]]+([0-9:]+).*/\1 \2/p' "$target" | head -n1)"
    end_text="$(sed -nE 's/^[[:space:]]*END[[:space:]]+([0-9-]+)[[:space:]]+([0-9:]+).*/\1 \2/p' "$target" | head -n1)"
    begin_epoch="$(date -d "$begin_text" +%s 2>/dev/null)" || fail "BEGIN ist ungueltig"
    end_epoch="$(date -d "$end_text" +%s 2>/dev/null)" || fail "END ist ungueltig"
    (( end_epoch > begin_epoch )) || fail "END muss nach BEGIN liegen"
    while IFS= read -r state_line; do
        duration=0
        for token in ${state_line#* }; do
            [[ "$token" =~ ^([DHMS])([0-9]+)$ ]] || fail "Ungueltige ON/OFF-Dauer: $token"
            number="${BASH_REMATCH[2]}"
            case "${BASH_REMATCH[1]}" in D) factor=86400;; H) factor=3600;; M) factor=60;; S) factor=1;; esac
            duration=$((duration + number * factor))
        done
        durations+=("$duration"); period=$((period + duration))
    done < <(sed -nE 's/^[[:space:]]*(ON|OFF)[[:space:]]+([^#]+).*/\1 \2/p' "$target")
    (( period > 0 )) || fail "Die Periodendauer muss groesser als 0 sein"
    current="$begin_epoch"
    while (( current < end_epoch && events <= 4096 )); do
        for duration in "${durations[@]}"; do
            current=$((current + duration)); ((events += 1))
            (( current >= end_epoch || events > 4096 )) && break
        done
    done
    (( events <= 4096 )) || fail "Das Skript erzeugt mehr als 4096 Ereignisse"
}

emit_local_log() {
    local log_size log_view_bytes log_partial
    [[ -s "$LOG_DIR/WittyPi5.log" ]] || fail "Auf dem Raspberry ist keine gespeicherte LOG-Datei vorhanden"
    log_size="$(wc -c <"$LOG_DIR/WittyPi5.log")"
    log_view_bytes=524288
    if (( log_size < log_view_bytes )); then log_view_bytes="$log_size"; fi
    [[ -f "$LOG_DIR/.WittyPi5.partial" ]] && log_partial=true || log_partial=false
    printf '{"ok":true,"filename":"WittyPi5.log","size":%s,"view_size":%s,"truncated":%s,"partial":%s,"content_base64":"%s"}\n' \
        "$log_size" "$log_view_bytes" \
        "$([[ "$log_size" -gt "$log_view_bytes" ]] && printf true || printf false)" \
        "$log_partial" "$(tail -c "$log_view_bytes" "$LOG_DIR/WittyPi5.log" | base64 -w0)"
}

action="${1:-status}"
case "$action" in
    status) status_action ;;
    system_to_witty) run_wp5 $'1\n14' >/dev/null; success "Systemzeit wurde in die Witty-RTC geschrieben" ;;
    witty_to_system) run_wp5 $'2\n14' >/dev/null; success "Witty-RTC wurde als Systemzeit uebernommen" ;;
    manual_to_witty)
        [[ "${2:-}" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}(:[0-9]{2})?$ ]] || fail "Ungueltige Zeit"
        date --set="${2/T/ }" >/dev/null
        run_wp5 $'1\n14' >/dev/null
        success "Zeit wurde gesetzt und in die Witty-RTC geschrieben"
        ;;
    gps_to_system)
        value="$(gps_time || true)"; [[ -n "$value" ]] || fail "Keine gueltige GPS-Zeit"
        date --set="$value" >/dev/null
        sync_internal_rtc
        success "GPS-Zeit wurde als Systemzeit und Raspberry-Pi-RTC uebernommen"
        ;;
    gps_to_witty)
        value="$(gps_time || true)"; [[ -n "$value" ]] || fail "Keine gueltige GPS-Zeit"
        date --set="$value" >/dev/null
        sync_internal_rtc
        run_wp5 $'1\n14' >/dev/null
        success "GPS-Zeit wurde in System-, Raspberry-Pi- und Witty-RTC geschrieben"
        ;;
    fixed_timezone)
        apply_fixed_timezone "${2:-}" "${3:-}"
        success "Zeitzoneneinstellung wurde übernommen und die Witty-RTC synchronisiert"
        ;;
    clear_schedule)
        clear_output="$(run_wp5 $'12\n1\n12\n2\n12\n3\n14')"
        if grep -qiE 'Failed to clear|Failed to stop|admin status|no response' <<<"$clear_output"; then
            fail "Zeitplan konnte nicht vollständig deaktiviert werden: $(grep -iE 'Failed to clear|Failed to stop|admin status|no response' <<<"$clear_output" | tail -n1 | sed 's/^[[:space:]]*//')"
        fi
        grep -Fq 'Scheduled startup time is cleared!' <<<"$clear_output" || fail "Der nächste Starttermin wurde nicht bestätigt gelöscht"
        grep -Fq 'Scheduled shutdown time is cleared!' <<<"$clear_output" || fail "Der nächste Abschalttermin wurde nicht bestätigt gelöscht"
        grep -Fq 'Schedule script is not being used now!' <<<"$clear_output" || fail "Die Skript-Deaktivierung wurde von Witty nicht bestätigt"
        rm -f -- "$STATE_DIR/active_schedule_name"
        success "Zeitplan, nächster Start und nächstes Herunterfahren wurden deaktiviert"
        ;;
    schedule_list) schedule_list_json ;;
    schedule_activate)
        filename="${2:-}"
        [[ "$filename" =~ ^[A-Za-z0-9._-]{1,64}$ ]] || fail "Ungueltiger Skriptname"
        index="$(remote_file_index 2 "$filename")"
        if [[ ! "$index" =~ ^[0-9]+$ && -f "$STATE_DIR/$filename" ]]; then
            upload_local_schedule "$filename"
        fi
        activation_rc=0
        activate_remote_schedule "$filename" || activation_rc=$?
        if (( activation_rc != 0 )); then
            (( activation_rc == 2 )) && fail "Skript $filename wird nicht als aktivierbar aufgelistet"
            fail "Witty konnte $filename auch nach drei Versuchen nicht aktivieren. Letzte Firmwaremeldung: $(grep -iE 'activation failed|I/O error|invalid|not found' <<<"$ACTIVATION_OUTPUT" | tail -n1 | sed 's/^[[:space:]]*//' || printf 'keine Detailmeldung')"
        fi
        printf '%s\n' "$filename" >"$STATE_DIR/active_schedule_name"
        success "Skript $filename wurde aktiviert"
        ;;
    schedule_delete)
        filename="${2:-}"
        [[ "$filename" =~ ^[A-Za-z0-9._-]{1,64}$ ]] || fail "Ungueltiger Skriptname"
        if schedule_is_in_use && [[ "$filename" == "$(tracked_schedule_name)" ]]; then
            fail "Das aktive Skript muss vor dem Loeschen deaktiviert oder gewechselt werden"
        fi
        index="$(remote_file_index 4 "$filename")"
        [[ "$index" =~ ^[0-9]+$ ]] || fail "Skript $filename wird nicht als loeschbar aufgelistet"
        delete_output="$(run_wp5 $'6\n4\n'"$index"$'\ny\n5\n14')"
        if grep -qiE 'failed|not found|invalid|requires firmware|timed out|cannot delete' <<<"$delete_output"; then
            fail "Skript konnte nicht geloescht werden: $delete_output"
        fi
        rm -f -- "$STATE_DIR/$filename"
        success "Skript $filename wurde geloescht"
        ;;
    read_schedule)
        filename="$(tracked_schedule_name)"
        if [[ "$filename" == "schedule.wpi" ]]; then
            inferred="$(infer_active_schedule_name || true)"
            if [[ -n "$inferred" ]]; then
                filename="$inferred"
                printf '%s\n' "$filename" >"$STATE_DIR/active_schedule_name"
            fi
        fi
        if [[ -f "$STATE_DIR/$filename" ]]; then
            printf '{"ok":true,"filename":"%s","content_base64":"%s"}\n' \
                "$(json_escape "$filename")" "$(base64 -w0 "$STATE_DIR/$filename")"
            exit 0
        fi
        remote_name="$filename"
        index="$(remote_file_index 3 "$remote_name")"
        if [[ ! "$index" =~ ^[0-9]+$ ]]; then
            inferred="$(infer_active_schedule_name || true)"
            if [[ -n "$inferred" ]]; then
                remote_name="$inferred"
                filename="$inferred"
                printf '%s\n' "$filename" >"$STATE_DIR/active_schedule_name"
                index="$(remote_file_index 3 "$remote_name")"
            fi
        fi
        if [[ ! "$index" =~ ^[0-9]+$ ]]; then
            remote_name="schedule"
            index="$(remote_file_index 3 "$remote_name")"
        fi
        [[ "$index" =~ ^[0-9]+$ ]] || fail "Zeitplan ist aktiv, aber die Firmware listet die interne Quelldatei weder als schedule.wpi noch als schedule zum Download auf"
        rm -f -- "$STATE_DIR/$filename" "$STATE_DIR/schedule" "$STATE_DIR/schedule.wpi"
        run_wp5 $'6\n3\n'"$index"$'\n5\n14' >/dev/null
        downloaded_file=""
        for candidate in "$STATE_DIR/$filename" "$STATE_DIR/$remote_name" "$STATE_DIR/schedule" "$STATE_DIR/schedule.wpi"; do
            [[ -f "$candidate" ]] && { downloaded_file="$candidate"; break; }
        done
        [[ -n "$downloaded_file" ]] || fail "Aktuelles Skript konnte nicht gelesen werden"
        printf '{"ok":true,"filename":"%s","content_base64":"%s"}\n' \
            "$(json_escape "$filename")" "$(base64 -w0 "$downloaded_file")"
        ;;
    read_log)
        download_dir="$LOG_DIR/download"
        log_partial=false
        mkdir -p "$download_dir"
        if [[ ! -s "$LOG_DIR/WittyPi5.log" ]]; then
            existing_log="$(find "$LOG_DIR" -maxdepth 2 -type f -iname '*.log' ! -path "$LOG_DIR/WittyPi5.log" -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -n1 | cut -d' ' -f2- || true)"
            if [[ -n "$existing_log" && -s "$existing_log" ]]; then
                install -m 0644 "$existing_log" "$LOG_DIR/WittyPi5.log"
            fi
        fi
        # Eine bereits vollstaendig gesicherte Datei sofort anzeigen. Damit
        # fuehrt "Log laden" nicht bei jedem Klick erneut den langsamen
        # Firmwaretransfer aus. Nach "Lokale Logs loeschen" wird neu geladen.
        if [[ ! -s "$LOG_DIR/WittyPi5.log" ]]; then
            find "$download_dir" -maxdepth 3 -type f -iname '*.log' -delete
            : >"$LOG_PROGRESS_FILE"
            trap 'rm -f -- "$LOG_PROGRESS_FILE"' EXIT
            log_settings="$(probe_wp5 $'11\n14\n14')"
            log_was_enabled=false
            if grep -qiE 'Log to file on Witty Pi.*\[Yes\]' <<<"$log_settings"; then
                log_was_enabled=true
            fi
            if $log_was_enabled; then
                pause_output="$(run_wp5 $'11\n12\n0\n14' 15 "$download_dir")"
                grep -Fqi 'Do not write log file on Witty Pi!' <<<"$pause_output" || \
                    fail "Die laufende Firmware-Protokollierung konnte für den Download nicht pausiert werden"
            fi
            save_rc=0; download_rc=0; restore_rc=0; save_output=""; log_output=""; restore_output=""
            set +e
            save_output="$(run_wp5 $'13\n6\n9\n14' 20 "$download_dir")"; save_rc=$?
            if (( save_rc == 0 )); then
                log_output="$(run_wp5 $'13\n7\n9\n14' 300 "$download_dir")"; download_rc=$?
            fi
            if $log_was_enabled; then
                restore_output="$(run_wp5 $'11\n12\n1\n14' 15 "$download_dir")"; restore_rc=$?
            fi
            set -e
            downloaded_log="$(find "$download_dir" -maxdepth 3 -type f -iname '*.log' -size +0c -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -n1 | cut -d' ' -f2- || true)"
            (( restore_rc == 0 )) || fail "Die Firmware-Protokollierung konnte nach dem Download nicht wieder aktiviert werden"
            (( save_rc == 0 )) || fail "Firmware-Log konnte nicht als Snapshot gespeichert werden: $save_output"
            if (( download_rc != 0 )); then
                [[ -n "$downloaded_log" && -s "$downloaded_log" ]] || fail "Firmware-Log konnte nicht heruntergeladen werden: $log_output"
                log_partial=true
            fi
            [[ -n "$downloaded_log" && -s "$downloaded_log" ]] || \
                fail "Die Firmware hat keine lesbare LOG-Datei bereitgestellt: $(grep -iE 'failed|error|not found|timed out' <<<"$log_output" | tail -n1 | sed 's/^[[:space:]]*//' || printf 'keine Detailmeldung')"
            install -m 0644 "$downloaded_log" "$LOG_DIR/WittyPi5.log"
            if $log_partial; then touch "$LOG_DIR/.WittyPi5.partial"; else rm -f -- "$LOG_DIR/.WittyPi5.partial"; fi
            rm -f -- "$LOG_PROGRESS_FILE"
            trap - EXIT
        fi
        emit_local_log
        ;;
    read_local_log) emit_local_log ;;
    delete_log)
        find "$LOG_DIR" -maxdepth 2 -type f -iname '*.log' -delete
        rm -f -- "$LOG_DIR/.WittyPi5.partial" "$LOG_PROGRESS_FILE"
        success "Alle lokalen LOG-Dateien wurden aus dem Witty-Webserver-Verzeichnis geloescht"
        ;;
    upload_schedule)
        filename="${2:-}"
        write_uploaded_schedule "$filename" "${3:-}"
        replaced_active=false
        if schedule_is_in_use && [[ "$filename" == "$(tracked_schedule_name)" ]]; then
            clear_output="$(run_wp5 $'12\n1\n12\n2\n12\n3\n14')"
            grep -Fq 'Scheduled startup time is cleared!' <<<"$clear_output" || fail "Das aktive Skript konnte vor dem Ersetzen nicht abgeschaltet werden"
            grep -Fq 'Scheduled shutdown time is cleared!' <<<"$clear_output" || fail "Das aktive Skript konnte vor dem Ersetzen nicht abgeschaltet werden"
            grep -Fq 'Schedule script is not being used now!' <<<"$clear_output" || fail "Die Skript-Deaktivierung wurde von Witty nicht bestätigt"
            rm -f -- "$STATE_DIR/active_schedule_name"
            replaced_active=true
        fi
        upload_local_schedule "$filename"
        # Die Download-Liste zeigt auch das aktive Skript; die Aktivierungsliste
        # blendet es aus. Fuer die reine Upload-Bestaetigung daher Option 3 nutzen.
        index="$(remote_file_index 3 "$filename")"
        if [[ ! "$index" =~ ^[0-9]+$ ]]; then
            available="$(remote_schedule_files | paste -sd ', ' -)"
            fail "Das hochgeladene Skript $filename wurde nicht in der Witty-Liste gefunden. Gefunden: ${available:-keine Dateien}"
        fi
        if $replaced_active; then
            upload_message="Das bisher aktive Skript $filename wurde abgeschaltet und ersetzt. Alle Skripte sind deaktiviert; die neue Version kann manuell aktiviert werden"
        else
            upload_message="Skript $filename wurde auf Witty kopiert. Die Aktivierung erfolgt manuell über die Skriptliste"
        fi
        printf '{"ok":true,"message":"%s","filename":"%s","deactivated":%s}\n' \
            "$(json_escape "$upload_message")" \
            "$(json_escape "$filename")" "$replaced_active"
        ;;
    service_start|service_stop)
        service="${2:-}"
        case "$service:$action" in
            wurb_2026:service_start) service_state="on"; service_command="$(command -v wurb-service || true)" ;;
            wurb_2026:service_stop) service_state="off"; service_command="$(command -v wurb-service || true)" ;;
            wirc_2026:service_start) service_state="on"; service_command="$(command -v wirc-service || true)" ;;
            wirc_2026:service_stop) service_state="off"; service_command="$(command -v wirc-service || true)" ;;
            *) fail "Dienst nicht erlaubt" ;;
        esac
        [[ -n "$service_command" ]] || fail "Der Befehl fuer den Dienst wurde nicht gefunden"
        timeout 30s "$service_command" "$service_state" || fail "$service_command $service_state ist fehlgeschlagen"
        success "sudo $(basename "$service_command") $service_state wurde ausgefuehrt"
        ;;
    shutdown) success "Raspberry Pi wird heruntergefahren"; (sleep 2; systemctl poweroff) >/dev/null 2>&1 & ;;
    internal_rtc_toggle)
        fail "Die interne Pi-5-RTC kann nicht sicher zur Laufzeit deaktiviert werden"
        ;;
    *) fail "Unbekannte Aktion" ;;
esac
