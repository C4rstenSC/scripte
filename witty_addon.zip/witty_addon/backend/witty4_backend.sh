#!/usr/bin/env bash
set -Eeuo pipefail
readonly HOME4="${WITTY4_HOME:-/home/wurb/wittypi}"
readonly STATE_DIR="/var/lib/witty-addon"
readonly APP_DIR="$(dirname "$(dirname "$(readlink -f "$0")")")"
readonly LOG_DIR="$APP_DIR/logs"
mkdir -p "$STATE_DIR" "$LOG_DIR"
exec 9>/run/lock/witty-addon.lock
flock -w 30 9 || { echo '{"ok":false,"error":"Witty ist beschäftigt"}'; exit 1; }

esc(){ local s="${1-}"; s=${s//\\/\\\\}; s=${s//\"/\\\"}; s=${s//$'\n'/\\n}; printf %s "$s"; }
fail(){ printf '{"ok":false,"error":"%s"}\n' "$(esc "$1")"; exit 1; }
ok(){ printf '{"ok":true,"message":"%s"}\n' "$(esc "${1:-OK}")"; }
[[ -r "$HOME4/utilities.sh" ]] || fail "Witty-Pi-4-Software fehlt in $HOME4"
# shellcheck disable=SC1090
source "$HOME4/utilities.sh"
firmware_id="$(i2c_read 1 0x08 0 2>/dev/null || true)"
[[ "$firmware_id" =~ ^0x(26|37)$ ]] || fail "Witty Pi 4 wurde an I2C-Adresse 0x08 nicht erkannt"

validate_name(){ [[ "$1" =~ ^[A-Za-z0-9][A-Za-z0-9._-]{0,58}\.wpi$ ]] || fail "Ungültiger Skriptname"; }
emit_file(){ printf '{"ok":true,"filename":"%s","content_base64":"%s"}\n' "$(esc "$1")" "$(base64 -w0 "$2")"; }
detect_gps_mode(){
  local device
  if [[ -e /etc/systemd/system/wurb-gps-bridge.service ]] || systemctl list-unit-files --no-legend 2>/dev/null | awk '{print $1}' | grep -qx 'wurb-gps-bridge.service'; then echo waveshare_l76x; return; fi
  for device in /dev/ttyACM* /dev/ttyUSB*; do [[ -e "$device" ]] || continue; [[ "$device" == /dev/ttyUSB9 ]] && continue; echo usb; return; done
  echo unknown
}
action="${1:-status}"
case "$action" in
 status)
  gps_mode="unknown"; [[ -r /etc/witty-addon.conf ]] && source /etc/witty-addon.conf; gps_mode="${GPS_MODE:-unknown}"
  if [[ "$gps_mode" != none && "$gps_mode" != usb && "$gps_mode" != waveshare_l76x ]]; then gps_mode="$(detect_gps_mode)"; fi
  fw="$(i2c_read 1 0x08 12 2>/dev/null || true)"; fw=$((fw))
  rtc="$(get_rtc_time 2>/dev/null || true)"; temp="$(get_temperature 2>/dev/null || true)"
  start="$(get_startup_time 2>/dev/null || true)"; stop="$(get_shutdown_time 2>/dev/null || true)"
  active=""; [[ -s "$HOME4/schedule.wpi" ]] && active="schedule.wpi"
  printf '{"ok":true,"connected":true,"model":"Witty Pi 4","firmware":"%s","system_time":"%s","witty_time":"%s","gps_mode":"%s","gps_valid":false,"gps_time":"","internal_rtc":false,"voltage":"","temperature":"%s","active_script":"%s","next_startup":"%s","next_shutdown":"%s"}\n' "$fw" "$(date --iso-8601=seconds)" "$(esc "$rtc")" "$(esc "$gps_mode")" "$(esc "$temp")" "$active" "$(esc "$start")" "$(esc "$stop")" ;;
 system_to_witty) system_to_rtc >/dev/null; ok "Systemzeit wurde in die Witty-Pi-4-RTC geschrieben" ;;
 witty_to_system) rtc_to_system >/dev/null; ok "Witty-Pi-4-RTC wurde als Systemzeit übernommen" ;;
 manual_to_witty) date --set="${2/T/ }" >/dev/null; system_to_rtc >/dev/null; ok "Zeit wurde gesetzt" ;;
 gps_to_system) v="$(timeout 3s gpspipe -w 2>/dev/null | jq -er 'select(.class=="TPV" and (.mode//0)>=2 and .time)|.time' | head -1)"; date --set="$v" >/dev/null; ok "GPS-Zeit übernommen" ;;
 gps_to_witty) v="$(timeout 3s gpspipe -w 2>/dev/null | jq -er 'select(.class=="TPV" and (.mode//0)>=2 and .time)|.time' | head -1)"; date --set="$v" >/dev/null; system_to_rtc >/dev/null; ok "GPS-Zeit in System und Witty-RTC geschrieben" ;;
 schedule_list)
  printf '{"ok":true,"active":"%s","files":[' "$([[ -s "$HOME4/schedule.wpi" ]] && echo schedule.wpi)"; sep=""
  for f in "$HOME4"/schedules/*.wpi; do [[ -f "$f" ]] || continue; printf '%s"%s"' "$sep" "$(esc "$(basename "$f")")"; sep=,; done; echo ']}' ;;
 upload_schedule)
  name="${2:-}"; validate_name "$name"; printf %s "${3:-}" | base64 -d >"$HOME4/schedules/$name" || fail "Ungültige Skriptdaten"; chmod 644 "$HOME4/schedules/$name"; ok "Skript wurde auf den Raspberry kopiert und kann manuell aktiviert werden" ;;
 schedule_activate)
  name="${2:-}"; validate_name "$name"; [[ -f "$HOME4/schedules/$name" ]] || fail "Skript nicht gefunden"; install -m 644 "$HOME4/schedules/$name" "$HOME4/schedule.wpi"; timeout 30s "$HOME4/runScript.sh" 0 revise >/dev/null 2>&1 || fail "Skript konnte nicht aktiviert werden"; printf %s "$name" >"$STATE_DIR/active_schedule_name"; ok "Skript wurde aktiviert" ;;
 clear_schedule) rm -f "$HOME4/schedule.wpi"; clear_startup_time; clear_shutdown_time; rm -f "$STATE_DIR/active_schedule_name"; ok "Zeitplan deaktiviert" ;;
 schedule_delete) name="${2:-}"; validate_name "$name"; rm -f -- "$HOME4/schedules/$name"; ok "Skript gelöscht" ;;
 read_named_schedule) name="${2:-}"; validate_name "$name"; [[ -f "$HOME4/schedules/$name" ]] || fail "Skript nicht gefunden"; emit_file "$name" "$HOME4/schedules/$name" ;;
 read_schedule) [[ -s "$HOME4/schedule.wpi" ]] || fail "Kein aktives Skript"; emit_file "$(cat "$STATE_DIR/active_schedule_name" 2>/dev/null || echo schedule.wpi)" "$HOME4/schedule.wpi" ;;
 read_log|read_local_log) cat "$HOME4/wittyPi.log" "$HOME4/schedule.log" 2>/dev/null >"$LOG_DIR/WittyPi4.log"; printf '{"ok":true,"filename":"WittyPi4.log","size":%s,"view_size":%s,"truncated":false,"partial":false,"content_base64":"%s"}\n' "$(wc -c <"$LOG_DIR/WittyPi4.log")" "$(wc -c <"$LOG_DIR/WittyPi4.log")" "$(tac "$LOG_DIR/WittyPi4.log" | base64 -w0)" ;;
 delete_log) rm -f "$LOG_DIR"/*.log; ok "Lokale Logs gelöscht" ;;
 fixed_timezone) timedatectl set-timezone "${3:-Etc/UTC}"; system_to_rtc >/dev/null; ok "Zeitzone übernommen" ;;
 shutdown) ok "Raspberry Pi wird heruntergefahren"; (sleep 2; systemctl poweroff) >/dev/null 2>&1 & ;;
 service_start|service_stop) svc="${2:-}"; [[ "$svc" =~ ^(wurb_2026|wirc_2026)$ ]] || fail "Dienst nicht erlaubt"; systemctl "${action#service_}" "$svc.service"; ok "Dienstbefehl ausgeführt" ;;
 internal_rtc_toggle) fail "Raspberry Pi 4 besitzt keine interne RTC" ;;
 *) fail "Aktion wird von Witty Pi 4 nicht unterstützt" ;;
esac
