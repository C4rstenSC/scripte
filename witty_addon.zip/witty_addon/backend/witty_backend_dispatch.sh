#!/usr/bin/env bash
set -Eeuo pipefail

model=""
if [[ -r /etc/witty-addon.conf ]]; then
  set -a
  source /etc/witty-addon.conf
  set +a
fi
model="${WITTY_MODEL:-$model}"
case "$model" in
  4) exec "$(dirname "$0")/witty4_backend.sh" "$@" ;;
  5) exec "$(dirname "$0")/witty5_backend.sh" "$@" ;;
esac

# For legacy installations, select only hardware that actually responds.
if command -v wp5 >/dev/null 2>&1 && timeout 10s wp5 <<<'14' 2>&1 | grep -q 'Model: Witty Pi 5'; then
  exec "$(dirname "$0")/witty5_backend.sh" "$@"
fi
if [[ -r "${WITTY4_HOME:-/home/wurb/wittypi}/utilities.sh" ]] && [[ "$(i2cget -y 1 0x08 0 2>/dev/null || true)" =~ ^0x(26|37)$ ]]; then
  exec "$(dirname "$0")/witty4_backend.sh" "$@"
fi
printf '{"ok":false,"error":"Keine passende Witty-Pi-4/5-Hardware erkannt"}\n'
exit 1
