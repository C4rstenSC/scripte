<?php
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'POST required']);
    exit;
}
$request = json_decode(file_get_contents('php://input'), true);
$action = $request['action'] ?? '';
$allowed = [
    'status', 'system_to_witty', 'witty_to_system', 'manual_to_witty',
    'gps_to_system', 'gps_to_witty', 'clear_schedule', 'read_schedule',
    'upload_schedule', 'shutdown', 'internal_rtc_toggle',
    'service_start', 'service_stop'
];
if (!in_array($action, $allowed, true)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Action not allowed']);
    exit;
}
$arguments = [$action];
if ($action === 'manual_to_witty') {
    $arguments[] = $request['value'] ?? '';
} elseif ($action === 'upload_schedule') {
    $arguments[] = $request['filename'] ?? '';
    $arguments[] = $request['content_base64'] ?? '';
} elseif ($action === 'service_start' || $action === 'service_stop') {
    $arguments[] = $request['service'] ?? '';
}
$command = 'sudo -n /usr/local/lib/witty-addon/witty_backend.sh';
foreach ($arguments as $argument) {
    $command .= ' ' . escapeshellarg($argument);
}
$output = [];
$returnCode = 0;
exec($command . ' 2>&1', $output, $returnCode);
$body = implode("\n", $output);
$decoded = json_decode($body, true);
if ($returnCode !== 0 || !is_array($decoded) || empty($decoded['ok'])) {
    http_response_code(502);
    echo is_array($decoded) ? json_encode($decoded) : json_encode(['ok' => false, 'error' => $body]);
    exit;
}
echo json_encode($decoded);

