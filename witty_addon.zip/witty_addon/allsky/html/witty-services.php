<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function navigationInstallationExists($names)
{
    $parents = array_merge(['/home'], glob('/home/*', GLOB_ONLYDIR) ?: []);
    $wanted = array_map('strtolower', $names);
    foreach ($parents as $parent) {
        foreach (glob($parent . '/*', GLOB_ONLYDIR) ?: [] as $directory) {
            if (in_array(strtolower(basename($directory)), $wanted, true)) {
                return true;
            }
        }
    }
    return false;
}

echo json_encode([
    'wurb' => navigationInstallationExists(['wurb_2026']),
    'wirc' => navigationInstallationExists(['wirc_2026']),
    'allsky' => navigationInstallationExists(['allsky']),
    'witty' => navigationInstallationExists([
        'wittypi', 'wittypi5', 'witty-pi-5-software', 'wp5'
    ])
]);
