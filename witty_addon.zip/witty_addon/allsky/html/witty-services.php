<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function navigationInstallationExists($names)
{
    $parents = array_merge(['/home'], glob('/home/*', GLOB_ONLYDIR) ?: []);
    $wanted = array_map('strtolower', $names);
    foreach ($parents as $parent) {
        foreach (glob($parent . '/*', GLOB_ONLYDIR) ?: [] as $directory) {
            if (in_array(strtolower(basename($directory)), $wanted, true)) {
                return true;
            }
        }
    }
    return false;
}

function allskyInstallationExists()
{
    foreach (array_merge(['/home'], glob('/home/*', GLOB_ONLYDIR) ?: []) as $parent) {
        $candidate = $parent . '/allsky';
        if (is_dir($candidate) && (
            is_file($candidate . '/allsky.sh')
            || is_file($candidate . '/variables.sh')
            || is_file($candidate . '/install.sh')
        )) {
            return true;
        }
    }
    return false;
}

echo json_encode([
    'wurb' => navigationInstallationExists(['wurb_2026']),
    'wirc' => navigationInstallationExists(['wirc_2026']),
    'allsky' => allskyInstallationExists(),
    'witty' => is_file('/usr/local/bin/wp5')
        || is_file('/usr/bin/wp5')
        || navigationInstallationExists([
            'wittypi', 'wittypi5', 'witty-pi-5-software', 'wp5'
        ])
]);
