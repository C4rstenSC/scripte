#!/usr/bin/env bash
set -Eeuo pipefail

# Privilegierter Befehlsadapter fuer die Witty-Pi-5-Webseite.
# Jeder wp5-Aufruf wird serialisiert; ein aktiver wp5d wird kurz angehalten und
# danach wieder gestartet. Dadurch entsteht keine zweite parallele wp5-Instanz.

readonly LOCK_FILE="/run/lock/witty-addon.lock"
readonly STATE_DIR="/var/lib/witty-addon"
readonly WP5_BIN="${WP5_BIN:-/usr/local/bin/wp5}"
mkdir -p "$STATE_DIR"
exec 9>"$LOCK_FILE"
flock -w 30 9 || { printf '{"ok":false,"error":"Witty ist beschaeftigt"}\n'; exit 1; }

json_escape() {
    local value="${1-}"
    value=${value//\\/\\\\}; value=${value//\"/\\\"}
    value=${value//$'\n'/\\n}; value=${value//$'\r'/\\r}; value=${value//$'\t'/\\t}
    printf '%s' "$value"
}

fail() { printf '{"ok":false,"error":"%s"}\n' "$(json_escape "$1")"; exit 1; }
success() { printf '{"ok":true,"message":"%s"}\n' "$(json_escape "${1:-OK}")"; }

find_wp5() {
    local candidate
    for candidate in "$WP5_BIN" /usr/bin/wp5 /usr/local/sbin/wp5 /home/*/Witty-Pi-5-Software/wp5 /home/*/witty-pi-5-software/wp5; do
        [[ -x "$candidate" ]] && { printf '%s\n' "$candidate"; return; }
    done
    return 1
}

run_wp5() {
    local input="$1" output service_was_active=0 wp5
    wp5="$(find_wp5)" || fail "wp5 wurde nicht gefunden"
    systemctl is-active --quiet wp5d.service && service_was_active=1 || true
    if (( service_was_active )); then
        systemctl stop wp5d.service || fail "wp5d konnte nicht angehalten werden"
    fi
    output="$(cd "$STATE_DIR" && timeout 45s "$wp5" <<<"$input" 2>&1)" || {
        local rc=$?
        (( service_was_active )) && systemctl start wp5d.service || true
        fail "wp5-Aufruf fehlgeschlagen (Code $rc): $output"
    }
    (( service_was_active )) && systemctl start wp5d.service || true
    printf '%s\n' "$output"
}

probe_wp5() {
    local input="$1" output service_was_active=0 wp5
    wp5="$(find_wp5)" || fail "wp5 wurde nicht gefunden"
    systemctl is-active --quiet wp5d.service && service_was_active=1 || true
    (( service_was_active )) && systemctl stop wp5d.service || true
    set +e
    output="$(cd "$STATE_DIR" && timeout 12s "$wp5" <<<"$input" 2>&1)"
    set -e
    (( service_was_active )) && systemctl start wp5d.service || true
    printf '%s\n' "$output"
}

remote_file_index() {
    local menu_option="$1" filename="$2" output escaped
    output="$(probe_wp5 $'6\n'"$menu_option")"
    escaped="$(printf '%s' "$filename" | sed 's/[][\\.^$*+?{}|()]/\\&/g')"
    sed -nE "s/^[[:space:]]*\\[([0-9]+)\\][[:space:]]+$escaped[[:space:]]*$/\\1/p" <<<"$output" | tail -n1
}

gps_time() {
    command -v gpspipe >/dev/null 2>&1 || return 1
    command -v jq >/dev/null 2>&1 || return 1
    timeout 4s gpspipe -w -n 12 2>/dev/null | jq -r \
        'select(.class=="TPV" and (.mode // 0) >= 2 and .time) | .time' | tail -n1
}

status_action() {
    local output rtc_time model voltage temperature startup shutdown active gps internal
    output="$(run_wp5 $'14')"
    model="$(sed -n 's/^  Model: //p' <<<"$output" | head -n1)"
    rtc_time="$(sed -n 's/^  RTC Time: *//p' <<<"$output" | head -n1)"
    voltage="$(sed -nE 's/.*V-(IN|USB): ([0-9.]+V).*/\2/p' <<<"$output" | head -n1)"
    temperature="$(sed -nE 's/^  Temperature: ([^ ]+).*/\1/p' <<<"$output" | head -n1)"
    startup="$(sed -nE 's/.*Schedule next startup *\[([^]]+)\].*/\1/p' <<<"$output" | head -n1)"
    shutdown="$(sed -nE 's/.*Schedule next shutdown *\[([^]]+)\].*/\1/p' <<<"$output" | head -n1)"
    if grep -q 'Manage schedule scripts.*(in use)' <<<"$output"; then
        active="$(cat "$STATE_DIR/active_schedule_name" 2>/dev/null || true)"
        [[ -n "$active" ]] || active="schedule.wpi"
    else
        active=""
    fi
    gps="$(gps_time || true)"
    [[ -e /dev/rtc0 ]] && internal=true || internal=false
    printf '{"ok":true,"connected":true,"model":"%s","system_time":"%s","witty_time":"%s","gps_valid":%s,"gps_time":"%s","internal_rtc":%s,"voltage":"%s","temperature":"%s","active_script":"%s","next_startup":"%s","next_shutdown":"%s"}\n' \
        "$(json_escape "$model")" "$(date --iso-8601=seconds)" "$(json_escape "$rtc_time")" \
        "$([[ -n "$gps" ]] && printf true || printf false)" "$(json_escape "$gps")" "$internal" \
        "$(json_escape "$voltage")" "$(json_escape "$temperature")" "$(json_escape "$active")" \
        "$(json_escape "$startup")" "$(json_escape "$shutdown")"
}

write_uploaded_schedule() {
    local filename="$1" encoded="$2" target bytes lines
    local begin_text end_text begin_epoch end_epoch period=0 events=1 current duration token number factor state_line
    local -a durations=()
    [[ "$filename" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}\.wpi$|^schedule\.wpi$ ]] || fail "Ungueltiger Dateiname"
    target="$STATE_DIR/$filename"
    printf '%s' "$encoded" | base64 -d >"$target" 2>/dev/null || fail "Ungueltige Skriptdaten"
    bytes="$(wc -c <"$target")"
    (( bytes > 0 && bytes <= 4000 )) || fail "Das Skript muss 1 bis 4000 Byte enthalten"
    lines="$(grep -Eic '^[[:space:]]*(ON|OFF)[[:space:]]+' "$target" || true)"
    (( lines <= 128 )) || fail "Mehr als 128 ON/OFF-Zeilen"
    while IFS= read -r state_line; do
        (( $(printf '%s' "$state_line" | wc -c) < 128 )) || fail "Eine Skriptzeile ist mindestens 128 Byte lang"
    done <"$target"
    grep -Eq '^BEGIN [0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}' "$target" || fail "BEGIN fehlt oder ist ungueltig"
    grep -Eq '^END [0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}' "$target" || fail "END fehlt oder ist ungueltig"
    ! grep -q '[<|>]' "$target" || fail "Die Zeichen <, | und > sind nicht erlaubt"
    begin_text="$(sed -nE 's/^BEGIN ([0-9-]+ [0-9:]+).*/\1/p' "$target" | head -n1)"
    end_text="$(sed -nE 's/^END ([0-9-]+ [0-9:]+).*/\1/p' "$target" | head -n1)"
    begin_epoch="$(date -d "$begin_text" +%s 2>/dev/null)" || fail "BEGIN ist ungueltig"
    end_epoch="$(date -d "$end_text" +%s 2>/dev/null)" || fail "END ist ungueltig"
    (( end_epoch > begin_epoch )) || fail "END muss nach BEGIN liegen"
    while IFS= read -r state_line; do
        duration=0
        for token in ${state_line#* }; do
            [[ "$token" =~ ^([DHMS])([0-9]+)$ ]] || fail "Ungueltige ON/OFF-Dauer: $token"
            number="${BASH_REMATCH[2]}"
            case "${BASH_REMATCH[1]}" in D) factor=86400;; H) factor=3600;; M) factor=60;; S) factor=1;; esac
            duration=$((duration + number * factor))
        done
        durations+=("$duration"); period=$((period + duration))
    done < <(sed -nE 's/^[[:space:]]*(ON|OFF)[[:space:]]+([^#]+).*/\1 \2/p' "$target")
    (( period > 0 )) || fail "Die Periodendauer muss groesser als 0 sein"
    current="$begin_epoch"
    while (( current < end_epoch && events <= 4096 )); do
        for duration in "${durations[@]}"; do
            current=$((current + duration)); ((events += 1))
            (( current >= end_epoch || events > 4096 )) && break
        done
    done
    (( events <= 4096 )) || fail "Das Skript erzeugt mehr als 4096 Ereignisse"
}

action="${1:-status}"
case "$action" in
    status) status_action ;;
    system_to_witty) run_wp5 $'1\n14' >/dev/null; success "Systemzeit wurde in die Witty-RTC geschrieben" ;;
    witty_to_system) run_wp5 $'2\n14' >/dev/null; success "Witty-RTC wurde als Systemzeit uebernommen" ;;
    manual_to_witty)
        [[ "${2:-}" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}(:[0-9]{2})?$ ]] || fail "Ungueltige Zeit"
        date --set="${2/T/ }" >/dev/null
        run_wp5 $'1\n14' >/dev/null
        success "Zeit wurde gesetzt und in die Witty-RTC geschrieben"
        ;;
    gps_to_system)
        value="$(gps_time || true)"; [[ -n "$value" ]] || fail "Keine gueltige GPS-Zeit"
        date --set="$value" >/dev/null; success "GPS-Zeit wurde als Systemzeit uebernommen"
        ;;
    gps_to_witty)
        value="$(gps_time || true)"; [[ -n "$value" ]] || fail "Keine gueltige GPS-Zeit"
        date --set="$value" >/dev/null; run_wp5 $'1\n14' >/dev/null
        success "GPS-Zeit wurde in die Witty-RTC geschrieben"
        ;;
    clear_schedule) run_wp5 $'12\n3\n14' >/dev/null; success "Zeitplan wurde deaktiviert" ;;
    read_schedule)
        filename="$(cat "$STATE_DIR/active_schedule_name" 2>/dev/null || printf 'schedule.wpi')"
        index="$(remote_file_index 3 "$filename")"
        [[ "$index" =~ ^[0-9]+$ ]] || fail "Aktives Skript '$filename' wurde auf Witty nicht gefunden"
        rm -f -- "$STATE_DIR/$filename"
        run_wp5 $'6\n3\n'"$index"$'\n5\n14' >/dev/null
        [[ -f "$STATE_DIR/$filename" ]] || fail "Aktuelles Skript konnte nicht gelesen werden"
        printf '{"ok":true,"filename":"%s","content_base64":"%s"}\n' \
            "$(json_escape "$filename")" "$(base64 -w0 "$STATE_DIR/$filename")"
        ;;
    read_log)
        rm -f -- "$STATE_DIR/WittyPi5.log"
        run_wp5 $'13\n7\n9\n14' >/dev/null
        [[ -f "$STATE_DIR/WittyPi5.log" ]] || fail "WittyPi5.log konnte nicht vom Witty gelesen werden"
        log_size="$(wc -c <"$STATE_DIR/WittyPi5.log")"
        (( log_size <= 5242880 )) || fail "WittyPi5.log ist groesser als 5 MiB"
        printf '{"ok":true,"filename":"WittyPi5.log","size":%s,"content_base64":"%s"}\n' \
            "$log_size" "$(base64 -w0 "$STATE_DIR/WittyPi5.log")"
        ;;
    upload_schedule)
        filename="${2:-}"
        write_uploaded_schedule "$filename" "${3:-}"
        run_wp5 $'6\n1\n'"$filename"$'\n5\n14' >/dev/null
        index="$(remote_file_index 2 "$filename")"
        [[ "$index" =~ ^[0-9]+$ ]] || fail "Das hochgeladene Skript wurde auf Witty nicht gefunden"
        run_wp5 $'6\n2\n'"$index"$'\n5\n14' >/dev/null
        printf '%s\n' "$filename" >"$STATE_DIR/active_schedule_name"
        success "Skript $filename wurde auf Witty kopiert und aktiviert"
        ;;
    service_start|service_stop)
        service="${2:-}"
        case "$service:$action" in
            wurb_2026:service_start) service_state="on"; other_unit="wirc_2026.service" ;;
            wurb_2026:service_stop) service_state="off"; other_unit="wirc_2026.service" ;;
            wirc_2026:service_start) service_state="on"; other_unit="wurb_2026.service" ;;
            wirc_2026:service_stop) service_state="off"; other_unit="wurb_2026.service" ;;
            *) fail "Dienst nicht erlaubt" ;;
        esac
        systemctl is-active --quiet "$other_unit" && other_was_active=1 || other_was_active=0
        systemd-run --quiet --collect --on-active=2s \
            --unit="witty-addon-${service}-${RANDOM}" \
            /usr/local/lib/witty-addon/witty_backend.sh service_apply \
            "$service" "$service_state" "$other_was_active"
        success "Dienstaktion wurde eingeplant"
        ;;
    service_apply)
        service="${2:-}"; service_state="${3:-}"; other_was_active="${4:-0}"
        [[ "$service_state" == on || "$service_state" == off ]] || fail "Dienstzustand nicht erlaubt"
        case "$service" in
            wurb_2026)
                service_command="$(command -v wurb-service || true)"
                other_unit="wirc_2026.service"; other_command="$(command -v wirc-service || true)"
                ;;
            wirc_2026)
                service_command="$(command -v wirc-service || true)"
                other_unit="wurb_2026.service"; other_command="$(command -v wurb-service || true)"
                ;;
            *) fail "Dienst nicht erlaubt" ;;
        esac
        [[ -n "$service_command" ]] || fail "Der Befehl fuer den Dienst wurde nicht gefunden"
        "$service_command" "$service_state"
        if [[ "$other_was_active" == 1 ]] && ! systemctl is-active --quiet "$other_unit"; then
            [[ -n "$other_command" ]] && "$other_command" on
        fi
        success "sudo $service_command $service_state wurde ausgefuehrt"
        ;;
    shutdown) success "Raspberry Pi wird heruntergefahren"; (sleep 2; systemctl poweroff) >/dev/null 2>&1 & ;;
    internal_rtc_toggle)
        fail "Die interne Pi-5-RTC kann nicht sicher zur Laufzeit deaktiviert werden"
        ;;
    *) fail "Unbekannte Aktion" ;;
esac
