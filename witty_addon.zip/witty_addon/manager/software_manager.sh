#!/usr/bin/env bash
set -Eeuo pipefail

# This component manager is intentionally limited to WURB, WIRC and Allsky.
# It is launched by the local Witty web service and never provides a shell.
readonly ACTION="${1:-}"
readonly COMPONENT="${2:-}"
readonly APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
readonly WURB_REPO="https://github.com/cloudedbats/wurb_2026.git"
readonly WIRC_REPO="https://github.com/cloudedbats/wirc_2026.git"
readonly ALLSKY_REPO="https://github.com/AllskyTeam/allsky.git"
readonly PATCHER="/usr/local/lib/wittypi5-webserver/patch_navigation.py"

[[ "$EUID" -eq 0 ]] || { echo "FEHLER: Softwareverwaltung benötigt Root-Rechte."; exit 1; }
[[ "$ACTION" =~ ^(install|uninstall)$ ]] || { echo "FEHLER: Ungültige Aktion."; exit 2; }
[[ "$COMPONENT" =~ ^(wurb|wirc|allsky)$ ]] || { echo "FEHLER: Ungültige Software."; exit 2; }
export DEBIAN_FRONTEND=noninteractive

ensure_user() {
    if ! id wurb >/dev/null 2>&1; then
        useradd --create-home --shell /bin/bash wurb
    fi
    usermod -aG dialout,sudo,audio,video wurb
}

run_as_wurb() {
    runuser -u wurb -- env HOME=/home/wurb "$@"
}

update_or_clone() {
    local url="$1" destination="$2"
    if [[ -d "$destination/.git" ]]; then
        run_as_wurb git -C "$destination" pull --ff-only
    elif [[ -e "$destination" ]]; then
        echo "FEHLER: $destination existiert, ist aber kein Git-Repository."
        exit 1
    else
        run_as_wurb git clone --depth 1 "$url" "$destination"
    fi
}

patch_pages() {
    [[ -x "$PATCHER" || -f "$PATCHER" ]] || return 0
    [[ -f /home/wurb/wurb_2026/wurb_app/templates/index.html ]] && \
        python3 "$PATCHER" --kind wurb --file /home/wurb/wurb_2026/wurb_app/templates/index.html || true
    [[ -f /home/wurb/wirc_2026/wirc_app/templates/index.html ]] && \
        python3 "$PATCHER" --kind wirc --file /home/wurb/wirc_2026/wirc_app/templates/index.html || true
    [[ -f /home/wurb/allsky/html/index.php ]] && \
        python3 "$PATCHER" --kind allsky --file /home/wurb/allsky/html/index.php || true
}

install_service_commands() {
    install -d -m 0755 /usr/local/sbin
    install -m 0755 "$APP_DIR/manager/wurb-service" /usr/local/sbin/wurb-service
    install -m 0755 "$APP_DIR/manager/wirc-service" /usr/local/sbin/wirc-service
}

install_wurb() {
    echo "=== WURB-2026 wird installiert ==="
    ensure_user
    apt-get update
    apt-get install -y python3-venv python3-pip python3-dev git alsa-utils ffmpeg \
        libasound2-dev libopenblas-dev pmount python3-pyaudio portaudio19-dev usbutils
    update_or_clone "$WURB_REPO" /home/wurb/wurb_2026
    chown -R wurb:wurb /home/wurb/wurb_2026
    run_as_wurb bash -lc 'set -e; cd /home/wurb/wurb_2026; python3 -m venv venv; . venv/bin/activate; python -m pip install --upgrade pip; if [[ -f requirements.txt ]]; then python -m pip install --no-cache-dir -r requirements.txt; fi; python -X faulthandler -c "import numpy; import scipy; print(\"NumPy/SciPy OK\")"'
    for pair in \
        "usb_pmount.rules:/etc/udev/rules.d/usb_pmount.rules:0644" \
        "usb_pmount_handler@.service:/lib/systemd/system/usb_pmount_handler@.service:0644" \
        "usb_pmount_script:/usr/local/bin/usb_pmount_script:0755" \
        "pettersson_m500_batmic.rules:/etc/udev/rules.d/pettersson_m500_batmic.rules:0644"; do
        IFS=: read -r source target mode <<<"$pair"
        [[ -f "/home/wurb/wurb_2026/raspberrypi_files/$source" ]] && \
            install -m "$mode" "/home/wurb/wurb_2026/raspberrypi_files/$source" "$target"
    done
    service_source=/home/wurb/wurb_2026/raspberrypi_files/wurb_2026.service
    [[ -f "$service_source" ]] || { echo "FEHLER: WURB-Servicevorlage fehlt."; exit 1; }
    install -m 0644 "$service_source" /etc/systemd/system/wurb_2026.service
    install_service_commands
    if [[ -r /etc/witty-addon.conf ]]; then
        # shellcheck disable=SC1091
        source /etc/witty-addon.conf
    fi
    if [[ "${GPS_MODE:-none}" =~ ^(usb|waveshare_l76x)$ && -x /usr/local/sbin/witty-gps-manager ]]; then
        /usr/local/sbin/witty-gps-manager configure "$GPS_MODE"
    fi
    udevadm control --reload-rules || true
    systemctl daemon-reload
    systemctl enable wurb_2026.service
    systemctl reset-failed wurb_2026.service || true
    systemctl start wurb_2026.service
    patch_pages
    echo "=== WURB-2026 wurde erfolgreich installiert ==="
}

install_wirc() {
    echo "=== WIRC-2026 wird installiert ==="
    ensure_user
    apt-get update
    apt-get install -y python3-venv python3-pip git python3-picamera2 python3-opencv ffmpeg
    update_or_clone "$WIRC_REPO" /home/wurb/wirc_2026
    chown -R wurb:wurb /home/wurb/wirc_2026
    run_as_wurb bash -lc 'set -e; cd /home/wurb/wirc_2026; python3 -m venv --system-site-packages venv; . venv/bin/activate; python -m pip install --upgrade pip; if [[ -f requirements.txt ]]; then python -m pip install --no-cache-dir -r requirements.txt; fi'
    service_source=/home/wurb/wirc_2026/raspberrypi_files/wirc_2026.service
    if [[ -f "$service_source" ]]; then
        install -m 0644 "$service_source" /etc/systemd/system/wirc_2026.service
    else
        install -m 0644 "$APP_DIR/manager/wirc_2026.service" /etc/systemd/system/wirc_2026.service
    fi
    install_service_commands
    systemctl daemon-reload
    systemctl enable wirc_2026.service
    systemctl reset-failed wirc_2026.service || true
    systemctl start wirc_2026.service
    patch_pages
    echo "=== WIRC-2026 wurde erfolgreich installiert ==="
}

install_allsky() {
    echo "=== Allsky wird installiert ==="
    echo "ACHTUNG: Für die Erstinstallation muss mindestens eine unterstützte Kamera angeschlossen sein."
    ensure_user
    apt-get update
    apt-get install -y git curl wget ca-certificates build-essential make gcc g++ pkg-config cmake \
        gawk dialog jq bc rsync unzip zip usbutils v4l-utils python3 python3-pip python3-venv \
        python3-dev network-manager
    apt-get install -y jc || true
    update_or_clone "$ALLSKY_REPO" /home/wurb/allsky
    chown -R wurb:wurb /home/wurb/allsky
    # The official installer may restart the Pi before this manager returns.
    # Prepare the one-shot navigation and dependency finaliser first.
    systemctl enable wittypi5-allsky-firstboot.service >/dev/null 2>&1 || true
    echo "Der offizielle Allsky-Installer startet jetzt. Antworten bitte unten eingeben und mit Enter senden."
    run_as_wurb bash -lc 'cd /home/wurb/allsky && bash ./install.sh'
    systemctl daemon-reload
    systemctl show --property=LoadState --value allsky.service | grep -Fxq loaded || {
        echo "FEHLER: Allsky wurde beendet, aber allsky.service fehlt."; exit 1;
    }
    if [[ -x /usr/local/lib/wittypi5-webserver/finalize_allsky.sh ]]; then
        /usr/local/lib/wittypi5-webserver/finalize_allsky.sh
    else
        patch_pages
        systemctl reload lighttpd.service || true
    fi
    echo "=== Allsky wurde erfolgreich installiert ==="
}

archive_project() {
    local project="$1" name="$2" backup_root="$3"
    if [[ -e "$project" ]]; then
        mkdir -p "$backup_root"
        mv -- "$project" "$backup_root/$name"
        echo "Projekt wurde zur Wiederherstellung gesichert: $backup_root/$name"
    fi
}

remove_unit_file() {
    local unit="$1" fragment
    fragment="$(systemctl show --property=FragmentPath --value "$unit" 2>/dev/null || true)"
    if [[ "$fragment" == /etc/systemd/system/* && -f "$fragment" ]]; then
        rm -f -- "$fragment"
    fi
}

uninstall_component() {
    local backup_root="/var/backups/witty-addon-uninstall/$(date +%Y%m%d-%H%M%S)-$COMPONENT"
    echo "=== $COMPONENT wird deinstalliert ==="
    case "$COMPONENT" in
        wurb)
            systemctl disable --now wurb_2026.service || true
            remove_unit_file wurb_2026.service
            rm -rf -- /etc/systemd/system/wurb_2026.service.d
            rm -f -- /usr/local/sbin/wurb-service
            archive_project /home/wurb/wurb_2026 wurb_2026 "$backup_root"
            ;;
        wirc)
            systemctl disable --now wirc_2026.service || true
            remove_unit_file wirc_2026.service
            rm -f -- /usr/local/sbin/wirc-service
            archive_project /home/wurb/wirc_2026 wirc_2026 "$backup_root"
            ;;
        allsky)
            systemctl disable --now allskyperiodic.timer allsky.service || true
            systemctl stop allskyperiodic.service || true
            remove_unit_file allskyperiodic.timer
            remove_unit_file allskyperiodic.service
            remove_unit_file allsky.service
            archive_project /home/wurb/allsky allsky "$backup_root"
            ;;
    esac
    systemctl daemon-reload
    patch_pages
    systemctl reload lighttpd.service || true
    echo "=== Deinstallation abgeschlossen; Benutzerdaten außerhalb des Projektordners wurden nicht gelöscht ==="
}

if [[ "$ACTION" == install ]]; then
    "install_$COMPONENT"
else
    uninstall_component
fi
