#!/usr/bin/env python3
import json
import mimetypes
import pathlib
import shutil
import subprocess
from datetime import datetime
from zoneinfo import ZoneInfo, available_timezones
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

APP_DIR = pathlib.Path(__file__).resolve().parent.parent
WEB_DIR = APP_DIR / "web"
BACKEND = APP_DIR / "backend" / "witty_backend.sh"
PORT = 8081


def project_installed(name):
    if name == "allsky":
        # Ein bloss vorhandener /opt/allsky- oder ~/allsky-Ordner kann von
        # einem abgebrochenen Installer stammen. Allsky gilt erst dann als
        # installiert, wenn Programm, Konfiguration und Weboberflaeche da sind.
        candidates = (
            pathlib.Path("/home/wurb/allsky"),
            pathlib.Path("/home/pi/allsky"),
            pathlib.Path("/home/allsky/allsky"),
            pathlib.Path("/opt/allsky"),
        )
        return any(
            (path / "allsky.sh").is_file()
            and (path / "config/config.sh").is_file()
            and (path / "html/index.php").is_file()
            for path in candidates
        )
    candidates = (pathlib.Path("/home/wurb") / name,
                  pathlib.Path("/home/pi") / name,
                  pathlib.Path("/opt") / name)
    if name == "wurb_2026":
        return any((path / "wurb_main.py").is_file()
                   and (path / "wurb_app/templates/index.html").is_file()
                   for path in candidates)
    if name == "wirc_2026":
        return any((path / "wirc_main.py").is_file()
                   and (path / "wirc_app/templates/index.html").is_file()
                   for path in candidates)
    return False


def service_active(name):
    try:
        return subprocess.run(
            ["systemctl", "is-active", "--quiet", name], timeout=3
        ).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def navigation_status():
    return {
        "wurb": project_installed("wurb_2026"),
        "wirc": project_installed("wirc_2026"),
        "allsky": project_installed("allsky"),
        "wurb_active": service_active("wurb_2026.service"),
        "wirc_active": service_active("wirc_2026.service"),
        "witty": pathlib.Path("/usr/local/bin/wp5").is_file()
                 or pathlib.Path("/usr/bin/wp5").is_file(),
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "wittypi5-webserver/1.0"

    def send_response_headers(self, status=200, content_type="application/json; charset=utf-8"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_OPTIONS(self):
        self.send_response_headers(204)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/navigation":
            self.send_response_headers()
            self.wfile.write(json.dumps(navigation_status()).encode())
            return
        if path == "/api/timezones":
            current_zone = subprocess.run(
                ["timedatectl", "show", "--property=Timezone", "--value"],
                capture_output=True, text=True, timeout=3
            ).stdout.strip() or "Etc/UTC"
            representatives = {}
            ordered_names = [current_zone] + sorted(available_timezones() - {current_zone})
            now = datetime.now()
            for name in ordered_names:
                try:
                    delta = now.replace(tzinfo=ZoneInfo(name)).utcoffset()
                    minutes = int(delta.total_seconds() // 60)
                    representatives.setdefault(minutes, name)
                except (ValueError, OSError):
                    continue
            zones = [{"minutes": value, "timezone": representatives[value]}
                     for value in sorted(representatives)]
            self.send_response_headers()
            self.wfile.write(json.dumps({"ok": True, "zones": zones,
                                         "current_timezone": current_zone}).encode())
            return
        if path == "/api/log-progress":
            log_dir = APP_DIR / "logs"
            candidates = [item for item in log_dir.glob("download/**/*.log") if item.is_file()]
            received = max((item.stat().st_size for item in candidates), default=0)
            self.send_response_headers()
            self.wfile.write(json.dumps({
                "ok": True,
                "active": (log_dir / ".log-download-active").is_file(),
                "received_bytes": received,
                "local_available": (log_dir / "WittyPi5.log").is_file()
                                   and (log_dir / "WittyPi5.log").stat().st_size > 0,
            }).encode())
            return
        if path == "/logs/WittyPi5.log":
            target = APP_DIR / "logs" / "WittyPi5.log"
            if not target.is_file():
                self.send_response_headers(404)
                self.wfile.write(b'{"ok":false,"error":"Log not found"}')
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Disposition", 'attachment; filename="WittyPi5.log"')
            self.send_header("Content-Length", str(target.stat().st_size))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with target.open("rb") as source:
                shutil.copyfileobj(source, self.wfile, length=64 * 1024)
            return
        files = {
            "/": WEB_DIR / "index.html",
            "/index.html": WEB_DIR / "index.html",
            "/assets/bulma-v1.0.4.min.css": WEB_DIR / "assets" / "bulma-v1.0.4.min.css",
            "/assets/cloudedbats_logo.png": WEB_DIR / "assets" / "cloudedbats_logo.png",
        }
        target = files.get(path)
        if not target or not target.is_file():
            self.send_response_headers(404)
            self.wfile.write(b'{"ok":false,"error":"Not found"}')
            return
        mime = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response_headers(200, mime)
        self.wfile.write(target.read_bytes())

    def do_POST(self):
        if urlparse(self.path).path != "/api":
            self.send_response_headers(404); self.wfile.write(b'{"ok":false,"error":"Not found"}'); return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 2 or length > 8 * 1024 * 1024:
                raise ValueError("Invalid request size")
            request = json.loads(self.rfile.read(length))
            action = request.get("action", "")
            allowed = {
                "status", "system_to_witty", "witty_to_system", "manual_to_witty",
                "gps_to_system", "gps_to_witty", "clear_schedule", "read_schedule",
                "upload_schedule", "read_log", "read_local_log", "delete_log", "shutdown", "internal_rtc_toggle",
                "service_start", "service_stop",
                "fixed_timezone",
                "schedule_list", "schedule_activate", "schedule_delete",
            }
            if action not in allowed:
                raise ValueError("Action not allowed")
            arguments = [str(BACKEND), action]
            if action == "manual_to_witty":
                arguments.append(str(request.get("value", "")))
            elif action == "upload_schedule":
                arguments.extend((str(request.get("filename", "")), str(request.get("content_base64", ""))))
            elif action in {"service_start", "service_stop"}:
                arguments.append(str(request.get("service", "")))
            elif action == "fixed_timezone":
                arguments.extend((str(bool(request.get("enabled", False))).lower(),
                                  str(request.get("timezone", "Etc/UTC"))))
            elif action in {"schedule_activate", "schedule_delete"}:
                arguments.append(str(request.get("filename", "")))
            result = subprocess.run(arguments, capture_output=True, text=True, timeout=420)
            try:
                payload = json.loads(result.stdout or "{}")
            except json.JSONDecodeError:
                detail = (result.stderr or result.stdout or "").strip()[-2000:]
                payload = {"ok": False, "error": detail or "Backend lieferte keine gültige JSON-Antwort"}
            if not payload.get("ok") and not payload.get("error"):
                detail = (result.stderr or result.stdout or "").strip()[-2000:]
                payload["error"] = detail or f"Backend wurde mit Code {result.returncode} beendet"
            status = 200 if result.returncode == 0 and payload.get("ok") else 502
        except Exception as error:
            status, payload = 400, {"ok": False, "error": str(error)}
        self.send_response_headers(status)
        self.wfile.write(json.dumps(payload).encode())

    def log_message(self, fmt, *args):
        print("wittypi5-webserver:", fmt % args, flush=True)


if __name__ == "__main__":
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
