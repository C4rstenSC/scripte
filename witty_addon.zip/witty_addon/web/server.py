#!/usr/bin/env python3
import json
import mimetypes
import os
import pathlib
import re
import shutil
import subprocess
import time
import uuid
import zipfile
from datetime import datetime
from zoneinfo import ZoneInfo, available_timezones
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlparse

APP_DIR = pathlib.Path(__file__).resolve().parent.parent
WEB_DIR = APP_DIR / "web"
BACKEND = APP_DIR / "backend" / "witty_backend.sh"
PORT = 8081
DOWNLOAD_DIR = APP_DIR / "downloads"
RECORDING_KINDS = {"wurb": "wurb_recordings", "wirc": "wirc_recordings"}
RECORDING_SUFFIXES = {"wurb": {".wav"}, "wirc": {".h264", ".mp4", ".mkv"}}


def is_recording_file(kind, path):
    return path.is_file() and not path.is_symlink() and path.suffix.lower() in RECORDING_SUFFIXES[kind]


def validate_upload_filename(kind, filename):
    filename = str(filename).strip()
    if (not filename or filename in {".", ".."} or "/" in filename or "\\" in filename
            or pathlib.Path(filename).name != filename):
        raise ValueError("Invalid filename")
    if pathlib.Path(filename).suffix.lower() not in RECORDING_SUFFIXES[kind]:
        raise ValueError("File type is not allowed for this recording page")
    return filename


def project_path(name):
    candidates = (pathlib.Path("/home/wurb") / name,
                  pathlib.Path("/home/pi") / name,
                  pathlib.Path("/opt") / name)
    if name == "wurb_2026":
        return next((path for path in candidates if (path / "wurb_main.py").is_file()
                     and (path / "wurb_app/templates/index.html").is_file()), None)
    if name == "wirc_2026":
        return next((path for path in candidates if (path / "wirc_main.py").is_file()
                     and (path / "wirc_app/templates/index.html").is_file()), None)
    return None


def project_installed(name):
    if name == "allsky":
        # Ein bloss vorhandener /opt/allsky- oder ~/allsky-Ordner kann von
        # einem abgebrochenen Installer stammen. Allsky gilt erst dann als
        # installiert, wenn Programm, Konfiguration und Weboberflaeche da sind.
        candidates = (
            pathlib.Path("/home/wurb/allsky"),
            pathlib.Path("/home/pi/allsky"),
            pathlib.Path("/home/allsky/allsky"),
            pathlib.Path("/opt/allsky"),
        )
        return any(
            (path / "allsky.sh").is_file()
            and (path / "config/config.sh").is_file()
            and (path / "html/index.php").is_file()
            for path in candidates
        )
    if name in {"wurb_2026", "wirc_2026"}:
        return project_path(name) is not None
    return False


def yaml_scalar(value):
    """Decode the simple scalar values used by CloudedBats record.targets."""
    value = value.split(" #", 1)[0].strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        value = value[1:-1]
    if value.lower() in {"true", "yes"}:
        return True
    if value.lower() in {"false", "no"}:
        return False
    try:
        return float(value)
    except ValueError:
        return value


def configured_record_targets(config_path):
    """Read record.targets without adding a PyYAML dependency to the webserver."""
    if not config_path.is_file():
        return []
    targets, current = [], None
    in_record = in_targets = False
    for raw_line in config_path.read_text(encoding="utf-8", errors="replace").splitlines():
        if not raw_line.strip() or raw_line.lstrip().startswith("#"):
            continue
        indent = len(raw_line) - len(raw_line.lstrip(" "))
        stripped = raw_line.strip()
        if indent == 0:
            in_record = stripped == "record:"
            in_targets = False
            continue
        if in_record and indent == 2:
            in_targets = stripped == "targets:"
            continue
        if not in_targets:
            continue
        if indent <= 2:
            break
        if indent == 4 and stripped.startswith("-"):
            if current:
                targets.append(current)
            current = {}
            stripped = stripped[1:].strip()
            if ":" in stripped:
                key, value = stripped.split(":", 1)
                current[key.strip()] = yaml_scalar(value)
        elif current is not None and indent >= 6 and ":" in stripped:
            key, value = stripped.split(":", 1)
            current[key.strip()] = yaml_scalar(value)
    if current:
        targets.append(current)
    return targets


def target_recording_path(project, target, require_free_space=True):
    rec_dir = str(target.get("rec_dir", "")).strip()
    if not rec_dir or str(target.get("os", "Linux")) not in {"", "Linux"}:
        return None
    rec_path = pathlib.Path(rec_dir)
    media_value = str(target.get("media_path", "")).strip()
    if rec_path.is_absolute():
        base, candidate = rec_path.parent, rec_path
    elif bool(target.get("executable_path_as_base", False)):
        base, candidate = project, project / rec_path
    elif media_value:
        base = pathlib.Path(media_value)
        if not base.is_mount():
            return None
        candidate = base / rec_path
    else:
        base, candidate = project, project / rec_path
    try:
        free_limit = float(target.get("free_disk_limit", 100)) * (2 ** 20)
        if not base.exists() or (require_free_space and shutil.disk_usage(base).free < free_limit):
            return None
        candidate.mkdir(parents=True, exist_ok=True)
        return candidate.resolve()
    except (OSError, TypeError, ValueError):
        return None


def recording_target_choices(kind):
    if kind not in RECORDING_KINDS:
        raise ValueError("Unknown recording type")
    project = project_path(f"{kind}_2026")
    if project is None:
        raise FileNotFoundError(f"{kind.upper()}-2026 is not installed")
    config_path = project.parent / f"{kind}_settings" / f"{kind}_config.yaml"
    default_path = project / f"{kind}_config_default.yaml"
    targets = configured_record_targets(config_path)
    if not targets:
        targets = configured_record_targets(default_path)
    active_path = next((path for configured_target in targets
                        if (path := target_recording_path(project, configured_target, True)) is not None), None)
    choices, used_ids = [], set()
    for index, configured_target in enumerate(targets, 1):
        path = target_recording_path(project, configured_target, False)
        if path is None:
            continue
        base_id = str(configured_target.get("id", "")).strip() or f"target-{index}"
        target_id, suffix = base_id, 2
        while target_id in used_ids:
            target_id = f"{base_id}-{suffix}"; suffix += 1
        used_ids.add(target_id)
        choices.append({"id": target_id,
                        "name": str(configured_target.get("name", "")).strip() or base_id,
                        "path": path,
                        "active": active_path is not None and path == active_path})
    if not choices:
        fallback = project.parent / RECORDING_KINDS[kind]
        fallback.mkdir(parents=True, exist_ok=True)
        choices.append({"id": "local", "name": "Local", "path": fallback.resolve(), "active": True})
    elif not any(choice["active"] for choice in choices):
        choices[0]["active"] = True
    return choices


def recording_root(kind, target_id="", strict=False):
    choices = recording_target_choices(kind)
    if target_id:
        selected = next((choice for choice in choices if choice["id"] == target_id), None)
        if selected is not None:
            return selected["path"]
        if strict:
            raise ValueError("Selected recording target is not available")
    return next((choice["path"] for choice in choices if choice["active"]), choices[0]["path"])


def safe_recording_path(root, relative="", must_exist=True):
    value = str(relative or "").replace("\\", "/")
    candidate_relative = pathlib.PurePosixPath(value)
    if candidate_relative.is_absolute() or ".." in candidate_relative.parts:
        raise ValueError("Invalid path")
    candidate = (root / pathlib.Path(*candidate_relative.parts)).resolve(strict=must_exist)
    if candidate != root and root not in candidate.parents:
        raise ValueError("Path outside recording directory")
    return candidate


def deletion_sources(root, kind, relative_paths):
    if not isinstance(relative_paths, list) or not relative_paths:
        raise ValueError("No files or folders selected")
    candidates = []
    for relative in dict.fromkeys(str(value) for value in relative_paths):
        source = safe_recording_path(root, relative)
        if source == root or source.is_symlink() or not (source.is_dir() or is_recording_file(kind, source)):
            raise ValueError(f"Can not delete {source.name}")
        candidates.append(source)
    candidates.sort(key=lambda item: len(item.parts))
    selected_roots = []
    for source in candidates:
        if not any(parent in selected_roots for parent in source.parents):
            selected_roots.append(source)
    folders_with_files = sum(
        1 for source in selected_roots
        if source.is_dir() and any(item.is_file() or item.is_symlink() for item in source.rglob("*"))
    )
    return selected_roots, folders_with_files


def recording_listing(kind, target_id=""):
    choices = recording_target_choices(kind)
    selected = next((choice for choice in choices if choice["id"] == target_id), None)
    if selected is None:
        selected = next((choice for choice in choices if choice["active"]), choices[0])
    root = selected["path"]
    directories, files = [], []
    for item in root.rglob("*"):
        try:
            resolved = item.resolve(strict=True)
            if resolved != root and root not in resolved.parents:
                continue
            relative = item.relative_to(root).as_posix()
            stat = item.stat()
            parent_relative = item.parent.relative_to(root)
            parent_name = "" if parent_relative == pathlib.Path(".") else parent_relative.as_posix()
            if item.is_dir() and not item.is_symlink():
                directories.append({"path": relative, "name": item.name,
                                    "parent": parent_name})
            elif is_recording_file(kind, item):
                files.append({"path": relative, "name": item.name,
                              "parent": parent_name,
                              "size": stat.st_size, "modified": int(stat.st_mtime)})
        except (OSError, ValueError):
            continue
    directories.sort(key=lambda item: (item["parent"].lower(), item["name"].lower()))
    files.sort(key=lambda item: (-item["modified"], item["name"].lower()))
    public_targets = [{"id": choice["id"], "name": choice["name"],
                       "path": str(choice["path"]), "active": choice["active"]}
                      for choice in choices]
    return {"ok": True, "kind": kind, "root": str(root), "selected_target": selected["id"],
            "targets": public_targets, "directories": directories, "files": files,
            "updated": datetime.now().astimezone().isoformat()}


def cleanup_old_downloads():
    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    limit = time.time() - 3600
    for item in DOWNLOAD_DIR.glob("*.zip"):
        try:
            if item.stat().st_mtime < limit:
                item.unlink()
        except OSError:
            pass


def create_recording_zip(kind, relative_paths, folder_path="", target_id=""):
    root = recording_root(kind, target_id, strict=True)
    selected = []
    if folder_path:
        folder = safe_recording_path(root, folder_path)
        if not folder.is_dir():
            raise ValueError("Folder not found")
        selected = [item for item in folder.rglob("*") if is_recording_file(kind, item)]
        archive_label = folder.name
    else:
        if not isinstance(relative_paths, list) or not relative_paths:
            raise ValueError("No files selected")
        for relative in relative_paths:
            item = safe_recording_path(root, relative)
            if not is_recording_file(kind, item):
                raise ValueError("Only files can be selected")
            selected.append(item)
        archive_label = f"{kind}_recordings_{datetime.now().astimezone():%Y-%m-%d--%H-%M-%S}"
    cleanup_old_downloads()
    token = uuid.uuid4().hex
    archive = DOWNLOAD_DIR / f"{token}.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as output:
        used_names = set()
        for item in selected:
            if folder_path:
                member_name = item.relative_to(root).as_posix()
            else:
                # A ZIP created from individually selected files is flat. If
                # different directories contain an identical filename, retain
                # both using a stable numeric suffix instead of overwriting.
                member_name = item.name
                counter = 2
                while member_name.casefold() in used_names:
                    member_name = f"{item.stem}_{counter}{item.suffix}"
                    counter += 1
                used_names.add(member_name.casefold())
            output.write(item, member_name)
    return token, re.sub(r"[^A-Za-z0-9._-]+", "_", archive_label).strip("._") + ".zip"


def service_active(name):
    try:
        return subprocess.run(
            ["systemctl", "is-active", "--quiet", name], timeout=3
        ).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def navigation_status():
    return {
        "wurb": project_installed("wurb_2026"),
        "wirc": project_installed("wirc_2026"),
        "allsky": project_installed("allsky"),
        "wurb_active": service_active("wurb_2026.service"),
        "wirc_active": service_active("wirc_2026.service"),
        "witty": pathlib.Path("/usr/local/bin/wp5").is_file()
                 or pathlib.Path("/usr/bin/wp5").is_file(),
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "wittypi5-webserver/1.0"

    def send_response_headers(self, status=200, content_type="application/json; charset=utf-8"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_OPTIONS(self):
        self.send_response_headers(204)

    def send_json(self, payload, status=200):
        encoded = json.dumps(payload).encode()
        self.send_response_headers(status)
        self.wfile.write(encoded)

    def send_download(self, target, download_name, delete_after=False):
        completed = False
        try:
            self.send_response(200)
            self.send_header("Content-Type", mimetypes.guess_type(download_name)[0] or "application/octet-stream")
            ascii_name = re.sub(r"[^A-Za-z0-9._-]+", "_", download_name)
            self.send_header("Content-Disposition", f"attachment; filename=\"{ascii_name}\"; filename*=UTF-8''{quote(download_name)}")
            self.send_header("Content-Length", str(target.stat().st_size))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with target.open("rb") as source:
                shutil.copyfileobj(source, self.wfile, length=1024 * 1024)
            completed = True
        finally:
            if delete_after and completed:
                try:
                    target.unlink()
                except OSError:
                    pass

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        if path == "/api/navigation":
            self.send_response_headers()
            self.wfile.write(json.dumps(navigation_status()).encode())
            return
        if path == "/api/timezones":
            current_zone = subprocess.run(
                ["timedatectl", "show", "--property=Timezone", "--value"],
                capture_output=True, text=True, timeout=3
            ).stdout.strip() or "Etc/UTC"
            representatives = {}
            ordered_names = [current_zone] + sorted(available_timezones() - {current_zone})
            now = datetime.now()
            for name in ordered_names:
                try:
                    delta = now.replace(tzinfo=ZoneInfo(name)).utcoffset()
                    minutes = int(delta.total_seconds() // 60)
                    representatives.setdefault(minutes, name)
                except (ValueError, OSError):
                    continue
            zones = [{"minutes": value, "timezone": representatives[value]}
                     for value in sorted(representatives)]
            self.send_response_headers()
            self.wfile.write(json.dumps({"ok": True, "zones": zones,
                                         "current_timezone": current_zone}).encode())
            return
        if path == "/api/log-progress":
            log_dir = APP_DIR / "logs"
            candidates = [item for item in log_dir.glob("download/**/*.log") if item.is_file()]
            received = max((item.stat().st_size for item in candidates), default=0)
            self.send_response_headers()
            self.wfile.write(json.dumps({
                "ok": True,
                "active": (log_dir / ".log-download-active").is_file(),
                "received_bytes": received,
                "local_available": (log_dir / "WittyPi5.log").is_file()
                                   and (log_dir / "WittyPi5.log").stat().st_size > 0,
            }).encode())
            return
        if path == "/logs/WittyPi5.log":
            target = APP_DIR / "logs" / "WittyPi5.log"
            if not target.is_file():
                self.send_response_headers(404)
                self.wfile.write(b'{"ok":false,"error":"Log not found"}')
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Disposition", 'attachment; filename="WittyPi5.log"')
            self.send_header("Content-Length", str(target.stat().st_size))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with target.open("rb") as source:
                shutil.copyfileobj(source, self.wfile, length=64 * 1024)
            return
        if path == "/api/recordings":
            try:
                self.send_json(recording_listing(query.get("kind", [""])[0], query.get("target", [""])[0]))
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 400)
            return
        if path == "/recording-file":
            try:
                kind = query.get("kind", [""])[0]
                relative = query.get("path", [""])[0]
                root = recording_root(kind, query.get("target", [""])[0], strict=True)
                target = safe_recording_path(root, relative)
                if not is_recording_file(kind, target):
                    raise FileNotFoundError("Recording not found")
                self.send_download(target, target.name)
            except Exception as error:
                self.send_json({"ok": False, "error": str(error)}, 404)
            return
        if path == "/recording-zip":
            token = query.get("token", [""])[0]
            name = query.get("name", ["recordings.zip"])[0]
            if not re.fullmatch(r"[a-f0-9]{32}", token):
                self.send_json({"ok": False, "error": "Invalid download token"}, 400)
                return
            target = DOWNLOAD_DIR / f"{token}.zip"
            if not target.is_file():
                self.send_json({"ok": False, "error": "ZIP file not found"}, 404)
                return
            self.send_download(target, pathlib.Path(name).name, delete_after=True)
            return
        files = {
            "/": WEB_DIR / "index.html",
            "/index.html": WEB_DIR / "index.html",
            "/recordings/wurb": WEB_DIR / "recordings.html",
            "/recordings/wirc": WEB_DIR / "recordings.html",
            "/assets/bulma-v1.0.4.min.css": WEB_DIR / "assets" / "bulma-v1.0.4.min.css",
            "/assets/cloudedbats_logo.png": WEB_DIR / "assets" / "cloudedbats_logo.png",
        }
        target = files.get(path)
        if not target or not target.is_file():
            self.send_response_headers(404)
            self.wfile.write(b'{"ok":false,"error":"Not found"}')
            return
        mime = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response_headers(200, mime)
        self.wfile.write(target.read_bytes())

    def do_POST(self):
        request_path = urlparse(self.path).path
        if request_path == "/api/recording-upload":
            self.handle_recording_upload()
            return
        if request_path not in {"/api", "/api/recordings"}:
            self.send_response_headers(404); self.wfile.write(b'{"ok":false,"error":"Not found"}'); return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 2 or length > 8 * 1024 * 1024:
                raise ValueError("Invalid request size")
            request = json.loads(self.rfile.read(length))
            if request_path == "/api/recordings":
                self.handle_recording_action(request)
                return
            action = request.get("action", "")
            allowed = {
                "status", "system_to_witty", "witty_to_system", "manual_to_witty",
                "gps_to_system", "gps_to_witty", "clear_schedule", "read_schedule", "read_named_schedule",
                "upload_schedule", "read_log", "read_local_log", "delete_log", "shutdown", "internal_rtc_toggle",
                "service_start", "service_stop",
                "fixed_timezone",
                "schedule_list", "schedule_activate", "schedule_delete",
            }
            if action not in allowed:
                raise ValueError("Action not allowed")
            arguments = [str(BACKEND), action]
            if action == "manual_to_witty":
                arguments.append(str(request.get("value", "")))
            elif action == "upload_schedule":
                arguments.extend((str(request.get("filename", "")), str(request.get("content_base64", ""))))
            elif action in {"service_start", "service_stop"}:
                arguments.append(str(request.get("service", "")))
            elif action == "fixed_timezone":
                arguments.extend((str(bool(request.get("enabled", False))).lower(),
                                  str(request.get("timezone", "Etc/UTC"))))
            elif action in {"schedule_activate", "schedule_delete", "read_named_schedule"}:
                arguments.append(str(request.get("filename", "")))
            result = subprocess.run(arguments, capture_output=True, text=True, timeout=420)
            try:
                payload = json.loads(result.stdout or "{}")
            except json.JSONDecodeError:
                detail = (result.stderr or result.stdout or "").strip()[-2000:]
                payload = {"ok": False, "error": detail or "Backend lieferte keine gültige JSON-Antwort"}
            if not payload.get("ok") and not payload.get("error"):
                detail = (result.stderr or result.stdout or "").strip()[-2000:]
                payload["error"] = detail or f"Backend wurde mit Code {result.returncode} beendet"
            status = 200 if result.returncode == 0 and payload.get("ok") else 502
        except Exception as error:
            status, payload = 400, {"ok": False, "error": str(error)}
        self.send_response_headers(status)
        self.wfile.write(json.dumps(payload).encode())

    def handle_recording_upload(self):
        destination_file = None
        write_path = None
        created = False
        try:
            query = parse_qs(urlparse(self.path).query, keep_blank_values=True)
            kind = query.get("kind", [""])[0]
            target_id = query.get("target", [""])[0]
            folder_name = query.get("folder", [""])[0]
            filename = validate_upload_filename(kind, query.get("name", [""])[0])
            overwrite = query.get("overwrite", ["false"])[0].lower() == "true"
            root = recording_root(kind, target_id, strict=True)
            folder = safe_recording_path(root, folder_name)
            if not folder.is_dir() or folder.is_symlink():
                raise ValueError("Upload folder not found")
            destination_file = safe_recording_path(
                root, (folder / filename).relative_to(root).as_posix(), must_exist=False
            )
            if destination_file.exists() and (destination_file.is_symlink() or not destination_file.is_file()):
                raise ValueError("Upload destination is not a regular file")
            if destination_file.exists() and not overwrite:
                raise FileExistsError(filename)
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 1024 ** 4:
                raise ValueError("Invalid upload size")
            reclaimable = destination_file.stat().st_size if overwrite and destination_file.exists() else 0
            if shutil.disk_usage(folder).free + reclaimable < length + 16 * 1024 * 1024:
                raise OSError("Not enough free space for upload")
            remaining = length
            write_path = folder / f".{uuid.uuid4().hex}.recording-upload"
            with write_path.open("xb") as output:
                created = True
                while remaining:
                    chunk = self.rfile.read(min(1024 * 1024, remaining))
                    if not chunk:
                        raise ConnectionError("Upload was interrupted")
                    output.write(chunk)
                    remaining -= len(chunk)
                output.flush()
                os.fsync(output.fileno())
            write_path.chmod(0o644)
            if destination_file.exists() and not overwrite:
                raise FileExistsError(filename)
            os.replace(write_path, destination_file)
            created = False
            self.send_json({"ok": True, "name": filename, "size": length})
        except FileExistsError:
            self.send_json({"ok": False, "error": "A file with this name already exists"}, 409)
        except Exception as error:
            if created and write_path is not None:
                try:
                    write_path.unlink()
                except OSError:
                    pass
            self.send_json({"ok": False, "error": str(error)}, 400)

    def handle_recording_action(self, request):
        try:
            kind = str(request.get("kind", ""))
            action = str(request.get("action", ""))
            target_id = str(request.get("target", ""))
            root = recording_root(kind, target_id, strict=True)
            if action == "create_folder":
                name = str(request.get("name", "")).strip()
                if not re.fullmatch(r"[A-Za-z0-9ÄÖÜäöüß][A-Za-z0-9ÄÖÜäöüß ._-]{0,79}", name) or name in {".", ".."}:
                    raise ValueError("Invalid folder name")
                parent = safe_recording_path(root, str(request.get("parent", "")))
                if not parent.is_dir() or parent.is_symlink():
                    raise ValueError("Parent folder not found")
                target = safe_recording_path(root, (parent / name).relative_to(root).as_posix(), must_exist=False)
                target.mkdir(exist_ok=False)
                payload = {"ok": True}
            elif action == "upload_check":
                folder = safe_recording_path(root, str(request.get("folder", "")))
                if not folder.is_dir() or folder.is_symlink():
                    raise ValueError("Upload folder not found")
                names = request.get("names", [])
                if not isinstance(names, list) or not names:
                    raise ValueError("No files selected")
                checked = [validate_upload_filename(kind, name) for name in names]
                conflicts = [name for name in dict.fromkeys(checked) if (folder / name).exists()]
                payload = {"ok": True, "conflicts": conflicts}
            elif action == "delete_check":
                paths = request.get("paths", [])
                sources, folders_with_files = deletion_sources(root, kind, paths)
                payload = {"ok": True, "requires_confirmation": folders_with_files > 0,
                           "folders_with_files": folders_with_files, "items": len(sources)}
            elif action == "delete":
                sources, folders_with_files = deletion_sources(root, kind, request.get("paths", []))
                if folders_with_files and request.get("confirm_recursive") is not True:
                    raise ValueError("A selected folder contains files; confirmation is required")
                for source in sources:
                    if source.is_dir():
                        shutil.rmtree(source)
                    else:
                        source.unlink()
                payload = {"ok": True}
            elif action == "move":
                paths = request.get("paths", [])
                if not isinstance(paths, list) or not paths:
                    raise ValueError("No files or folders selected")
                destination = safe_recording_path(root, request.get("destination", ""))
                if not destination.is_dir() or destination.is_symlink():
                    raise ValueError("Destination folder not found")
                candidates = []
                for relative in dict.fromkeys(str(value) for value in paths):
                    source = safe_recording_path(root, relative)
                    if source == root or source.is_symlink() or not (source.is_dir() or is_recording_file(kind, source)):
                        raise ValueError(f"Can not move {source.name}")
                    candidates.append(source)
                candidates.sort(key=lambda item: len(item.parts))
                selected_roots = []
                for source in candidates:
                    if not any(parent in selected_roots for parent in source.parents):
                        selected_roots.append(source)
                sources, targets = [], set()
                for source in selected_roots:
                    if destination == source or source in destination.parents:
                        raise ValueError(f"Can not move {source.name} into itself")
                    target = destination / source.name
                    if target.exists() or target in targets:
                        raise ValueError(f"Can not move {source.name}")
                    targets.add(target)
                    sources.append((source, target))
                for source, target in sources:
                    shutil.move(str(source), str(target))
                payload = {"ok": True}
            elif action == "create_zip":
                token, name = create_recording_zip(kind, request.get("paths", []), str(request.get("folder", "")), target_id)
                payload = {"ok": True, "url": f"/recording-zip?token={token}&name={quote(name)}"}
            else:
                raise ValueError("Action not allowed")
            self.send_json(payload)
        except Exception as error:
            self.send_json({"ok": False, "error": str(error)}, 400)

    def log_message(self, fmt, *args):
        print("wittypi5-webserver:", fmt % args, flush=True)


if __name__ == "__main__":
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
