#!/usr/bin/env python3
import json
import mimetypes
import pathlib
import subprocess
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

APP_DIR = pathlib.Path(__file__).resolve().parent.parent
WEB_DIR = APP_DIR / "web"
BACKEND = APP_DIR / "backend" / "witty_backend.sh"
PORT = 8081


def unit_installed(name):
    return any((base / name).is_file() for base in map(pathlib.Path, (
        "/etc/systemd/system", "/usr/lib/systemd/system", "/lib/systemd/system"
    )))


def navigation_status():
    return {
        "wurb": unit_installed("wurb_2026.service"),
        "wirc": unit_installed("wirc_2026.service"),
        "allsky": unit_installed("allsky.service"),
        "witty": pathlib.Path("/usr/local/bin/wp5").is_file()
                 or pathlib.Path("/usr/bin/wp5").is_file(),
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "wittypi5-webserver/1.0"

    def headers(self, status=200, content_type="application/json; charset=utf-8"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.end_headers()

    def do_OPTIONS(self):
        self.headers(204)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/navigation":
            self.headers()
            self.wfile.write(json.dumps(navigation_status()).encode())
            return
        files = {
            "/": WEB_DIR / "index.html",
            "/index.html": WEB_DIR / "index.html",
            "/assets/bulma-v1.0.4.min.css": WEB_DIR / "assets" / "bulma-v1.0.4.min.css",
            "/assets/cloudedbats_logo.png": WEB_DIR / "assets" / "cloudedbats_logo.png",
        }
        target = files.get(path)
        if not target or not target.is_file():
            self.headers(404)
            self.wfile.write(b'{"ok":false,"error":"Not found"}')
            return
        mime = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.headers(200, mime)
        self.wfile.write(target.read_bytes())

    def do_POST(self):
        if urlparse(self.path).path != "/api":
            self.headers(404); self.wfile.write(b'{"ok":false,"error":"Not found"}'); return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 2 or length > 8 * 1024 * 1024:
                raise ValueError("Invalid request size")
            request = json.loads(self.rfile.read(length))
            action = request.get("action", "")
            allowed = {
                "status", "system_to_witty", "witty_to_system", "manual_to_witty",
                "gps_to_system", "gps_to_witty", "clear_schedule", "read_schedule",
                "upload_schedule", "read_log", "shutdown", "internal_rtc_toggle",
                "service_start", "service_stop",
            }
            if action not in allowed:
                raise ValueError("Action not allowed")
            arguments = [str(BACKEND), action]
            if action == "manual_to_witty":
                arguments.append(str(request.get("value", "")))
            elif action == "upload_schedule":
                arguments.extend((str(request.get("filename", "")), str(request.get("content_base64", ""))))
            elif action in {"service_start", "service_stop"}:
                arguments.append(str(request.get("service", "")))
            result = subprocess.run(arguments, capture_output=True, text=True, timeout=180)
            payload = json.loads(result.stdout or "{}")
            status = 200 if result.returncode == 0 and payload.get("ok") else 502
        except Exception as error:
            status, payload = 400, {"ok": False, "error": str(error)}
        self.headers(status)
        self.wfile.write(json.dumps(payload).encode())

    def log_message(self, fmt, *args):
        print("wittypi5-webserver:", fmt % args, flush=True)


if __name__ == "__main__":
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
