#!/usr/bin/env bash
set -Eeuo pipefail

# Ein-Befehl-Aktualisierung fuer das Witty-Addon.
readonly ADDON_URL="https://raw.githubusercontent.com/C4rstenSC/scripte/main/witty_addon.zip"

log() { printf '[witty-update] %s\n' "$*"; }
die() { printf '[witty-update] FEHLER: %s\n' "$*" >&2; exit 1; }

if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    die "Bitte mit sudo starten: sudo bash $0"
fi

for command_name in curl unzip; do
    command -v "$command_name" >/dev/null 2>&1 || die "Das Programm '$command_name' fehlt."
done

update_dir="$(mktemp -d /var/tmp/witty-addon-update.XXXXXX)"
cleanup() { rm -rf -- "$update_dir"; }
trap cleanup EXIT

archive_path="$update_dir/witty_addon.zip"
extract_path="$update_dir/extracted"
mkdir -p "$extract_path"

log "Lade die aktuelle Komplettversion von GitHub ..."
curl --fail --location --show-error --silent --retry 3 \
    --output "$archive_path" "$ADDON_URL"
unzip -tq "$archive_path" >/dev/null || die "Das ZIP-Archiv ist ungueltig."
unzip -q "$archive_path" -d "$extract_path"

installer="$extract_path/witty_addon/install_witty_addon.sh"
[[ -f "$installer" ]] || die "witty_addon/install_witty_addon.sh fehlt im Archiv."
chmod 0755 "$installer"

log "Installiere nur die Add-on-Dateien aus der neuen Version ..."
bash "$installer" "$archive_path"
log "Aktualisierung abgeschlossen."
