#!/usr/bin/python3
# -*- coding:utf-8 -*-
# Project: https://github.com/cloudedbats/wurb_2026
# Author: Arnold Andreasson, info@cloudedbats.org
# License: MIT License (see LICENSE or http://opensource.org/licenses/mit).

import logging
import pathlib
import fastapi
import fastapi.staticfiles
import fastapi.templating
import fastapi.responses
from pydantic import BaseModel
from typing import Optional

# CloudedBats WURB.
import wurb_core
import wurb_api

logger = logging.getLogger(wurb_core.logger_name)


def installed_services():
    """Return installed companion services without checking whether they run."""
    home_path = pathlib.Path("/home")
    home_directories = list(home_path.iterdir()) if home_path.is_dir() else []

    def exists_below_home(*names):
        wanted = {name.lower() for name in names}
        for parent in [home_path, *home_directories]:
            if parent.is_dir():
                for child in parent.iterdir():
                    if child.is_dir() and child.name.lower() in wanted:
                        return True
        return False

    return {
        "wurb": exists_below_home("wurb_2026"),
        "wirc": exists_below_home("wirc_2026"),
        "allsky": exists_below_home("allsky"),
        "witty": exists_below_home(
            "wittypi", "wittypi5", "witty-pi-5-software", "wp5"
        ),
    }

app = fastapi.FastAPI(
    title="CloudedBats WURB-2026",
    description="CloudedBats WURB-2026, the DIY bat detector.",
    version=wurb_core.__version__,
)

# Relative paths.
static_path = pathlib.Path(wurb_core.workdir_path, "wurb_app/static")
templates_path = pathlib.Path(wurb_core.workdir_path, "wurb_app/templates")

app.mount(
    "/static",
    fastapi.staticfiles.StaticFiles(directory=static_path),
    name="static",
)
templates = fastapi.templating.Jinja2Templates(directory=templates_path)


@app.on_event("startup")
async def startup_event():
    """ """
    logger.debug("API called: startup.")


@app.on_event("shutdown")
async def shutdown_event():
    """ """
    logger.debug("API called: shutdown.")


# Include modules.
app.include_router(wurb_api.record_router)
app.include_router(wurb_api.annotations_router)
app.include_router(wurb_api.admin_router)
app.include_router(wurb_api.about_router)


@app.get("/", tags=["HTML pages"], description="Main application page loaded as HTML.")
async def load_main_application_page(request: fastapi.Request):
    """ """
    try:
        logger.debug("API called: webpage.")
        services = installed_services()
        return templates.TemplateResponse(
            request=request,
            name="index.html",
            context={
                "wurb_version": wurb_core.__version__,
                "wirc_installed": services["wirc"],
                "allsky_installed": services["allsky"],
                "witty_installed": services["witty"],
            },
            # "index.html",
            # {
            #     "request": request,
            #     "wurb_version": wurb_core.__version__,
            # },
        )
    except Exception as e:
        message = "API - load_main_application_page. Exception: " + str(e)
        logger.debug(message)


@app.get("/navigation/services", include_in_schema=False)
async def get_installed_navigation_services():
    return installed_services()


@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    favicon_path = pathlib.Path(
        wurb_core.workdir_path, "wurb_app/static/images/favicon.ico"
    )
    return fastapi.responses.FileResponse(favicon_path)
