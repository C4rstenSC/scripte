#!/usr/bin/env bash
set -Eeuo pipefail

# Witty-Addon fuer Raspberry Pi OS Trixie 64-bit
# Quelle: https://github.com/C4rstenSC/scripte/blob/main/witty_addon.zip

readonly ADDON_URL="https://raw.githubusercontent.com/C4rstenSC/scripte/main/witty_addon.zip"
readonly ARCHIVE_NAME="witty_addon.zip"
readonly ADDON_DIR_NAME="witty_addon"

log() { printf '[witty-addon] %s\n' "$*"; }
die() { printf '[witty-addon] FEHLER: %s\n' "$*" >&2; exit 1; }

if [[ "${EUID:-$(id -u)}" -ne 0 ]]; then
    die "Bitte mit sudo starten: sudo bash $0"
fi

for command_name in curl unzip install find systemctl stat flock timeout base64; do
    command -v "$command_name" >/dev/null 2>&1 || \
        die "Das benoetigte Programm '$command_name' fehlt."
done

work_dir="$(mktemp -d /var/tmp/witty-addon.XXXXXX)"
cleanup() { rm -rf -- "$work_dir"; }
trap cleanup EXIT

archive_path="$work_dir/$ARCHIVE_NAME"
extract_path="$work_dir/extracted"
mkdir -p "$extract_path"

if [[ -n "${1:-}" ]]; then
    [[ -f "$1" ]] || die "Lokales Archiv nicht gefunden: $1"
    log "Verwende lokales Archiv $1 ..."
    cp -- "$1" "$archive_path"
else
    log "Lade $ARCHIVE_NAME herunter ..."
    curl --fail --location --show-error --silent \
        --retry 3 --output "$archive_path" "$ADDON_URL"
fi

unzip -tq "$archive_path" >/dev/null || die "Das heruntergeladene ZIP-Archiv ist ungueltig."
unzip -q "$archive_path" -d "$extract_path"
source_dir="$extract_path/$ADDON_DIR_NAME"
[[ -d "$source_dir" ]] || \
    die "Der erwartete Ordner '$ADDON_DIR_NAME' fehlt im ZIP-Archiv."

backup_root="/var/backups/witty-addon/$(date +%Y%m%d-%H%M%S)"
installed_count=0

backup_and_install() {
    local source_file="$1"
    local target_file="$2"
    local relative_target="${target_file#/}"
    local owner_reference
    local target_uid
    local target_gid

    [[ -f "$source_file" ]] || die "Quelldatei fehlt: $source_file"
    if [[ -e "$target_file" ]]; then
        mkdir -p "$backup_root/$(dirname "$relative_target")"
        cp -a -- "$target_file" "$backup_root/$relative_target"
        owner_reference="$target_file"
    else
        owner_reference="$(dirname "$target_file")"
    fi
    target_uid="$(stat -c '%u' "$owner_reference")"
    target_gid="$(stat -c '%g' "$owner_reference")"
    install -D -m 0644 -o "$target_uid" -g "$target_gid" -- \
        "$source_file" "$target_file"
}

install_wurb() {
    local home_dir="$1"
    log "Installiere Erweiterung fuer WURB-2026 in $home_dir ..."
    backup_and_install "$source_dir/wurb_2026/wurb_api/main.py" \
        "$home_dir/wurb_api/main.py"
    backup_and_install "$source_dir/wurb_2026/wurb_app/templates/index.html" \
        "$home_dir/wurb_app/templates/index.html"
    backup_and_install "$source_dir/wurb_2026/wurb_app/static/witty.html" \
        "$home_dir/wurb_app/static/witty.html"
    installed_count=$((installed_count + 1))
    systemctl try-restart wurb_2026.service 2>/dev/null || true
}

install_wirc() {
    local home_dir="$1"
    log "Installiere Erweiterung fuer WIRC-2026 in $home_dir ..."
    backup_and_install "$source_dir/wirc_2026/wirc_api/api_main.py" \
        "$home_dir/wirc_api/api_main.py"
    backup_and_install "$source_dir/wirc_2026/wirc_app/templates/index.html" \
        "$home_dir/wirc_app/templates/index.html"
    backup_and_install "$source_dir/wirc_2026/wirc_app/static/witty.html" \
        "$home_dir/wirc_app/static/witty.html"
    installed_count=$((installed_count + 1))
    systemctl try-restart wirc_2026.service 2>/dev/null || true
}

install_allsky() {
    local home_dir="$1"
    log "Installiere Erweiterung fuer Allsky in $home_dir ..."
    backup_and_install "$source_dir/allsky/html/index.php" \
        "$home_dir/html/index.php"
    backup_and_install "$source_dir/allsky/html/witty.html" \
        "$home_dir/html/witty.html"
    backup_and_install "$source_dir/allsky/html/witty-services.php" \
        "$home_dir/html/witty-services.php"
    backup_and_install "$source_dir/allsky/html/witty-api.php" \
        "$home_dir/html/witty-api.php"
    installed_count=$((installed_count + 1))
}

find_project_dir() {
    local project_name="$1"
    local candidate
    for candidate in \
        "/home/wurb/$project_name" \
        "/home/pi/$project_name" \
        "/opt/$project_name"; do
        [[ -d "$candidate" ]] && { printf '%s\n' "$candidate"; return 0; }
    done
    find /home -mindepth 2 -maxdepth 3 -type d -name "$project_name" \
        -print -quit 2>/dev/null
}

wurb_home="$(find_project_dir wurb_2026 || true)"
wirc_home="$(find_project_dir wirc_2026 || true)"

[[ -n "$wurb_home" ]] && install_wurb "$wurb_home"
[[ -n "$wirc_home" ]] && install_wirc "$wirc_home"

allsky_home=""
for candidate in /home/pi/allsky /home/allsky/allsky /opt/allsky; do
    if [[ -d "$candidate/html" && -f "$candidate/variables.sh" ]]; then
        allsky_home="$candidate"
        break
    fi
done
if [[ -z "$allsky_home" ]]; then
    allsky_home="$(find /home -mindepth 2 -maxdepth 3 -type f \
        -name variables.sh -path '*/allsky/variables.sh' -printf '%h\n' \
        -quit 2>/dev/null || true)"
fi
[[ -n "$allsky_home" ]] && install_allsky "$allsky_home"

log "Installiere den Witty-Hintergrundadapter ..."
install -D -m 0755 "$source_dir/witty/witty_backend.sh" \
    /usr/local/lib/witty-addon/witty_backend.sh
install -D -m 0440 "$source_dir/witty/witty-addon-sudoers" \
    /etc/sudoers.d/witty-addon
if command -v visudo >/dev/null 2>&1; then
    visudo -cf /etc/sudoers.d/witty-addon >/dev/null || \
        die "Die Witty-sudoers-Datei ist ungueltig"
fi

(( installed_count > 0 )) || \
    die "Keine Installation von WURB-2026, WIRC-2026 oder Allsky gefunden."

if [[ -n "$allsky_home" ]]; then
    systemctl reload lighttpd.service 2>/dev/null || \
        systemctl restart lighttpd.service 2>/dev/null || true
fi

log "$installed_count installierte Komponente(n) aktualisiert."
if [[ -d "$backup_root" ]]; then
    log "Sicherung der ersetzten Dateien: $backup_root"
fi
log "Installation abgeschlossen."
